import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import multer from 'multer';
import { fileURLToPath } from 'url';
import crypto from 'crypto';
import { spawn } from 'child_process';
import { sequelize, User, Patient, Company, Product, IysSetting, IysConsentLog } from './src/database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT || 3001);
const HOST = process.env.HOST || '0.0.0.0';
const readLocalVersion = () => {
    try {
        const versionFile = path.join(__dirname, 'pharmalog_version.json');
        if (!fs.existsSync(versionFile)) return '1.0.0';
        const payload = JSON.parse(fs.readFileSync(versionFile, 'utf8'));
        return payload?.version || '1.0.0';
    } catch (error) {
        return '1.0.0';
    }
};
const getCurrentAppVersion = () => process.env.PHARMALOG_VERSION || readLocalVersion();
const UPDATE_MANIFEST_URL = process.env.PHARMALOG_UPDATE_MANIFEST_URL || 'https://www.pharmalog.com.tr/updates/manifest.json';
const UPDATE_DOWNLOAD_HOSTS = new Set(['www.pharmalog.com.tr', 'pharmalog.com.tr']);

// Global Error Handlers
process.on('uncaughtException', (err) => {
    console.error('UNCAUGHT EXCEPTION:', err);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('UNHANDLED REJECTION:', reason);
});

// Simple In-Memory Token Store
const ACTIVE_TOKENS = {};
const DEFAULT_SESSION_TTL_MS = 12 * 60 * 60 * 1000; // 12h
const MIN_SESSION_TTL_MS = 5 * 60 * 1000; // 5m
const MAX_SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30d
const rawSessionTtl = process.env.SESSION_TTL_MS;
const parsedSessionTtl = Number(rawSessionTtl);
const hasCustomSessionTtl = rawSessionTtl !== undefined;
const isValidSessionTtl = Number.isFinite(parsedSessionTtl)
    && parsedSessionTtl >= MIN_SESSION_TTL_MS
    && parsedSessionTtl <= MAX_SESSION_TTL_MS;

if (hasCustomSessionTtl && !isValidSessionTtl) {
    console.warn(
        `Invalid SESSION_TTL_MS='${rawSessionTtl}'. Using default ${DEFAULT_SESSION_TTL_MS}ms. ` +
        `Allowed range: ${MIN_SESSION_TTL_MS}-${MAX_SESSION_TTL_MS}ms.`
    );
}

const SESSION_TTL_MS = isValidSessionTtl ? parsedSessionTtl : DEFAULT_SESSION_TTL_MS;

const cleanupExpiredTokens = () => {
    const now = Date.now();
    for (const [token, session] of Object.entries(ACTIVE_TOKENS)) {
        if (!session || typeof session !== 'object') {
            delete ACTIVE_TOKENS[token];
            continue;
        }
        if (typeof session.expiresAt !== 'number' || session.expiresAt <= now) {
            delete ACTIVE_TOKENS[token];
        }
    }
};

const createTokenSession = (userId) => ({
    userId,
    expiresAt: Date.now() + SESSION_TTL_MS
});

const revokeUserTokens = (userId) => {
    for (const [token, session] of Object.entries(ACTIVE_TOKENS)) {
        if (session?.userId === userId) {
            delete ACTIVE_TOKENS[token];
        }
    }
};

const clearAllTokens = () => {
    for (const token of Object.keys(ACTIVE_TOKENS)) {
        delete ACTIVE_TOKENS[token];
    }
};

const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) {
    fs.mkdirSync(UPLOAD_DIR);
}

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

const upload = multer({ dest: 'uploads/' });

const PASSWORD_PREFIX = 'scrypt$';

const isPasswordHashed = (value) => {
    return typeof value === 'string' && value.startsWith(PASSWORD_PREFIX);
};

const hashPassword = (plainText) => {
    const safeText = String(plainText ?? '');
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = crypto.scryptSync(safeText, salt, 64).toString('hex');
    return `${PASSWORD_PREFIX}${salt}$${hash}`;
};

const verifyPassword = (plainText, storedPassword) => {
    if (typeof storedPassword !== 'string') return false;
    const safeText = String(plainText ?? '');

    if (!isPasswordHashed(storedPassword)) {
        return storedPassword === safeText;
    }

    const parts = storedPassword.split('$');
    if (parts.length !== 3) return false;

    const salt = parts[1];
    const originalHashHex = parts[2];
    const calculatedHashHex = crypto.scryptSync(safeText, salt, 64).toString('hex');
    const originalHash = Buffer.from(originalHashHex, 'hex');
    const calculatedHash = Buffer.from(calculatedHashHex, 'hex');

    if (originalHash.length !== calculatedHash.length) return false;
    return crypto.timingSafeEqual(originalHash, calculatedHash);
};

// --- DB INITIALIZATION ---
sequelize.sync().then(async () => {
    console.log('SQLite Database Synced (Strict Mode)');
}).catch(err => {
    console.error('Failed to sync database:', err);
});

const isSuperAdminUser = (req) => req?.user?.role === 'super-admin';
const canManageProducts = (req) => ['super-admin', 'admin'].includes(req?.user?.role);
const canRestoreUser = (req) => ['super-admin', 'admin'].includes(req?.user?.role);
const canManageUsers = (req) => ['super-admin', 'admin', 'manager'].includes(req?.user?.role);
const isManagerUser = (req) => req?.user?.role === 'manager';
const canViewAllGroups = (req) => ['super-admin', 'admin'].includes(req?.user?.role);

const compareVersions = (a, b) => {
    const left = String(a || '0').split('.').map(n => Number.parseInt(n, 10) || 0);
    const right = String(b || '0').split('.').map(n => Number.parseInt(n, 10) || 0);
    const max = Math.max(left.length, right.length);
    for (let i = 0; i < max; i++) {
        const diff = (left[i] || 0) - (right[i] || 0);
        if (diff !== 0) return diff;
    }
    return 0;
};

const quotePowerShellLiteral = (value) => `'${String(value).replace(/'/g, "''")}'`;

const assertSafeUpdateUrl = (url) => {
    const parsed = new URL(url);
    if (parsed.protocol !== 'https:') {
        throw new Error('Güncelleme adresi HTTPS olmalıdır.');
    }
    if (!UPDATE_DOWNLOAD_HOSTS.has(parsed.hostname)) {
        throw new Error('Güncelleme adresi güvenilir PharmaLog alan adında değil.');
    }
    if (!parsed.pathname.toLowerCase().endsWith('.zip')) {
        throw new Error('Güncelleme paketi zip dosyası olmalıdır.');
    }
    return parsed;
};

const writeUpdateApplyScript = ({ packagePath, version }) => {
    const scriptPath = path.join(osTmpDir(), `pharmalog_apply_update_${Date.now()}.ps1`);
    const rootPath = __dirname;
    const logPath = path.join(rootPath, 'pharmalog_update.log');
    const restartTarget = path.join(rootPath, 'ana_bilgisayar_gizli_baslat.vbs');
    const safeVersion = String(version || 'unknown').replace(/[^0-9A-Za-z._-]/g, '_');
    const backupDir = path.join(rootPath, `update_backup_${safeVersion}_${Date.now()}`);

    const script = `
$ErrorActionPreference = "Stop"
$Root = ${quotePowerShellLiteral(rootPath)}
$Package = ${quotePowerShellLiteral(packagePath)}
$BackupDir = ${quotePowerShellLiteral(backupDir)}
$Log = ${quotePowerShellLiteral(logPath)}
$RestartTarget = ${quotePowerShellLiteral(restartTarget)}
$ExtractDir = Join-Path $env:TEMP ("pharmalog_update_extract_" + [guid]::NewGuid().ToString())

function Log($Message) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $Message"
    Add-Content -Path $Log -Value $line -Encoding UTF8
}

Start-Sleep -Seconds 3
Log "Guncelleme basladi. Paket: $Package"

New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
foreach ($item in @("database.sqlite", "uploads")) {
    $source = Join-Path $Root $item
    if (Test-Path -LiteralPath $source) {
        Copy-Item -LiteralPath $source -Destination (Join-Path $BackupDir $item) -Recurse -Force
        Log "Yedeklendi: $item"
    }
}

if (Test-Path -LiteralPath $ExtractDir) {
    Remove-Item -LiteralPath $ExtractDir -Recurse -Force
}
New-Item -ItemType Directory -Path $ExtractDir -Force | Out-Null
Expand-Archive -LiteralPath $Package -DestinationPath $ExtractDir -Force

$Protected = @(
    "database.sqlite",
    "uploads",
    "node_modules",
    "local_server.out.log",
    "local_server.err.log",
    "pharmalog_server.pid",
    "pharmalog_update.log"
)

Get-ChildItem -LiteralPath $ExtractDir -Force | ForEach-Object {
    if ($Protected -contains $_.Name) {
        Log "Korundu, kopyalanmadi: $($_.Name)"
        return
    }
    $destination = Join-Path $Root $_.Name
    Copy-Item -LiteralPath $_.FullName -Destination $destination -Recurse -Force
    Log "Guncellendi: $($_.Name)"
}

Remove-Item -LiteralPath $ExtractDir -Recurse -Force
Log "Guncelleme tamamlandi. Program yeniden baslatiliyor."

if (Test-Path -LiteralPath $RestartTarget) {
    Start-Process -FilePath "wscript.exe" -ArgumentList @($RestartTarget) -WindowStyle Hidden
} else {
    Start-Process -FilePath "cmd.exe" -ArgumentList @("/c", "start", "", "http://localhost:3001") -WindowStyle Hidden
}
`;

    fs.writeFileSync(scriptPath, script, 'utf8');
    return scriptPath;
};

const osTmpDir = () => process.env.TEMP || process.env.TMP || __dirname;

// --- AUTH MIDDLEWARE (STRICT ID-BASED) ---
const authenticate = async (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ error: "Giriş yapmanız gerekiyor." });

    const token = authHeader.split(' ')[1];
    cleanupExpiredTokens();
    const session = ACTIVE_TOKENS[token];
    const userId = session?.userId;

    if (!userId) {
        return res.status(401).json({ error: "Oturum süresi dolmuş." });
    }

    try {
        const user = await User.findByPk(userId);

        if (!user) {
            delete ACTIVE_TOKENS[token];
            return res.status(401).json({ error: "Kullanıcı bulunamadı." });
        }

        req.user = user;
        req.id = user.id;
        req.username = user.username;
        req.group = user.group;
        req.pharmacyName = user.pharmacyName;
        req.token = token;

        // Sliding expiration: extend session on activity.
        ACTIVE_TOKENS[token].expiresAt = Date.now() + SESSION_TTL_MS;

        next();
    } catch (error) {
        console.error("Auth error:", error);
        res.status(500).json({ error: "Yetkilendirme hatası." });
    }
};

// --- AUTH ENDPOINTS ---
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        cleanupExpiredTokens();
        const user = await User.findOne({ where: { username: username } });

        if (user && verifyPassword(password, user.password)) {
            // Automatic migration for legacy plaintext records.
            if (!isPasswordHashed(user.password)) {
                user.password = hashPassword(password);
                await user.save();
            }

            const token = crypto.randomUUID();
            ACTIVE_TOKENS[token] = createTokenSession(user.id);
            res.json({
                success: true,
                token,
                expiresInMs: SESSION_TTL_MS,
                user: {
                    id: user.id,
                    username,
                    name: user.name,
                    role: user.role,
                    pharmacyName: user.pharmacyName
                }
            });
        } else {
            res.status(401).json({ error: "Hatalı kullanıcı adı veya şifre." });
        }
    } catch (error) {
        res.status(500).json({ error: "Giriş hatası." });
    }
});

app.post('/api/logout', (req, res) => {
    const authHeader = req.headers.authorization;
    if (authHeader) {
        const token = authHeader.split(' ')[1];
        delete ACTIVE_TOKENS[token];
    }
    res.json({ success: true });
});

app.get('/api/check-auth', authenticate, (req, res) => {
    res.json({
        success: true,
        user: {
            id: req.user.id,
            username: req.user.username,
            name: req.user.name,
            pharmacyName: req.user.pharmacyName,
            role: req.user.role
        }
    });
});

app.get('/api/update/check', authenticate, async (req, res) => {
    try {
        const response = await fetch(UPDATE_MANIFEST_URL, { cache: 'no-store' });
        if (!response.ok) {
            return res.status(502).json({ error: "Güncelleme bilgisi alınamadı." });
        }

        const manifest = await response.json();
        const currentVersion = getCurrentAppVersion();
        const latestVersion = manifest?.version || currentVersion;
        const hasUpdate = compareVersions(latestVersion, currentVersion) > 0;

        res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
        res.setHeader('Pragma', 'no-cache');
        res.setHeader('Expires', '0');
        res.json({
            success: true,
            currentVersion,
            latestVersion,
            hasUpdate,
            title: manifest?.title || `PharmaLog ${latestVersion}`,
            notes: Array.isArray(manifest?.notes) ? manifest.notes : [],
            packageUrl: manifest?.packageUrl || null,
            installerUrl: manifest?.installerUrl || manifest?.packageUrl || null,
            publishedAt: manifest?.publishedAt || null,
            mandatory: Boolean(manifest?.mandatory)
        });
    } catch (error) {
        console.error("Update check error:", error);
        res.status(500).json({ error: "Güncelleme kontrolü yapılamadı." });
    }
});

app.post('/api/update/apply', authenticate, async (req, res) => {
    if (!['super-admin', 'admin', 'manager'].includes(req.user.role)) {
        return res.status(403).json({ error: 'Güncelleme yapma yetkiniz yok.' });
    }

    try {
        const { packageUrl, version } = req.body || {};
        if (!packageUrl) {
            return res.status(400).json({ error: 'Güncelleme indirme adresi bulunamadı.' });
        }

        const parsedUrl = assertSafeUpdateUrl(packageUrl);
        const targetVersion = String(version || '').trim();
        const currentVersion = getCurrentAppVersion();
        if (targetVersion && compareVersions(targetVersion, currentVersion) <= 0) {
            return res.status(400).json({ error: 'Bu sürüm zaten yüklü veya daha eski.' });
        }

        const updatesDir = path.join(osTmpDir(), 'pharmalog_updates');
        fs.mkdirSync(updatesDir, { recursive: true });
        const safeName = path.basename(parsedUrl.pathname).replace(/[^0-9A-Za-z._-]/g, '_') || `pharmalog-${Date.now()}.zip`;
        const packagePath = path.join(updatesDir, safeName);

        const downloadResponse = await fetch(parsedUrl.href, { cache: 'no-store' });
        if (!downloadResponse.ok) {
            return res.status(502).json({ error: 'Güncelleme paketi indirilemedi.' });
        }

        const packageBytes = Buffer.from(await downloadResponse.arrayBuffer());
        if (packageBytes.length < 1024) {
            return res.status(502).json({ error: 'Güncelleme paketi geçersiz görünüyor.' });
        }
        fs.writeFileSync(packagePath, packageBytes);

        const scriptPath = writeUpdateApplyScript({
            packagePath,
            version: targetVersion || 'manual'
        });

        const updater = spawn('powershell.exe', [
            '-NoProfile',
            '-ExecutionPolicy',
            'Bypass',
            '-File',
            scriptPath
        ], {
            cwd: __dirname,
            detached: true,
            stdio: 'ignore',
            windowsHide: true
        });
        updater.unref();

        res.json({
            success: true,
            message: 'Güncelleme indirildi. Program birkaç saniye içinde kapanıp yeniden açılacak.',
            version: targetVersion || null
        });

        setTimeout(() => {
            process.exit(0);
        }, 1200);
    } catch (error) {
        console.error('Update apply error:', error);
        res.status(500).json({ error: error.message || 'Güncelleme uygulanamadı.' });
    }
});

app.post('/api/change-password', authenticate, async (req, res) => {
    const { currentPassword, newPassword } = req.body || {};

    if (!currentPassword || !newPassword) {
        return res.status(400).json({ error: "Mevcut sifre ve yeni sifre zorunludur." });
    }
    if (String(newPassword).trim().length < 6) {
        return res.status(400).json({ error: "Yeni sifre en az 6 karakter olmalidir." });
    }

    try {
        const user = await User.findByPk(req.user.id);
        if (!user) return res.status(404).json({ error: "Kullanici bulunamadi." });

        if (!verifyPassword(currentPassword, user.password)) {
            return res.status(400).json({ error: "Mevcut sifre hatali." });
        }

        if (verifyPassword(newPassword, user.password)) {
            return res.status(400).json({ error: "Yeni sifre mevcut sifre ile ayni olamaz." });
        }

        user.password = hashPassword(newPassword);
        await user.save();
        revokeUserTokens(user.id);

        res.json({ success: true });
    } catch (e) {
        console.error("Change Password Error:", e);
        res.status(500).json({ error: "Sifre degistirilemedi." });
    }
});

// --- PUBLIC PUBLIC ENDPOINTS (No Auth Required) ---

app.post('/api/update-profile', authenticate, async (req, res) => {
    const { name, password, pharmacyName } = req.body;
    try {
        const user = await User.findByPk(req.user.id);
        if (!user) return res.status(404).json({ error: "Kullanıcı bulunamadı." });

        if (name) user.name = name;
        if (password && password.trim().length > 0) {
            return res.status(400).json({ error: "Sifre degisikligi icin guvenlik ekranini kullanin." });
        }
        if (pharmacyName !== undefined) user.pharmacyName = pharmacyName;

        await user.save();
        res.json({ success: true });
    } catch (e) {
        console.error("Profile Update Error:", e);
        res.status(500).json({ error: "Güncelleme başarısız." });
    }
});

const IYS_ALLOWED_TYPES = new Set(['MESAJ', 'ARAMA', 'EPOSTA']);
const IYS_ALLOWED_STATUSES = new Set(['ONAY', 'RET']);
const IYS_ALLOWED_SOURCES = new Set([
    'HS_FIZIKSEL_ORTAM',
    'HS_WEB',
    'HS_MESAJ',
    'HS_EPOSTA',
    'HS_CAGRI_MERKEZI'
]);
const IYS_ALLOWED_RECIPIENT_TYPES = new Set(['BIREYSEL', 'TACIR']);
const VERIMOR_IYS_ENDPOINT = process.env.VERIMOR_IYS_ENDPOINT || 'https://sms.verimor.com.tr/v2/iys_consents.json';

const normalizeIysText = (value) => String(value || '').trim().toUpperCase();

const normalizePhoneForIys = (phone) => {
    const digits = String(phone || '').replace(/\D/g, '');
    if (!digits) return '';
    if (digits.length === 10 && digits.startsWith('5')) return `90${digits}`;
    if (digits.length === 11 && digits.startsWith('0')) return `9${digits}`;
    if (digits.length === 12 && digits.startsWith('90')) return digits;
    return digits;
};

const formatIysConsentDate = (value = new Date()) => {
    const date = value instanceof Date ? value : new Date(value);
    const safeDate = Number.isNaN(date.getTime()) ? new Date() : date;
    const pad = (number) => String(number).padStart(2, '0');
    return [
        safeDate.getFullYear(),
        pad(safeDate.getMonth() + 1),
        pad(safeDate.getDate())
    ].join('-') + ' ' + [
        pad(safeDate.getHours()),
        pad(safeDate.getMinutes()),
        pad(safeDate.getSeconds())
    ].join(':');
};

const getIysOwnerUserId = async (req) => {
    const groupAdmin = await User.findOne({
        where: { group: req.group, role: ['admin', 'super-admin'] },
        order: [['id', 'ASC']]
    });
    return groupAdmin?.id || req.user.id;
};

const sanitizeIysSetting = (setting) => {
    if (!setting) {
        return {
            enabled: false,
            provider: 'verimor',
            verimorUsername: '',
            hasVerimorPassword: false,
            sourceAddr: '',
            defaultSource: 'HS_FIZIKSEL_ORTAM',
            defaultRecipientType: 'BIREYSEL'
        };
    }

    return {
        enabled: Boolean(setting.enabled),
        provider: setting.provider || 'verimor',
        verimorUsername: setting.verimorUsername || '',
        hasVerimorPassword: Boolean(setting.verimorPassword),
        sourceAddr: setting.sourceAddr || '',
        defaultSource: setting.defaultSource || 'HS_FIZIKSEL_ORTAM',
        defaultRecipientType: setting.defaultRecipientType || 'BIREYSEL'
    };
};

const sendVerimorIysConsent = async (payload) => {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 20000);

    try {
        const response = await fetch(VERIMOR_IYS_ENDPOINT, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify(payload),
            signal: controller.signal
        });

        const text = await response.text();
        let body = text;
        try {
            body = text ? JSON.parse(text) : {};
        } catch (error) {
            body = { raw: text };
        }

        if (!response.ok) {
            const error = new Error('Verimor IYS API error');
            error.status = response.status;
            error.body = body;
            throw error;
        }

        return {
            status: response.status,
            body
        };
    } finally {
        clearTimeout(timeout);
    }
};

app.get('/api/iys/settings', authenticate, async (req, res) => {
    try {
        const ownerUserId = await getIysOwnerUserId(req);
        const setting = await IysSetting.findOne({ where: { UserId: ownerUserId } });
        res.json({ success: true, settings: sanitizeIysSetting(setting) });
    } catch (error) {
        console.error('IYS settings read error:', error);
        res.status(500).json({ error: 'İYS ayarları okunamadı.' });
    }
});

app.put('/api/iys/settings', authenticate, async (req, res) => {
    if (!['super-admin', 'admin', 'manager'].includes(req.user.role)) {
        return res.status(403).json({ error: 'İYS ayarlarını değiştirme yetkiniz yok.' });
    }

    try {
        const ownerUserId = await getIysOwnerUserId(req);
        const {
            enabled,
            verimorUsername,
            verimorPassword,
            sourceAddr,
            defaultSource,
            defaultRecipientType
        } = req.body || {};

        const cleanDefaultSource = normalizeIysText(defaultSource || 'HS_FIZIKSEL_ORTAM');
        const cleanRecipientType = normalizeIysText(defaultRecipientType || 'BIREYSEL');

        if (!IYS_ALLOWED_SOURCES.has(cleanDefaultSource)) {
            return res.status(400).json({ error: 'Geçersiz İYS izin kaynağı.' });
        }

        if (!IYS_ALLOWED_RECIPIENT_TYPES.has(cleanRecipientType)) {
            return res.status(400).json({ error: 'Geçersiz alıcı tipi.' });
        }

        const existing = await IysSetting.findOne({ where: { UserId: ownerUserId } });
        const nextPassword = typeof verimorPassword === 'string' && verimorPassword.trim()
            ? verimorPassword.trim()
            : existing?.verimorPassword || null;

        const settingPayload = {
            provider: 'verimor',
            enabled: Boolean(enabled),
            verimorUsername: String(verimorUsername || '').trim(),
            verimorPassword: nextPassword,
            sourceAddr: String(sourceAddr || '').trim(),
            defaultSource: cleanDefaultSource,
            defaultRecipientType: cleanRecipientType
        };

        const setting = existing
            ? await existing.update(settingPayload)
            : await IysSetting.create({ ...settingPayload, UserId: ownerUserId });

        res.json({ success: true, settings: sanitizeIysSetting(setting) });
    } catch (error) {
        console.error('IYS settings save error:', error);
        res.status(500).json({ error: 'İYS ayarları kaydedilemedi.' });
    }
});

app.post('/api/iys/consents', authenticate, async (req, res) => {
    try {
        const ownerUserId = await getIysOwnerUserId(req);
        const setting = await IysSetting.findOne({ where: { UserId: ownerUserId } });

        if (!setting?.enabled) {
            return res.status(400).json({ error: 'İYS entegrasyonu aktif değil. Lütfen Ayarlar menüsünden etkinleştirin.' });
        }

        if (!setting.verimorUsername || !setting.verimorPassword || !setting.sourceAddr) {
            return res.status(400).json({ error: 'Verimor kullanıcı adı, API şifresi veya SMS başlığı eksik.' });
        }

        const type = normalizeIysText(req.body?.type || 'MESAJ');
        const status = normalizeIysText(req.body?.status || 'ONAY');
        const source = normalizeIysText(req.body?.source || setting.defaultSource || 'HS_FIZIKSEL_ORTAM');
        const recipientType = normalizeIysText(req.body?.recipientType || setting.defaultRecipientType || 'BIREYSEL');
        const patientId = req.body?.patientId ? String(req.body.patientId) : null;
        const rawRecipient = type === 'EPOSTA' ? String(req.body?.recipient || req.body?.email || '').trim() : normalizePhoneForIys(req.body?.recipient || req.body?.phone);

        if (!IYS_ALLOWED_TYPES.has(type)) return res.status(400).json({ error: 'Geçersiz izin tipi.' });
        if (!IYS_ALLOWED_STATUSES.has(status)) return res.status(400).json({ error: 'Geçersiz izin durumu.' });
        if (!IYS_ALLOWED_SOURCES.has(source)) return res.status(400).json({ error: 'Geçersiz izin kaynağı.' });
        if (!IYS_ALLOWED_RECIPIENT_TYPES.has(recipientType)) return res.status(400).json({ error: 'Geçersiz alıcı tipi.' });
        if (!rawRecipient) return res.status(400).json({ error: 'Alıcı telefon/e-posta bilgisi zorunludur.' });

        if (patientId) {
            const patient = await Patient.findByPk(patientId);
            const canAccess = patient ? await isOwnerInRequesterGroup(req, patient.UserId) : false;
            if (!canAccess) return res.status(403).json({ error: 'Bu danışan için İYS işlemi yapma yetkiniz yok.' });
        }

        const consentDate = req.body?.consentDate ? new Date(req.body.consentDate) : new Date();
        const consent = {
            type,
            source,
            status,
            recipient_type: recipientType,
            consent_date: formatIysConsentDate(consentDate),
            recipient: rawRecipient
        };

        const payload = {
            username: setting.verimorUsername,
            password: setting.verimorPassword,
            source_addr: setting.sourceAddr,
            consents: [consent]
        };

        const log = await IysConsentLog.create({
            UserId: req.user.id,
            patientId,
            recipient: rawRecipient,
            type,
            status,
            source,
            recipientType,
            consentDate,
            requestStatus: 'PENDING',
            requestPayload: { ...payload, password: '***' }
        });

        try {
            const verimorResult = await sendVerimorIysConsent(payload);
            log.requestStatus = 'SUCCESS';
            log.responsePayload = verimorResult;
            await log.save();

            res.json({
                success: true,
                message: 'İYS izni Verimor üzerinden gönderildi.',
                logId: log.id,
                response: verimorResult.body
            });
        } catch (error) {
            log.requestStatus = 'FAILED';
            log.errorMessage = error.body ? JSON.stringify(error.body) : error.message;
            log.responsePayload = {
                status: error.status || 500,
                body: error.body || { message: error.message }
            };
            await log.save();

            res.status(error.status || 502).json({
                success: false,
                message: 'İYS sisteminden hata döndü.',
                details: error.body || error.message,
                logId: log.id
            });
        }
    } catch (error) {
        console.error('IYS consent error:', error);
        res.status(500).json({ error: 'İYS izni gönderilemedi.' });
    }
});

app.get('/api/iys/logs', authenticate, async (req, res) => {
    try {
        const groupUsers = await User.findAll({ where: { group: req.group }, attributes: ['id'] });
        const groupUserIds = groupUsers.map(user => user.id);
        const logs = await IysConsentLog.findAll({
            where: { UserId: groupUserIds },
            order: [['createdAt', 'DESC']],
            limit: 50
        });

        res.json({
            success: true,
            logs: logs.map(log => ({
                id: log.id,
                patientId: log.patientId,
                recipient: log.recipient,
                type: log.type,
                status: log.status,
                source: log.source,
                recipientType: log.recipientType,
                consentDate: log.consentDate,
                requestStatus: log.requestStatus,
                errorMessage: log.errorMessage,
                createdAt: log.createdAt
            }))
        });
    } catch (error) {
        console.error('IYS logs error:', error);
        res.status(500).json({ error: 'İYS işlem geçmişi okunamadı.' });
    }
});

app.get('/api/public/events/:companyId/:eventId', async (req, res) => {
    const { companyId, eventId } = req.params;
    try {
        const company = await Company.findByPk(companyId);
        if (!company) return res.status(404).json({ error: "Firma bulunamadı." });

        // Robust data parsing
        let companyData = company.data;
        // Ensure it's an object
        if (typeof companyData === 'string') {
            try {
                companyData = JSON.parse(companyData);
            } catch (e) {
                console.error("JSON Parse Error in public event:", e);
                companyData = {};
            }
        }

        const expertDays = companyData.expertDays || [];
        // Robust comparisons
        const targetEventId = String(eventId).trim();
        const event = expertDays.find(d => d && String(d.id).trim() === targetEventId);

        if (!event) {
            console.error(`Event not found: ${eventId} in company ${company.name}`);
            return res.status(404).json({ error: "Etkinlik bulunamadı." });
        }

        // Filter out sensitive data, only return busy slots
        const appointments = event.invitations?.filter(i => i.appointmentTime) || [];
        const busySlots = appointments.map(i => i.appointmentTime);

        const pharmacyOwnerId = company.UserId;
        let pharmacyName = "";

        if (pharmacyOwnerId) {
            const owner = await User.findByPk(pharmacyOwnerId);
            if (owner && owner.pharmacyName) {
                pharmacyName = owner.pharmacyName;
            }
        }

        res.json({
            companyName: company.name,
            pharmacyName: pharmacyName,
            date: event.date,
            startHour: event.startHour || "09:00",
            endHour: event.endHour || "18:00",
            slotDuration: event.slotDuration || 30,
            note: event.note,
            busySlots: busySlots
        });

    } catch (e) {
        console.error("Public Event Error:", e);
        res.status(500).json({ error: "Sunucu hatası." });
    }
});

app.post('/api/public/book', async (req, res) => {
    const { companyId, eventId, time, fullName, phone } = req.body;

    if (!companyId || !eventId || !time || !fullName || !phone) {
        return res.status(400).json({ error: "Eksik bilgi." });
    }

    const normalizePhone = (p) => {
        if (!p) return "";
        const digits = String(p).replace(/\D/g, '');
        return digits.slice(-10);
    };

    const httpError = (status, message) => {
        const err = new Error(message);
        err.status = status;
        return err;
    };

    try {
        await sequelize.transaction({ type: 'IMMEDIATE' }, async (t) => {
            const company = await Company.findByPk(companyId, { transaction: t });
            if (!company) throw httpError(404, "Firma bulunamadi.");

            let companyData = company.data;
            if (typeof companyData === 'string') {
                try {
                    companyData = JSON.parse(companyData);
                } catch {
                    companyData = {};
                }
            }

            const days = companyData.expertDays || [];
            const targetEventId = String(eventId).trim();
            const dayIndex = days.findIndex(d => d && String(d.id).trim() === targetEventId);
            if (dayIndex === -1) throw httpError(404, "Etkinlik bulunamadi.");

            const day = days[dayIndex];
            if (!Array.isArray(day.invitations)) day.invitations = [];

            const isTaken = day.invitations.some(i => {
                if (!i.isConfirmed) return false;
                const times = i.appointmentTimes || (i.appointmentTime ? [i.appointmentTime] : []);
                return times.includes(time);
            });
            if (isTaken) throw httpError(409, "Bu saat maalesef doldu.");

            let groupUserIds = [];
            if (company.UserId) {
                const owner = await User.findByPk(company.UserId, { transaction: t });
                if (owner) {
                    const groupUsers = await User.findAll({
                        where: { group: owner.group },
                        attributes: ['id'],
                        transaction: t
                    });
                    groupUserIds = groupUsers.map(u => u.id);
                }
            }
            if (groupUserIds.length === 0 && company.UserId) groupUserIds = [company.UserId];

            const allPatients = await Patient.findAll({
                where: groupUserIds.length > 0 ? { UserId: groupUserIds } : {},
                attributes: ['id', 'fullName', 'phone'],
                transaction: t
            });

            const cleanPhone = normalizePhone(phone);
            const searchName = String(fullName).toLocaleLowerCase('tr').trim();

            let patient = allPatients.find(p => {
                const pPhone = normalizePhone(p.phone);
                return pPhone && cleanPhone && pPhone === cleanPhone;
            });

            if (!patient) {
                patient = allPatients.find(p => {
                    const pName = (p.fullName || "").toLocaleLowerCase('tr').trim();
                    return pName === searchName;
                });
            }

            if (patient) {
                patient = await Patient.findByPk(patient.id, { transaction: t });
                if (!patient.phone && phone) {
                    patient.phone = phone;
                    await patient.save({ transaction: t });
                }
            } else {
                const ownerId = company.UserId || company.dataValues?.UserId || company.userId;
                patient = await Patient.create({
                    id: crypto.randomUUID(),
                    fullName,
                    phone,
                    UserId: ownerId,
                    patient_data: {
                        source: 'public_booking',
                        createdAt: new Date(),
                        notes: 'Otomatik olusturulan kayit (Online Randevu)'
                    }
                }, { transaction: t });
            }

            const bookingEntry = {
                patientId: patient.id,
                fullName,
                phone,
                invitedAt: new Date().toISOString(),
                isConfirmed: true,
                isCalled: true,
                isReached: true,
                isAttended: false,
                appointmentTime: time,
                note: 'Online Randevu (Web)'
            };

            const existingInviteIndex = day.invitations.findIndex(i => i.patientId === patient.id);
            let inviteIndex = existingInviteIndex;
            if (existingInviteIndex !== -1) {
                day.invitations[existingInviteIndex] = {
                    ...day.invitations[existingInviteIndex],
                    ...bookingEntry
                };
            } else {
                day.invitations.push(bookingEntry);
                inviteIndex = day.invitations.length - 1;
            }

            let pData = patient.patient_data || {};
            if (typeof pData === 'string') {
                try {
                    pData = JSON.parse(pData);
                } catch {
                    pData = {};
                }
            }
            if (!Array.isArray(pData.visits)) pData.visits = [];

            const todayStr = new Date().toISOString().split('T')[0];
            const existingRelatedVisitId = day.invitations[inviteIndex]?.relatedVisitId;

            let existingVisitIndex = -1;
            if (existingRelatedVisitId) {
                existingVisitIndex = pData.visits.findIndex(v => v.id === existingRelatedVisitId);
            }
            if (existingVisitIndex === -1) {
                existingVisitIndex = pData.visits.findIndex(v => {
                    const vDate = v.date ? String(v.date).split('T')[0] : '';
                    return vDate === todayStr;
                });
            }

            let readableDate = day.date;
            try {
                readableDate = new Intl.DateTimeFormat('tr-TR', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric'
                }).format(new Date(day.date));
            } catch {}

            const newNote = `${company.name} - ${readableDate} Saat: ${time} randevusu alindi.`;
            let finalVisitId;

            if (existingVisitIndex !== -1) {
                const existingNote = pData.visits[existingVisitIndex].note || '';
                const noteToSave = existingNote.includes(time)
                    ? existingNote
                    : (existingNote ? `${existingNote}\n\n${newNote}` : newNote);

                pData.visits[existingVisitIndex] = {
                    ...pData.visits[existingVisitIndex],
                    date: new Date().toISOString(),
                    note: noteToSave
                };
                finalVisitId = pData.visits[existingVisitIndex].id;
            } else {
                finalVisitId = crypto.randomUUID();
                pData.visits.unshift({
                    id: finalVisitId,
                    date: new Date().toISOString(),
                    type: 'Online Randevu',
                    note: newNote,
                    createdBy: 'Sistem (Online)',
                    products: []
                });
            }

            day.invitations[inviteIndex].relatedVisitId = finalVisitId;
            days[dayIndex] = day;
            companyData.expertDays = days;

            patient.patient_data = pData;
            patient.changed('patient_data', true);
            await patient.save({ transaction: t });

            company.data = companyData;
            company.changed('data', true);
            await company.save({ transaction: t });
        });

        res.json({ success: true, message: "Randevunuz basariyla olusturuldu." });
    } catch (e) {
        if (e.status) {
            return res.status(e.status).json({ error: e.message });
        }
        console.error('Booking Error:', e);
        res.status(500).json({ error: 'Islem sirasinda bir hata olustu.' });
    }
});
// --- USER MANAGEMENT ---
app.get('/api/users', authenticate, async (req, res) => {
    if (!canManageUsers(req)) return res.status(403).json({ error: "Yetkiniz yok." });

    try {
        const users = await User.findAll();

        let patientCounts = {};
        const counts = await Patient.findAll({
            attributes: ['UserId', [sequelize.fn('COUNT', sequelize.col('id')), 'count']],
            group: ['UserId']
        });
        counts.forEach(c => {
            const d = c.toJSON();
            patientCounts[d.UserId] = d.count;
        });

        const showAllGroups = canViewAllGroups(req);

        const userList = users.map(u => u.toJSON()).map(u => ({
            id: u.id,
            username: u.username,
            name: u.name,
            role: u.role,
            group: u.group,
            patientCount: patientCounts[u.id] || 0
        }));

        if (!showAllGroups) {
            res.json(userList.filter(u => u.group === req.group));
        } else {
            res.json(userList);
        }

    } catch (error) {
        console.error("Users fetch error:", error);
        res.status(500).json({ error: "Hata" });
    }
});

app.post('/api/users', authenticate, async (req, res) => {
    if (!canManageUsers(req)) return res.status(403).json({ error: "Yetkisiz." });
    const { username, password, name, role, group, createIsolatedGroup } = req.body;
    const isSuperAdmin = isSuperAdminUser(req);
    const isManager = isManagerUser(req);
    const isAdmin = req.user.role === 'admin';
    const allowIsolatedGroup = Boolean(createIsolatedGroup) && (isSuperAdmin || isAdmin);
    try {
        if (!password || String(password).trim().length === 0) {
            return res.status(400).json({ error: "Sifre zorunludur." });
        }

        // Group managers can add people only as staff within their own group.
        if (isManager && !isSuperAdmin) {
            if (role && role !== 'staff') {
                return res.status(403).json({ error: "Yonetici sadece personel ekleyebilir." });
            }
        }

        if (!isSuperAdmin && (role === 'super-admin')) {
            return res.status(403).json({ error: "Bu rol ile kullanici olusturma yetkiniz yok." });
        }

        if (!isSuperAdmin && !allowIsolatedGroup && role === 'admin') {
            return res.status(403).json({ error: "Bu rol ile kullanici olusturma yetkiniz yok." });
        }

        const isolatedGroupId = `group_admin_${crypto.randomUUID().slice(0, 8)}`;
        const targetGroup = allowIsolatedGroup
            ? isolatedGroupId
            : (isSuperAdmin ? (group || req.group || 'main_group') : (req.group || 'main_group'));
        const finalRole = (allowIsolatedGroup && isAdmin && role !== 'super-admin') ? 'admin' : role;

        await User.create({
            username,
            password: hashPassword(password),
            name,
            role: finalRole,
            group: targetGroup
        });
        res.json({ success: true });
    } catch (e) {
        res.status(400).json({ error: "Kullanıcı oluşturulamadı (Benzersiz isim seçin)." });
    }
});

app.put('/api/users/:username', authenticate, async (req, res) => {
    if (!canManageUsers(req)) return res.status(403).json({ error: "Yetkisiz." });

    const currentUsername = req.params.username;

    try {
        const userToUpdate = await User.findOne({ where: { username: currentUsername } });
        if (!userToUpdate) return res.status(404).json({ error: "Kullanıcı bulunamadı." });

        const { username, newUsername, name, password, role } = req.body;
        const targetUsername = newUsername || username;
        const isManager = isManagerUser(req);
        const isSuperAdmin = isSuperAdminUser(req);

        // Manager: same-group only, and cannot change role/password or edit admins.
        if (isManager) {
            if (userToUpdate.group !== req.group) {
                return res.status(403).json({ error: "Bu kullaniciyi guncelleme yetkiniz yok." });
            }
            if (password !== undefined || role !== undefined) {
                return res.status(403).json({ error: "Yoneticiler rol veya sifre degistiremez." });
            }
            if (userToUpdate.role === 'admin' || userToUpdate.role === 'super-admin') {
                return res.status(403).json({ error: "Yuksek yetkili kullanicilari duzenleyemezsiniz." });
            }
        }

        // Non-super admins cannot update users outside their own group.
        if (!isSuperAdmin && userToUpdate.group !== req.group) {
            return res.status(403).json({ error: "Bu kullaniciyi guncelleme yetkiniz yok." });
        }

        // Super-admin accounts are immutable by non-super users.
        if (!isSuperAdmin && userToUpdate.role === 'super-admin') {
            return res.status(403).json({ error: "Bu kullanici guncellenemez." });
        }

        // Non-super admins cannot manage high-privilege users or promote to high privileges.
        if (!isSuperAdmin && !isManager) {
            if (userToUpdate.role === 'admin' || userToUpdate.role === 'super-admin') {
                return res.status(403).json({ error: "Yuksek yetkili kullanicilari guncelleyemezsiniz." });
            }
            if (role === 'admin' || role === 'super-admin') {
                return res.status(403).json({ error: "Bu role yukseltme yetkiniz yok." });
            }
        }

        if (targetUsername && targetUsername !== currentUsername) {
            const exists = await User.findOne({ where: { username: targetUsername } });
            if (exists) return res.status(400).json({ error: "Bu kullanıcı adı zaten dolu." });
            userToUpdate.username = targetUsername;
        }

        const isPasswordReset = !isManager && Boolean(password && password.length > 0);
        if (name) userToUpdate.name = name;
        if (isPasswordReset) userToUpdate.password = hashPassword(password);
        if (!isManager && role) userToUpdate.role = role;

        await userToUpdate.save();
        if (isPasswordReset) {
            revokeUserTokens(userToUpdate.id);
        }

        res.json({ success: true, message: "Kullanıcı güncellendi." });
    } catch (e) {
        console.error("Update error:", e);
        res.status(500).json({ error: "Güncelleme yapılamadı." });
    }
});

app.delete('/api/users/:username', authenticate, async (req, res) => {
    if (!canManageUsers(req)) return res.status(403).json({ error: "Yetkisiz." });
    // Note: Parameter is still 'username' for legacy frontend compatibility, but we can fix frontend later.
    // Let's assume we find by username.
    try {
        const u = await User.findOne({ where: { username: req.params.username } });
        if (u) {
            const isSuperAdmin = isSuperAdminUser(req);
            const isManager = isManagerUser(req);

            if (!isSuperAdmin && u.role === 'super-admin') {
                return res.status(403).json({ error: "Bu kullanici silinemez." });
            }

            if (!isSuperAdmin && u.group !== req.group) {
                return res.status(403).json({ error: "Bu kullaniciyi silme yetkiniz yok." });
            }

            if ((isManager || (!isSuperAdmin && !isManager)) && (u.role === 'admin' || u.role === 'super-admin')) {
                return res.status(403).json({ error: "Yuksek yetkili kullanicilari silemezsiniz." });
            }
            revokeUserTokens(u.id);
            await u.destroy(); // Cascade deletes patients? Yes defined in database.js
            res.json({ success: true });
        } else {
            res.status(404).json({ error: "Kullanıcı yok." });
        }
    } catch (e) { res.status(500).json({ error: "Silinemedi." }); }
});


// --- GRANULAR DATA ENDPOINTS ---

// Helper to format patient for frontend
const formatPatient = (p) => {
    const raw = p.toJSON();
    const extras = raw.patient_data || {};
    return {
        id: raw.id,
        fullName: raw.fullName,
        phone: raw.phone,
        owner: raw.User ? raw.User.username : 'Bilinmiyor',
        createdAt: raw.createdAt,
        updatedAt: raw.updatedAt,
        ...extras
    };
};

const isOwnerInRequesterGroup = async (req, ownerUserId) => {
    if (!ownerUserId) return false;

    const ownerUser = await User.findByPk(ownerUserId, { attributes: ['id', 'group'] });
    if (!ownerUser) return false;
    return ownerUser.group === req.group;
};

// GET ALL (Still needed for initial load)
app.get('/api/data', authenticate, async (req, res) => {
    try {
        const groupUsers = await User.findAll({ where: { group: req.group }, attributes: ['id'] });
        const groupUserIds = groupUsers.map(u => u.id);

        const patients = await Patient.findAll({
            where: { UserId: groupUserIds },
            include: [{ model: User, attributes: ['username'] }]
        });

        const companies = await Company.findAll({
            where: { UserId: groupUserIds },
            include: [{ model: User, attributes: ['username'] }]
        });

        const products = await Product.findAll();

        res.json({
            _version: new Date().getTime(),
            patients: patients.map(formatPatient),
            companies: companies.map(c => {
                const raw = c.toJSON();
                const extras = raw.data || {};
                return { id: raw.id, name: raw.name, owner: raw.User ? raw.User.username : '', ...extras };
            }),
            products: products.map(p => ({ id: p.id, ...p.data }))
        });

    } catch (error) {
        console.error("GET Data Error:", error);
        res.status(500).json({ error: "Data error" });
    }
});

// SINGLE PATIENT UPSERT
app.post('/api/patient', authenticate, async (req, res) => {
    const p = req.body;
    const { id, fullName, phone, visits, skinCareData, detailedAnamnesis, dermoAnamnesis, followUps, ...others } = p;
    const extras = { visits, skinCareData, detailedAnamnesis, dermoAnamnesis, followUps, ...others };

    try {
        const existing = await Patient.findByPk(id);
        let targetUserId = req.id;

        if (existing) {
            const canAccess = await isOwnerInRequesterGroup(req, existing.UserId);
            if (!canAccess) return res.status(403).json({ error: "Bu danışan kaydini guncelleme yetkiniz yok." });
            targetUserId = existing.UserId; // Preserve owner
        }

        await Patient.upsert({
            id: id,
            fullName: fullName,
            phone: phone,
            UserId: targetUserId,
            patient_data: extras,
            updatedAt: new Date()
        });

        res.json({ success: true, id: id });
    } catch (e) {
        console.error("Patient Save Error:", e);
        res.status(500).json({ error: "Kaydedilemedi." });
    }
});

// SINGLE PATIENT DELETE
app.delete('/api/patient/:id', authenticate, async (req, res) => {
    try {
        const p = await Patient.findByPk(req.params.id);
        if (p) {
            const canAccess = await isOwnerInRequesterGroup(req, p.UserId);
            if (!canAccess) return res.status(403).json({ error: "Bu danışan kaydini silme yetkiniz yok." });
            await p.destroy();
        }
        res.json({ success: true });
    } catch (e) { res.status(500).json({ error: "Silinemedi" }); }
});

// SINGLE COMPANY UPSERT
app.post('/api/company', authenticate, async (req, res) => {
    const c = req.body;
    const { id, name, ...data } = c;
    try {
        const existing = await Company.findByPk(id);
        let targetUserId = req.id;
        if (existing) {
            const canAccess = await isOwnerInRequesterGroup(req, existing.UserId);
            if (!canAccess) return res.status(403).json({ error: "Bu firma kaydini guncelleme yetkiniz yok." });
            targetUserId = existing.UserId;
        }

        await Company.upsert({
            id, name, UserId: targetUserId, data
        });
        res.json({ success: true });
    } catch (e) { res.status(500).json({ error: "Şirket kaydedilemedi" }); }
});

// SINGLE COMPANY DELETE
app.delete('/api/company/:id', authenticate, async (req, res) => {
    try {
        const company = await Company.findByPk(req.params.id);
        if (company) {
            const canAccess = await isOwnerInRequesterGroup(req, company.UserId);
            if (!canAccess) return res.status(403).json({ error: "Bu firma kaydini silme yetkiniz yok." });
            await company.destroy();
        }
        res.json({ success: true });
    } catch (e) { res.status(500).json({ error: "Hata" }); }
});

// SINGLE PRODUCT UPSERT
app.post('/api/product', authenticate, async (req, res) => {
    if (!canManageProducts(req)) {
        return res.status(403).json({ error: "Urun ekleme/guncelleme yetkiniz yok." });
    }

    const p = req.body;
    const { id, ...data } = p;
    try {
        await Product.upsert({ id, data: { ...data, id } });
        res.json({ success: true });
    } catch (e) { res.status(500).json({ error: "Ürün kaydedilemedi" }); }
});

// SINGLE PRODUCT DELETE
app.delete('/api/product/:id', authenticate, async (req, res) => {
    if (!canManageProducts(req)) {
        return res.status(403).json({ error: "Urun silme yetkiniz yok." });
    }

    try {
        await Product.destroy({ where: { id: req.params.id } });
        res.json({ success: true });
    } catch (e) { res.status(500).json({ error: "Hata" }); }
});

// BULK PRODUCT IMPORT
app.post('/api/products/bulk', authenticate, async (req, res) => {
    if (!canManageProducts(req)) {
        return res.status(403).json({ error: "Toplu urun ekleme yetkiniz yok." });
    }

    const products = req.body;
    if (!Array.isArray(products) || products.length === 0) {
        return res.status(400).json({ error: "Geçersiz veri." });
    }

    try {
        // Prepare data for bulk create
        const productData = products.map(p => ({
            id: p.id || crypto.randomUUID(),
            data: p // Store the whole object in the JSON column 'data'
        }));

        // Use updateOnDuplicate to handle potential re-imports of same IDs if any,
        // but mostly we rely on the logic that we generated new IDs or checked barcodes in frontend.
        // However, since we store everything in 'data' JSON column, and 'id' is the PK.
        // If we want to dedup by barcode, we rely on the frontend check OR we'd need a virtual generated column unique constraint.
        // For now, simpler is just insert.

        await Product.bulkCreate(productData, {
            updateOnDuplicate: ['data']
        });

        res.json({ success: true, count: products.length });
    } catch (e) {
        console.error("Bulk Product Import Error:", e);
        res.status(500).json({ error: "Toplu ekleme başarısız." });
    }
});

// Legacy Bulk Endpoint (Deprecated)
app.post('/api/data', authenticate, (req, res) => {
    res.status(400).json({ error: "Toplu kayıt devre dışı. Lütfen sayfayı yenileyin." });
});

// --- BACKUP & RESTORE ---
app.get('/api/backup', authenticate, async (req, res) => {
    // Staff cannot download full database dumps.
    if (req.user.role === 'staff') {
        return res.status(403).json({ error: "Yedek alma yetkiniz yok." });
    }

    try {
        const isSuperAdmin = isSuperAdminUser(req);

        let users;
        let patients;
        let companies;

        if (isSuperAdmin) {
            users = await User.findAll();
            patients = await Patient.findAll();
            companies = await Company.findAll();
        } else {
            users = await User.findAll({ where: { group: req.group } });
            const groupUserIds = users.map(u => u.id);
            patients = await Patient.findAll({ where: { UserId: groupUserIds } });
            companies = await Company.findAll({ where: { UserId: groupUserIds } });
        }

        const products = await Product.findAll();

        const backupData = {
            version: "2.0",
            date: new Date().toISOString(),
            source: "sqlite_dump",
            users,
            patients,
            companies,
            products
        };

        res.setHeader('Content-Disposition', 'attachment; filename=dermasoft_backup.json');
        res.setHeader('Content-Type', 'application/json');
        res.send(JSON.stringify(backupData, null, 2));

    } catch (error) {
        console.error("Backup Error:", error);
        res.status(500).json({ error: "Yedek oluşturulamadı." });
    }
});

app.post('/api/restore', authenticate, upload.single('backupFile'), async (req, res) => {
    const canRestore = canRestoreUser(req);
    if (!req.file) return res.status(400).json({ error: "Dosya yüklenmedi." });
    if (!canRestore) {
        if (req.file && fs.existsSync(req.file.path)) {
            fs.unlinkSync(req.file.path);
        }
        return res.status(403).json({ error: "Geri yukleme yetkiniz yok." });
    }


    try {
        const fileContent = fs.readFileSync(req.file.path, 'utf8');
        let data;
        try {
            data = JSON.parse(fileContent);
        } catch (e) {
            return res.status(400).json({ error: "Geçersiz dosya formatı. JSON okunamadı." });
        }

        // VALIDATION: Ensure at least some data exists to avoid accidental wipe
        if (!data || (!data.users && !data.patients && !data.companies)) {
            return res.status(400).json({ error: "Yedek dosyası boş veya geçersiz formatta (Veri bulunamadı)." });
        }

        await sequelize.transaction(async (t) => {
            // 1. Clear existing data (Order matters for FK)
            await Patient.destroy({ where: {}, transaction: t });
            await Company.destroy({ where: {}, transaction: t });
            await Product.destroy({ where: {}, transaction: t });
            // Note: We don't delete Users to prevent locking out the admin, 
            // unless we strictly upsert them.

            // 2. Restore
            if (data.users && Array.isArray(data.users)) {
                const normalizedUsers = data.users.map(u => ({
                    ...u,
                    password: (() => {
                        const incoming = typeof u.password === 'string' ? u.password : '';
                        if (incoming.length === 0) return hashPassword(crypto.randomUUID());
                        return isPasswordHashed(incoming) ? incoming : hashPassword(incoming);
                    })()
                }));

                await User.bulkCreate(normalizedUsers, {
                    updateOnDuplicate: ['name', 'password', 'role', 'group', 'pharmacyName'],
                    transaction: t
                });
            }

            if (data.companies && Array.isArray(data.companies)) {
                await Company.bulkCreate(data.companies, { transaction: t });
            }

            if (data.patients && Array.isArray(data.patients)) {
                await Patient.bulkCreate(data.patients, { transaction: t });
            }

            if (data.products && Array.isArray(data.products)) {
                await Product.bulkCreate(data.products, { transaction: t });
            }
        });
        clearAllTokens();

        res.json({ success: true, message: "Geri yükleme başarılı." });

    } catch (error) {
        console.error("Restore Error:", error);
        res.status(500).json({ error: "Geri yükleme başarısız: " + error.message });
    } finally {
        if (req.file && fs.existsSync(req.file.path)) {
            fs.unlinkSync(req.file.path);
        }
    }
});

// Static
app.use(express.static(path.join(__dirname, 'dist')));
app.get(/.*/, (req, res) => {
    if (req.path.startsWith('/api')) return res.status(404).json({});
    res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

// Start
app.listen(PORT, HOST, () => {
    console.log(`Server strict mode running on ${HOST}:${PORT}`);
});
