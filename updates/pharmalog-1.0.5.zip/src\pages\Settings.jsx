import { useState, useRef, useEffect } from "react";
import { useTheme } from "../context/ThemeContext";
import { useAuth } from "../context/AuthContext";
import { DataService } from "../lib/data";
import {
    Database, Loader2, CheckCircle, AlertTriangle, Play,
    Settings as SettingsIcon, Download, Upload, ShieldCheck,
    Moon, Sun, Palette, Printer, FileText, X, MessageSquare, Save, History
} from "lucide-react";
import PrintableDetailedForm from '../components/PrintableDetailedForm';
import PrintableDermoForm from '../components/PrintableDermoForm';




export default function Settings() {
    const { user } = useAuth();
    const [printingType, setPrintingType] = useState(null); // 'detailed' | 'dermo' | null

    const handlePrint = (type) => {
        setPrintingType(type);
        // State update sonrası yazdırma işlemini tetikle
        setTimeout(() => {
            window.print();
            // Yazdırma diyaloğu kapandıktan sonra (veya hemen, çünkü print bloklar) state'i sıfırlamaya gerek yok, 
            // ama CSS'in print harici etkilememesi için print sonrası temizlemek iyi olabilir.
            // Ancak window.print() render thread'i bloklar, kullanıcı diyaloğu kapatınca kod devam eder.
            // Ama yine de kullanıcı 'iptal' derse state'in kalması sorun değil çünkü CSS sadece @media print'te aktif.
            // Yine de temiz tutmak için bir süre sonra resetleyebiliriz veya onafterprint eventi kullanırız.
        }, 100);
    };

    useEffect(() => {
        const handleAfterPrint = () => {
            setPrintingType(null);
        };
        window.addEventListener('afterprint', handleAfterPrint);
        return () => window.removeEventListener('afterprint', handleAfterPrint);
    }, []);

    return (
        <>
            {/* Dinamik Print CSS'i */}
            {printingType && (
                <style>
                    {`
                    @media print {
                        /* Her şeyi gizle */
                        body * {
                            visibility: hidden;
                        }
                        
                        /* Sadece print container ve içindekileri göster */
                        #print-container, #print-container * {
                            visibility: visible !important;
                        }

                        /* Container'ı sayfanın en başına zorla taşı ve görünür yap */
                        /* Container'ı sayfanın en başına taşı ve akışa bırak (pagination için absolute şart) */
                        #print-container {
                            position: absolute !important;
                            left: 0 !important;
                            top: 0 !important;
                            width: 100% !important;
                            height: auto !important; /* 100% yerine auto olmalı ki sayfalar uzasın */
                            min-height: 100% !important;
                            margin: 0 !important;
                            padding: 0 !important;
                            background: white !important;
                            opacity: 1 !important;
                            pointer-events: auto !important;
                            z-index: 999999 !important;
                            display: block !important;
                        }
                        
                        /* Sadece aktif olan formu göster, diğerini gizle (display none ile yer kaplamasın) */
                        ${printingType === 'detailed' ? '#print-section-dermo { display: none; }' : ''}
                        ${printingType === 'dermo' ? '#print-section-detailed { display: none; }' : ''}

                        /* Sayfa ayarları */
                        @page {
                            size: auto;
                            margin: 0mm;
                        }
                    }
                    `}
                </style>
            )}

            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700 transform-gpu">
                <div>
                    <h1 className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-slate-900 to-slate-700 dark:from-white dark:to-slate-300 flex items-center gap-3">
                        <SettingsIcon size={32} className="text-slate-800 dark:text-slate-200" />
                        Ayarlar & Bakım
                    </h1>
                    <p className="text-slate-500 dark:text-slate-400 mt-2 font-medium max-w-2xl">
                        Sistem yedekleme, veri taşıma, görünüm ve yazdırma ayarlarını buradan yönetebilirsiniz.
                    </p>
                </div>

                <div className="grid grid-cols-1 gap-8">
                    <ProfileSettings />
                    <AppearanceSettings />
                    <IysIntegrationSettings />
                    <BlankFormsSection
                        onPrintDetailed={() => handlePrint('detailed')}
                        onPrintDermo={() => handlePrint('dermo')}
                    />
                    {user?.role !== 'staff' && <BackupTool />}
                    <ProductMigrationTool />
                </div>
            </div>

            {/* Print Forms: Ekran dışına saklanmış Container */}
            <div id="print-container" className="fixed top-0 left-[-10000px] opacity-0 pointer-events-none w-[210mm] min-h-[297mm]">
                <div id="print-section-detailed">
                    <PrintableDetailedForm isEmpty={true} />
                </div>
                <div id="print-section-dermo">
                    <PrintableDermoForm isEmpty={true} />
                </div>
            </div>
        </>
    );
}



function AppearanceSettings() {
    const { theme, setTheme } = useTheme();

    return (
        <div className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-xl rounded-2xl border border-white/40 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-black/20 p-8 transition-colors hover:scale-[1.01] duration-300">
            <div className="flex items-start gap-5 mb-8">
                <div className="p-4 bg-purple-50 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400 rounded-2xl shadow-sm">
                    <Palette size={28} />
                </div>
                <div className="flex-1">
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white">Görünüm Ayarları</h3>
                    <p className="text-slate-500 dark:text-slate-400 mt-1 font-medium">
                        Uygulama temasını ve renklerini kişiselleştirin.
                    </p>
                </div>
            </div>

            <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-slate-50/50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-700/50">
                    <div className="flex items-center gap-4">
                        {theme === 'dark' ? (
                            <div className="p-2 bg-slate-200 dark:bg-slate-700 rounded-lg">
                                <Moon className="text-slate-600 dark:text-slate-300" size={20} />
                            </div>
                        ) : (
                            <div className="p-2 bg-amber-100 rounded-lg">
                                <Sun className="text-amber-500" size={20} />
                            </div>
                        )}
                        <div>
                            <p className="font-bold text-slate-900 dark:text-white">Tema Modu</p>
                            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-medium">
                                {theme === 'dark' ? 'Koyu Mod Aktif' : 'Açık Mod Aktif'}
                            </p>
                        </div>
                    </div>

                    <div className="flex bg-slate-200 dark:bg-slate-900 rounded-xl p-1.5 shadow-inner">
                        <button
                            onClick={() => setTheme('light')}
                            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${theme === 'light'
                                ? 'bg-white text-slate-900 shadow-md transform scale-105'
                                : 'text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-black/5 dark:hover:bg-white/5'
                                }`}
                        >
                            Açık
                        </button>
                        <button
                            onClick={() => setTheme('dark')}
                            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${theme === 'dark'
                                ? 'bg-slate-700 text-white shadow-md transform scale-105'
                                : 'text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-black/5 dark:hover:bg-white/5'
                                }`}
                        >
                            Koyu
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}

function BlankFormsSection({ onPrintDetailed, onPrintDermo }) {
    return (
        <div className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-xl rounded-2xl border border-white/40 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-black/20 p-8 transition-colors hover:scale-[1.01] duration-300">
            <div className="flex items-start gap-5 mb-8">
                <div className="p-4 bg-blue-50 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400 rounded-2xl shadow-sm">
                    <Printer size={28} />
                </div>
                <div className="flex-1">
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white">Boş Form Yazdırma</h3>
                    <p className="text-slate-500 dark:text-slate-400 mt-1 font-medium">
                        Danışanlarınız için boş anamnez formları yazdırın.
                    </p>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <button
                    onClick={onPrintDetailed}
                    className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-teal-500 dark:hover:border-teal-500 hover:shadow-lg hover:shadow-teal-500/10 group transition-all text-left"
                >
                    <div className="flex items-center gap-3 mb-2">
                        <div className="p-2 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-lg group-hover:bg-teal-50 dark:group-hover:bg-teal-900/20 group-hover:text-teal-600 transition-colors">
                            <FileText size={20} />
                        </div>
                        <span className="font-bold text-slate-700 dark:text-slate-200 group-hover:text-teal-600 transition-colors">Detaylı Anamnez Formu</span>
                    </div>
                    <p className="text-xs text-slate-500">Boş çıktı alarak elle doldurmak için kullanabilirsiniz.</p>
                </button>

                <button
                    onClick={onPrintDermo}
                    className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-teal-500 dark:hover:border-teal-500 hover:shadow-lg hover:shadow-teal-500/10 group transition-all text-left"
                >
                    <div className="flex items-center gap-3 mb-2">
                        <div className="p-2 bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 rounded-lg group-hover:bg-teal-50 dark:group-hover:bg-teal-900/20 group-hover:text-teal-600 transition-colors">
                            <FileText size={20} />
                        </div>
                        <span className="font-bold text-slate-700 dark:text-slate-200 group-hover:text-teal-600 transition-colors">Dermo Anamnez Formu</span>
                    </div>
                    <p className="text-xs text-slate-500">Cilt analizi ve takibi için boş form çıktısı.</p>
                </button>
            </div>
        </div>
    );
}
function IysIntegrationSettings() {
    const { user } = useAuth();
    const canEdit = ['super-admin', 'admin', 'manager'].includes(user?.role);
    const [settings, setSettings] = useState({
        enabled: false,
        verimorUsername: '',
        verimorPassword: '',
        sourceAddr: '',
        defaultSource: 'HS_FIZIKSEL_ORTAM',
        defaultRecipientType: 'BIREYSEL'
    });
    const [logs, setLogs] = useState([]);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [message, setMessage] = useState(null);

    useEffect(() => {
        let mounted = true;
        const load = async () => {
            try {
                const [nextSettings, nextLogs] = await Promise.all([
                    DataService.getIysSettings(),
                    DataService.getIysLogs()
                ]);
                if (!mounted) return;
                setSettings({
                    enabled: Boolean(nextSettings.enabled),
                    verimorUsername: nextSettings.verimorUsername || '',
                    verimorPassword: '',
                    sourceAddr: nextSettings.sourceAddr || '',
                    defaultSource: nextSettings.defaultSource || 'HS_FIZIKSEL_ORTAM',
                    defaultRecipientType: nextSettings.defaultRecipientType || 'BIREYSEL',
                    hasVerimorPassword: Boolean(nextSettings.hasVerimorPassword)
                });
                setLogs(nextLogs || []);
            } catch (error) {
                if (mounted) setMessage({ type: 'error', text: error.message || 'İYS ayarları yüklenemedi.' });
            } finally {
                if (mounted) setLoading(false);
            }
        };
        load();
        return () => {
            mounted = false;
        };
    }, []);

    const updateField = (field, value) => {
        setSettings(prev => ({ ...prev, [field]: value }));
    };

    const handleSave = async () => {
        setSaving(true);
        setMessage(null);
        try {
            const result = await DataService.saveIysSettings(settings);
            const nextSettings = result.settings || {};
            setSettings(prev => ({
                ...prev,
                ...nextSettings,
                verimorPassword: '',
                hasVerimorPassword: Boolean(nextSettings.hasVerimorPassword)
            }));
            setMessage({ type: 'success', text: 'İYS / Verimor ayarları kaydedildi.' });
        } catch (error) {
            setMessage({ type: 'error', text: error.message || 'Ayarlar kaydedilemedi.' });
        } finally {
            setSaving(false);
        }
    };

    return (
        <div className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-xl rounded-2xl border border-white/40 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-black/20 p-8 transition-colors hover:scale-[1.01] duration-300">
            <div className="flex items-start gap-5 mb-8">
                <div className="p-4 bg-teal-50 text-teal-600 dark:bg-teal-900/30 dark:text-teal-400 rounded-2xl shadow-sm">
                    <MessageSquare size={28} />
                </div>
                <div className="flex-1">
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white">İleti Yönetim Sistemi / Verimor</h3>
                    <p className="text-slate-500 dark:text-slate-400 mt-1 font-medium">
                        Danışan iletişim izinlerini Verimor üzerinden İYS'ye göndermek için entegrasyon bilgilerini tanımlayın.
                    </p>
                </div>
            </div>

            {loading ? (
                <div className="flex items-center gap-3 text-slate-500 dark:text-slate-400 font-semibold">
                    <Loader2 className="animate-spin" size={18} />
                    İYS ayarları yükleniyor...
                </div>
            ) : (
                <div className="space-y-6">
                    {message && (
                        <div className={`flex items-start gap-3 p-4 rounded-xl border text-sm font-semibold ${message.type === 'success'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-900/20 dark:text-emerald-300 dark:border-emerald-800'
                            : 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-900/20 dark:text-rose-300 dark:border-rose-800'
                            }`}>
                            {message.type === 'success' ? <CheckCircle size={18} /> : <AlertTriangle size={18} />}
                            {message.text}
                        </div>
                    )}

                    <div className="p-4 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl text-sm text-amber-800 dark:text-amber-200 font-medium leading-relaxed">
                        Bu entegrasyon yalnızca teknik gönderim altyapısını sağlar. İYS başlık/marka tanımları, mevzuata uygun izin metni,
                        açık rıza ve gönderim sorumluluğu kullanıcı eczacıya aittir.
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <label className="flex items-center justify-between gap-4 p-4 bg-slate-50/70 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-700">
                            <div>
                                <p className="font-bold text-slate-900 dark:text-white">Entegrasyonu Aktif Et</p>
                                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Kapalıyken İYS'ye gönderim yapılmaz.</p>
                            </div>
                            <input
                                type="checkbox"
                                checked={settings.enabled}
                                disabled={!canEdit}
                                onChange={(event) => updateField('enabled', event.target.checked)}
                                className="w-5 h-5 accent-teal-600"
                            />
                        </label>

                        <div className="p-4 bg-slate-50/70 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-700">
                            <p className="font-bold text-slate-900 dark:text-white">Sağlayıcı</p>
                            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Verimor SMS API / İYS Hizmetleri</p>
                        </div>

                        <div>
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Verimor Kullanıcı Adı</label>
                            <input
                                value={settings.verimorUsername}
                                disabled={!canEdit}
                                onChange={(event) => updateField('verimorUsername', event.target.value)}
                                placeholder="Örn: 908501234567"
                                className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-teal-500"
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">
                                Verimor API Şifresi {settings.hasVerimorPassword && <span className="text-xs text-emerald-600">(kayıtlı)</span>}
                            </label>
                            <input
                                type="password"
                                value={settings.verimorPassword}
                                disabled={!canEdit}
                                onChange={(event) => updateField('verimorPassword', event.target.value)}
                                placeholder={settings.hasVerimorPassword ? 'Değiştirmeyecekseniz boş bırakın' : 'API şifresi'}
                                className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-teal-500"
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Verimor SMS Başlığı</label>
                            <input
                                value={settings.sourceAddr}
                                disabled={!canEdit}
                                onChange={(event) => updateField('sourceAddr', event.target.value)}
                                placeholder="Örn: ECZANEADI"
                                className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-teal-500"
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Varsayılan İzin Kaynağı</label>
                            <select
                                value={settings.defaultSource}
                                disabled={!canEdit}
                                onChange={(event) => updateField('defaultSource', event.target.value)}
                                className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-teal-500"
                            >
                                <option value="HS_FIZIKSEL_ORTAM">Fiziksel Ortam</option>
                                <option value="HS_WEB">Web</option>
                                <option value="HS_MESAJ">Mesaj</option>
                                <option value="HS_EPOSTA">E-posta</option>
                                <option value="HS_CAGRI_MERKEZI">Çağrı Merkezi</option>
                            </select>
                        </div>
                    </div>

                    <div className="flex flex-wrap gap-3">
                        <button
                            onClick={handleSave}
                            disabled={!canEdit || saving}
                            className="inline-flex items-center gap-2 px-5 py-3 bg-teal-600 hover:bg-teal-700 disabled:opacity-60 text-white rounded-xl font-bold transition-colors"
                        >
                            {saving ? <Loader2 className="animate-spin" size={18} /> : <Save size={18} />}
                            Ayarları Kaydet
                        </button>
                        {!canEdit && (
                            <p className="text-sm text-slate-500 dark:text-slate-400 self-center">
                                Bu ayarları yalnızca yetkili kullanıcılar değiştirebilir.
                            </p>
                        )}
                    </div>

                    <div className="border-t border-slate-200 dark:border-slate-800 pt-6">
                        <div className="flex items-center gap-2 mb-4">
                            <History size={18} className="text-slate-500" />
                            <h4 className="font-bold text-slate-900 dark:text-white">Son İYS Gönderimleri</h4>
                        </div>
                        {logs.length === 0 ? (
                            <p className="text-sm text-slate-500 dark:text-slate-400">Henüz İYS gönderim kaydı yok.</p>
                        ) : (
                            <div className="space-y-2">
                                {logs.slice(0, 5).map(log => (
                                    <div key={log.id} className="flex items-center justify-between gap-3 p-3 bg-slate-50/70 dark:bg-slate-800/50 rounded-xl text-sm">
                                        <div>
                                            <p className="font-bold text-slate-800 dark:text-slate-100">{log.recipient} · {log.type} · {log.status}</p>
                                            <p className="text-xs text-slate-500 dark:text-slate-400">{new Date(log.createdAt).toLocaleString('tr-TR')}</p>
                                        </div>
                                        <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${log.requestStatus === 'SUCCESS'
                                            ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300'
                                            : log.requestStatus === 'FAILED'
                                                ? 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300'
                                                : 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-200'
                                            }`}>
                                            {log.requestStatus}
                                        </span>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}


function BackupTool() {
    const { user } = useAuth();
    const canRestore = user?.role === 'super-admin' || user?.role === 'admin';
    const [isRestoring, setIsRestoring] = useState(false);
    const fileInputRef = useRef(null);

    const handleDownloadBackup = async () => {
        try {
            const token = localStorage.getItem('token');
            const response = await fetch('/api/backup', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Yedek indirilemedi");
            }

            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'dermasoft_yedek.json';
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        } catch (error) {
            console.error("Backup download error:", error);
            alert("Yedek indirme başarısız: " + error.message);
        }
    };

    const handleRestoreBackup = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        if (!window.confirm("DİKKAT! Yedekten geri yükleme yaptığınızda mevcut verilerin üzerine yazılacaktır. Bu işlem geri alınamaz.\n\nDevam etmek istiyor musunuz?")) {
            e.target.value = null;
            return;
        }

        setIsRestoring(true);
        const formData = new FormData();
        formData.append('backupFile', file);

        try {
            const response = await fetch('/api/restore', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}` // Fixed: Add Auth
                },
                body: formData
            });

            const result = await response.json();

            if (response.ok) {
                alert("Yedek başarıyla geri yüklendi! Sayfa yenilenecek.");
                window.location.reload();
            } else {
                alert("Hata: " + (result.error || "Bilinmeyen bir hata oluştu."));
            }
        } catch (error) {
            console.error("Restore error:", error);
            alert("Sunucuya bağlanılamadı.");
        } finally {
            setIsRestoring(false);
            e.target.value = null;
        }
    };

    return (
        <div className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-xl rounded-2xl border border-white/40 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-black/20 p-8 transition-colors hover:scale-[1.01] duration-300">
            <div className="flex items-start gap-5 mb-8">
                <div className="p-4 bg-teal-100/50 text-teal-600 dark:bg-teal-900/30 dark:text-teal-400 rounded-2xl shadow-sm">
                    <ShieldCheck size={28} />
                </div>
                <div className="flex-1">
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white">Yedekleme & Geri Yükleme</h3>
                    <p className="text-slate-500 dark:text-slate-400 mt-1 font-medium">
                        Verilerinizi güvene alın veya eski bir tarihe geri dönün.
                    </p>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Backup Section */}
                <div className="bg-slate-50/50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700/50 rounded-2xl p-6 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                    <div className="flex items-center gap-3 mb-4">
                        <div className="p-2 bg-teal-100 dark:bg-teal-900/30 rounded-lg text-teal-600 dark:text-teal-400">
                            <Download size={20} />
                        </div>
                        <h4 className="font-bold text-slate-800 dark:text-slate-200">Yedek Al</h4>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mb-6 leading-relaxed">
                        Tüm veritabanını (danışanlar, ürünler, firmalar) bilgisayarınıza indirir.
                    </p>
                    <button
                        onClick={handleDownloadBackup}
                        className="w-full bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 hover:bg-teal-50 dark:hover:bg-teal-900/20 hover:border-teal-200 dark:hover:border-teal-700 text-slate-700 dark:text-slate-200 px-4 py-3 rounded-xl font-bold text-sm transition-all shadow-sm flex items-center justify-center gap-2 group"
                    >
                        <Download size={16} className="group-hover:scale-110 transition-transform" />
                        Yedeği İndir (.json)
                    </button>
                </div>

                {canRestore && (
                    <>
                {/* Restore Section */}
                <div className="bg-slate-50/50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700/50 rounded-2xl p-6 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                    <div className="flex items-center gap-3 mb-4">
                        <div className="p-2 bg-amber-100 dark:bg-amber-900/30 rounded-lg text-amber-600 dark:text-amber-500">
                            <Upload size={20} />
                        </div>
                        <h4 className="font-bold text-slate-800 dark:text-slate-200">Geri Yükle</h4>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mb-6 leading-relaxed">
                        Dosyadan geri yükleme yapar. <span className="text-red-500 font-bold">Mevcut veriler silinir!</span>
                    </p>

                    <input
                        type="file"
                        ref={fileInputRef}
                        accept=".json"
                        onChange={handleRestoreBackup}
                        className="hidden"
                    />

                    <button
                        onClick={() => fileInputRef.current.click()}
                        disabled={isRestoring}
                        className="w-full bg-white dark:bg-slate-700 border border-amber-200 dark:border-amber-900/30 text-amber-700 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-900/20 px-4 py-3 rounded-xl font-bold text-sm transition-all shadow-sm flex items-center justify-center gap-2 group"
                    >
                        {isRestoring ? (
                            <Loader2 size={16} className="animate-spin" />
                        ) : (
                            <Upload size={16} className="group-hover:scale-110 transition-transform" />
                        )}
                        {isRestoring ? "Yükleniyor..." : "Yedek Dosyası Seç"}
                    </button>
                </div>
                    </>
                )}
            </div>
        </div>
    );
}

function ProductMigrationTool() {
    const [status, setStatus] = useState("idle"); // idle, scanning, processing, completed
    const [progress, setProgress] = useState({ current: 0, total: 0 });
    const [report, setReport] = useState({ patientsFixed: 0, productsExtracted: 0 });
    const [skippedItems, setSkippedItems] = useState([]); // Array of {patientName, date, noteContent}

    const handleStartScan = async () => {
        if (!window.confirm("Bu işlem tüm danışan kayıtlarını tarayacak ve notlar içinde geçen ürün isimlerini 'Verilen Ürünler' listesine taşıyacaktır. İşlem geri alınamaz. Devam etmek istiyor musunuz?")) return;

        setStatus("scanning");
        try {
            const dbProducts = await DataService.getDbProducts();
            const patients = await DataService.getPatients();

            // Sort products by length (Longest first)
            const sortedProducts = [...dbProducts].sort((a, b) => b.productName.length - a.productName.length);

            setProgress({ current: 0, total: patients.length });
            setStatus("processing");

            let fixedCount = 0;
            let extractedCount = 0;
            const newSkipped = [];

            for (let i = 0; i < patients.length; i++) {
                const patient = patients[i];
                let patientModified = false;
                const newVisits = patient.visits ? [...patient.visits] : [];

                newVisits.forEach(visit => {
                    if (!visit.note) return;

                    let noteContent = visit.note;
                    const newProducts = [];

                    // Escape Regex special characters
                    const escapeRegExp = (string) => {
                        return string.replace(/[.*+?^${ }()|[\]\\]/g, '\\$&');
                    };

                    // Regex Scan
                    sortedProducts.forEach(prod => {
                        const escapedName = escapeRegExp(prod.productName);
                        // Using word boundary \b might fail with symbols like +, so we might need a looser check or specific handling
                        // If it ends with symbol, \b won't match. 
                        // Strategy: Use \b at start, but checking end depends. 
                        // Safer approach for exact phrase match with spaces:

                        const regex = new RegExp(escapedName, 'gi');
                        // If we strictly want whole words, we'd need boundaries but \b breaks on symbols.
                        // Let's stick to simple replacement for now, or sophisticated boundary check.
                        // Given "PA++++", \b matches between + and space? No. + is non-word.
                        // Ideally: (\s|^)escapedName(\s|$|[.,])

                        // Let's use a simpler replace without strict \b for symbols, or careful construction.
                        // However, \b is generally good for "Retinol" vs "Retinol Intense".
                        // If I remove \b, "Retinol" matches inside "BioRetinol".
                        // Compromise: Use \b only if char is word char.

                        // For now, let's just fix the crash by escaping.
                        // And maybe simple replacement is enough since we sort by length desc.

                        if (regex.test(noteContent)) {
                            // Found product
                            newProducts.push({
                                productName: prod.productName,
                                productId: prod.id,
                                durationDays: 30,
                                givenDate: visit.date,
                                notes: "Otomatik ayrıştırıldı"
                            });

                            // Remove from note
                            noteContent = noteContent.replace(regex, '');
                            extractedCount++;
                            patientModified = true;
                        }
                    });

                    if (newProducts.length > 0) {
                        // Cleanup Note
                        noteContent = noteContent
                            .replace(/,\s*,/g, ',')
                            .replace(/\s+/g, ' ')
                            .replace(/^\s*[-,]\s*/, '')
                            .trim();

                        // Update Visit
                        visit.note = noteContent;
                        if (!visit.products) visit.products = [];
                        visit.products = [...newProducts, ...visit.products];
                    }

                    // Checks only if there is still content remaining
                    if (noteContent && noteContent.trim().length > 1) {
                        newSkipped.push({
                            patientName: patient.fullName,
                            date: new Date(visit.date).toLocaleDateString(),
                            noteContent: noteContent
                        });
                    }
                });

                if (patientModified) {
                    await DataService.updatePatient(patient.id, { visits: newVisits });
                    fixedCount++;
                }

                setProgress({ current: i + 1, total: patients.length });
            }

            setReport({ patientsFixed: fixedCount, productsExtracted: extractedCount });
            setSkippedItems(newSkipped);
            setStatus("completed");

        } catch (error) {
            console.error(error);
            alert("Bir hata oluştu: " + error.message);
            setStatus("idle");
        }
    };

    return (
        <div className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-xl rounded-2xl border border-white/40 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-black/20 p-8 transition-colors hover:scale-[1.01] duration-300">
            <div className="flex items-start gap-5 mb-8">
                <div className="p-4 bg-amber-100/50 text-amber-600 dark:bg-amber-900/30 dark:text-amber-500 rounded-2xl shadow-sm">
                    <Database size={28} />
                </div>
                <div className="flex-1">
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white">Geçmiş Verileri Ayrıştırma</h3>
                    <p className="text-slate-500 dark:text-slate-400 mt-1 font-medium">
                        Eski kayıtlardaki notları tarar ve içinde geçen ürün isimlerini otomatik olarak "Verilen Ürünler" listesine taşır.
                    </p>

                    {status === "idle" && (
                        <div className="mt-6">
                            <div className="flex items-start gap-3 text-xs text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/10 p-4 rounded-xl border border-amber-100 dark:border-amber-800 mb-6">
                                <AlertTriangle size={18} className="flex-shrink-0 mt-0.5" />
                                <span className="font-medium">Bu işlem veritabanındaki kayıtları değiştirecektir. Yedek almanız önerilir.</span>
                            </div>
                            <button
                                onClick={handleStartScan}
                                className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-xl font-bold transition-all shadow-lg shadow-indigo-500/30 hover:shadow-indigo-500/50 flex items-center gap-2 hover:-translate-y-0.5"
                            >
                                <Play size={20} fill="currentColor" />
                                Taramayı Başlat
                            </button>
                        </div>
                    )}

                    {(status === "scanning" || status === "processing") && (
                        <div className="mt-6 space-y-3">
                            <div className="flex items-center justify-between text-sm font-bold text-slate-700 dark:text-slate-200">
                                <span>İşleniyor...</span>
                                <span>{Math.round((progress.current / progress.total) * 100)}%</span>
                            </div>
                            <div className="h-3 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden shadow-inner">
                                <div
                                    className="h-full bg-indigo-500 transition-all duration-300 rounded-full"
                                    style={{ width: `${(progress.current / progress.total) * 100}%` }}
                                ></div>
                            </div>
                            <p className="text-xs text-slate-400 font-medium text-center">
                                {progress.current} / {progress.total} danışan kontrol edildi
                            </p>
                        </div>
                    )}

                    {status === "completed" && (
                        <div className="mt-6 bg-teal-50 dark:bg-teal-900/10 border border-teal-100 dark:border-teal-900/30 rounded-xl p-6">
                            <div className="flex items-center gap-2 text-teal-700 dark:text-teal-400 font-bold mb-4">
                                <CheckCircle size={22} />
                                <span>İşlem Tamamlandı</span>
                            </div>
                            <ul className="text-sm text-teal-800 dark:text-teal-300 space-y-2 mb-4 font-medium">
                                <li className="flex items-center gap-2">
                                    <span className="w-1.5 h-1.5 bg-teal-500 rounded-full"></span>
                                    <span><strong>{report.patientsFixed}</strong> danışan kaydı güncellendi.</span>
                                </li>
                                <li className="flex items-center gap-2">
                                    <span className="w-1.5 h-1.5 bg-teal-500 rounded-full"></span>
                                    <span><strong>{report.productsExtracted}</strong> ürün notlardan ayrıştırıldı.</span>
                                </li>
                            </ul>
                            <button
                                onClick={() => setStatus("idle")}
                                className="text-xs font-bold text-teal-600 hover:text-teal-800 dark:text-teal-400 dark:hover:text-teal-200 underline"
                            >
                                Yeni Tarama Yap
                            </button>

                            {skippedItems.length > 0 && (
                                <div className="mt-6 border-t border-teal-200/50 dark:border-teal-800/30 pt-4">
                                    <h4 className="text-sm font-bold text-teal-800 dark:text-teal-300 mb-3 flex items-center gap-2">
                                        <AlertTriangle size={16} className="text-amber-500" />
                                        Ayrıştırılamayan / Atlanan Veriler ({skippedItems.length})
                                    </h4>
                                    <p className="text-xs text-teal-700 dark:text-teal-400 mb-3 font-medium">
                                        Aşağıdaki notlar eşleştirilemediği için <strong>notlar kısmında bırakılmıştır</strong>.
                                    </p>
                                    <div className="max-h-60 overflow-y-auto bg-white dark:bg-slate-900 rounded-xl border border-teal-100 dark:border-slate-700 divide-y divide-slate-100 dark:divide-slate-800 text-xs shadow-inner">
                                        {skippedItems.map((item, idx) => (
                                            <div key={idx} className="p-3 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                                                <div className="flex justify-between font-bold text-slate-700 dark:text-slate-200 mb-1">
                                                    <span>{item.patientName}</span>
                                                    <span className="text-slate-400 font-normal">{item.date}</span>
                                                </div>
                                                <div className="text-slate-600 dark:text-slate-300 font-mono bg-slate-50 dark:bg-slate-800 p-2 rounded border border-slate-100 dark:border-slate-700">
                                                    "{item.noteContent}"
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

function ProfileSettings() {
    const { user } = useAuth();
    // Removed UserIcon import, so use User from lucide-react if needed, but wait, UserIcon was removed. 
    // I need to check imports. "User as UserIcon" was removed in Step 852.
    // I should probably just use "SettingsIcon" or no icon, or re-add the import. 
    // Let's use SettingsIcon for now to avoid import errors, or just text.
    // Actually, let's look at Step 843. It used UserIcon.
    // I will use SettingsIcon or just no icon.
    // Let's use SettingsIcon which is imported.

    const [form, setForm] = useState({
        name: user?.name || "",
        pharmacyName: user?.pharmacyName || ""
    });
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (user) {
            setForm(prev => ({
                ...prev,
                name: user.name || "",
                pharmacyName: user.pharmacyName || ""
            }));
        }
    }, [user]);

    const handleUpdate = async (e) => {
        e.preventDefault();
        if (!window.confirm("Profil bilgilerini güncellemek istediğinize emin misiniz?")) return;

        setLoading(true);
        try {
            const token = localStorage.getItem('token');
            // Wait, did I remove /api/update-profile? 
            // In Step 882 I removed it. 
            // So this component won't work if I don't restore the endpoint.
            // The screenshot "Fixing event is not defined" implies the app was working.
            // Did /api/update-profile exist BACK THEN?
            // The summary says "Updated server.js to Add POST /api/update-profile".
            // So BEFORE that properly, it might NOT have existed.
            // But if the user wants "Profile Settings" in Settings page, it must have done something?
            // "The user requested to move the profile editing functionality... from the Settings page".
            // This implies it WAS there.
            // If I removed the endpoint, I must restore it OR assume the "old state" didn't have editing?
            // "Added a pharmacyName field... Updated server.js to ... Add a POST /api/update-profile".
            // This implies update-profile was ADDED for this feature.
            // BEFORE that, maybe there was no profile editing?
            // Or maybe there was `api/users/:id` update?
            // Let's check `server.js` for other update endpoints.
            // I see `app.put('/api/users/:username'...)`.
            // Maybe the old ProfileSettings used that?
            // But `api/update-profile` is simpler.
            // If I restore `ProfileSettings`, I MUST restore the endpoint too if I want it to work.
            // But the user said "sadece eczane adı eklemek istemiştim".
            // This implies they wanted to ADD it to an EXISTING feature? 
            // "The primary goal was to add a 'Pharmacy Name' field to the user profile".
            // This suggests the profile existed.
            // So `ProfileSettings` likely existed. 
            // Did it use `update-profile`? 
            // If I look at the logs, "Pharmacy Name Implementation" added `update-profile`.
            // So BEFORE that, how did they update profile?
            // Maybe they COULDN'T? Or used `PUT /api/users/:username`?
            // `PUT /api/users/:username` checks checking `req.user.role !== 'admin'`.
            // If normal user, they might not be able to update themselves via that?
            // Wait, line 433: `if (req.user.role !== 'admin' && req.user.role !== 'manager') return 403`.
            // So standard users couldn't use that.
            // Maybe there was NO profile editing for standard users before?
            // If so, "ProfileSettings" might have been Admin only?
            // Or maybe I should just NOT restore `ProfileSettings` if it didn't exist or work?
            // BUT, the user said "move... FROM Settings page". So it WAS there.
            // I will restore `api/update-profile` WITHOUT pharmacyName in `server.js` to support this.

            const res = await fetch('/api/update-profile', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(form)
            });

            if (res.ok) {
                alert("Profil güncellendi.");
                window.location.reload();
            } else {
                const d = await res.json();
                alert(d.error || "Hata.");
            }
        } catch {
            alert("Hata.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-xl rounded-2xl border border-white/40 dark:border-slate-800 p-8">
            <h3 className="text-xl font-bold mb-4 text-slate-900 dark:text-white">Profil Bilgileri</h3>
            <form onSubmit={handleUpdate} className="space-y-4 max-w-xl">
                <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase ml-1">Eczane Adı (Antet İçin)</label>
                    <input
                        type="text"
                        className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3"
                        placeholder="Örn: X ECZANESİ"
                        value={form.pharmacyName}
                        onChange={e => setForm({ ...form, pharmacyName: e.target.value })}
                    />
                    <p className="text-[10px] text-slate-400 ml-1">
                        Bu alan randevu sayfasında başlık olarak görünecektir. (Örn: X ECZANESİ Y FRİMASI ETKİNLİĞİ)
                    </p>
                </div>

                <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase ml-1">Ad Soyad</label>
                    <input
                        type="text"
                        className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3"
                        value={form.name}
                        onChange={e => setForm({ ...form, name: e.target.value })}
                    />
                </div>

                <button
                    type="submit"
                    disabled={loading}
                    className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold"
                >
                    {loading ? "Kaydediliyor..." : "Güncelle"}
                </button>
            </form>
        </div>
    );
}
