import { Sequelize, DataTypes } from 'sequelize';
import path from 'path';
import { fileURLToPath } from 'url';
import { safeJsonParse } from './lib/safeJsonParse.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Veritabanı dosyasının yolu: Ana dizinde 'database.sqlite'
const storagePath = process.env.DERMASOFT_DB_PATH
    ? path.resolve(process.env.DERMASOFT_DB_PATH)
    : path.join(__dirname, '..', 'database.sqlite');

const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: storagePath,
    logging: false // Konsol kirliliğini önlemek için logları kapatıyoruz
});

// --- MODELLER ---

// Kullanıcı Modeli (Relational Master)
const User = sequelize.define('User', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    username: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false
    },
    name: {
        type: DataTypes.STRING,
        allowNull: true
    },
    role: {
        type: DataTypes.STRING,
        defaultValue: 'staff'
    },
    pharmacyName: {
        type: DataTypes.STRING,
        allowNull: true
    },
    // Group logic can remain for team visibility if needed
    group: {
        type: DataTypes.STRING,
        defaultValue: 'main_group'
    }
});

// Hasta Modeli
const Patient = sequelize.define('Patient', {
    id: {
        type: DataTypes.STRING, // Frontend generated UUID
        primaryKey: true
    },
    // UserId Foreign Key will be added by association below

    fullName: {
        type: DataTypes.STRING,
        allowNull: true
    },
    phone: {
        type: DataTypes.STRING,
        allowNull: true
    },

    // JSON Data Bag for everything else (Schema-less flexibility)
    patient_data: {
        type: DataTypes.TEXT,
        defaultValue: '{}',
        get() {
            const raw = this.getDataValue('patient_data');
            return safeJsonParse(raw, {});
        },
        set(value) {
            this.setDataValue('patient_data', JSON.stringify(value));
        }
    },

    createdAt: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
    updatedAt: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
});

// Şirket Modeli
const Company = sequelize.define('Company', {
    id: {
        type: DataTypes.STRING,
        primaryKey: true
    },
    name: {
        type: DataTypes.STRING,
        allowNull: true
    },
    data: {
        type: DataTypes.TEXT,
        defaultValue: '{}',
        get() { return safeJsonParse(this.getDataValue('data'), {}); },
        set(val) { this.setDataValue('data', JSON.stringify(val)); }
    }
});

// Ürün Modeli
const Product = sequelize.define('Product', {
    id: {
        type: DataTypes.STRING,
        primaryKey: true
    },
    data: {
        type: DataTypes.TEXT,
        defaultValue: '{}',
        get() { return safeJsonParse(this.getDataValue('data'), {}); },
        set(val) { this.setDataValue('data', JSON.stringify(val)); }
    }
});

// Associations
User.hasMany(Patient, { onDelete: 'CASCADE' });
Patient.belongsTo(User);

User.hasMany(Company, { onDelete: 'CASCADE' });
Company.belongsTo(User);

export { sequelize, User, Patient, Company, Product };

