@echo off
setlocal

set "APP_URL=%~1"
if "%APP_URL%"=="" set "APP_URL=http://localhost:3001"

set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"

if exist "%EDGE%" (
    start "" "%EDGE%" --app="%APP_URL%" --class=PharmaLog
    exit /b
)

if exist "%CHROME%" (
    start "" "%CHROME%" --app="%APP_URL%"
    exit /b
)

start "" "%APP_URL%"
