@echo off
setlocal EnableDelayedExpansion
title PharmaLog Terminal
color 0B
cls

set "CONFIG_FILE=%~dp0terminal_adres.txt"
set "APP_URL="

if exist "%CONFIG_FILE%" (
    set /p APP_URL=<"%CONFIG_FILE%"
)

if "%APP_URL%"=="ECHO is off." set "APP_URL="
if "%APP_URL%"=="ECHO is on." set "APP_URL="

if "%APP_URL%"=="" (
    echo.
    echo Ana bilgisayar adresini yazin.
    echo Ornek: http://192.168.1.190:3001
    echo.
    set /p APP_URL=Adres: 
    if "!APP_URL!"=="" (
        echo Adres bos olamaz.
        pause
        exit /b 1
    )
    >"%CONFIG_FILE%" echo(!APP_URL!
)

if "%APP_URL%"=="" (
    echo Adres bos olamaz.
    pause
    exit /b 1
)

echo.
echo Baglanti kontrol ediliyor: %APP_URL%
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "try { $r = Invoke-WebRequest -Uri '%APP_URL%' -UseBasicParsing -TimeoutSec 5; if ($r.StatusCode -ge 200 -and $r.StatusCode -lt 500) { exit 0 } else { exit 1 } } catch { exit 1 }"
if %errorlevel% neq 0 (
    echo.
    echo [HATA] Ana bilgisayara baglanilamadi.
    echo.
    echo Kontrol edin:
    echo 1. Ana bilgisayarda "PharmaLog Ana Bilgisayar" acik mi?
    echo 2. Bu bilgisayar ayni Wi-Fi/agda mi?
    echo 3. Adres dogru mu? Ornek: http://192.168.1.190:3001
    echo 4. Ana bilgisayarda Windows Guvenlik Duvari izin verdi mi?
    echo.
    echo Kayitli adresi degistirmek icin terminal_adres_sifirla.bat calistirin.
    pause
    exit /b 1
)

call "%~dp0pharmalog_app_ac.bat" "%APP_URL%"
