import { useEffect, useState } from "react";
import { Download, RefreshCw, X } from "lucide-react";

export default function UpdateNotifier() {
    const [updateInfo, setUpdateInfo] = useState(null);
    const [loading, setLoading] = useState(false);
    const [hidden, setHidden] = useState(false);

    const checkForUpdate = async (manual = false) => {
        const token = localStorage.getItem("token");
        if (!token) return;

        setLoading(true);
        try {
            const response = await fetch("/api/update/check", {
                headers: { Authorization: `Bearer ${token}` }
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data?.error || "Güncelleme kontrolü başarısız.");

            const dismissedVersion = localStorage.getItem("pharmalog_dismissed_update_version");
            if (data.hasUpdate && (manual || data.latestVersion !== dismissedVersion)) {
                setUpdateInfo(data);
                setHidden(false);
                if (manual) {
                    const shouldDownload = window.confirm(
                        `PharmaLog ${data.latestVersion} güncellemesi var.\n\nŞimdi indirmek ister misiniz?`
                    );
                    if (shouldDownload) {
                        openInstaller(data);
                    }
                }
            } else if (manual && !data.hasUpdate) {
                alert(`Program güncel. Mevcut sürüm: ${data.currentVersion}`);
            }
        } catch (error) {
            if (manual) alert(error.message || "Güncelleme kontrolü yapılamadı.");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        const timer = setTimeout(() => checkForUpdate(false), 5000);
        return () => clearTimeout(timer);
    }, []);

    const handleLater = () => {
        localStorage.setItem("pharmalog_dismissed_update_version", updateInfo.latestVersion);
        setHidden(true);
    };

    const openInstaller = (info) => {
        if (!info?.installerUrl) {
            alert("Güncelleme indirme adresi manifest dosyasında tanımlı değil.");
            return;
        }
        window.open(info.installerUrl, "_blank", "noopener,noreferrer");
    };

    const handleDownload = () => {
        openInstaller(updateInfo);
    };

    return (
        <div className="mx-4 mb-3 space-y-2">
            {updateInfo && !hidden && (
                <div className="rounded-2xl border border-amber-200 dark:border-amber-800/60 bg-amber-50 dark:bg-amber-900/20 p-3 shadow-sm">
                    <div className="flex items-start gap-2">
                        <div className="mt-0.5 rounded-lg bg-amber-100 dark:bg-amber-900/60 p-1.5 text-amber-700 dark:text-amber-300">
                            <Download size={16} />
                        </div>
                        <div className="min-w-0 flex-1">
                            <div className="flex items-start justify-between gap-2">
                                <p className="text-sm font-extrabold text-slate-900 dark:text-white">Güncelleme var</p>
                                <button onClick={handleLater} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200" title="Daha sonra">
                                    <X size={14} />
                                </button>
                            </div>
                            <p className="mt-0.5 text-xs font-medium text-slate-600 dark:text-slate-300">
                                {updateInfo.currentVersion} → {updateInfo.latestVersion}
                            </p>
                            {updateInfo.notes?.length > 0 && (
                                <p className="mt-1 line-clamp-2 text-xs text-slate-500 dark:text-slate-400">
                                    {updateInfo.notes[0]}
                                </p>
                            )}
                            <div className="mt-3 flex gap-2">
                                <button
                                    onClick={handleDownload}
                                    className="flex-1 rounded-lg bg-amber-500 px-3 py-2 text-xs font-bold text-white hover:bg-amber-600"
                                >
                                    Şimdi İndir
                                </button>
                                <button
                                    onClick={handleLater}
                                    className="rounded-lg bg-white/70 px-3 py-2 text-xs font-bold text-slate-600 hover:bg-white dark:bg-slate-800/70 dark:text-slate-300 dark:hover:bg-slate-800"
                                >
                                    Daha Sonra
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
            <button
                onClick={() => checkForUpdate(true)}
                disabled={loading}
                className="flex w-full items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-white/70 px-3 py-2 text-[11px] font-bold text-slate-600 shadow-sm hover:bg-white disabled:opacity-60 dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-300 dark:hover:bg-slate-800"
            >
                <RefreshCw size={12} className={loading ? "animate-spin" : ""} />
                Güncellemeleri Kontrol Et
            </button>
        </div>
    );
}
