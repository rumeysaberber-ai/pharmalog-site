import { BrowserRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { AuthProvider, useAuth } from "./context/AuthContext";
import Layout from "./components/Layout";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Patients from "./pages/Patients";
import PatientDetail from "./pages/PatientDetail";
import Products from "./pages/Products";
import Companies from "./pages/Companies";
import CompanyDetail from "./pages/CompanyDetail";
import CareTracking from "./pages/CareTracking";
import Settings from "./pages/Settings";
import Profile from "./pages/Profile";
import DesignPreview from "./pages/DesignPreview";
import DashboardModern from "./pages/DashboardModern";
import LayoutModern from "./components/LayoutModern";
import { Loader2 } from "lucide-react";
import PrintWrapper from "./pages/PrintWrapper";
import PrintableDetailedForm from "./components/PrintableDetailedForm";

import PrintableDermoForm from "./components/PrintableDermoForm";
import PublicBooking from "./pages/PublicBooking";

function RequireAuth({ children }) {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-slate-900">
        <Loader2 className="h-10 w-10 text-rose-500 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return children;
}

import { ThemeProvider } from "./context/ThemeContext";

import { DataService } from "./lib/data";
import { useEffect } from "react";

function App() {
  // Global Auto-Sync (Every 3 seconds)
  useEffect(() => {
    console.log("Starting Global Auto-Sync...");
    const stopSync = DataService.startAutoSync();
    return () => {
      stopSync();
    };
  }, []);

  return (
    <ThemeProvider>
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<Login />} />

            {/* Print Routes - No Layout */}
            <Route path="/print/detailed" element={
              <PrintWrapper title="Detaylı Anamnez Formu">
                <PrintableDetailedForm isEmpty={true} />
              </PrintWrapper>
            } />
            <Route path="/print/dermo" element={
              <PrintWrapper title="Dermo Anamnez Formu">
                <PrintableDermoForm isEmpty={true} />
              </PrintWrapper>
            } />

            <Route path="/dashboard-new" element={
              <RequireAuth>
                <LayoutModern>
                  <DashboardModern />
                </LayoutModern>
              </RequireAuth>
            } />

            {/* Public Booking Route */}
            <Route path="/book/:companyId/:eventId" element={<PublicBooking />} />

            <Route path="/*" element={
              <RequireAuth>
                <Layout>
                  <Routes>
                    <Route path="/" element={<Dashboard />} />
                    <Route path="/patients" element={<Patients />} />
                    <Route path="/patients/:id" element={<PatientDetail />} />
                    <Route path="/products" element={<Products />} />
                    <Route path="/companies" element={<Companies />} />
                    <Route path="/companies/:id" element={<CompanyDetail />} />
                    <Route path="/care-tracking" element={<CareTracking />} />
                    <Route path="/settings" element={<Settings />} />
                    <Route path="/profile" element={<Profile />} />
                    <Route path="/design-preview" element={<DesignPreview />} />
                  </Routes>
                </Layout>
              </RequireAuth>
            } />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
