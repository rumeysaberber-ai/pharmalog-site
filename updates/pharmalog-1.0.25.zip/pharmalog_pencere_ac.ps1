param(
    [string]$AppUrl = "http://localhost:3001"
)

$ErrorActionPreference = "Stop"

$projectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$cacheBuster = Get-Random -Minimum 100000 -Maximum 999999
if ($AppUrl.Contains("?")) {
    $AppUrl = "$AppUrl&v=$cacheBuster"
} else {
    $AppUrl = "$AppUrl?v=$cacheBuster"
}

$browserProfile = Join-Path $env:LOCALAPPDATA "PharmaLog\BrowserProfile"
New-Item -ItemType Directory -Path $browserProfile -Force | Out-Null

$edgeCandidates = @(
    (Join-Path ${env:ProgramFiles(x86)} "Microsoft\Edge\Application\msedge.exe"),
    (Join-Path $env:ProgramFiles "Microsoft\Edge\Application\msedge.exe")
) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }

$chromeCandidates = @(
    (Join-Path $env:ProgramFiles "Google\Chrome\Application\chrome.exe"),
    (Join-Path ${env:ProgramFiles(x86)} "Google\Chrome\Application\chrome.exe")
) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }

$browserExe = $edgeCandidates | Select-Object -First 1
if (-not $browserExe) {
    $browserExe = $chromeCandidates | Select-Object -First 1
}

if (-not $browserExe) {
    Start-Process $AppUrl
    exit
}

$iconCandidates = @(
    (Join-Path $projectDir "pharmalog.ico"),
    (Join-Path $projectDir "public\favicon.ico")
) | Where-Object { Test-Path -LiteralPath $_ }
$iconPath = $iconCandidates | Select-Object -First 1
if (-not $iconPath) {
    $iconPath = $browserExe
}

$shortcutPath = Join-Path $projectDir "PharmaLog Pencere.lnk"
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $browserExe
$shortcut.Arguments = "--app=`"$AppUrl`" --class=PharmaLog --user-data-dir=`"$browserProfile`" --disable-application-cache --disk-cache-size=1"
$shortcut.WorkingDirectory = $projectDir
$shortcut.IconLocation = $iconPath
$shortcut.WindowStyle = 1
$shortcut.Save()

Start-Process -FilePath $shortcutPath
