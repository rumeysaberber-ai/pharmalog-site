import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { parseISO, startOfToday, isBefore } from "date-fns";
import { Search, Plus, Building, Info, ArrowRight, Trash2, X, ArrowLeft, Pencil } from "lucide-react";
import { DataService } from "../lib/data";
import { cn, normalizeString } from "../lib/utils";

export default function Companies() {
    const [companies, setCompanies] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingCompany, setEditingCompany] = useState(null);
    const [formData, setFormData] = useState({ name: "", description: "" });

    useEffect(() => {
        DataService.getCompanies().then(setCompanies);
    }, []);

    const getClosestUpcomingDate = (company) => {
        if (!company.expertDays || company.expertDays.length === 0) return null;

        const today = startOfToday();

        // Filter for future or today's events and sort them
        const upcomingDays = company.expertDays
            .map(d => parseISO(d.date))
            .filter(date => !isBefore(date, today)) // Keep dates >= today
            .sort((a, b) => a - b);

        return upcomingDays.length > 0 ? upcomingDays[0] : null;
    };

    const filteredAndSortedCompanies = companies
        .filter(c => {
            const term = normalizeString(searchTerm);
            const name = normalizeString(c.name);
            return name.includes(term);
        })
        .sort((a, b) => {
            const dateA = getClosestUpcomingDate(a);
            const dateB = getClosestUpcomingDate(b);

            // 1. Both have upcoming dates -> Sort by date (asc)
            if (dateA && dateB) {
                return dateA - dateB;
            }

            // 2. Only A has upcoming date -> A comes first
            if (dateA) return -1;

            // 3. Only B has upcoming date -> B comes first
            if (dateB) return 1;

            // 4. Neither has upcoming date -> Sort by name (asc)
            return a.name.localeCompare(b.name, 'tr', { sensitivity: 'base' });
        });

    const handleAddClick = () => {
        setEditingCompany(null);
        setFormData({ name: "", description: "" });
        setIsModalOpen(true);
    };

    const handleEditClick = (e, company) => {
        e.preventDefault();
        e.stopPropagation(); // Prevent navigation to detail
        setEditingCompany(company);
        setFormData({ name: company.name, description: company.description || "" });
        setIsModalOpen(true);
    };

    const handleSaveCompany = async (e) => {
        e.preventDefault();
        if (!formData.name) return;

        if (editingCompany) {
            await DataService.updateCompany(editingCompany.id, formData);
        } else {
            await DataService.addCompany(formData);
        }

        const allCompanies = await DataService.getCompanies();
        setCompanies(allCompanies);
        setIsModalOpen(false);
        setFormData({ name: "", description: "" });
        setEditingCompany(null);
    };

    const handleDeleteCompany = async (e, id) => {
        e.preventDefault();
        e.stopPropagation();
        if (window.confirm("Bu firmayı silmek istediğinize emin misiniz?")) {
            const updated = await DataService.deleteCompany(id);
            setCompanies(updated);
        }
    };

    return (
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
            {/* Header */}
            <Link to="/" className="inline-flex items-center text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 transition-colors mb-6 group">
                <div className="p-2 rounded-full bg-white dark:bg-slate-800 group-hover:bg-indigo-50 dark:group-hover:bg-indigo-900/30 mr-2 transition-colors shadow-sm">
                    <ArrowLeft size={18} />
                </div>
                <span className="font-medium">Ana Ekrana Dön</span>
            </Link>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 mb-8">
                <div>
                    <h1 className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-slate-900 to-slate-700 dark:from-white dark:to-slate-300">
                        Firmalar & Günler
                    </h1>
                    <p className="text-slate-500 dark:text-slate-400 mt-1 font-medium">Anlaşmalı firmalar ve uzman günü etkinlikleri.</p>
                </div>

                <button
                    onClick={handleAddClick}
                    className="bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 text-white px-5 py-2.5 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-lg shadow-teal-500/30 hover:shadow-teal-500/50 hover:-translate-y-0.5"
                >
                    <Plus size={20} strokeWidth={3} />
                    Yeni Firma
                </button>
            </div>

            {/* Search */}
            <div className="flex flex-col sm:flex-row gap-4 mb-8 p-4 bg-white/40 dark:bg-slate-900/40 backdrop-blur-xl rounded-2xl border border-white/20 dark:border-slate-800 shadow-sm">
                <div className="relative flex-1">
                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <Search className="h-5 w-5 text-slate-400" />
                    </div>
                    <input
                        type="text"
                        className="block w-full pl-11 pr-4 py-3 bg-white/60 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 rounded-xl leading-5 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 transition-all shadow-sm backdrop-blur-sm"
                        placeholder="Firma ara..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
            </div>

            {/* List */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredAndSortedCompanies.length > 0 ? (
                    filteredAndSortedCompanies.map((company) => (
                        <Link to={`/companies/${company.id}`} key={company.id} className="block group">
                            <div className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-xl rounded-2xl border border-white/40 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-black/20 p-6 hover:scale-[1.02] hover:shadow-2xl transition-all hover:border-teal-500/30 relative overflow-hidden">
                                <div className="absolute top-0 right-0 -mt-8 -mr-8 w-32 h-32 bg-gradient-to-br from-teal-500/10 to-indigo-500/10 rounded-full blur-2xl group-hover:bg-teal-500/20 transition-all"></div>

                                <div className="flex items-start justify-between mb-4 relative z-10">
                                    <div className="h-14 w-14 rounded-2xl bg-white dark:bg-slate-800 shadow-sm border border-slate-100 dark:border-slate-700 flex items-center justify-center text-teal-600 dark:text-teal-400 group-hover:bg-teal-50 dark:group-hover:bg-teal-900/30 group-hover:rotate-6 transition-all duration-300">
                                        <Building size={28} />
                                    </div>
                                    <div className="flex bg-white dark:bg-slate-800 rounded-full shadow-sm border border-slate-100 dark:border-slate-700 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <button
                                            onClick={(e) => handleEditClick(e, company)}
                                            className="p-2 text-slate-400 hover:text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-l-full transition-colors border-r border-slate-100 dark:border-slate-700"
                                            title="Düzenle"
                                        >
                                            <Pencil size={18} />
                                        </button>
                                        <button
                                            onClick={(e) => handleDeleteCompany(e, company.id)}
                                            className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-r-full transition-colors"
                                            title="Sil"
                                        >
                                            <Trash2 size={18} />
                                        </button>
                                    </div>
                                </div>
                                <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2 group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors relative z-10">
                                    {company.name}
                                </h3>
                                {company.description && (
                                    <p className="text-sm text-slate-500 dark:text-slate-400 line-clamp-2 mb-4 relative z-10 font-medium">
                                        {company.description}
                                    </p>
                                )}
                                <div className="flex items-center text-xs font-bold text-slate-400 uppercase tracking-widest mt-auto relative z-10">
                                    <span className="bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded-md">{company.expertDays?.length || 0} ETKİNLİK</span>
                                    <ArrowRight size={16} className="ml-auto opacity-0 group-hover:opacity-100 transition-all -translate-x-2 group-hover:translate-x-0 text-teal-500" />
                                </div>
                            </div>
                        </Link>
                    ))
                ) : (
                    <div className="col-span-full p-12 text-center bg-white/40 dark:bg-slate-900/40 backdrop-blur-xl rounded-3xl border border-white/20 dark:border-slate-700 border-dashed flex flex-col items-center justify-center">
                        <div className="w-16 h-16 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mb-4">
                            <Info className="h-8 w-8 text-slate-400 dark:text-slate-500" />
                        </div>
                        <h3 className="text-lg font-bold text-slate-900 dark:text-white">Firma Bulunamadı</h3>
                        <p className="text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto">
                            Henüz hiç firma eklenmemiş veya arama kriterlerine uygun sonuç bulunamadı.
                        </p>
                    </div>
                )}
            </div>

            {/* Modal - Add/Edit */}
            {isModalOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-300">
                    <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-300 border border-white/20 dark:border-slate-800 ring-1 ring-black/5">
                        <div className="px-8 py-6 border-b border-slate-100 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-sm flex items-center justify-between">
                            <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                                {editingCompany ? "Firmayı Düzenle" : "Yeni Firma Ekle"}
                            </h3>
                            <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 bg-slate-100 dark:bg-slate-800 p-2 rounded-full hover:bg-slate-200 transition-colors">
                                <X size={20} />
                            </button>
                        </div>
                        <form onSubmit={handleSaveCompany} className="p-8 space-y-6">
                            <div>
                                <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Firma Adı</label>
                                <input
                                    required
                                    type="text"
                                    className="w-full rounded-xl border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white border px-4 py-3 focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500 transition-all font-medium placeholder:font-normal"
                                    placeholder="Örn: Loreal, Bioderma..."
                                    value={formData.name}
                                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Açıklama</label>
                                <textarea
                                    rows={3}
                                    className="w-full rounded-xl border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white border px-4 py-3 focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500 transition-all font-medium placeholder:font-normal"
                                    placeholder="Firma hakkında kısa notlar..."
                                    value={formData.description}
                                    onChange={e => setFormData({ ...formData, description: e.target.value })}
                                />
                            </div>
                            <div className="pt-2 flex justify-end gap-3">
                                <button type="button" onClick={() => setIsModalOpen(false)} className="px-6 py-3 text-slate-600 dark:text-slate-400 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors">İptal</button>
                                <button type="submit" className="px-6 py-3 bg-gradient-to-r from-teal-500 to-emerald-600 text-white rounded-xl font-bold hover:shadow-lg hover:shadow-teal-500/30 transition-all hover:-translate-y-0.5">
                                    {editingCompany ? "Güncelle" : "Kaydet"}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}
