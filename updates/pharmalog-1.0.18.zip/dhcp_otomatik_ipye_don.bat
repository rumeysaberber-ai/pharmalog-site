@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0dhcp_otomatik_ipye_don.ps1"
pause
