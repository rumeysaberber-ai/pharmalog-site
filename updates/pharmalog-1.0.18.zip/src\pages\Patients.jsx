
import { useState, useEffect, useMemo, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Search, Plus, User, Info, ArrowRight, Trash2, Filter, X, ArrowUpDown, Calendar, ChevronDown, Check, Phone, ArrowUpAz, ArrowDownZa, Clock, History, ArrowLeft, Upload, Package, CalendarPlus, FileText, Activity, Ban, Shield } from "lucide-react";
import { DataService } from "../lib/data";
import { cn, normalizeString, formatPhoneNumber } from "../lib/utils";
import { canUseCommercialChannel, getKvkkConsent, isKvkkPending } from "../lib/compliance";
import BulkImportModal from "../components/BulkImportModal";
import { format } from "date-fns";
import { tr } from "date-fns/locale";

import DetailedAnamnesisModal from "../components/DetailedAnamnesisModal";
import DermoAnamnesisModal from "../components/DermoAnamnesisModal";

const CATEGORY_OPTIONS = ["Yeni Danışan", "Kontrol", "VIP", "Tamamlandı", "Diğer"];
const REPORT_PATIENTS_GROUP_ID = "REPORT_PATIENTS";
const REPORT_PATIENTS_GROUP_LABEL = "Raporlu Danışanlar";

export default function Patients() {
    const navigate = useNavigate();
    const [patients, setPatients] = useState([]);
    const [companies, setCompanies] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");
    const [selectedCategory, setSelectedCategory] = useState(() => sessionStorage.getItem("patientCategory") || "Tümü");
    const [selectedInterestedCompany, setSelectedInterestedCompany] = useState(() => sessionStorage.getItem("patientInterestedCompany") || "Tümü");
    const [currentPage, setCurrentPage] = useState(() => parseInt(sessionStorage.getItem("patientCurrentPage")) || 1);

    useEffect(() => {
        sessionStorage.setItem("patientCategory", selectedCategory);
    }, [selectedCategory]);

    useEffect(() => {
        sessionStorage.setItem("patientInterestedCompany", selectedInterestedCompany);
    }, [selectedInterestedCompany]);

    useEffect(() => {
        sessionStorage.setItem("patientCurrentPage", currentPage);
    }, [currentPage]);

    // Sort State
    const [sortOption, setSortOption] = useState(() => {
        return localStorage.getItem("patientSortOption") || "date_desc";
    });

    useEffect(() => {
        localStorage.setItem("patientSortOption", sortOption);
    }, [sortOption]);
    const [isSortDropdownOpen, setIsSortDropdownOpen] = useState(false);

    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [isBulkImportModalOpen, setIsBulkImportModalOpen] = useState(false);

    const [isDetailedAnamnesisModalOpen, setIsDetailedAnamnesisModalOpen] = useState(false);
    const [isDermoAnamnesisModalOpen, setIsDermoAnamnesisModalOpen] = useState(false);

    // Interest Management State
    const [isInterestModalOpen, setIsInterestModalOpen] = useState(false);
    const [selectedPatientForInterest, setSelectedPatientForInterest] = useState(null);
    const [tempInterestedCompanies, setTempInterestedCompanies] = useState([]);

    // Invite State
    const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);
    const [selectedPatientForInvite, setSelectedPatientForInvite] = useState(null);
    const [upcomingEvents, setUpcomingEvents] = useState([]);

    // Aggregate company interest counts for the filter dropdown
    const companyInterestCounts = useMemo(() => {
        const counts = {};
        patients.forEach(p => {
            // Count "Do Not Call" patients
            if (p.isDoNotCall) {
                counts['DO_NOT_CALL'] = (counts['DO_NOT_CALL'] || 0) + 1;
            }

            // Count "No Interest" patients (Not Do Not Call AND No Interests)
            // Note: If they have "Do Not Call", they usually aren't counted as "No Interest" because they are explicitly opted out.
            // But if user wants "Empty" list, we might exclude "Do Not Call" from it or include it. 
            // Usually "Empty" means "Potentials we haven't assigned yet". So exclude Do Not Call.
            if (!p.isDoNotCall && (!p.interestedCompanies || p.interestedCompanies.length === 0)) {
                counts['NO_COMPANY'] = (counts['NO_COMPANY'] || 0) + 1;
            }

            if (p.interestedCompanies) {
                p.interestedCompanies.forEach(cId => {
                    counts[cId] = (counts[cId] || 0) + 1;
                });
            }
        });
        return counts;
    }, [patients]);

    // Scroll Restoration Effect
    useEffect(() => {
        // Wait for patients to load and render
        if (patients.length > 0) {
            const lastViewedId = sessionStorage.getItem("lastViewedPatientId");
            if (lastViewedId) {
                // Small timeout to ensure DOM is ready
                setTimeout(() => {
                    const element = document.getElementById(`patient-${lastViewedId}`);
                    if (element) {
                        element.scrollIntoView({ behavior: 'auto', block: 'center' });
                        // Highlight effect (optional)
                        element.classList.add("bg-teal-50");
                        setTimeout(() => element.classList.remove("bg-teal-50"), 2000);

                        // Clear it so it doesn't scroll on next refresh/filter
                        sessionStorage.removeItem("lastViewedPatientId");
                    }
                }, 100);
            }
        }
    }, [patients, currentPage]); // Re-run when patients load or page changes

    const handleOpenInterestModal = (patient) => {
        setSelectedPatientForInterest(patient);
        setTempInterestedCompanies(patient.interestedCompanies || []);
        setIsInterestModalOpen(true);
    };

    const handleSaveInterests = async () => {
        if (!selectedPatientForInterest) return;

        // Sanitize: ensure only IDs that actually exist in the Companies list are saved
        // This fixes "orphaned" IDs or type mismatch issues by strictly matching valid IDs
        const validIds = tempInterestedCompanies.filter(tempId =>
            companies.some(c => String(c.id) === String(tempId))
        );

        await DataService.updatePatient(selectedPatientForInterest.id, {
            interestedCompanies: validIds
        });

        // Update local state immediately
        setPatients(prev => prev.map(p =>
            p.id === selectedPatientForInterest.id
                ? { ...p, interestedCompanies: validIds }
                : p
        ));

        setIsInterestModalOpen(false);
    };

    const handleSelectInterestAndClose = async (companyId) => {
        if (!selectedPatientForInterest) return;

        // Current state
        const currentInterests = selectedPatientForInterest.interestedCompanies || [];
        const exists = currentInterests.some(id => String(id) === String(companyId));

        // New list
        let newInterests;
        if (exists) {
            newInterests = currentInterests.filter(id => String(id) !== String(companyId));
        } else {
            newInterests = [...currentInterests, companyId];
        }

        // Save immediately
        await DataService.updatePatient(selectedPatientForInterest.id, {
            interestedCompanies: newInterests
        });

        // Update local state
        setPatients(prev => prev.map(p =>
            p.id === selectedPatientForInterest.id
                ? { ...p, interestedCompanies: newInterests }
                : p
        ));

        // We don't close automatically anymore to allow multiple selects if desired, 
        // OR we keep it closing. The user didn't specify, but for 'Do Not Call' we might want to stay open.
        // But the previous behavior was closing? Let's check. 
        // The previous function name is `handleSelectInterestAndClose`. 
        // I will keep it closing for company selection to minimize friction, 
        // but for Do Not Call I will use a separate handler.
        setIsInterestModalOpen(false);
    };

    const handleToggleDoNotCall = async () => {
        if (!selectedPatientForInterest) return;

        const newValue = !selectedPatientForInterest.isDoNotCall;
        const patientUpdates = newValue
            ? { isDoNotCall: true, interestedCompanies: [] }
            : { isDoNotCall: false };

        await DataService.updatePatient(selectedPatientForInterest.id, patientUpdates);

        setPatients(prev => prev.map(p =>
            p.id === selectedPatientForInterest.id
                ? {
                    ...p,
                    isDoNotCall: newValue,
                    interestedCompanies: newValue ? [] : (p.interestedCompanies || [])
                }
                : p
        ));

        // Update the selected patient object too so the modal UI updates instantly
        setSelectedPatientForInterest(prev => ({
            ...prev,
            isDoNotCall: newValue,
            interestedCompanies: newValue ? [] : (prev.interestedCompanies || [])
        }));
    };

    const handleOpenInviteModal = async (patient) => {
        setSelectedPatientForInvite(patient);
        const events = await DataService.getUpcomingExpertDays();
        setUpcomingEvents(events);
        setIsInviteModalOpen(true);
    };

    const handleInviteConfirm = async (event) => {
        if (!selectedPatientForInvite) return;

        const isAlreadyInvited = event.invitations?.some(i => i.patientId === selectedPatientForInvite.id);

        if (isAlreadyInvited) {
            // REMOVE Logic
            await DataService.removePatientFromExpertDay(event.companyId, event.id, selectedPatientForInvite.id);

            // Update local state (Remove)
            setUpcomingEvents(prev => prev.map(e => {
                if (e.id === event.id) {
                    return {
                        ...e,
                        invitations: e.invitations.filter(i => i.patientId !== selectedPatientForInvite.id)
                    };
                }
                return e;
            }));
        } else {
            // ADD Logic
            await DataService.addPatientToExpertDay(event.companyId, event.id, selectedPatientForInvite.id);

            // Update local state (Add)
            setUpcomingEvents(prev => prev.map(e => {
                if (e.id === event.id) {
                    const newInvite = { patientId: selectedPatientForInvite.id };
                    return { ...e, invitations: [newInvite, ...(e.invitations || [])] };
                }
                return e;
            }));
        }

        // Background refresh for data consistency
        const [pts, comps] = await Promise.all([
            DataService.getPatients(),
            DataService.getCompanies()
        ]);
        setPatients(pts);
        setCompanies(comps);
        // Do NOT close modal, so user sees the toggle
        // setIsInviteModalOpen(false); 
        setIsInviteModalOpen(false); // Auto-close as requested 
    };

    const getPatientInvitations = (patientId) => {
        try {
            const invites = [];
            const today = new Date();
            today.setHours(0, 0, 0, 0);

            if (!Array.isArray(companies)) return [];

            companies.forEach(c => {
                if (Array.isArray(c.expertDays)) {
                    c.expertDays.forEach(d => {
                        if (!d) return;
                        try {
                            const eventDate = new Date(d.date);
                            // Only show future or today's events on the card
                            // Validate date and invitations array
                            if (!isNaN(eventDate.getTime()) &&
                                eventDate >= today &&
                                Array.isArray(d.invitations) &&
                                d.invitations.some(i => i && i.patientId === patientId)) {

                                invites.push({
                                    companyId: c.id,
                                    companyName: c.name,
                                    date: d.date,
                                    dayId: d.id
                                });
                            }
                        } catch (e) {
                            // Ignore individual malformed entries
                        }
                    })
                }
            });
            return invites;
        } catch (error) {
            console.error("Error calculating invitations:", error);
            return [];
        }
    };

    // Form State
    const [formData, setFormData] = useState({
        fullName: "",
        age: "",
        phone: "",
        category: CATEGORY_OPTIONS[0],
        description: "",
        anamnesis: "",
        birthDate: "",
        detailedAnamnesis: null,
        dermoAnamnesis: null,
        kvkkConsent: {
            enlightenmentDone: false,
            explicitConsent: false,
            dataProcessing: false,
            sms: false,
            phoneCall: false,
            email: false,
            iysResponsibilityAccepted: false,
            consentDate: "",
            consentSource: "Eczane içi bilgilendirme"
        }
    });

    const dateInputRef = useRef(null);

    useEffect(() => {
        const load = async () => {
            const [pts, comps] = await Promise.all([
                DataService.getPatients(),
                DataService.getCompanies()
            ]);
            setPatients(pts);
            setCompanies(comps);
        };
        load();

        // Auto Sync
        const cleanup = DataService.startAutoSync((newData) => {
            // Only update patients to avoid flickering everything
            if (newData?.patients) setPatients(newData.patients);
            if (newData?.companies) setCompanies(newData.companies);
        });

        return () => {
            if (cleanup) cleanup();
        };
    }, []);



    // Helper for smart sorting (ignores symbols like ☐)
    const cleanSortName = (name) => {
        // Remove anything that is NOT a letter from the start
        // Unicode aware: [^\p{L}] means "not a letter"
        return normalizeString(name).replace(/^[^\p{L}]+/u, '');
    };

    const filteredPatients = patients.filter(p => {
        const term = normalizeString(searchTerm);
        const fullName = normalizeString(p.fullName);
        const description = normalizeString(p.description);

        // Multi-word search logic
        const searchWords = term.split(/\s+/).filter(word => word.length > 0);

        // Prepare a searchable blob for the patient
        // We join all searchable text into one normalized string for efficiency
        let searchBlob = `${fullName} ${p.phone} ${description} ${normalizeString(p.anamnesis || "")}`;

        // Add Visit Notes & Products
        if (p.visits) {
            p.visits.forEach(v => {
                searchBlob += ` ${normalizeString(v.note || "")}`;
                if (v.products) {
                    v.products.forEach(prod => {
                        searchBlob += ` ${normalizeString(prod.productName || "")}`;
                    });
                }
            });
        }

        // Add Legacy/Direct Products
        if (p.products) {
            p.products.forEach(prod => {
                searchBlob += ` ${normalizeString(prod.productName || "")}`;
            });
        }

        const matchesSearch = searchWords.every(word => searchBlob.includes(word));
        const matchesCategory = selectedCategory === "Tümü" || p.category === selectedCategory;

        const matchesCompanyInterest = selectedInterestedCompany === "Tümü" || (selectedInterestedCompany === "DO_NOT_CALL" ? p.isDoNotCall : (p.interestedCompanies && p.interestedCompanies.includes(selectedInterestedCompany)));

        let finalMatch = matchesSearch && matchesCategory;

        // Specialized Logic for Interest Filter
        if (selectedInterestedCompany === "Tümü") {
            // Keep existing match
        } else if (selectedInterestedCompany === "DO_NOT_CALL") {
            finalMatch = finalMatch && p.isDoNotCall;
        } else if (selectedInterestedCompany === "NO_COMPANY") {
            finalMatch = finalMatch && !p.isDoNotCall && (!p.interestedCompanies || p.interestedCompanies.length === 0);
        } else {
            // Standard Company ID
            finalMatch = finalMatch && (p.interestedCompanies && p.interestedCompanies.includes(selectedInterestedCompany));
        }

        return finalMatch;

    }).sort((a, b) => {
        if (sortOption === "name_asc") {
            return cleanSortName(a.fullName).localeCompare(cleanSortName(b.fullName), 'tr');
        }
        if (sortOption === "name_desc") {
            return cleanSortName(b.fullName).localeCompare(cleanSortName(a.fullName), 'tr');
        }
        if (sortOption === "date_asc") {
            return new Date(a.updatedAt || a.createdAt || 0) - new Date(b.updatedAt || b.createdAt || 0);
        }
        if (sortOption === "date_desc") {
            return new Date(b.updatedAt || b.createdAt || 0) - new Date(a.updatedAt || a.createdAt || 0);
        }
        return 0;
    });

    const ITEMS_PER_PAGE = 50;

    // Reset page ONLY if search/filters change significantly AND we are past the result count
    // But since we want persistence, we ideally keep the page if results exist
    useEffect(() => {
        // If data hasn't loaded yet, do NOT reset the page. 
        // This preserves the session storage value during initial mount.
        if (patients.length === 0) return;

        const maxPage = Math.ceil(filteredPatients.length / ITEMS_PER_PAGE) || 1;
        if (currentPage > maxPage) {
            setCurrentPage(1);
        }
    }, [searchTerm, selectedCategory, selectedInterestedCompany, filteredPatients.length, patients.length]);

    const totalPages = Math.ceil(filteredPatients.length / ITEMS_PER_PAGE);
    const currentPatients = filteredPatients.slice(
        (currentPage - 1) * ITEMS_PER_PAGE,
        currentPage * ITEMS_PER_PAGE
    );

    const handleDeletePatient = async (e, id) => {
        e.preventDefault(); // Prevent link navigation
        e.stopPropagation();
        if (window.confirm("Bu danışanı silmek istediğinize emin misiniz?")) {
            const updated = await DataService.deletePatient(id);
            setPatients(updated);
        }
    };

    const handleDeleteAllPatients = async () => {
        if (window.confirm("DİKKAT! Tüm danışan kayıtları SİLİNECEK. Bu işlem geri alınamaz!\n\nOnaylıyor musunuz?")) {
            // İkinci bir güvenlik onayı
            if (window.confirm("Son kez soruyorum: Tüm danışanları gerçekten silmek istiyor musunuz?")) {
                const updated = await DataService.deleteAllPatients();
                setPatients(updated);
            }
        }
    };

    const handleSaveDetailedAnamnesis = (data) => {
        setFormData(prev => ({ ...prev, detailedAnamnesis: data }));
        setIsDetailedAnamnesisModalOpen(false);
    };

    const handleSaveDermoAnamnesis = (data) => {
        setFormData(prev => ({ ...prev, dermoAnamnesis: data }));
        setIsDermoAnamnesisModalOpen(false);
    };

    const sendIysConsentsForPatient = async (patient) => {
        const consent = getKvkkConsent(patient);
        const consentTypes = [
            ['sms', 'MESAJ'],
            ['phoneCall', 'ARAMA'],
            ['email', 'EPOSTA']
        ].filter(([key]) => consent[key]);

        if (consentTypes.length === 0) return;

        const blockedTypes = consentTypes
            .filter(([, type]) => !canUseCommercialChannel(patient, type))
            .map(([, type]) => type);

        if (blockedTypes.length > 0) {
            alert(`İYS gönderimi yapılmadı.\n\nTicari ileti için önce KVKK aydınlatması, açık rıza ve ilgili iletişim izni işaretlenmelidir.\n\nEngellenen izinler: ${blockedTypes.join(', ')}`);
            return;
        }

        const failures = [];
        for (const [, type] of consentTypes) {
            const recipient = type === 'EPOSTA' ? patient.email : patient.phone;
            if (!recipient) {
                failures.push(`${type}: Alıcı bilgisi yok`);
                continue;
            }

            try {
                await DataService.sendIysConsent({
                    patientId: patient.id,
                    phone: patient.phone,
                    email: patient.email,
                    recipient,
                    type,
                    status: 'ONAY',
                    source: 'HS_FIZIKSEL_ORTAM',
                    recipientType: 'BIREYSEL',
                    consentDate: consent.consentDate || new Date().toISOString()
                });
            } catch (error) {
                failures.push(`${type}: ${error.message}`);
            }
        }

        if (failures.length > 0) {
            alert(`Danışan kaydedildi ancak bazı İYS gönderimleri tamamlanamadı:\n\n${failures.join('\n')}\n\nAyarlar > İleti Yönetim Sistemi bölümünden bilgileri kontrol edebilirsiniz.`);
        }
    };

    const handleAddPatient = async (e) => {
        e.preventDefault();
        if (!formData.fullName) return;

        // Phone Validation (Optional)
        const cleanPhone = formData.phone.replace(/\D/g, '');
        if (cleanPhone.length > 0) {
            const phoneRegex = /^5\d{9}$/;
            if (!phoneRegex.test(cleanPhone)) {
                alert("Lütfen telefon numarasını '5xxxxxxxxx' formatında, başında 0 olmadan ve 10 hane olarak giriniz.");
                return;
            }

            // Duplicate Check (Only if phone is provided)
            if (await DataService.checkPhoneExists(formData.phone)) {
                alert("Bu telefon numarası ile kayıtlı bir danışan zaten mevcut!");
                return;
            }
        }

        const newPatient = await DataService.addPatient({
            ...formData,
            age: parseInt(formData.age) || 0,
            kvkkConsent: getKvkkConsent(formData)
        });

        await sendIysConsentsForPatient({
            ...formData,
            id: newPatient.id,
            age: parseInt(formData.age) || 0,
            kvkkConsent: getKvkkConsent(formData)
        });

        const allPatients = await DataService.getPatients();
        setPatients(allPatients); // Refresh full list to be safe
        setIsAddModalOpen(false);

        setFormData({
            fullName: "",
            age: "",
            phone: "",
            category: CATEGORY_OPTIONS[0],
            description: "",
            anamnesis: "",
            birthDate: "",
            detailedAnamnesis: null,
            dermoAnamnesis: null,
            kvkkConsent: {
                enlightenmentDone: false,
                explicitConsent: false,
                dataProcessing: false,
                sms: false,
                phoneCall: false,
                email: false,
                iysResponsibilityAccepted: false,
                consentDate: "",
                consentSource: "Eczane içi bilgilendirme"
            }
        });

        // Redirect to the new patient's detailed page
        navigate(`/patients/${newPatient.id}`);
    };



    return (
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
            {/* Header & Actions */}
            <Link to="/" className="inline-flex items-center text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 transition-colors mb-6 group">
                <div className="p-2 rounded-full bg-white dark:bg-slate-800 group-hover:bg-indigo-50 dark:group-hover:bg-indigo-900/30 mr-2 transition-colors shadow-sm">
                    <ArrowLeft size={18} />
                </div>
                <span className="font-medium">Ana Ekrana Dön</span>
            </Link>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 mb-8">
                <div>
                    <h1 className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-slate-900 to-slate-700 dark:from-white dark:to-slate-300">Danışanlar</h1>
                    <p className="text-slate-500 dark:text-slate-400 mt-1 font-medium">
                        Toplam {filteredPatients.length} kayıt listeleniyor. (Sayfa {currentPage} / {totalPages > 0 ? totalPages : 1})
                    </p>
                </div>

                <div className="flex gap-3">
                    <button
                        onClick={handleDeleteAllPatients}
                        className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm border border-red-200 dark:border-red-900/30 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 px-4 py-2.5 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-sm hover:shadow-md"
                        title="Tüm danışanları sil"
                    >
                        <Trash2 size={20} />
                        <span className="hidden sm:inline">Tümünü Sil</span>
                    </button>
                    <button
                        onClick={() => setIsBulkImportModalOpen(true)}
                        className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 px-4 py-2.5 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-sm hover:shadow-md"
                    >
                        <Upload size={20} />
                        <span className="hidden sm:inline">Toplu Kayıt</span>
                    </button>
                    <button
                        onClick={() => setIsAddModalOpen(true)}
                        className="bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 text-white px-5 py-2.5 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-lg shadow-teal-500/30 hover:shadow-teal-500/50 hover:-translate-y-0.5"
                    >
                        <Plus size={20} strokeWidth={3} />
                        <span className="hidden sm:inline">Yeni Danışan</span>
                    </button>
                </div>
            </div>

            <BulkImportModal
                isOpen={isBulkImportModalOpen}
                onClose={() => setIsBulkImportModalOpen(false)}
                onImportComplete={() => DataService.getPatients().then(setPatients)}
            />

            {/* Search Bar & Filters */}
            <div className="flex flex-col sm:flex-row gap-4 mb-6 p-4 bg-white/40 dark:bg-slate-900/40 backdrop-blur-xl rounded-2xl border border-white/20 dark:border-slate-800 shadow-sm">
                <div className="relative flex-1">
                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <Search className="h-5 w-5 text-slate-400" />
                    </div>
                    <input
                        type="text"
                        className="block w-full pl-11 pr-4 py-3 bg-white/60 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 rounded-xl leading-5 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 transition-all shadow-sm backdrop-blur-sm"
                        placeholder="İsim veya telefon ile arama yapın..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                    {searchTerm && (
                        <button
                            onClick={() => setSearchTerm("")}
                            className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600"
                        >
                            <X size={20} />
                        </button>
                    )}
                </div>
                <div className="flex flex-col sm:flex-row gap-2 sm:w-auto">
                    <div className="relative sm:w-48">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <Filter className="h-4 w-4 text-slate-500" />
                        </div>
                        <select
                            className="block w-full pl-9 pr-8 py-3 bg-white/60 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 rounded-xl leading-5 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 sm:text-sm shadow-sm appearance-none font-medium cursor-pointer hover:bg-white/80 dark:hover:bg-slate-900/80 transition-colors"
                            value={selectedCategory}
                            onChange={(e) => setSelectedCategory(e.target.value)}
                        >
                            <option value="Tümü">Tüm Kategoriler</option>
                            {CATEGORY_OPTIONS.map(opt => (
                                <option key={opt} value={opt}>{opt}</option>
                            ))}
                        </select>
                    </div>

                    <div className="relative sm:w-48">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <Package className="h-4 w-4 text-slate-500" />
                        </div>
                        <select
                            className="block w-full pl-9 pr-8 py-3 bg-white/60 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 rounded-xl leading-5 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 sm:text-sm shadow-sm appearance-none font-medium cursor-pointer hover:bg-white/80 dark:hover:bg-slate-900/80 transition-colors"
                            value={selectedInterestedCompany}
                            onChange={(e) => setSelectedInterestedCompany(e.target.value)}
                        >
                            <option value="Tümü">İlgilenilen Firma</option>
                            <option value="DO_NOT_CALL" className="text-red-600 dark:text-red-400 font-bold">
                                BİRDAHA ARANMAYACAK ({companyInterestCounts['DO_NOT_CALL'] || 0})
                            </option>
                            <option value="NO_COMPANY" className="text-slate-600 dark:text-slate-400 font-bold">
                                Firma Seçilmemiş ({companyInterestCounts['NO_COMPANY'] || 0})
                            </option>
                            <option value={REPORT_PATIENTS_GROUP_ID} className="text-amber-600 dark:text-amber-400 font-bold">
                                {REPORT_PATIENTS_GROUP_LABEL} ({companyInterestCounts[REPORT_PATIENTS_GROUP_ID] || 0})
                            </option>
                            {companies.map(c => (
                                <option key={c.id} value={c.id}>
                                    {c.name} ({companyInterestCounts[c.id] || 0})
                                </option>
                            ))}
                        </select>
                    </div>
                </div>
            </div>

            {/* Sort Dropdown */}
            <div className="flex justify-end mb-4 relative">
                <div className="relative">
                    <button
                        onClick={() => setIsSortDropdownOpen(!isSortDropdownOpen)}
                        className="flex items-center gap-2 px-4 py-2 bg-white/60 dark:bg-slate-800/60 backdrop-blur-sm border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-bold text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800 hover:shadow-md transition-all"
                    >
                        <ArrowUpDown size={16} className="text-slate-400" />
                        <span>Sıralama</span>
                        <ChevronDown size={14} className={cn("text-slate-400 transition-transform", isSortDropdownOpen && "rotate-180")} />
                    </button>

                    {isSortDropdownOpen && (
                        <div className="absolute right-0 top-full mt-2 w-64 bg-white dark:bg-slate-900 rounded-2xl shadow-xl shadow-slate-200/50 dark:shadow-black/50 border border-slate-100 dark:border-slate-800 py-3 z-20 animate-in fade-in zoom-in-95 duration-200">
                            <div className="px-3 py-2 text-xs font-semibold text-slate-400 uppercase tracking-wider">Sıralama Ölçütü</div>

                            <button
                                onClick={() => { setSortOption("name_asc"); setIsSortDropdownOpen(false); }}
                                className="w-full text-left px-4 py-2.5 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700/50 flex items-center justify-between group"
                            >
                                <span className="flex items-center gap-2">
                                    <ArrowUpDown size={16} className="text-slate-400 group-hover:text-teal-500" />
                                    Alfabetik (A-Z)
                                </span>
                                {sortOption === "name_asc" && <Check size={16} className="text-teal-600" />}
                            </button>

                            <button
                                onClick={() => { setSortOption("name_desc"); setIsSortDropdownOpen(false); }}
                                className="w-full text-left px-4 py-2.5 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700/50 flex items-center justify-between group"
                            >
                                <span className="flex items-center gap-2">
                                    <ArrowUpDown size={16} className="text-slate-400 group-hover:text-teal-500" />
                                    Alfabetik (Z-A)
                                </span>
                                {sortOption === "name_desc" && <Check size={16} className="text-teal-600" />}
                            </button>

                            <div className="my-1 border-t border-slate-100 dark:border-slate-700"></div>

                            <button
                                onClick={() => { setSortOption("date_desc"); setIsSortDropdownOpen(false); }}
                                className="w-full text-left px-4 py-2.5 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700/50 flex items-center justify-between group"
                            >
                                <span className="flex items-center gap-2">
                                    <Calendar size={16} className="text-slate-400 group-hover:text-teal-500" />
                                    Son İşlem (En Yeni)
                                </span>
                                {sortOption === "date_desc" && <Check size={16} className="text-teal-600" />}
                            </button>

                            <button
                                onClick={() => { setSortOption("date_asc"); setIsSortDropdownOpen(false); }}
                                className="w-full text-left px-4 py-2.5 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700/50 flex items-center justify-between group"
                            >
                                <span className="flex items-center gap-2">
                                    <Calendar size={16} className="text-slate-400 group-hover:text-teal-500" />
                                    Son İşlem (En Eski)
                                </span>
                                {sortOption === "date_asc" && <Check size={16} className="text-teal-600" />}
                            </button>
                        </div>
                    )}
                </div>
            </div>

            {/* Patient List */}
            <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl rounded-2xl border border-white/20 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-black/20 overflow-hidden flex flex-col">
                {currentPatients.length > 0 ? (
                    <>
                        <ul className="divide-y divide-slate-100/50 dark:divide-slate-800/50">
                            {currentPatients.map((patient) => {
                                return (
                                    <li key={patient.id} id={`patient-${patient.id}`} className="group hover:bg-indigo-50/30 dark:hover:bg-indigo-900/10 transition-colors bg-transparent border-b border-slate-100/50 dark:border-slate-800/50 last:border-0 relative">
                                        <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-teal-400 to-indigo-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                                        <Link
                                            to={`/patients/${patient.id}`}
                                            className="block p-6"
                                            onClick={() => sessionStorage.setItem("lastViewedPatientId", patient.id)}
                                        >
                                            <div className="flex items-center justify-between gap-4">
                                                {/* Left: Name & Info */}
                                                <div className="flex items-center gap-5 min-w-[300px]">
                                                    <div className="h-14 w-14 rounded-2xl bg-white dark:bg-slate-800 shadow-sm border border-slate-100 dark:border-slate-700 flex items-center justify-center text-slate-400 dark:text-slate-500 group-hover:bg-indigo-50 dark:group-hover:bg-indigo-900/30 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-all duration-300 flex-shrink-0">
                                                        <User size={28} />
                                                    </div>
                                                    <div>
                                                        <h3 className="text-lg font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                                                            {patient.fullName.replace(/^[^a-zA-Z\u00C0-\u017F]+/, '')}

                                                        </h3>
                                                        {patient.description && (
                                                            <p className="text-sm text-slate-600 dark:text-slate-400 italic mb-0.5 line-clamp-1">{patient.description}</p>
                                                        )}
                                                        <div className="flex items-center gap-3 text-sm text-slate-500 dark:text-slate-500">
                                                            {patient.age > 0 && (
                                                                <>
                                                                    <span>{patient.age} Yaş</span>
                                                                    <span>•</span>
                                                                </>
                                                            )}
                                                            <span className="flex items-center gap-1">
                                                                <Phone size={12} /> {formatPhoneNumber(patient.phone)}
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>

                                                {/* Center: Invitation Badges */}
                                                <div className="flex-1 flex flex-col items-end gap-2 px-4">
                                                    {isKvkkPending(patient) && (
                                                        <span
                                                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold border bg-amber-100 dark:bg-amber-900/30 border-amber-300 dark:border-amber-800 text-amber-700 dark:text-amber-300 whitespace-nowrap"
                                                            title={patient.integrationMeta?.importNote || "Eczane otomasyonundan aktarıldı"}
                                                        >
                                                            <Shield size={10} />
                                                            KVKK BEKLİYOR
                                                        </span>
                                                    )}

                                                    {/* Interested Companies */}
                                                    {patient.isDoNotCall ? (
                                                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold border bg-red-100 dark:bg-red-900/30 border-red-300 dark:border-red-800 text-red-600 dark:text-red-400 whitespace-nowrap">
                                                            <Ban size={10} />
                                                            BİRDAHA ARANMAYACAK
                                                        </span>
                                                    ) : (
                                                        patient.interestedCompanies && patient.interestedCompanies.length > 0 && (
                                                            <div className="flex flex-wrap gap-1.5 justify-end">
                                                                {patient.interestedCompanies.some(id => String(id) === REPORT_PATIENTS_GROUP_ID) && (
                                                                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium border bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-400 whitespace-nowrap">
                                                                        <FileText size={10} />
                                                                        {REPORT_PATIENTS_GROUP_LABEL}
                                                                    </span>
                                                                )}
                                                                {companies.filter(c => patient.interestedCompanies.some(id => String(id) === String(c.id))).map(comp => (
                                                                    <span
                                                                        key={comp.id}
                                                                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium border bg-pink-50 dark:bg-pink-900/20 border-pink-200 dark:border-pink-800 text-pink-700 dark:text-pink-400 whitespace-nowrap"
                                                                    >
                                                                        <Check size={10} />
                                                                        {comp.name}
                                                                    </span>
                                                                ))}
                                                            </div>
                                                        )
                                                    )}

                                                    {/* Invited Companies */}
                                                    {(() => {
                                                        const invites = getPatientInvitations(patient.id);
                                                        if (invites.length > 0) {
                                                            return (
                                                                <div className="flex flex-wrap gap-1.5 justify-end mt-1.5">
                                                                    {invites.map((inv, idx) => (
                                                                        <span
                                                                            key={idx}
                                                                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium border bg-indigo-50 dark:bg-indigo-900/20 border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-400 whitespace-nowrap"
                                                                            title={`${inv.companyName} - ${inv.date ? format(new Date(inv.date), "d MMMM yyyy", { locale: tr }) : ""}`}
                                                                        >
                                                                            <Calendar size={10} />
                                                                            {inv.companyName}
                                                                            <span className="opacity-70 ml-0.5">
                                                                                ({inv.date ? format(new Date(inv.date), "d MMM", { locale: tr }) : ""})
                                                                            </span>
                                                                        </span>
                                                                    ))}
                                                                </div>
                                                            );
                                                        }
                                                        return null;
                                                    })()}
                                                </div>

                                                {/* Right: Actions */}
                                                <div className="flex items-center gap-3 flex-shrink-0">
                                                    <div className="flex flex-col gap-2 items-end">
                                                        <button
                                                            onClick={(e) => {
                                                                e.preventDefault();
                                                                e.stopPropagation();
                                                                handleOpenInterestModal(patient);
                                                            }}
                                                            className="px-3 py-1.5 bg-pink-50 dark:bg-pink-900/10 text-pink-600 dark:text-pink-400 hover:bg-pink-100 dark:hover:bg-pink-900/20 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 w-full justify-center"
                                                        >
                                                            <Package size={16} />
                                                            <span className="hidden sm:inline">İlgilendiği Firma</span>
                                                        </button>
                                                        <button
                                                            onClick={(e) => {
                                                                e.preventDefault();
                                                                e.stopPropagation();
                                                                handleOpenInviteModal(patient);
                                                            }}
                                                            className="px-3 py-1.5 bg-indigo-50 dark:bg-indigo-900/10 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-900/20 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 w-full justify-center"
                                                        >
                                                            <CalendarPlus size={16} />
                                                            <span className="hidden sm:inline">Davet Et</span>
                                                        </button>
                                                    </div>
                                                    <button
                                                        onClick={(e) => handleDeletePatient(e, patient.id)}
                                                        className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-full transition-colors"
                                                        title="Danışanı Sil"
                                                    >
                                                        <Trash2 size={20} />
                                                    </button>
                                                    <div className="text-slate-400">
                                                        <ArrowRight size={20} />
                                                    </div>
                                                </div>
                                            </div>
                                        </Link>
                                    </li>
                                );
                            })}
                        </ul>
                        {/* Pagination Controls */}
                        {totalPages > 1 && (
                            <div className="px-6 py-4 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between bg-slate-50 dark:bg-slate-800/50 gap-4">
                                <button
                                    onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                                    disabled={currentPage === 1}
                                    className="px-3 py-1 text-sm font-medium text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md hover:bg-slate-50 dark:hover:bg-slate-600 disabled:opacity-50 disabled:cursor-not-allowed hidden sm:block"
                                >
                                    Önceki
                                </button>

                                <div className="flex items-center gap-1 overflow-x-auto no-scrollbar justify-center flex-1">
                                    {(() => {
                                        let pages = [];
                                        if (totalPages <= 7) {
                                            pages = Array.from({ length: totalPages }, (_, i) => i + 1);
                                        } else {
                                            if (currentPage <= 4) {
                                                pages = [1, 2, 3, 4, 5, '...', totalPages];
                                            } else if (currentPage >= totalPages - 3) {
                                                pages = [1, '...', totalPages - 4, totalPages - 3, totalPages - 2, totalPages - 1, totalPages];
                                            } else {
                                                pages = [1, '...', currentPage - 1, currentPage, currentPage + 1, '...', totalPages];
                                            }
                                        }

                                        return pages.map((page, idx) => (
                                            <button
                                                key={idx}
                                                onClick={() => typeof page === 'number' && setCurrentPage(page)}
                                                disabled={page === '...'}
                                                className={`min-w-[32px] h-8 flex items-center justify-center text-sm font-medium rounded-md transition-colors ${page === currentPage
                                                    ? "bg-teal-600 text-white border border-teal-600"
                                                    : page === '...'
                                                        ? "text-slate-400 cursor-default"
                                                        : "bg-white text-slate-600 border border-slate-300 hover:bg-slate-50"
                                                    }`}
                                            >
                                                {page}
                                            </button>
                                        ));
                                    })()}
                                </div>

                                <button
                                    onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                                    disabled={currentPage === totalPages}
                                    className="px-3 py-1 text-sm font-medium text-slate-600 bg-white border border-slate-300 rounded-md hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed hidden sm:block"
                                >
                                    Sonraki
                                </button>
                            </div>
                        )}
                    </>
                ) : (
                    <div className="p-12 text-center">
                        <Info className="mx-auto h-12 w-12 text-slate-300 mb-4" />
                        <h3 className="text-lg font-medium text-slate-900">Kayıt Bulunamadı</h3>
                        <p className="text-slate-500 mt-1">
                            {searchTerm ? "Aradığınız kriterlere uygun danışan bulunamadı." : "Henüz hiç danışan eklenmemiş."}
                        </p>
                    </div>
                )}
            </div>

            {/* Interest Management Modal */}
            {isInterestModalOpen && selectedPatientForInterest && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
                    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in duration-200 border border-slate-200 dark:border-slate-800">
                        <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 flex items-center justify-between">
                            <div>
                                <h3 className="text-lg font-semibold text-slate-900 dark:text-white">İlgilendiği Firmalar</h3>
                                <p className="text-sm text-slate-500 dark:text-slate-400">{selectedPatientForInterest.fullName}</p>
                            </div>
                            <button
                                onClick={() => setIsInterestModalOpen(false)}
                                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
                            >
                                <X size={20} />
                            </button>
                        </div>

                        <div className="p-4 max-h-[60vh] overflow-y-auto space-y-2">

                            {/* Do Not Call Toggle */}
                            <div
                                onClick={handleToggleDoNotCall}
                                className={cn(
                                    "w-full flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer mb-4",
                                    selectedPatientForInterest.isDoNotCall
                                        ? "bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-900/50 text-red-900 dark:text-red-400"
                                        : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-red-200 dark:hover:border-red-800 hover:bg-red-50/50 dark:hover:bg-red-900/10 text-slate-700 dark:text-slate-200"
                                )}
                            >
                                <span className="font-bold flex items-center gap-2">
                                    <Ban size={18} className={selectedPatientForInterest.isDoNotCall ? "text-red-600 dark:text-red-400" : "text-slate-400"} />
                                    <span className="text-red-600 dark:text-red-400">BİRDAHA ARANMAYACAK</span>
                                </span>
                                {selectedPatientForInterest.isDoNotCall && <Check size={18} className="text-red-600 dark:text-red-400" />}
                            </div>

                            <div className="h-px bg-slate-100 dark:bg-slate-800 my-2"></div>

                            <p className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-2 px-1">İlgilendiği Firmaları Seçin</p>
                            <div
                                onClick={() => handleSelectInterestAndClose(REPORT_PATIENTS_GROUP_ID)}
                                className={cn(
                                    "w-full flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer mb-2",
                                    selectedPatientForInterest.interestedCompanies?.some(id => String(id) === REPORT_PATIENTS_GROUP_ID)
                                        ? "bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-900/50 text-amber-900 dark:text-amber-300"
                                        : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-amber-300 dark:hover:border-amber-700 hover:bg-amber-50/40 dark:hover:bg-amber-900/10 text-slate-700 dark:text-slate-200"
                                )}
                            >
                                <span className="font-bold flex items-center gap-2">
                                    <FileText size={16} />
                                    {REPORT_PATIENTS_GROUP_LABEL}
                                </span>
                                {selectedPatientForInterest.interestedCompanies?.some(id => String(id) === REPORT_PATIENTS_GROUP_ID) && <Check size={18} className="text-amber-600 dark:text-amber-400" />}
                            </div>

                            {/* No Group Option */}
                            <div
                                onClick={async () => {
                                    if (!selectedPatientForInterest) return;
                                    await DataService.updatePatient(selectedPatientForInterest.id, {
                                        interestedCompanies: []
                                    });
                                    setPatients(prev => prev.map(p =>
                                        p.id === selectedPatientForInterest.id
                                            ? { ...p, interestedCompanies: [] }
                                            : p
                                    ));
                                    setIsInterestModalOpen(false);
                                }}
                                className={cn(
                                    "w-full flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer mb-2",
                                    (!selectedPatientForInterest.interestedCompanies || selectedPatientForInterest.interestedCompanies.length === 0) && !selectedPatientForInterest.isDoNotCall
                                        ? "bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-600 text-slate-900 dark:text-slate-100 ring-1 ring-slate-300 dark:ring-slate-600"
                                        : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-500 hover:bg-slate-50 dark:hover:bg-slate-700/50 text-slate-500 dark:text-slate-400"
                                )}
                            >
                                <span className="font-bold flex items-center gap-2">
                                    <div className={cn("p-1.5 rounded-full", (!selectedPatientForInterest.interestedCompanies || selectedPatientForInterest.interestedCompanies.length === 0) ? "bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300" : "bg-slate-100 dark:bg-slate-800 text-slate-400")}>
                                        <Ban size={16} />
                                    </div>
                                    Firma Seçilmemiş
                                </span>
                                {(!selectedPatientForInterest.interestedCompanies || selectedPatientForInterest.interestedCompanies.length === 0) && !selectedPatientForInterest.isDoNotCall && <Check size={18} className="text-slate-600 dark:text-slate-300" />}
                            </div>

                            {companies.length > 0 ? (
                                companies.map(company => {
                                    const isSelected = tempInterestedCompanies.some(id => String(id) === String(company.id));
                                    return (
                                        <div
                                            key={company.id}
                                            onClick={() => handleSelectInterestAndClose(company.id)}
                                            className={cn(
                                                "w-full flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer",
                                                isSelected
                                                    ? "bg-pink-50 dark:bg-pink-900/20 border-pink-200 dark:border-pink-900/50 text-pink-900 dark:text-pink-300"
                                                    : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-500 hover:bg-slate-50 dark:hover:bg-slate-700/50 dark:text-slate-200"
                                            )}
                                        >
                                            <span className="font-medium">{company.name}</span>
                                            {isSelected && <Check size={18} className="text-pink-600 dark:text-pink-400" />}
                                        </div>
                                    );
                                })
                            ) : (
                                <div className="text-center py-8 text-slate-500 dark:text-slate-400 text-sm">
                                    Henüz hiç firma eklenmemiş.
                                </div>
                            )}
                        </div>

                        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 flex justify-end gap-2">
                            <button
                                onClick={() => setIsInterestModalOpen(false)}
                                className="px-4 py-2 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                            >
                                Kapat
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Quick Invite Modal */}
            {isInviteModalOpen && selectedPatientForInvite && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
                    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in duration-200 border border-slate-200 dark:border-slate-800">
                        <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 flex items-center justify-between">
                            <div>
                                <h3 className="text-lg font-semibold text-slate-900 dark:text-white">Uzman Gününe Davet Et</h3>
                                <p className="text-sm text-slate-500 dark:text-slate-400">{selectedPatientForInvite.fullName}</p>
                            </div>
                            <button
                                onClick={() => setIsInviteModalOpen(false)}
                                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
                            >
                                <X size={20} />
                            </button>
                        </div>

                        <div className="p-4 max-h-[60vh] overflow-y-auto space-y-2">
                            <p className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-2 px-1">Yaklaşan Uzman Günleri</p>
                            {upcomingEvents.length > 0 ? (
                                upcomingEvents.map(event => {
                                    const isInvited = event.invitations?.some(i => i.patientId === selectedPatientForInvite.id);
                                    return (
                                        <button
                                            key={`${event.companyId}-${event.id}`}
                                            onClick={() => handleInviteConfirm(event)}
                                            className={cn(
                                                "w-full flex items-center justify-between p-4 rounded-xl border transition-all text-left group",
                                                isInvited
                                                    ? "bg-teal-50 dark:bg-teal-900/20 border-teal-200 dark:border-teal-900/50 shadow-sm"
                                                    : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 hover:border-indigo-200 dark:hover:border-indigo-800 hover:shadow-sm"
                                            )}
                                        >
                                            <div>
                                                <div className={cn("font-semibold", isInvited ? "text-teal-900 dark:text-teal-300" : "text-slate-900 dark:text-white group-hover:text-indigo-700 dark:group-hover:text-indigo-300")}>
                                                    {event.companyName}
                                                </div>
                                                <div className={cn("text-sm flex items-center gap-2 mt-1", isInvited ? "text-teal-700 dark:text-teal-400" : "text-slate-500 dark:text-slate-400")}>
                                                    <Calendar size={14} />
                                                    {new Date(event.date).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' })}
                                                    {isInvited && <span className="text-[10px] font-bold bg-white dark:bg-teal-900 px-2 py-0.5 rounded-full border border-teal-200 dark:border-teal-800 ml-2">DAVET EDİLDİ</span>}
                                                </div>
                                            </div>
                                            <div className={cn(
                                                "h-8 w-8 rounded-full flex items-center justify-center transition-colors",
                                                isInvited
                                                    ? "bg-teal-100 dark:bg-teal-900 text-teal-600 dark:text-teal-300"
                                                    : "bg-slate-100 dark:bg-slate-700 text-slate-400 group-hover:bg-indigo-100 dark:group-hover:bg-indigo-900 group-hover:text-indigo-600 dark:group-hover:text-indigo-300"
                                            )}>
                                                {isInvited ? <Check size={18} /> : <Plus size={18} />}
                                            </div>
                                        </button>
                                    );
                                })
                            ) : (
                                <div className="text-center py-8 text-slate-500 dark:text-slate-400 text-sm">
                                    Yaklaşan uzman günü bulunmuyor.
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {/* Add Patient Modal */}
            {isAddModalOpen && (
                <div className="fixed inset-0 z-50 flex items-start justify-center p-4 bg-black/50 backdrop-blur-sm overflow-y-auto">
                    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl w-full max-w-lg max-h-[calc(100vh-2rem)] overflow-hidden animate-in fade-in zoom-in duration-200 border border-slate-200 dark:border-slate-800 my-auto flex flex-col">
                        <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 flex items-center justify-between flex-shrink-0">
                            <h3 className="text-lg font-semibold text-slate-900 dark:text-white">Yeni Danışan Kaydı</h3>
                            <button
                                onClick={() => setIsAddModalOpen(false)}
                                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
                            >
                                <X size={20} />
                            </button>
                        </div>

                        <form onSubmit={handleAddPatient} className="p-6 space-y-4 overflow-y-auto">
                            <div>
                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Ad Soyad</label>
                                <input
                                    required
                                    type="text"
                                    className="w-full rounded-lg border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-3 py-2 focus:ring-teal-500 focus:border-teal-500"
                                    value={formData.fullName}
                                    onChange={e => setFormData({ ...formData, fullName: e.target.value })}
                                />
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Danışan Tanımı</label>
                                <input
                                    type="text"
                                    className="w-full rounded-lg border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-3 py-2 focus:ring-teal-500 focus:border-teal-500"
                                    placeholder="Örn: Ayşe Hanım'ın arkadaşı..."
                                    value={formData.description}
                                    onChange={e => setFormData({ ...formData, description: e.target.value })}
                                />
                            </div>



                            <div className="grid grid-cols-2 gap-4">
                                <div className="col-span-2 sm:col-span-1">
                                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                                        Doğum Tarihi <span className="text-xs text-slate-400 font-normal ml-1">(Gün.Ay.Yıl veya Yıl)</span>
                                    </label>
                                    <div className="relative">
                                        <div
                                            className="absolute inset-y-0 left-0 pl-3 flex items-center cursor-pointer pointer-events-auto z-10"
                                            onClick={() => dateInputRef.current?.showPicker()}
                                        >
                                            <Calendar className="h-5 w-5 text-slate-400 hover:text-teal-600 dark:hover:text-teal-400 transition-colors" />
                                        </div>
                                        <input
                                            type="text"
                                            placeholder="Örn: 1990 veya 15.05.1985"
                                            className="w-full rounded-lg border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border pl-10 pr-3 py-2 focus:ring-teal-500 focus:border-teal-500"
                                            value={formData.birthDate || ""}
                                            onChange={e => {
                                                const val = e.target.value;
                                                let newAge = formData.age;

                                                // Year Check (YYYY)
                                                if (/^\d{4}$/.test(val)) {
                                                    const year = parseInt(val);
                                                    const currentYear = new Date().getFullYear();
                                                    if (year > 1900 && year <= currentYear) {
                                                        newAge = currentYear - year;
                                                    }
                                                }
                                                // Full Date Check (DD.MM.YYYY)
                                                else {
                                                    const parts = val.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/);
                                                    if (parts) {
                                                        const day = parseInt(parts[1]);
                                                        const month = parseInt(parts[2]) - 1;
                                                        const year = parseInt(parts[3]);
                                                        const birthDate = new Date(year, month, day);
                                                        const today = new Date();
                                                        let age = today.getFullYear() - birthDate.getFullYear();
                                                        const m = today.getMonth() - birthDate.getMonth();
                                                        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                                                            age--;
                                                        }
                                                        newAge = age > 0 ? age : 0;
                                                    }
                                                }

                                                setFormData({ ...formData, birthDate: val, age: newAge });
                                            }}
                                        />
                                        <input
                                            type="date"
                                            ref={dateInputRef}
                                            className="absolute inset-0 opacity-0 pointer-events-none w-0 h-0"
                                            tabIndex={-1}
                                            onChange={(e) => {
                                                const val = e.target.value; // YYYY-MM-DD
                                                if (!val) return;
                                                const [year, month, day] = val.split('-');
                                                const formatted = `${day}.${month}.${year}`;

                                                const birthDate = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
                                                const today = new Date();
                                                let age = today.getFullYear() - birthDate.getFullYear();
                                                const m = today.getMonth() - birthDate.getMonth();
                                                if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                                                    age--;
                                                }
                                                const newAge = age > 0 ? age : 0;

                                                setFormData({ ...formData, birthDate: formatted, age: newAge });
                                            }}
                                        />
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Yaş</label>
                                    <input
                                        type="number"
                                        className="w-full rounded-lg border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-3 py-2 focus:ring-teal-500 focus:border-teal-500"
                                        value={formData.age}
                                        onChange={e => setFormData({ ...formData, age: e.target.value })}
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                                        Telefon <span className="text-xs text-slate-400 font-normal ml-1">(5xx xxx xx xx)</span>
                                    </label>
                                    <input
                                        type="tel"
                                        maxLength={15}
                                        placeholder="5** *** ** **"
                                        className="w-full rounded-lg border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-3 py-2 focus:ring-teal-500 focus:border-teal-500"
                                        value={formData.phone}
                                        onChange={e => {
                                            setFormData({ ...formData, phone: formatPhoneNumber(e.target.value) });
                                        }}
                                    />
                                </div>
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Anamnez / Hikaye</label>
                                <div className="relative">
                                    <textarea
                                        rows={3}
                                        className="w-full rounded-lg border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-3 py-2 focus:ring-teal-500 focus:border-teal-500 pr-8"
                                        placeholder="Danışanın şikayetleri ve geçmişi..."
                                        value={formData.anamnesis}
                                        onChange={e => setFormData({ ...formData, anamnesis: e.target.value })}
                                    />
                                    {formData.anamnesis && (
                                        <button
                                            type="button"
                                            onClick={() => setFormData({ ...formData, anamnesis: "" })}
                                            className="absolute top-2 right-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1 bg-white/50 dark:bg-slate-700/50 rounded-full hover:bg-slate-100 dark:hover:bg-slate-600 transition-colors"
                                            title="Temizle"
                                        >
                                            <X size={14} />
                                        </button>
                                    )}
                                </div>
                            </div>

                            <div className="bg-amber-50 dark:bg-amber-900/10 p-4 rounded-xl border border-amber-200 dark:border-amber-800/40 space-y-3">
                                <div className="flex items-start gap-3">
                                    <Shield className="h-5 w-5 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0" />
                                    <div>
                                        <h4 className="font-bold text-slate-900 dark:text-white">İletişim İzinleri / KVKK</h4>
                                        <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                                            Bu bölüm, danışandan alınan izinlerin kaydı içindir. İYS entegrasyonu veya izin kontrolü yapılmadan ticari elektronik ileti gönderilmesi halinde sorumluluk kullanıcı eczacıya aittir.
                                        </p>
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 gap-2">
                                    {[
                                        ["enlightenmentDone", "Danışana KVKK aydınlatması yapıldı."],
                                        ["explicitConsent", "Kişisel verilerin kaydı/saklanması için açık rıza alındı."]
                                    ].map(([key, label]) => (
                                        <label key={key} className="flex items-start gap-2 text-sm text-slate-700 dark:text-slate-300">
                                            <input
                                                type="checkbox"
                                                className="mt-1 rounded border-slate-300 text-teal-600 focus:ring-teal-500"
                                                checked={!!formData.kvkkConsent?.[key]}
                                                onChange={e => {
                                                    const nextConsent = {
                                                        ...formData.kvkkConsent,
                                                        [key]: e.target.checked,
                                                        consentDate: e.target.checked && !formData.kvkkConsent?.consentDate ? new Date().toISOString() : formData.kvkkConsent?.consentDate
                                                    };
                                                    nextConsent.dataProcessing = !!nextConsent.enlightenmentDone && !!nextConsent.explicitConsent;
                                                    setFormData({ ...formData, kvkkConsent: nextConsent });
                                                }}
                                            />
                                            {label}
                                        </label>
                                    ))}
                                </div>

                                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                                    {[
                                        ["sms", "SMS izni"],
                                        ["phoneCall", "Arama izni"],
                                        ["email", "E-posta izni"]
                                    ].map(([key, label]) => (
                                        <label key={key} className="flex items-center gap-2 text-sm bg-white/70 dark:bg-slate-800/70 border border-amber-100 dark:border-amber-900/40 rounded-lg px-3 py-2 text-slate-700 dark:text-slate-300">
                                            <input
                                                type="checkbox"
                                                className="rounded border-slate-300 text-teal-600 focus:ring-teal-500"
                                                checked={!!formData.kvkkConsent?.[key]}
                                                onChange={e => setFormData({ ...formData, kvkkConsent: { ...formData.kvkkConsent, [key]: e.target.checked, consentDate: e.target.checked && !formData.kvkkConsent?.consentDate ? new Date().toISOString() : formData.kvkkConsent?.consentDate } })}
                                            />
                                            {label}
                                        </label>
                                    ))}
                                </div>

                                <label className="flex items-start gap-2 text-xs text-amber-800 dark:text-amber-300 font-medium">
                                    <input
                                        type="checkbox"
                                        className="mt-0.5 rounded border-amber-300 text-amber-600 focus:ring-amber-500"
                                        checked={!!formData.kvkkConsent?.iysResponsibilityAccepted}
                                        onChange={e => setFormData({ ...formData, kvkkConsent: { ...formData.kvkkConsent, iysResponsibilityAccepted: e.target.checked } })}
                                    />
                                    İYS entegrasyonu yapılmadığı veya izinler İYS üzerinden doğrulanmadığı durumlarda, mevzuata uygun hareket etme ve gerekli kontrolleri yapma sorumluluğunun kullanıcı eczacıda olduğunu kabul ederim.
                                </label>
                            </div>

                            <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-200 dark:border-slate-700">
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-3">
                                        <div className={cn("p-2 rounded-lg", formData.detailedAnamnesis ? "bg-teal-100 dark:bg-teal-900/30 text-teal-600 dark:text-teal-400" : "bg-slate-100 dark:bg-slate-700 text-slate-400 dark:text-slate-500")}>
                                            <FileText size={20} />
                                        </div>
                                        <div>
                                            <h4 className="font-semibold text-slate-700 dark:text-slate-200">Detaylı Anamnez Formu</h4>
                                            <p className="text-xs text-slate-500 dark:text-slate-400">
                                                {formData.detailedAnamnesis ? "Form dolduruldu." : "Henüz doldurulmadı."}
                                            </p>
                                        </div>
                                    </div>
                                    <button
                                        type="button"
                                        onClick={() => setIsDetailedAnamnesisModalOpen(true)}
                                        className={cn(
                                            "flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors",
                                            formData.detailedAnamnesis
                                                ? "bg-teal-50 dark:bg-teal-900/20 text-teal-700 dark:text-teal-400 hover:bg-teal-100 dark:hover:bg-teal-900/40 border border-teal-200 dark:border-teal-800"
                                                : "bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-700"
                                        )}
                                    >
                                        {formData.detailedAnamnesis ? "Düzenle" : "Formu Aç"}
                                    </button>
                                </div>
                            </div>

                            <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-200 dark:border-slate-700">
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-3">
                                        <div className={cn("p-2 rounded-lg", formData.dermoAnamnesis ? "bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400" : "bg-slate-100 dark:bg-slate-700 text-slate-400 dark:text-slate-500")}>
                                            <Activity size={20} />
                                        </div>
                                        <div>
                                            <h4 className="font-semibold text-slate-700 dark:text-slate-200">Dermo Anamnez Formu</h4>
                                            <p className="text-xs text-slate-500 dark:text-slate-400">
                                                {formData.dermoAnamnesis ? "Form dolduruldu." : "Henüz doldurulmadı."}
                                            </p>
                                        </div>
                                    </div>
                                    <button
                                        type="button"
                                        onClick={() => setIsDermoAnamnesisModalOpen(true)}
                                        className={cn(
                                            "flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors",
                                            formData.dermoAnamnesis
                                                ? "bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-400 hover:bg-purple-100 dark:hover:bg-purple-900/40 border border-purple-200 dark:border-purple-800"
                                                : "bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-700"
                                        )}
                                    >
                                        {formData.dermoAnamnesis ? "Düzenle" : "Formu Aç"}
                                    </button>
                                </div>
                            </div>

                            <div className="pt-4 flex justify-end gap-3">
                                <button
                                    type="button"
                                    onClick={() => setIsAddModalOpen(false)}
                                    className="px-4 py-2 text-slate-700 dark:text-slate-300 font-medium hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                                >
                                    İptal
                                </button>
                                <button
                                    type="submit"
                                    className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-medium rounded-lg transition-colors shadow-sm shadow-teal-200 dark:shadow-none"
                                >
                                    Kaydet
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {isDetailedAnamnesisModalOpen && (
                <DetailedAnamnesisModal
                    isOpen={isDetailedAnamnesisModalOpen}
                    onClose={() => setIsDetailedAnamnesisModalOpen(false)}
                    onSave={handleSaveDetailedAnamnesis}
                    initialData={formData.detailedAnamnesis}
                />
            )}

            {isDermoAnamnesisModalOpen && (
                <DermoAnamnesisModal
                    isOpen={isDermoAnamnesisModalOpen}
                    onClose={() => setIsDermoAnamnesisModalOpen(false)}
                    onSave={handleSaveDermoAnamnesis}
                    initialData={formData.dermoAnamnesis}
                />
            )}
        </div>
    )
}



