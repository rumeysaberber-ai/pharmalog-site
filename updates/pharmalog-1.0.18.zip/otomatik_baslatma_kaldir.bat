@echo off
title PharmaLog Otomatik Baslatma Kaldir
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0otomatik_baslatma_kaldir.ps1"
pause
