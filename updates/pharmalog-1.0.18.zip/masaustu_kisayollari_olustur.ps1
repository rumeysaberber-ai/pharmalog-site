$projectDir = Split-Path -Parent $MyInvocation.MyCommand.Path

$desktopCandidates = New-Object System.Collections.Generic.List[string]
$desktopCandidates.Add([Environment]::GetFolderPath("Desktop"))
$desktopCandidates.Add([Environment]::GetFolderPath("DesktopDirectory"))

if ($env:OneDrive) {
    $desktopCandidates.Add((Join-Path $env:OneDrive "Desktop"))
    $desktopCandidates.Add((Join-Path $env:OneDrive "Masaüstü"))
}

if ($env:OneDriveCommercial) {
    $desktopCandidates.Add((Join-Path $env:OneDriveCommercial "Desktop"))
    $desktopCandidates.Add((Join-Path $env:OneDriveCommercial "Masaüstü"))
}

if ($env:USERPROFILE) {
    $desktopCandidates.Add((Join-Path $env:USERPROFILE "Desktop"))
    $desktopCandidates.Add((Join-Path $env:USERPROFILE "Masaüstü"))
    $desktopCandidates.Add((Join-Path $env:USERPROFILE "OneDrive\Desktop"))
    $desktopCandidates.Add((Join-Path $env:USERPROFILE "OneDrive\Masaüstü"))
}

$desktopCandidates.Add((Split-Path -Parent $projectDir))

$desktop = $desktopCandidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
if (-not $desktop) {
    throw "Masaustu klasoru bulunamadi."
}

$iconPath = Join-Path $projectDir "pharmalog.ico"
$pngCandidates = @(
    (Join-Path $projectDir "public\pharmalog-logo.png"),
    (Join-Path $projectDir "src\assets\pharmalog_logo.png")
) | Where-Object { Test-Path $_ }

if (-not (Test-Path $iconPath) -and $pngCandidates.Count -gt 0) {
    try {
        Add-Type -AssemblyName System.Drawing
        $sourcePng = $pngCandidates | Select-Object -First 1
        $sourceImage = [System.Drawing.Image]::FromFile($sourcePng)
        $bitmap = New-Object System.Drawing.Bitmap 256, 256
        $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
        $graphics.Clear([System.Drawing.Color]::Transparent)
        $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
        $graphics.DrawImage($sourceImage, 0, 0, 256, 256)
        $icon = [System.Drawing.Icon]::FromHandle($bitmap.GetHicon())
        $stream = [System.IO.File]::Create($iconPath)
        $icon.Save($stream)
        $stream.Close()
        $icon.Dispose()
        $graphics.Dispose()
        $bitmap.Dispose()
        $sourceImage.Dispose()
    } catch {
        $iconPath = "$env:SystemRoot\System32\shell32.dll,220"
    }
}

if (-not (Test-Path $iconPath)) {
    $iconPath = "$env:SystemRoot\System32\shell32.dll,220"
}

$shell = New-Object -ComObject WScript.Shell

$hostShortcut = $shell.CreateShortcut((Join-Path $desktop "PharmaLog Ana Bilgisayar.lnk"))
$hostShortcut.TargetPath = "$env:SystemRoot\System32\wscript.exe"
$hostShortcut.Arguments = "`"$(Join-Path $projectDir "ana_bilgisayar_gizli_baslat.vbs")`""
$hostShortcut.WorkingDirectory = $projectDir
$hostShortcut.IconLocation = $iconPath
$hostShortcut.Save()

$terminalShortcut = $shell.CreateShortcut((Join-Path $desktop "PharmaLog Terminal.lnk"))
$terminalShortcut.TargetPath = (Join-Path $projectDir "terminal_program_ac.bat")
$terminalShortcut.WorkingDirectory = $projectDir
$terminalShortcut.IconLocation = $iconPath
$terminalShortcut.Save()

$stopShortcut = $shell.CreateShortcut((Join-Path $desktop "PharmaLog Sunucuyu Durdur.lnk"))
$stopShortcut.TargetPath = (Join-Path $projectDir "pharmalog_sunucu_durdur.bat")
$stopShortcut.WorkingDirectory = $projectDir
$stopShortcut.IconLocation = "$env:SystemRoot\System32\shell32.dll,131"
$stopShortcut.Save()

Write-Host "Masaustu kisayollari olusturuldu:"
Write-Host "- PharmaLog Ana Bilgisayar"
Write-Host "- PharmaLog Terminal"
Write-Host "- PharmaLog Sunucuyu Durdur"
