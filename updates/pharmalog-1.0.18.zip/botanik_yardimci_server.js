﻿import http from 'http';
import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const PORT = Number(process.env.BOTANIK_HELPER_PORT || 3017);
const HOST = '127.0.0.1';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const SETTINGS_FILE = path.join(__dirname, 'botanik_yardimci_ayar.json');

const readHelperSettings = () => {
    try {
        if (!fs.existsSync(SETTINGS_FILE)) return {};
        return JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8')) || {};
    } catch {
        return {};
    }
};

const writeHelperSettings = (settings) => {
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2), 'utf8');
};

const sanitizeSqlServer = (value) => {
    const text = String(value || '').trim();
    if (!text) return '';
    if (!/^[^;"'`|&<>]{1,120}$/.test(text) || /[\r\n]/.test(text)) {
        throw new Error('Botanik SQL sunucu adı geçersiz görünüyor.');
    }
    return text;
};

const quotePowerShellLiteral = (value) => `'${String(value).replace(/'/g, "''")}'`;

const sendJson = (res, statusCode, payload) => {
    const body = JSON.stringify(payload);
    res.writeHead(statusCode, {
        'Content-Type': 'application/json; charset=utf-8',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type'
    });
    res.end(body);
};

const readRequestBody = (req) => new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
        body += chunk;
        if (body.length > 1024 * 1024) {
            req.destroy();
            reject(new Error('İstek çok büyük.'));
        }
    });
    req.on('end', () => {
        try {
            resolve(body ? JSON.parse(body) : {});
        } catch {
            reject(new Error('İstek JSON formatında değil.'));
        }
    });
    req.on('error', reject);
});

const parseDateRange = ({ startDate, endDate }) => {
    const start = startDate ? new Date(`${startDate}T00:00:00`) : null;
    const end = endDate ? new Date(`${endDate}T23:59:59`) : null;
    if (!start || !end || Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
        throw new Error('Geçerli başlangıç ve bitiş tarihi girin.');
    }
    if (end < start) throw new Error('Bitiş tarihi başlangıç tarihinden önce olamaz.');
    return {
        startSql: start.toISOString().slice(0, 19).replace('T', ' '),
        endSql: end.toISOString().slice(0, 19).replace('T', ' ')
    };
};

const runPowerShellJson = (script) => new Promise((resolve, reject) => {
    const child = spawn('powershell.exe', [
        '-NoProfile',
        '-ExecutionPolicy',
        'Bypass',
        '-Command',
        script
    ], { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });

    let stdout = '';
    let stderr = '';
    child.stdout.setEncoding('utf8');
    child.stderr.setEncoding('utf8');
    child.stdout.on('data', chunk => { stdout += chunk; });
    child.stderr.on('data', chunk => { stderr += chunk; });
    child.on('error', reject);
    child.on('close', code => {
        if (code !== 0) {
            reject(new Error(stderr || stdout || `Botanik yardımcı servis hata kodu: ${code}`));
            return;
        }
        try {
            resolve(stdout.trim() ? JSON.parse(stdout) : []);
        } catch {
            reject(new Error('Botanik SQL yanıtı okunamadı.'));
        }
    });
});

const fetchBotanikSales = async ({ startDate, endDate, sqlServer }) => {
    const { startSql, endSql } = parseDateRange({ startDate, endDate });
    const savedSettings = readHelperSettings();
    const selectedSqlServer = sanitizeSqlServer(sqlServer || savedSettings.sqlServer || process.env.BOTANIK_SQL_SERVER || '.\\BOTANIKSQL');
    if (sqlServer) {
        writeHelperSettings({ ...savedSettings, sqlServer: selectedSqlServer });
    }
    const query = `
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = "Stop"
$sqlServer = ${quotePowerShellLiteral(selectedSqlServer)}
$connectionString = "Server=$sqlServer;Database=eczane;Integrated Security=True;TrustServerCertificate=True;"
$query = @"
WITH CategoryTree AS (
    SELECT KatId, KatUstId, KatAdi, KatId AS RootKatId, KatAdi AS RootKatAdi
    FROM dbo.UrunKategorisi
    WHERE KatId IN (2, 9) AND ISNULL(KatSilme, 0) = 0
    UNION ALL
    SELECT child.KatId, child.KatUstId, child.KatAdi, parent.RootKatId, parent.RootKatAdi
    FROM dbo.UrunKategorisi child
    JOIN CategoryTree parent ON child.KatUstId = parent.KatId
    WHERE ISNULL(child.KatSilme, 0) = 0
),
TargetSales AS (
    SELECT TOP (5000) ea.RxId
    FROM dbo.EldenAna ea
    JOIN dbo.EldenIlaclari ei ON ei.RIRxId = ea.RxId
    JOIN dbo.UrunKategori uk ON uk.UrunId = ei.RIUrunId
    JOIN CategoryTree ct ON ct.KatId = uk.KatId
    JOIN dbo.Musteri m ON m.MusteriId = ea.RxMusteriId
    CROSS APPLY (
        SELECT COALESCE(NULLIF(LTRIM(RTRIM(m.MusteriAdiSoyadi)), ''), NULLIF(LTRIM(RTRIM(CONCAT(ISNULL(m.MusteriAdi, ''), ' ', ISNULL(m.MusteriSoyadi, '')))), '')) AS CustomerName
    ) names
    WHERE ISNULL(ea.RxSilme, 0) = 0
      AND ISNULL(ei.RISilme, 0) = 0
      AND ISNULL(ei.RIIade, 0) = 0
      AND ea.RxIslemTarihi >= CONVERT(datetime, '${startSql}', 120)
      AND ea.RxIslemTarihi <= CONVERT(datetime, '${endSql}', 120)
      AND ea.RxMusteriId IS NOT NULL
      AND ea.RxMusteriId <> 0
      AND names.CustomerName IS NOT NULL
    GROUP BY ea.RxId
    ORDER BY ea.RxId ASC
)
SELECT
    ea.RxId AS SaleId,
    CONVERT(varchar(33), ea.RxIslemTarihi, 126) AS SaleDate,
    ea.RxMusteriId AS CustomerId,
    names.CustomerName,
    ISNULL(m.MusteriTelCep, '') AS Phone,
    ISNULL(CONVERT(varchar(10), m.MusteriDogumTarihi, 23), '') AS BirthDate,
    ct.RootKatAdi AS MainCategory,
    ct.KatAdi AS Category,
    ei.RIId AS SaleLineId,
    ei.RIUrunId AS ProductId,
    ISNULL(u.UrunAdi, '') AS ProductName,
    ISNULL(bar.BarkodAdi, '') AS Barcode,
    ISNULL(ei.RIAdet, 1) AS Quantity,
    ISNULL(ei.RIEtiketFiyati, 0) AS Price,
    ISNULL(ei.RIToplam, 0) AS Total
FROM TargetSales ts
JOIN dbo.EldenAna ea ON ea.RxId = ts.RxId
JOIN dbo.EldenIlaclari ei ON ei.RIRxId = ea.RxId
JOIN dbo.Urun u ON u.UrunId = ei.RIUrunId
JOIN dbo.UrunKategori uk ON uk.UrunId = ei.RIUrunId
JOIN CategoryTree ct ON ct.KatId = uk.KatId
JOIN dbo.Musteri m ON m.MusteriId = ea.RxMusteriId
CROSS APPLY (
    SELECT COALESCE(NULLIF(LTRIM(RTRIM(m.MusteriAdiSoyadi)), ''), NULLIF(LTRIM(RTRIM(CONCAT(ISNULL(m.MusteriAdi, ''), ' ', ISNULL(m.MusteriSoyadi, '')))), '')) AS CustomerName
) names
OUTER APPLY (
    SELECT TOP 1 b.BarkodAdi
    FROM dbo.Barkod b
    WHERE b.BarkodUrunId = ei.RIUrunId AND ISNULL(b.BarkodSilme, 0) = 0
    ORDER BY b.BarkodAdi
) bar
WHERE ISNULL(ei.RISilme, 0) = 0
  AND ISNULL(ei.RIIade, 0) = 0
ORDER BY ea.RxId ASC, ei.RIId ASC
OPTION (MAXRECURSION 20)
"@
$connection = New-Object System.Data.SqlClient.SqlConnection $connectionString
$command = $connection.CreateCommand()
$command.CommandText = $query
$command.CommandTimeout = 120
$table = New-Object System.Data.DataTable
$adapter = New-Object System.Data.SqlClient.SqlDataAdapter $command
try {
    [void]$adapter.Fill($table)
    $rows = foreach ($row in $table.Rows) {
        [ordered]@{
            SaleId = [string]$row.SaleId
            SaleDate = [string]$row.SaleDate
            CustomerId = [string]$row.CustomerId
            CustomerName = [string]$row.CustomerName
            Phone = [string]$row.Phone
            BirthDate = [string]$row.BirthDate
            MainCategory = [string]$row.MainCategory
            Category = [string]$row.Category
            SaleLineId = [string]$row.SaleLineId
            ProductId = [string]$row.ProductId
            ProductName = [string]$row.ProductName
            Barcode = [string]$row.Barcode
            Quantity = [int]$row.Quantity
            Price = [decimal]$row.Price
            Total = [decimal]$row.Total
        }
    }
    @($rows) | ConvertTo-Json -Compress -Depth 5
} finally {
    $connection.Close()
    $connection.Dispose()
}
`;
    const rows = await runPowerShellJson(query);
    const salesById = new Map();
    for (const row of Array.isArray(rows) ? rows : [rows]) {
        if (!row?.SaleId) continue;
        const saleId = String(row.SaleId);
        if (!salesById.has(saleId)) {
            salesById.set(saleId, {
                externalSaleId: `Botanik-Elden-${saleId}`,
                externalCustomerId: String(row.CustomerId || ''),
                customerName: String(row.CustomerName || '').trim(),
                phone: String(row.Phone || '').trim(),
                birthDate: String(row.BirthDate || '').trim(),
                saleDate: row.SaleDate ? new Date(row.SaleDate).toISOString() : new Date().toISOString(),
                category: 'Botanik elden satış',
                note: 'Botanik elden satış aktarımı',
                products: []
            });
        }
        salesById.get(saleId).products.push({
            id: `Botanik-Elden-Line-${row.SaleLineId}`,
            productId: String(row.ProductId || ''),
            barcode: String(row.Barcode || ''),
            productName: String(row.ProductName || ''),
            quantity: Number(row.Quantity) || 1,
            price: Number(row.Price) || 0,
            total: Number(row.Total) || 0,
            notes: `${row.MainCategory || ''} / ${row.Category || ''}`.trim()
        });
    }
    return Array.from(salesById.values());
};

const server = http.createServer(async (req, res) => {
    if (req.method === 'OPTIONS') return sendJson(res, 200, { ok: true });
    if (req.method === 'GET' && req.url === '/health') {
        const settings = readHelperSettings();
        return sendJson(res, 200, { ok: true, service: 'botanik-helper', sqlServer: settings.sqlServer || null });
    }

    if (req.method === 'POST' && req.url === '/api/botanik/sales/read') {
        try {
            const payload = await readRequestBody(req);
            const sales = await fetchBotanikSales(payload);
            return sendJson(res, 200, { success: true, sourceName: 'Botanik', sales });
        } catch (error) {
            return sendJson(res, 500, { error: error.message || 'Botanik satışları okunamadı.' });
        }
    }

    return sendJson(res, 404, { error: 'Botanik yardımcı servis yolu bulunamadı.' });
});

server.listen(PORT, HOST, () => {
    console.log(`Botanik helper listening on http://${HOST}:${PORT}`);
});

