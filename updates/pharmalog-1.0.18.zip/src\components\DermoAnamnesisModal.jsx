import { useState, useEffect } from 'react';
import { X, Check, Save } from 'lucide-react';
import { cn } from '../lib/utils';

export default function DermoAnamnesisModal({ isOpen, onClose, onSave, initialData }) {
    const [formData, setFormData] = useState({
        // Cilt
        skinType: "",
        skinCondition: [],

        // Göz/Saç/Vücut
        eyeCondition: [],
        hairCondition: [],
        bodyCondition: [],

        // Özel
        specialCondition: [],
        habits: [], // Sigara, Alkol

        // Diğer
        complaint: "",
        expectation: "",
        careTime: "",
        notes: ""
    });

    useEffect(() => {
        if (isOpen && initialData) {
            setFormData(prev => ({ ...prev, ...initialData }));
        } else if (isOpen) {
            setFormData({
                skinType: "",
                skinCondition: [],
                eyeCondition: [],
                hairCondition: [],
                bodyCondition: [],
                specialCondition: [],
                habits: [],
                complaint: "",
                expectation: "",
                careTime: "",
                notes: ""
            });
        }
    }, [isOpen, initialData]);

    const handleCheckboxChange = (field, value) => {
        setFormData(prev => {
            const current = prev[field] || [];
            if (current.includes(value)) {
                return { ...prev, [field]: current.filter(item => item !== value) };
            } else {
                return { ...prev, [field]: [...current, value] };
            }
        });
    };

    const handleRadioChange = (field, value) => {
        setFormData(prev => ({
            ...prev,
            [field]: prev[field] === value ? "" : value
        }));
    };

    const handleSave = () => {
        onSave(formData);
        onClose();
    };

    if (!isOpen) return null;

    // Helper Component for Section Headers
    const SectionHeader = ({ title }) => (
        <div className="flex items-center gap-4 my-6 first:mt-0">
            <h4 className="text-lg font-bold text-slate-800 dark:text-white uppercase tracking-wider">{title}</h4>
            <div className="h-px bg-slate-200 dark:bg-slate-700 flex-1"></div>
        </div>
    );

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-300 overflow-y-auto">
            <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-2xl shadow-2xl w-full max-w-4xl my-8 flex flex-col h-auto max-h-[90vh] border border-white/20 dark:border-slate-700 animate-in zoom-in-95 duration-200">

                {/* Header */}
                <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 flex items-center justify-between flex-shrink-0">
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                        Dermokozmetik Anamnez
                    </h3>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400">
                        <X size={24} />
                    </button>
                </div>

                {/* Content - Single Scrollable Page */}
                <div className="p-6 overflow-y-auto custom-scrollbar flex-1 bg-white dark:bg-slate-900">

                    {/* 1. CİLT */}
                    <SectionHeader title="CİLT" />
                    <div className="space-y-6">
                        <div className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-4">
                            <h5 className="text-sm font-bold text-slate-500 mb-3 uppercase">Cilt Tipi</h5>
                            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                                {["Karma Cilt", "Kuru Cilt", "Yağlı Cilt", "Normal Cilt"].map(opt => (
                                    <label key={opt} className="flex items-center gap-2 cursor-pointer group">
                                        <input
                                            type="radio"
                                            name="skinType"
                                            className="w-5 h-5 text-teal-600 border-slate-300 focus:ring-teal-500"
                                            checked={formData.skinType === opt}
                                            onClick={() => handleRadioChange('skinType', opt)}
                                            onChange={() => { }}
                                        />
                                        <span className="text-sm font-bold text-slate-700 dark:text-slate-300 group-hover:text-teal-600 transition-colors">{opt}</span>
                                    </label>
                                ))}
                            </div>
                        </div>

                        <div className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-4">
                            <h5 className="text-sm font-bold text-slate-500 mb-3 uppercase">Cilt Durumu</h5>
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-3">
                                {[
                                    "Alerjik", "Atopik", "Gözenekli", "Kırışık", "Nemsiz",
                                    "Sarkma Sıklık Kaybı", "Seboroik Dermatit", "Sivilce",
                                    "Siyah Nokta", "Parlama", "Rosecea", "Yara-Çatlak-İrrite", "Lekeli"
                                ].map(opt => (
                                    <label key={opt} className="flex items-center gap-2 cursor-pointer group">
                                        <input
                                            type="checkbox"
                                            className="w-4 h-4 text-teal-600 rounded border-slate-300 focus:ring-teal-500"
                                            checked={formData.skinCondition?.includes(opt)}
                                            onChange={() => handleCheckboxChange('skinCondition', opt)}
                                        />
                                        <span className="text-sm font-medium text-slate-700 dark:text-slate-300 group-hover:text-teal-600 transition-colors">{opt}</span>
                                    </label>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* 2. GÖZ / SAÇ / VÜCUT */}
                    <SectionHeader title="GÖZ / SAÇ / VÜCUT" />
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-6">
                            {/* Göz Çevresi */}
                            <div className="border border-slate-200 dark:border-slate-700 rounded-lg p-4 bg-white dark:bg-slate-800">
                                <h4 className="font-bold text-slate-900 dark:text-white mb-3">Göz Çevresi</h4>
                                <div className="space-y-2">
                                    {["Nemsiz", "Kırışık", "Kahverengi Halka", "Gözaltı Torbaları", "Alerjik Hassas"].map(opt => (
                                        <label key={opt} className="flex items-center gap-2 cursor-pointer">
                                            <input
                                                type="checkbox"
                                                className="w-4 h-4 text-teal-600 rounded border-slate-300"
                                                checked={formData.eyeCondition?.includes(opt)}
                                                onChange={() => handleCheckboxChange('eyeCondition', opt)}
                                            />
                                            <span className="text-sm text-slate-700 dark:text-slate-300">{opt}</span>
                                        </label>
                                    ))}
                                </div>
                            </div>

                            {/* Vücut Durumu */}
                            <div className="border border-slate-200 dark:border-slate-700 rounded-lg p-4 bg-white dark:bg-slate-800">
                                <h4 className="font-bold text-slate-900 dark:text-white mb-3">Vücut Durumu</h4>
                                <div className="space-y-2">
                                    {["Nemsizlik", "Atopik Dermatit", "Egzama", "Selülit"].map(opt => (
                                        <label key={opt} className="flex items-center gap-2 cursor-pointer">
                                            <input
                                                type="checkbox"
                                                className="w-4 h-4 text-teal-600 rounded border-slate-300"
                                                checked={formData.bodyCondition?.includes(opt)}
                                                onChange={() => handleCheckboxChange('bodyCondition', opt)}
                                            />
                                            <span className="text-sm text-slate-700 dark:text-slate-300">{opt}</span>
                                        </label>
                                    ))}
                                </div>
                            </div>
                        </div>

                        {/* Saçlı Durumu */}
                        <div className="border border-slate-200 dark:border-slate-700 rounded-lg p-4 bg-white dark:bg-slate-800 h-full">
                            <h4 className="font-bold text-slate-900 dark:text-white mb-3">Saçlı Durumu</h4>
                            <div className="space-y-2">
                                {["Yağlı", "Kuru", "Kuru Kepek", "Yağlı Kepek", "Seboroid Dermatit", "Dökülme", "Yoğun Dökülme", "Hassas ve Kaşıntılı Saç Derisi"].map(opt => (
                                    <label key={opt} className="flex items-center gap-2 cursor-pointer">
                                        <input
                                            type="checkbox"
                                            className="w-4 h-4 text-teal-600 rounded border-slate-300"
                                            checked={formData.hairCondition?.includes(opt)}
                                            onChange={() => handleCheckboxChange('hairCondition', opt)}
                                        />
                                        <span className="text-sm text-slate-700 dark:text-slate-300">{opt}</span>
                                    </label>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* 3. ÖZEL DURUMLAR */}
                    <SectionHeader title="ÖZEL DURUMLAR" />
                    <div className="space-y-6">
                        <div className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-4">
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                {[
                                    "Gebelik", "Lohusalık", "Menapoz", "Yoğun Akne",
                                    "Kemoterapi", "Radyoterapi", "Estetik", "Lazer", "Kimyasal Peeling"
                                ].map(opt => (
                                    <label key={opt} className="flex items-center gap-2 cursor-pointer">
                                        <input
                                            type="checkbox"
                                            className="w-4 h-4 text-teal-600 rounded border-slate-300"
                                            checked={formData.specialCondition?.includes(opt)}
                                            onChange={() => handleCheckboxChange('specialCondition', opt)}
                                        />
                                        <span className="text-sm text-slate-700 dark:text-slate-300">{opt}</span>
                                    </label>
                                ))}
                            </div>
                        </div>

                        <div className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-4">
                            <div className="flex gap-6">
                                {["SİGARA", "ALKOL"].map(opt => (
                                    <label key={opt} className="flex items-center gap-2 cursor-pointer border border-slate-300 dark:border-slate-600 px-3 py-2 rounded hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">
                                        <input
                                            type="checkbox"
                                            className="w-5 h-5 text-teal-600 rounded border-slate-300"
                                            checked={formData.habits?.includes(opt)}
                                            onChange={() => handleCheckboxChange('habits', opt)}
                                        />
                                        <span className="text-sm font-bold text-slate-700 dark:text-slate-300">{opt}</span>
                                    </label>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* 4. DİĞER BİLGİLER */}
                    <SectionHeader title="DİĞER BİLGİLER" />
                    <div className="space-y-5">
                        <div className="bg-slate-50 dark:bg-slate-800/30 p-4 rounded-xl border border-slate-100 dark:border-slate-700/50">
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Cildinizde en çok rahatsız olduğunuz durum nedir?</label>
                            <textarea
                                rows={2}
                                className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-teal-500 focus:border-teal-500 shadow-sm resize-none"
                                value={formData.complaint}
                                onChange={e => setFormData({ ...formData, complaint: e.target.value })}
                                placeholder="Örn: Burun çevresindeki gözenekler..."
                            />
                        </div>
                        <div className="bg-slate-50 dark:bg-slate-800/30 p-4 rounded-xl border border-slate-100 dark:border-slate-700/50">
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">
                                Cilt bakım ürünlerinden beklentiniz nedir?
                                <span className="text-slate-400 font-normal text-xs ml-1">(Parlaklık, leke açma, anti-aging vb.)</span>
                            </label>
                            <textarea
                                rows={2}
                                className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-teal-500 focus:border-teal-500 shadow-sm resize-none"
                                value={formData.expectation}
                                onChange={e => setFormData({ ...formData, expectation: e.target.value })}
                                placeholder="Örn: Daha canlı ve parlak bir görünüm..."
                            />
                        </div>
                        <div className="bg-slate-50 dark:bg-slate-800/30 p-4 rounded-xl border border-slate-100 dark:border-slate-700/50">
                            <div className="flex flex-col md:flex-row gap-4">
                                <div className="flex-1">
                                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Bakım için ne kadar zaman ayırabilirsiniz?</label>
                                    <input
                                        type="text"
                                        className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-teal-500 focus:border-teal-500 shadow-sm"
                                        value={formData.careTime}
                                        onChange={e => setFormData({ ...formData, careTime: e.target.value })}
                                        placeholder="Örn: Günde 10 dakika, Sabah/Akşam..."
                                    />
                                </div>
                            </div>
                        </div>
                        <div className="bg-slate-50 dark:bg-slate-800/30 p-4 rounded-xl border border-slate-100 dark:border-slate-700/50">
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Genel Notlar</label>
                            <textarea
                                rows={2}
                                className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-teal-500 focus:border-teal-500 shadow-sm resize-none"
                                value={formData.notes || ""}
                                onChange={e => setFormData({ ...formData, notes: e.target.value })}
                                placeholder="Eklemek istediğiniz notlar..."
                            />
                        </div>
                    </div>

                </div>

                {/* Footer */}
                <div className="px-6 py-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 flex justify-end gap-3 flex-shrink-0 rounded-b-2xl">
                    <button
                        onClick={onClose}
                        className="px-6 py-2.5 text-slate-700 dark:text-slate-300 font-bold hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors"
                    >
                        Vazgeç
                    </button>
                    <button
                        onClick={handleSave}
                        className="px-6 py-2.5 bg-teal-600 text-white font-bold rounded-xl hover:bg-teal-700 shadow-lg flex items-center gap-2"
                    >
                        <Save size={18} />
                        Kaydet
                    </button>
                </div>
            </div>
        </div>
    );
}
