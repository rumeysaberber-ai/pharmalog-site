$ErrorActionPreference = "Stop"

$projectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$helperScript = Join-Path $projectDir "botanik_yardimci_server.js"
$outLog = Join-Path $projectDir "botanik_yardimci.out.log"
$errLog = Join-Path $projectDir "botanik_yardimci.err.log"
$pidFile = Join-Path $projectDir "botanik_yardimci.pid"
$bundledNode = Join-Path $projectDir "runtime\node.exe"
$nodeExe = "node"
if (Test-Path -LiteralPath $bundledNode) {
    $nodeExe = $bundledNode
}

if (-not (Test-Path -LiteralPath $helperScript)) {
    exit 0
}

try {
    $health = Invoke-WebRequest -Uri "http://127.0.0.1:3017/health" -UseBasicParsing -TimeoutSec 1
    if ($health.StatusCode -eq 200) {
        exit 0
    }
} catch { }

if (Test-Path -LiteralPath $pidFile) {
    $oldPid = Get-Content -LiteralPath $pidFile -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($oldPid -match '^\d+$') {
        $process = Get-Process -Id ([int]$oldPid) -ErrorAction SilentlyContinue
        if ($process -and $process.ProcessName -eq "node") {
            exit 0
        }
    }
}

$env:BOTANIK_HELPER_PORT = "3017"
$node = Start-Process -WindowStyle Hidden -FilePath $nodeExe -ArgumentList "botanik_yardimci_server.js" -WorkingDirectory $projectDir -RedirectStandardOutput $outLog -RedirectStandardError $errLog -PassThru
Set-Content -Path $pidFile -Value $node.Id -Encoding ASCII
