import React, { useState, useEffect, useRef } from 'react';
import { X, Plus, Trash2, Upload, FileText, Check, Search, Package } from 'lucide-react';
import { DataService } from '../lib/data';
import { cn, generateUUID } from '../lib/utils';

export default function DetailedAnamnesisModal({ isOpen, onClose, onSave, initialData }) {
    const [formData, setFormData] = useState({
        weight: "",
        height: "",
        bmi: "",
        smoking: false,
        alcohol: false,
        chronicDiseases: "",
        previousTreatments: "",
        activeMedicines: "",
        supplements: "",
        complaints: "",
        bowelProblems: "",
        bloodValues: null, // { name, content (base64) }
        recommendedProducts: [],
        givenProducts: [],
        notes: ""
    });

    const [dbProducts, setDbProducts] = useState([]);

    // Product Search State
    const [productSearchTerm, setProductSearchTerm] = useState("");
    const [activeProductSection, setActiveProductSection] = useState(null); // 'recommended' or 'given'
    const [isProductDropdownOpen, setIsProductDropdownOpen] = useState(false);
    const productDropdownRef = useRef(null);

    useEffect(() => {
        if (isOpen) {
            // Load initial data if provided
            if (initialData) {
                setFormData(prev => ({ ...prev, ...initialData }));
            }
            // Load products for autocomplete
            DataService.getDbProducts().then(setDbProducts);
        }
    }, [isOpen, initialData]);

    // BMI Calculation
    useEffect(() => {
        if (formData.weight && formData.height) {
            const weight = parseFloat(formData.weight);
            const heightM = parseFloat(formData.height) / 100;
            if (weight > 0 && heightM > 0) {
                const bmi = (weight / (heightM * heightM)).toFixed(2);
                setFormData(prev => ({ ...prev, bmi }));
            }
        } else {
            setFormData(prev => ({ ...prev, bmi: "" }));
        }
    }, [formData.weight, formData.height]);

    // Click outside for product dropdown
    useEffect(() => {
        function handleClickOutside(event) {
            if (productDropdownRef.current && !productDropdownRef.current.contains(event.target)) {
                setIsProductDropdownOpen(false);
            }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    const handleFileUpload = (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onloadend = () => {
            setFormData(prev => ({
                ...prev,
                bloodValues: {
                    name: file.name,
                    content: reader.result,
                    type: file.type
                }
            }));
        };
        reader.readAsDataURL(file);
    };



    const handleSave = () => {
        onSave(formData);
        onClose();
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-300 overflow-y-auto">
            <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-2xl shadow-2xl w-full max-w-4xl my-8 flex flex-col max-h-[90vh] border border-white/20 dark:border-slate-700 animate-in zoom-in-95 duration-200">

                {/* Header */}
                <div className="px-6 py-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 flex items-center justify-between flex-shrink-0">
                    <div>
                        <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                            <FileText size={20} className="text-teal-500" />
                            Detaylı Anamnez Formu
                        </h3>
                        <p className="text-sm font-medium text-slate-500 dark:text-slate-400 mt-0.5">Danışan detaylarını eksiksiz doldurun.</p>
                    </div>
                    <button
                        onClick={onClose}
                        className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
                    >
                        <X size={24} />
                    </button>
                </div>

                {/* Content - Scrollable */}
                <div className="p-6 overflow-y-auto custom-scrollbar space-y-6">

                    {/* 1. Fiziksel Ölçümler */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                        <div>
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Kilo (kg)</label>
                            <input
                                type="number"
                                className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-teal-500 focus:border-teal-500 shadow-sm"
                                placeholder="Örn: 70"
                                value={formData.weight}
                                onChange={e => setFormData({ ...formData, weight: e.target.value })}
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Boy (cm)</label>
                            <input
                                type="number"
                                className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-teal-500 focus:border-teal-500 shadow-sm"
                                placeholder="Örn: 175"
                                value={formData.height}
                                onChange={e => setFormData({ ...formData, height: e.target.value })}
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">VKİ (Otomatik)</label>
                            <input
                                type="text"
                                readOnly
                                className="w-full rounded-xl border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-700/50 border px-4 py-3 text-slate-600 dark:text-slate-300 font-bold"
                                value={formData.bmi}
                                placeholder="--"
                            />
                        </div>
                    </div>

                    {/* 2. Alışkanlıklar (Glass Card) */}
                    <div className="flex flex-wrap gap-8 p-5 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-700/50 shadow-sm">
                        <label className="flex items-center gap-3 cursor-pointer group select-none">
                            <div className={cn(
                                "w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all duration-200",
                                formData.smoking
                                    ? "bg-teal-500 border-teal-500 text-white shadow-teal-500/30 shadow-lg scale-110"
                                    : "bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-600 group-hover:border-teal-400 dark:group-hover:border-teal-500"
                            )}>
                                {formData.smoking && <Check size={14} strokeWidth={3} />}
                            </div>
                            <input
                                type="checkbox"
                                className="hidden"
                                checked={formData.smoking}
                                onChange={e => setFormData({ ...formData, smoking: e.target.checked })}
                            />
                            <span className={cn("font-bold transition-colors", formData.smoking ? "text-teal-700 dark:text-teal-400" : "text-slate-700 dark:text-slate-300")}>Sigara Kullanımı</span>
                        </label>

                        <label className="flex items-center gap-3 cursor-pointer group select-none">
                            <div className={cn(
                                "w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all duration-200",
                                formData.alcohol
                                    ? "bg-teal-500 border-teal-500 text-white shadow-teal-500/30 shadow-lg scale-110"
                                    : "bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-600 group-hover:border-teal-400 dark:group-hover:border-teal-500"
                            )}>
                                {formData.alcohol && <Check size={14} strokeWidth={3} />}
                            </div>
                            <input
                                type="checkbox"
                                className="hidden"
                                checked={formData.alcohol}
                                onChange={e => setFormData({ ...formData, alcohol: e.target.checked })}
                            />
                            <span className={cn("font-bold transition-colors", formData.alcohol ? "text-teal-700 dark:text-teal-400" : "text-slate-700 dark:text-slate-300")}>Alkol Kullanımı</span>
                        </label>
                    </div>

                    {/* 3. Tıbbi Geçmiş ve Şikayetler */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Kronik Hastalıklar</label>
                            <textarea
                                rows={2}
                                className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-teal-500 focus:border-teal-500 shadow-sm resize-none"
                                placeholder="Varsa belirtiniz..."
                                value={formData.chronicDiseases}
                                onChange={e => setFormData({ ...formData, chronicDiseases: e.target.value })}
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Önceden Görülmüş Tedavi</label>
                            <textarea
                                rows={2}
                                className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-teal-500 focus:border-teal-500 shadow-sm resize-none"
                                placeholder="Geçmiş tedaviler..."
                                value={formData.previousTreatments}
                                onChange={e => setFormData({ ...formData, previousTreatments: e.target.value })}
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Aktif Kullanılan İlaçlar</label>
                            <textarea
                                rows={2}
                                className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-teal-500 focus:border-teal-500 shadow-sm resize-none"
                                placeholder="Şu an kullanılan ilaçlar..."
                                value={formData.activeMedicines}
                                onChange={e => setFormData({ ...formData, activeMedicines: e.target.value })}
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Kullanılan Takviyeler</label>
                            <textarea
                                rows={2}
                                className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-teal-500 focus:border-teal-500 shadow-sm resize-none"
                                placeholder="Vitamin, mineral vb..."
                                value={formData.supplements}
                                onChange={e => setFormData({ ...formData, supplements: e.target.value })}
                            />
                        </div>
                    </div>

                    <div className="grid grid-cols-1 gap-6">
                        <div>
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Şikayetler</label>
                            <textarea
                                rows={3}
                                className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-teal-500 focus:border-teal-500 shadow-sm resize-none"
                                placeholder="Danışanın güncel şikayetleri..."
                                value={formData.complaints}
                                onChange={e => setFormData({ ...formData, complaints: e.target.value })}
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Bağırsak Problemi</label>
                            <textarea
                                rows={2}
                                className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-teal-500 focus:border-teal-500 shadow-sm resize-none"
                                placeholder="Kabızlık, şişkinlik vb..."
                                value={formData.bowelProblems}
                                onChange={e => setFormData({ ...formData, bowelProblems: e.target.value })}
                            />
                        </div>
                    </div>

                    {/* 4. Kan Değerleri - Dosya Yükleme */}
                    <div>
                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-3">Kan Değerleri / Raporlar</label>
                        <div className="flex items-center gap-4">
                            <label className="cursor-pointer bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-700/50 text-slate-700 dark:text-slate-200 px-5 py-3 rounded-xl font-bold transition-all shadow-sm hover:shadow-md flex items-center gap-2 group">
                                <Upload size={20} className="text-slate-400 group-hover:text-teal-500 transition-colors" />
                                Dosya veya Görsel Seç
                                <input type="file" className="hidden" onChange={handleFileUpload} accept="image/*,.pdf,.doc,.docx" />
                            </label>
                            {formData.bloodValues && (
                                <div className="flex items-center gap-3 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-300 px-4 py-3 rounded-xl border border-indigo-200 dark:border-indigo-800 animate-in fade-in slide-in-from-left-2">
                                    <div className="p-1.5 bg-indigo-100 dark:bg-indigo-800 rounded-lg">
                                        <FileText size={18} />
                                    </div>
                                    <span className="text-sm font-bold truncate max-w-[200px]">{formData.bloodValues.name}</span>
                                    <button
                                        onClick={() => setFormData({ ...formData, bloodValues: null })}
                                        className="text-indigo-400 hover:text-red-500 ml-1 p-1 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-full transition-colors"
                                    >
                                        <X size={16} />
                                    </button>
                                </div>
                            )}
                        </div>
                        <p className="text-xs text-slate-400 mt-2 font-medium">Kan tahlili sonuçları veya ilgili tıbbi raporları buradan yükleyebilirsiniz.</p>
                    </div>

                    <div className="h-px bg-slate-100 dark:bg-slate-800 w-full"></div>


                </div>

                {/* 6. Notlar */}
                <div className="px-6 pb-6">
                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Genel Notlar</label>
                    <textarea
                        rows={3}
                        className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-teal-500 focus:border-teal-500 shadow-sm resize-none"
                        placeholder="Eklemek istediğiniz notlar..."
                        value={formData.notes || ""}
                        onChange={e => setFormData({ ...formData, notes: e.target.value })}
                    />
                </div>


                {/* Footer */}
                <div className="px-6 py-5 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 flex justify-end gap-3 flex-shrink-0 rounded-b-2xl">
                    <button
                        onClick={onClose}
                        className="px-6 py-3 text-slate-700 dark:text-slate-300 font-bold hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors"
                    >
                        Vazgeç
                    </button>
                    <button
                        onClick={handleSave}
                        className="px-6 py-3 bg-teal-600 text-white font-bold rounded-xl hover:bg-teal-700 shadow-lg shadow-teal-500/30 hover:shadow-teal-500/40 active:scale-95 transition-all flex items-center gap-2"
                    >
                        <Check size={20} strokeWidth={2.5} />
                        Anamnezi Kaydet
                    </button>
                </div>
            </div>
        </div>
    );
}
