$ErrorActionPreference = "Stop"

$projectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$addressFile = Join-Path $projectDir "ana_bilgisayar_sabit_adresi.txt"

if (Test-Path $addressFile) {
    $terminalAddress = (Get-Content -LiteralPath $addressFile -Raw).Trim()
} else {
    $config = Get-NetIPConfiguration |
        Where-Object {
            $_.IPv4Address -and
            $_.IPv4DefaultGateway -and
            $_.NetAdapter.Status -eq "Up" -and
            $_.IPv4Address.IPAddress -notlike "169.254.*"
        } |
        Select-Object -First 1

    if (-not $config) {
        throw "Ana bilgisayarin yerel IP adresi bulunamadi."
    }

    $terminalAddress = "http://$($config.IPv4Address.IPAddress):3001"
}

if ($terminalAddress -notmatch '^https?://.+:3001$') {
    throw "Terminal adresi gecersiz gorunuyor: $terminalAddress"
}

$targets = @(
    (Join-Path $projectDir "terminal_adres.txt"),
    (Join-Path $projectDir "SIFIR_KURULUM_PAKETLERI\PharmaLog_Terminal\terminal_adres.txt")
)

foreach ($target in $targets) {
    $dir = Split-Path -Parent $target
    if (Test-Path $dir) {
        Set-Content -LiteralPath $target -Value $terminalAddress -Encoding ASCII
        Write-Host "Hazirlandi: $target"
    }
}

Write-Host ""
Write-Host "Terminal adresi:"
Write-Host $terminalAddress
Write-Host ""
Write-Host "Terminal bilgisayara terminal_adres.txt dosyasini terminal klasorunun icine kopyalarsaniz adres sormadan acilir."
