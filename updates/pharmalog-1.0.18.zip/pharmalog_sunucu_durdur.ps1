$projectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$pidFile = Join-Path $projectDir "pharmalog_server.pid"

if (Test-Path $pidFile) {
    $pidText = (Get-Content $pidFile -ErrorAction SilentlyContinue | Select-Object -First 1)
    if ($pidText -match '^\d+$') {
        Stop-Process -Id ([int]$pidText) -ErrorAction SilentlyContinue
    }
    Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
}

$portOwners = Get-NetTCPConnection -LocalPort 3001 -ErrorAction SilentlyContinue |
    Where-Object { $_.State -eq "Listen" -or $_.State -eq "Established" } |
    Select-Object -ExpandProperty OwningProcess -Unique

foreach ($ownerPid in $portOwners) {
    $process = Get-Process -Id $ownerPid -ErrorAction SilentlyContinue
    if ($process -and $process.ProcessName -eq "node") {
        Stop-Process -Id $ownerPid -ErrorAction SilentlyContinue
    }
}

Write-Host "PharmaLog sunucusu durduruldu."
Start-Sleep -Seconds 2
