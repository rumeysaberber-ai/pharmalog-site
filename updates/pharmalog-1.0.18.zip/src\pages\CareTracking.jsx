import React, { useState, useEffect } from 'react';
import { DataService } from '../lib/data'; // Adjust path if necessary
import { format } from 'date-fns';
import { tr } from 'date-fns/locale';
import { Shield, Calendar, History, Search, User, Phone, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { cn } from '../lib/utils'; // Adjust path if necessary

export default function CareTracking() {
    const [patients, setPatients] = useState([]);
    const [activeTab, setActiveTab] = useState('appointments'); // rights, performed, appointments
    const [searchTerm, setSearchTerm] = useState("");

    useEffect(() => {
        const loadData = async () => {
            const data = await DataService.getPatients();
            setPatients(data);
        };
        loadData();

        const handleDataChange = () => loadData();
        window.addEventListener('data-change', handleDataChange);
        return () => window.removeEventListener('data-change', handleDataChange);
    }, []);

    // 1. Care Rights Holders
    const rightsHolders = patients
        .map(p => {
            const txs = p.skinCareData?.transactions || [];
            const calculatedRights = txs.reduce((acc, t) => {
                if (t.type === 'add_right') return acc + (parseInt(t.value) || 0);
                if (t.type === 'use_right') return acc - 1;
                return acc;
            }, 0);

            return {
                id: p.id,
                name: p.fullName,
                phone: p.phone,
                rights: calculatedRights
            };
        })
        .filter(p => p.rights > 0)
        .filter(i => i.name.toLowerCase().includes(searchTerm.toLowerCase()));

    // 2. Performed Care History (Flattened)
    const careHistory = patients
        .flatMap(p => {
            if (!p.skinCareData?.transactions) return [];
            return p.skinCareData.transactions.map(t => ({
                ...t,
                patientId: p.id,
                patientName: p.fullName,
                patientPhone: p.phone
            }));
        })
        .filter(t => ['use_right', 'paid_service'].includes(t.type)) // Only actual care actions
        .sort((a, b) => new Date(b.date) - new Date(a.date))
        .filter(i => i.patientName.toLowerCase().includes(searchTerm.toLowerCase()));

    // 3. Upcoming Appointments (Flattened)
    const appointments = patients
        .flatMap(p => {
            if (!p.skinCareData?.appointments) return [];
            return p.skinCareData.appointments.map(a => ({
                ...a,
                patientId: p.id,
                patientName: p.fullName,
                patientPhone: p.phone
            }));
        })
        .filter(a => a.status === 'scheduled')
        .sort((a, b) => new Date(a.date) - new Date(b.date))
        .filter(i => i.patientName.toLowerCase().includes(searchTerm.toLowerCase()));


    return (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div>
                    <h1 className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-slate-900 to-slate-700 dark:from-white dark:to-slate-300">
                        Cilt Bakım Takibi
                    </h1>
                    <p className="text-slate-500 dark:text-slate-400 mt-1 font-medium">Bakım hakkı olanlar, yapılan işlemler ve randevular.</p>
                </div>
                <div className="relative w-full md:w-72">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input
                        type="text"
                        placeholder="Danışan ara..."
                        className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white/60 dark:bg-slate-900/60 backdrop-blur-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500 transition-all shadow-sm"
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                    />
                </div>
            </div>

            {/* Stats Overview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white/60 dark:bg-slate-900/60 backdrop-blur-xl p-6 rounded-2xl border border-white/40 dark:border-slate-800 shadow-lg shadow-slate-200/50 dark:shadow-black/20 flex items-center gap-5 hover:scale-[1.02] transition-transform">
                    <div className="w-14 h-14 rounded-2xl bg-teal-100 dark:bg-teal-900/30 flex items-center justify-center text-teal-600 dark:text-teal-400 shadow-sm">
                        <Shield size={28} />
                    </div>
                    <div>
                        <div className="text-sm text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wide">Hakkı Olan Kişi</div>
                        <div className="text-3xl font-black text-slate-800 dark:text-white">{rightsHolders.length}</div>
                    </div>
                </div>
                <div className="bg-white/60 dark:bg-slate-900/60 backdrop-blur-xl p-6 rounded-2xl border border-white/40 dark:border-slate-800 shadow-lg shadow-slate-200/50 dark:shadow-black/20 flex items-center gap-5 hover:scale-[1.02] transition-transform">
                    <div className="w-14 h-14 rounded-2xl bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center text-purple-600 dark:text-purple-400 shadow-sm">
                        <History size={28} />
                    </div>
                    <div>
                        <div className="text-sm text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wide">Toplam İşlem</div>
                        <div className="text-3xl font-black text-slate-800 dark:text-white">{careHistory.length}</div>
                    </div>
                </div>
                <div className="bg-white/60 dark:bg-slate-900/60 backdrop-blur-xl p-6 rounded-2xl border border-white/40 dark:border-slate-800 shadow-lg shadow-slate-200/50 dark:shadow-black/20 flex items-center gap-5 hover:scale-[1.02] transition-transform">
                    <div className="w-14 h-14 rounded-2xl bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 dark:text-blue-400 shadow-sm">
                        <Calendar size={28} />
                    </div>
                    <div>
                        <div className="text-sm text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wide">Bekleyen Randevu</div>
                        <div className="text-3xl font-black text-slate-800 dark:text-white">{appointments.length}</div>
                    </div>
                </div>
            </div>

            {/* Tabs & Content */}
            <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl rounded-3xl border border-white/20 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-black/20 min-h-[500px] flex flex-col overflow-hidden">
                <div className="p-2 bg-slate-100/50 dark:bg-slate-800/50 border-b border-slate-200/50 dark:border-slate-700/50 overflow-x-auto">
                    <div className="flex p-1 gap-2">
                        <button
                            onClick={() => setActiveTab('appointments')}
                            className={cn(
                                "px-6 py-2.5 text-sm font-bold rounded-xl transition-all whitespace-nowrap flex items-center justify-center gap-2 flex-1",
                                activeTab === 'appointments'
                                    ? "bg-white dark:bg-slate-800 text-teal-600 dark:text-teal-400 shadow-sm"
                                    : "text-slate-500 dark:text-slate-400 hover:bg-white/50 dark:hover:bg-slate-700/50"
                            )}
                        >
                            <Calendar size={18} />
                            Randevular ({appointments.length})
                        </button>
                        <button
                            onClick={() => setActiveTab('rights')}
                            className={cn(
                                "px-6 py-2.5 text-sm font-bold rounded-xl transition-all whitespace-nowrap flex items-center justify-center gap-2 flex-1",
                                activeTab === 'rights'
                                    ? "bg-white dark:bg-slate-800 text-teal-600 dark:text-teal-400 shadow-sm"
                                    : "text-slate-500 dark:text-slate-400 hover:bg-white/50 dark:hover:bg-slate-700/50"
                            )}
                        >
                            <Shield size={18} />
                            Bakım Hakkı Olanlar ({rightsHolders.length})
                        </button>
                        <button
                            onClick={() => setActiveTab('performed')}
                            className={cn(
                                "px-6 py-2.5 text-sm font-bold rounded-xl transition-all whitespace-nowrap flex items-center justify-center gap-2 flex-1",
                                activeTab === 'performed'
                                    ? "bg-white dark:bg-slate-800 text-teal-600 dark:text-teal-400 shadow-sm"
                                    : "text-slate-500 dark:text-slate-400 hover:bg-white/50 dark:hover:bg-slate-700/50"
                            )}
                        >
                            <History size={18} />
                            İşlem Geçmişi
                        </button>
                    </div>
                </div>

                <div className="p-0 flex-1 overflow-auto">
                    {/* --- APPOINTMENTS TAB --- */}
                    {activeTab === 'appointments' && (
                        appointments.length > 0 ? (
                            <table className="w-full text-left text-sm">
                                <thead className="bg-slate-50/50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 font-bold sticky top-0 z-10 backdrop-blur-sm">
                                    <tr>
                                        <th className="px-8 py-4 uppercase tracking-wider text-xs">Tarih & Saat</th>
                                        <th className="px-8 py-4 uppercase tracking-wider text-xs">Danışan Adı</th>
                                        <th className="px-8 py-4 uppercase tracking-wider text-xs">Not / İşlem</th>
                                        <th className="px-8 py-4 w-10"></th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                                    {appointments.map(app => (
                                        <tr key={app.id} className="hover:bg-indigo-50/30 dark:hover:bg-indigo-900/10 transition-colors group">
                                            <td className="px-8 py-5 text-slate-700 dark:text-slate-200 font-medium">
                                                <div className="flex items-center gap-3">
                                                    <div className="bg-blue-50 dark:bg-blue-900/20 p-2 rounded-lg text-blue-600 dark:text-blue-400">
                                                        <Calendar size={18} />
                                                    </div>
                                                    <div>
                                                        <div>{format(new Date(app.date), 'dd MMMM yyyy', { locale: tr })}</div>
                                                        <div className="text-slate-500 font-normal text-xs mt-0.5">
                                                            {format(new Date(app.date), 'HH:mm')}
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td className="px-8 py-5">
                                                <div className="font-bold text-slate-800 dark:text-white">{app.patientName}</div>
                                                <div className="text-xs text-slate-400 font-mono mt-0.5">{app.patientPhone}</div>
                                            </td>
                                            <td className="px-8 py-5 text-slate-600 dark:text-slate-300 font-medium italic">{app.note}</td>
                                            <td className="px-8 py-5">
                                                <Link
                                                    to={`/patients/${app.patientId}`}
                                                    className="w-10 h-10 bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-white hover:bg-teal-500 rounded-full transition-all flex items-center justify-center opacity-0 group-hover:opacity-100 shadow-sm"
                                                    title="Danışan Detayına Git"
                                                >
                                                    <ArrowRight size={18} />
                                                </Link>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        ) : (
                            <EmptyState message="Bekleyen bakım randevusu bulunmuyor." icon={Calendar} />
                        )
                    )}

                    {/* --- RIGHTS TAB --- */}
                    {activeTab === 'rights' && (
                        rightsHolders.length > 0 ? (
                            <table className="w-full text-left text-sm">
                                <thead className="bg-slate-50/50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 font-bold sticky top-0 z-10 backdrop-blur-sm">
                                    <tr>
                                        <th className="px-8 py-4 uppercase tracking-wider text-xs">Danışan Adı</th>
                                        <th className="px-8 py-4 uppercase tracking-wider text-xs">Telefon</th>
                                        <th className="px-8 py-4 text-center uppercase tracking-wider text-xs">Kalan Hak</th>
                                        <th className="px-8 py-4 w-10"></th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                                    {rightsHolders.map(p => (
                                        <tr key={p.id} className="hover:bg-indigo-50/30 dark:hover:bg-indigo-900/10 transition-colors group">
                                            <td className="px-8 py-5 font-bold text-slate-800 dark:text-white">
                                                <div className="flex items-center gap-4">
                                                    <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center text-slate-500 dark:text-slate-300 border border-slate-200 dark:border-slate-600">
                                                        <User size={18} />
                                                    </div>
                                                    {p.name}
                                                </div>
                                            </td>
                                            <td className="px-8 py-5 text-slate-600 dark:text-slate-300 font-mono">
                                                <div className="flex items-center gap-2">
                                                    <Phone size={14} className="text-slate-300 dark:text-slate-500" />
                                                    {p.phone}
                                                </div>
                                            </td>
                                            <td className="px-8 py-5 text-center">
                                                <span className="inline-flex items-center px-4 py-1.5 rounded-full text-sm font-bold bg-teal-50 dark:bg-teal-900/20 text-teal-700 dark:text-teal-400 border border-teal-100 dark:border-teal-800 shadow-sm">
                                                    {p.rights} Hak
                                                </span>
                                            </td>
                                            <td className="px-8 py-5">
                                                <Link
                                                    to={`/patients/${p.id}`}
                                                    className="w-10 h-10 bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-white hover:bg-teal-500 rounded-full transition-all flex items-center justify-center opacity-0 group-hover:opacity-100 shadow-sm"
                                                    title="Danışan Detayına Git"
                                                >
                                                    <ArrowRight size={18} />
                                                </Link>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        ) : (
                            <EmptyState message="Tanımlanmış bakım hakkı bulunan danışan yok." icon={Shield} />
                        )
                    )}

                    {/* --- PERFORMED TAB --- */}
                    {activeTab === 'performed' && (
                        careHistory.length > 0 ? (
                            <table className="w-full text-left text-sm">
                                <thead className="bg-slate-50/50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 font-bold sticky top-0 z-10 backdrop-blur-sm">
                                    <tr>
                                        <th className="px-8 py-4 uppercase tracking-wider text-xs">Tarih</th>
                                        <th className="px-8 py-4 uppercase tracking-wider text-xs">Danışan</th>
                                        <th className="px-8 py-4 uppercase tracking-wider text-xs">İşlem</th>
                                        <th className="px-8 py-4 uppercase tracking-wider text-xs">Detay</th>
                                        <th className="px-8 py-4 w-10"></th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                                    {careHistory.map(item => (
                                        <tr key={item.id} className="hover:bg-indigo-50/30 dark:hover:bg-indigo-900/10 transition-colors group">
                                            <td className="px-8 py-5 text-slate-600 dark:text-slate-300 font-medium whitespace-nowrap">
                                                {format(new Date(item.date), 'dd.MM.yyyy HH:mm', { locale: tr })}
                                            </td>
                                            <td className="px-8 py-5">
                                                <div className="font-bold text-slate-800 dark:text-white">{item.patientName}</div>
                                            </td>
                                            <td className="px-8 py-5">
                                                <span className={cn(
                                                    "px-3 py-1 rounded-full text-xs font-bold border shadow-sm",
                                                    item.type === 'use_right'
                                                        ? "bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400 border-amber-200 dark:border-amber-800"
                                                        : "bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-400 border-purple-200 dark:border-purple-800"
                                                )}>
                                                    {item.type === 'use_right' ? 'Hak Kullanımı' : 'Ücretli İşlem'}
                                                </span>
                                            </td>
                                            <td className="px-8 py-5 text-slate-600 dark:text-slate-300 font-medium">
                                                {item.description}
                                                {item.amount > 0 && <span className="text-slate-400 ml-2 font-mono">({item.amount} TL)</span>}
                                            </td>
                                            <td className="px-8 py-5">
                                                <Link
                                                    to={`/patients/${item.patientId}`}
                                                    className="w-10 h-10 bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-white hover:bg-teal-500 rounded-full transition-all flex items-center justify-center opacity-0 group-hover:opacity-100 shadow-sm"
                                                    title="Danışan Detayına Git"
                                                >
                                                    <ArrowRight size={18} />
                                                </Link>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        ) : (
                            <EmptyState message="Henüz yapılmış bakım işlemi kaydı bulunmuyor." icon={History} />
                        )
                    )}
                </div>
            </div>
        </div>
    );
}

function EmptyState({ message, icon: Icon }) {
    return (
        <div className="flex flex-col items-center justify-center py-24 text-slate-400 animate-in fade-in zoom-in duration-500">
            <div className="w-20 h-20 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center mb-6 shadow-inner">
                <Icon size={36} className="opacity-40" />
            </div>
            <p className="font-medium text-lg">{message}</p>
        </div>
    );
}
