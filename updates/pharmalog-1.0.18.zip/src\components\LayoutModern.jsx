import { Link, useLocation } from "react-router-dom";
import { LayoutDashboard, Users, Menu, X, Package, Settings, Building, Shield, User, LogOut } from "lucide-react";

import { useState, useEffect } from "react";
import { cn } from "../lib/utils";
import { DataService } from "../lib/data";
import UpdateNotifier from "./UpdateNotifier";

export default function LayoutModern({ children }) {
    const [isSidebarOpen, setIsSidebarOpen] = useState(true);
    const [patientCount, setPatientCount] = useState(0);
    const location = useLocation();

    // Fetch count
    useEffect(() => {
        const fetchCount = () => {
            DataService.getPatients().then(pts => setPatientCount(pts.length));
        };
        fetchCount();
        const handleDataChange = () => fetchCount();
        window.addEventListener('data-change', handleDataChange);
        return () => window.removeEventListener('data-change', handleDataChange);
    }, []);

    const navigation = [
        { name: "Genel Bakış", href: "/dashboard-new", icon: LayoutDashboard },
        { name: "Danışanlar", href: "/patients", icon: Users, badge: patientCount },
        { name: "Firmalar", href: "/companies", icon: Building },
        { name: "Bakım Takibi", href: "/care-tracking", icon: Shield },
        { name: "Ürünler", href: "/products", icon: Package },
    ];

    return (
        <div className="min-h-screen bg-slate-100 dark:bg-slate-950 flex transition-colors duration-500 font-sans selection:bg-teal-500/30">
            {/* Background Ambient Mesh */}
            <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
                <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-teal-500/10 rounded-full blur-[100px] mix-blend-multiply dark:mix-blend-screen opacity-50 animate-pulse" style={{ animationDuration: '4s' }} />
                <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-indigo-500/10 rounded-full blur-[100px] mix-blend-multiply dark:mix-blend-screen opacity-50 animate-pulse" style={{ animationDuration: '7s' }} />
            </div>

            {/* Mobile Overlay */}
            <div className={cn("fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden transition-opacity", isSidebarOpen ? "opacity-100" : "opacity-0 pointer-events-none")} onClick={() => setIsSidebarOpen(false)} />

            {/* --- MODERN SIDEBAR --- */}
            <aside className={cn(
                "fixed lg:static inset-y-0 left-0 z-50 w-72 transform transition-all duration-300 ease-out lg:transform-none lg:bg-transparent pl-4 py-4 flex flex-col",
                isSidebarOpen ? "translate-x-0 bg-white dark:bg-slate-900 shadow-2xl lg:shadow-none" : "-translate-x-full"
            )}>
                <div className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-xl border border-white/40 dark:border-slate-800 rounded-3xl shadow-xl shadow-slate-200/50 dark:shadow-black/20 h-full flex flex-col overflow-hidden">
                    {/* Brand */}
                    <div className="h-32 flex items-center px-2 border-b border-slate-100/50 dark:border-slate-800/50">
                        <div className="flex items-center gap-1 w-full">
                            <img src="/pharmalog-logo.png" alt="Logo" className="h-20 w-auto object-contain drop-shadow-md flex-shrink-0" />
                            <span className="text-xl font-extrabold text-slate-800 dark:text-white tracking-tight flex-1 text-center -ml-9">
                                PharmaLog
                            </span>
                        </div>
                        <button onClick={() => setIsSidebarOpen(false)} className="ml-auto lg:hidden text-slate-400">
                            <X size={20} />
                        </button>
                    </div>

                    {/* Nav */}
                    <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
                        <div className="px-4 pb-2">
                            <p className="text-xs font-bold text-slate-400 dark:text-slate-600 uppercase tracking-wider">Menü</p>
                        </div>
                        {navigation.map((item) => {
                            const Icon = item.icon;
                            // Strict check for active state on dashboard-new
                            const isActive = location.pathname === item.href;
                            return (
                                <Link
                                    key={item.name}
                                    to={item.href}
                                    className={cn(
                                        "group flex items-center justify-between px-4 py-3.5 rounded-2xl text-sm font-bold transition-all duration-200",
                                        isActive
                                            ? "bg-gradient-to-r from-teal-500 to-indigo-600 text-white shadow-lg shadow-indigo-500/30 transform scale-[1.02]"
                                            : "text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white"
                                    )}
                                >
                                    <div className="flex items-center gap-3.5">
                                        <Icon size={20} className={cn(isActive ? "text-white" : "text-slate-400 dark:text-slate-500 group-hover:text-slate-600 dark:group-hover:text-slate-300")} />
                                        {item.name}
                                    </div>
                                    {item.badge !== undefined && item.badge > 0 && (
                                        <span className={cn(
                                            "text-[10px] font-extrabold px-2 py-0.5 rounded-full",
                                            isActive ? "bg-white/20 text-white" : "bg-teal-100 dark:bg-teal-900/50 text-teal-700 dark:text-teal-400"
                                        )}>
                                            {item.badge}
                                        </span>
                                    )}
                                </Link>
                            );
                        })}

                        <div className="mt-8 px-4 pb-2">
                            <p className="text-xs font-bold text-slate-400 dark:text-slate-600 uppercase tracking-wider">Hesap</p>
                        </div>
                        <Link to="/profile" className="flex items-center gap-3.5 px-4 py-3.5 rounded-2xl text-sm font-medium text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors">
                            <User size={20} />
                            Profil
                        </Link>
                        <Link to="/settings" className="flex items-center gap-3.5 px-4 py-3.5 rounded-2xl text-sm font-medium text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors">
                            <Settings size={20} />
                            Ayarlar
                        </Link>
                    </nav>

                    {/* Footer User Profile */}
                    <div className="p-4 mt-auto">
                        <UpdateNotifier />
                        <div className="bg-slate-50 dark:bg-slate-800/50 rounded-2xl p-3 flex items-center gap-3 border border-slate-100 dark:border-slate-800">
                            <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-900 flex items-center justify-center text-indigo-700 dark:text-indigo-300 font-bold">
                                A
                            </div>
                            <div className="flex-1 min-w-0">
                                <p className="text-sm font-bold text-slate-900 dark:text-white truncate">Admin User</p>
                                <p className="text-xs text-slate-500 dark:text-slate-400 truncate">Sistem Yöneticisi</p>
                            </div>
                        </div>
                    </div>
                </div>
            </aside>

            {/* --- MAIN CONTENT --- */}
            <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden relative z-10">
                <header className="h-20 flex items-center justify-between px-8 pt-4 pb-2">
                    <button
                        onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                        className="p-2.5 bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 lg:hidden"
                    >
                        <Menu size={20} />
                    </button>

                    {/* Header Actions */}
                    <div className="ml-auto flex items-center gap-4">
                        <div className="hidden md:flex items-center px-4 py-2 bg-white/60 dark:bg-slate-800/60 backdrop-blur-md rounded-full border border-white/20 dark:border-slate-700 shadow-sm text-sm font-medium text-slate-600 dark:text-slate-300">
                            <span className="w-2 h-2 rounded-full bg-emerald-500 mr-2 animate-pulse"></span>
                            Sistem Çevrimiçi
                        </div>
                    </div>
                </header>

                <main className="flex-1 overflow-x-hidden overflow-y-auto px-4 lg:px-8 pb-8 pt-2">
                    <div className="max-w-7xl mx-auto">
                        {children}
                    </div>
                    <div className="h-8"></div>
                </main>
            </div>
        </div>
    );
}
