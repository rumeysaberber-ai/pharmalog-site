$startup = [Environment]::GetFolderPath("Startup")
if (-not $startup) {
    $startup = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Startup"
}

$shortcutPath = Join-Path $startup "PharmaLog Sunucu Otomatik Baslat.lnk"
Remove-Item -LiteralPath $shortcutPath -Force -ErrorAction SilentlyContinue

Write-Host "PharmaLog otomatik baslatma kaldirildi."
