import { Sequelize, DataTypes } from 'sequelize';
import path from 'path';
import { fileURLToPath } from 'url';
import { safeJsonParse } from './lib/safeJsonParse.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Veritabanı dosyasının yolu: Ana dizinde 'database.sqlite'
const storagePath = process.env.DERMASOFT_DB_PATH
    ? path.resolve(process.env.DERMASOFT_DB_PATH)
    : path.join(__dirname, '..', 'database.sqlite');

const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: storagePath,
    logging: false // Konsol kirliliğini önlemek için logları kapatıyoruz
});

// --- MODELLER ---

// Kullanıcı Modeli (Relational Master)
const User = sequelize.define('User', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    username: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false
    },
    name: {
        type: DataTypes.STRING,
        allowNull: true
    },
    role: {
        type: DataTypes.STRING,
        defaultValue: 'staff'
    },
    pharmacyName: {
        type: DataTypes.STRING,
        allowNull: true
    },
    // Group logic can remain for team visibility if needed
    group: {
        type: DataTypes.STRING,
        defaultValue: 'main_group'
    }
});

// Hasta Modeli
const Patient = sequelize.define('Patient', {
    id: {
        type: DataTypes.STRING, // Frontend generated UUID
        primaryKey: true
    },
    // UserId Foreign Key will be added by association below

    fullName: {
        type: DataTypes.STRING,
        allowNull: true
    },
    phone: {
        type: DataTypes.STRING,
        allowNull: true
    },

    // JSON Data Bag for everything else (Schema-less flexibility)
    patient_data: {
        type: DataTypes.TEXT,
        defaultValue: '{}',
        get() {
            const raw = this.getDataValue('patient_data');
            return safeJsonParse(raw, {});
        },
        set(value) {
            this.setDataValue('patient_data', JSON.stringify(value));
        }
    },

    createdAt: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
    updatedAt: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
});

// Şirket Modeli
const Company = sequelize.define('Company', {
    id: {
        type: DataTypes.STRING,
        primaryKey: true
    },
    name: {
        type: DataTypes.STRING,
        allowNull: true
    },
    data: {
        type: DataTypes.TEXT,
        defaultValue: '{}',
        get() { return safeJsonParse(this.getDataValue('data'), {}); },
        set(val) { this.setDataValue('data', JSON.stringify(val)); }
    }
});

// Ürün Modeli
const Product = sequelize.define('Product', {
    id: {
        type: DataTypes.STRING,
        primaryKey: true
    },
    data: {
        type: DataTypes.TEXT,
        defaultValue: '{}',
        get() { return safeJsonParse(this.getDataValue('data'), {}); },
        set(val) { this.setDataValue('data', JSON.stringify(val)); }
    }
});

const IysSetting = sequelize.define('IysSetting', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    provider: {
        type: DataTypes.STRING,
        defaultValue: 'verimor'
    },
    enabled: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
    },
    verimorUsername: {
        type: DataTypes.STRING,
        allowNull: true
    },
    verimorPassword: {
        type: DataTypes.STRING,
        allowNull: true
    },
    sourceAddr: {
        type: DataTypes.STRING,
        allowNull: true
    },
    defaultSource: {
        type: DataTypes.STRING,
        defaultValue: 'HS_FIZIKSEL_ORTAM'
    },
    defaultRecipientType: {
        type: DataTypes.STRING,
        defaultValue: 'BIREYSEL'
    },
    data: {
        type: DataTypes.TEXT,
        defaultValue: '{}',
        get() { return safeJsonParse(this.getDataValue('data'), {}); },
        set(val) { this.setDataValue('data', JSON.stringify(val || {})); }
    }
}, {
    tableName: 'iys_settings'
});

const IysConsentLog = sequelize.define('IysConsentLog', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    patientId: {
        type: DataTypes.STRING,
        allowNull: true
    },
    recipient: {
        type: DataTypes.STRING,
        allowNull: false
    },
    type: {
        type: DataTypes.STRING,
        allowNull: false
    },
    status: {
        type: DataTypes.STRING,
        allowNull: false
    },
    source: {
        type: DataTypes.STRING,
        allowNull: false
    },
    recipientType: {
        type: DataTypes.STRING,
        allowNull: false
    },
    consentDate: {
        type: DataTypes.DATE,
        allowNull: false
    },
    requestStatus: {
        type: DataTypes.STRING,
        defaultValue: 'PENDING'
    },
    requestPayload: {
        type: DataTypes.TEXT,
        defaultValue: '{}',
        get() { return safeJsonParse(this.getDataValue('requestPayload'), {}); },
        set(val) { this.setDataValue('requestPayload', JSON.stringify(val || {})); }
    },
    responsePayload: {
        type: DataTypes.TEXT,
        defaultValue: '{}',
        get() { return safeJsonParse(this.getDataValue('responsePayload'), {}); },
        set(val) { this.setDataValue('responsePayload', JSON.stringify(val || {})); }
    },
    errorMessage: {
        type: DataTypes.TEXT,
        allowNull: true
    }
}, {
    tableName: 'iys_consent_logs'
});

// Associations
User.hasMany(Patient, { onDelete: 'CASCADE' });
Patient.belongsTo(User);

User.hasMany(Company, { onDelete: 'CASCADE' });
Company.belongsTo(User);

User.hasOne(IysSetting, { onDelete: 'CASCADE' });
IysSetting.belongsTo(User);

User.hasMany(IysConsentLog, { onDelete: 'CASCADE' });
IysConsentLog.belongsTo(User);

Patient.hasMany(IysConsentLog, { foreignKey: 'patientId', sourceKey: 'id', constraints: false });
IysConsentLog.belongsTo(Patient, { foreignKey: 'patientId', targetKey: 'id', constraints: false });

export { sequelize, User, Patient, Company, Product, IysSetting, IysConsentLog };

