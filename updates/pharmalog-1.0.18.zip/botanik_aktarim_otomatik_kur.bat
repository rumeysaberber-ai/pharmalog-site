@echo off
title Botanik Aktarim Otomatik Kurulum
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0botanik_aktarim_otomatik_kur.ps1"
pause
