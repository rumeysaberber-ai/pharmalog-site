import React from 'react';
import { format } from "date-fns";
import { tr } from "date-fns/locale";
import logo from "../assets/pharmalog_logo.png";

const PrintableDetailedForm = React.forwardRef(({ data, patientName, isEmpty }, ref) => {
    // If isEmpty is true, we ignore data and render purely blank fields for handwriting
    const formData = isEmpty ? {} : (data || {});

    // Helper for rendering line for handwriting
    const Line = ({ label, value, unit = "" }) => (
        <div className="mb-4">
            <span className="block text-xs font-bold text-slate-800 mb-1">{label}</span>
            {isEmpty ? (
                <div className="border-b border-slate-300 h-6 w-full flex items-end justify-end px-2 text-xs text-slate-400">{unit}</div>
            ) : (
                <div className="text-sm font-medium text-slate-900 border-b border-slate-200 pb-1">
                    {value ? `${value} ${unit}` : '-'}
                </div>
            )}
        </div>
    );

    const YesNo = ({ label, value }) => (
        <div className="flex items-center justify-between border-b border-slate-200 pb-2 mb-2">
            <span className="text-sm font-medium text-slate-800">{label}</span>
            <div className="flex gap-4">
                <div className="flex items-center gap-1">
                    <div className={`w-4 h-4 border border-slate-400 rounded-full flex items-center justify-center ${(!isEmpty && value) ? 'bg-slate-800' : ''}`}>
                        {(!isEmpty && value) && <div className="w-1.5 h-1.5 bg-white rounded-full"></div>}
                    </div>
                    <span className="text-xs">EVET</span>
                </div>
                <div className="flex items-center gap-1">
                    <div className={`w-4 h-4 border border-slate-400 rounded-full flex items-center justify-center ${(!isEmpty && !value && value !== undefined) ? 'bg-slate-800' : ''}`}>
                        {(!isEmpty && !value && value !== undefined) && <div className="w-1.5 h-1.5 bg-white rounded-full"></div>}
                    </div>
                    <span className="text-xs">HAYIR</span>
                </div>
            </div>
        </div>
    );

    const TextAreaBox = ({ label, value, height = "h-48" }) => (
        <div className={`border border-slate-300 rounded p-4 mb-5 break-inside-avoid ${height} flex flex-col justify-between shadow-sm`}>
            <h5 className="text-xs font-bold text-slate-900 uppercase mb-2 border-b border-slate-200 pb-1 tracking-wide">{label}</h5>
            {!isEmpty && value && <p className="text-sm text-slate-800 leading-relaxed">{value}</p>}
        </div>
    );

    return (
        <div ref={ref} className="p-10 bg-white text-slate-900 font-sans max-w-[210mm] mx-auto print:w-full min-h-[297mm] flex flex-col">
            {/* Header */}
            <div className="border-b-2 border-slate-900 pb-6 mb-8">
                <div className="flex justify-between items-start mb-8">
                    <div className="flex items-center gap-5">
                        <img src={logo} alt="Logo" className="h-14 w-auto object-contain" />
                        <div>
                            <h1 className="text-xl font-bold tracking-tight">DETAYLI ANAMNEZ FORMU</h1>
                            <p className="text-xs text-slate-500 uppercase font-medium tracking-wider">PharmaLog Otomasyon Sistemi</p>
                        </div>
                    </div>
                    <div className="text-right">
                        <div className="text-xs text-slate-500 font-medium">{format(new Date(), "d MMMM yyyy", { locale: tr })}</div>
                    </div>
                </div>

                {/* Patient Info Fields */}
                <div className="flex justify-between gap-8 mb-2">
                    <div className="flex-1 border-b border-slate-400 pb-2">
                        <span className="block text-xs font-bold text-black uppercase mb-6 tracking-wide">Adı Soyadı</span>
                        <div className="h-2"></div>
                    </div>
                    <div className="flex-1 border-b border-slate-400 pb-2">
                        <span className="block text-xs font-bold text-black uppercase mb-6 tracking-wide">Doğum Tarihi / Yaş</span>
                        <div className="h-2"></div>
                    </div>
                    <div className="flex-1 border-b border-slate-400 pb-2">
                        <span className="block text-xs font-bold text-black uppercase mb-6 tracking-wide">Telefon Numarası</span>
                        <div className="h-2"></div>
                    </div>
                </div>
            </div>

            {/* FİZİKSEL */}
            <div className="grid grid-cols-3 gap-8 mb-8">
                <Line label="Boy" value={formData.height} unit="cm" />
                <Line label="Kilo" value={formData.weight} unit="kg" />
                <Line label="VKİ (kg/m²)" value={formData.bmi} />
            </div>

            <div className="grid grid-cols-2 gap-10 mb-8">
                <YesNo label="Sigara Kullanımı" value={formData.smoking} />
                <YesNo label="Alkol Kullanımı" value={formData.alcohol} />
            </div>

            {/* TIBBİ GEÇMİŞ */}
            <h3 className="text-sm font-bold bg-slate-100 p-3 uppercase mb-6 border-l-4 border-slate-800 tracking-wider">TIBBİ GEÇMİŞ</h3>
            <div className="flex flex-col gap-5 mb-8">
                <TextAreaBox label="Kronik Hastalıklar" value={formData.chronicDiseases} height="h-28" />
                <TextAreaBox label="Önceden Görülmüş Tedaviler" value={formData.previousTreatments} height="h-28" />
                <TextAreaBox label="Aktif Kullanılan İlaçlar" value={formData.activeMedicines} height="h-28" />
                <TextAreaBox label="Kullanılan Takviyeler" value={formData.supplements} height="h-28" />
            </div>

            {/* ŞİKAYETLER - Forced to Page 2 */}
            <div className="break-before-page mt-8" style={{ pageBreakBefore: 'always' }}>
                <h3 className="text-sm font-bold bg-slate-100 p-3 uppercase mb-6 border-l-4 border-slate-800 tracking-wider">ŞİKAYETLER</h3>
                <div className="flex flex-col gap-4">
                    <TextAreaBox label="Güncel Şikayetler" value={formData.complaints} height="h-44" />
                    <TextAreaBox label="Bağırsak Problemleri (Kabızlık/Şişkinlik)" value={formData.bowelProblems} height="h-32" />
                </div>
            </div>

            {/* NOTLAR */}
            <div className="mt-8 border border-slate-200 rounded-lg p-5 h-40 shadow-sm break-inside-avoid">
                <span className="block text-xs font-bold text-slate-800 mb-2 uppercase tracking-wide">Genel Notlar / Uzman Görüşü:</span>
                {!isEmpty && formData.notes && <p className="text-sm leading-relaxed">{formData.notes}</p>}
            </div>

            {/* Footer Spacer */}
            <div className="flex-1 min-h-[2rem]"></div>

            {/* KVKK & Signatures */}
            <div className="mt-auto pt-6 border-t border-slate-300 break-inside-avoid">
                <p className="text-[10px] text-justify text-slate-500 mb-6 leading-relaxed">
                    6698 sayılı Kişisel Verilerin Korunması Kanunu (KVKK) kapsamında; yukarıda paylaştığım kimlik, iletişim ve sağlık verilerimin,
                    Irmak Eczanesi tarafından sunulan hizmetlerin (cilt analizi, ürün önerisi, ilaç takibi vb.) yerine getirilmesi amacıyla işlenmesine,
                    eczanenin kullandığı PharmaLog danışan takip yazılımına kaydedilmesine ve saklanmasına, tarafımla iletişim kurulmasına özgür irademle
                    <strong> AÇIK RIZA</strong> gösteriyorum. Eczanede asılı bulunan veya tarafıma sunulan detaylı KVKK Aydınlatma Metnini okudum ve anladım.
                </p>

                <div className="flex justify-between items-end mt-4 pb-2">
                    <div className="flex-1 flex flex-col gap-3">
                        <p className="text-xs font-bold text-slate-800 tracking-wide">
                            Tarih: ..... / ..... / 20..
                        </p>
                        <p className="text-xs font-bold text-slate-800 tracking-wide">
                            Adı Soyadı: .................................................
                        </p>
                        <p className="text-xs font-bold text-slate-800 tracking-wide">
                            İmza: ..............................
                        </p>
                    </div>
                    <div className="text-center min-w-[150px]">
                        <div className="h-6"></div>
                        <p className="text-[10px] font-bold border-t border-slate-400 px-4 pt-1 uppercase tracking-wider">UZMAN İMZA</p>
                    </div>
                </div>
            </div>
        </div>
    );
});

export default PrintableDetailedForm;
