$ruleName = "PharmaLog Yerel Ag 3001"

Write-Host "PharmaLog icin Windows Guvenlik Duvari izni ekleniyor..."

try {
    $existing = Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue
    if ($existing) {
        Remove-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue
    }

    New-NetFirewallRule `
        -DisplayName $ruleName `
        -Direction Inbound `
        -Action Allow `
        -Protocol TCP `
        -LocalPort 3001 `
        -Profile Any | Out-Null

    Write-Host "Tamam: 3001 portu yerel ag icin acildi."
} catch {
    Write-Host "PowerShell kurali eklenemedi, netsh deneniyor..."
    netsh advfirewall firewall delete rule name="$ruleName" | Out-Null
    netsh advfirewall firewall add rule name="$ruleName" dir=in action=allow protocol=TCP localport=3001 profile=any | Out-Null
    Write-Host "Tamam: 3001 portu netsh ile acildi."
}

Write-Host ""
Write-Host "Simdi terminal bilgisayardan su adresi deneyin:"
Write-Host "http://192.168.1.190:3001"
Start-Sleep -Seconds 5
