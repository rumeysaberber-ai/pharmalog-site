@echo off
powershell.exe -ExecutionPolicy Bypass -File "%~dp0guncelleme_sonrasi_kontrol.ps1"
pause
