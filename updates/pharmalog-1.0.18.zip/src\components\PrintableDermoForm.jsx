import React from 'react';
import { format } from "date-fns";
import { tr } from "date-fns/locale";
import logo from "../assets/pharmalog_logo.png";

const PrintableDermoForm = React.forwardRef(({ data, patientName, isEmpty }, ref) => {
    // If isEmpty is true, we ignore data and render purely blank fields for handwriting
    const formData = isEmpty ? {} : (data || {});

    // Helper for rendering checkboxes
    const Checkbox = ({ label, checked }) => (
        <div className="flex items-center gap-2 mb-1">
            <div className={`w-4 h-4 border border-slate-400 rounded flex items-center justify-center ${checked ? 'bg-slate-800' : 'bg-white'}`}>
                {checked && <div className="w-2 h-2 bg-white rounded-sm"></div>}
            </div>
            <span className="text-xs text-slate-700">{label}</span>
        </div>
    );

    // Helper for rendering line for handwriting
    const Line = ({ label, value }) => (
        <div className="mb-4">
            <span className="block text-xs font-bold text-slate-800 mb-1">{label}</span>
            {isEmpty ? (
                <div className="border-b border-slate-300 h-6 w-full"></div>
            ) : (
                <div className="text-sm font-medium text-slate-900 border-b border-slate-200 pb-1">{value || '-'}</div>
            )}
        </div>
    );

    const BoxSection = ({ title, options, selected = [] }) => (
        <div className="border border-slate-300 rounded p-3 mb-4 break-inside-avoid">
            <h5 className="text-xs font-bold text-slate-900 uppercase mb-2 border-b border-slate-200 pb-1">{title}</h5>
            <div className="grid grid-cols-2 gap-x-4">
                {options.map(opt => (
                    <Checkbox key={opt} label={opt} checked={!isEmpty && selected.includes(opt)} />
                ))}
            </div>
        </div>
    );

    const TextAreaBox = ({ label, value, height = "h-48" }) => (
        <div className={`border border-slate-300 rounded p-4 mb-4 break-inside-avoid ${height} flex flex-col justify-between shadow-sm`}>
            <h5 className="text-xs font-bold text-slate-900 uppercase mb-2 border-b border-slate-200 pb-1 tracking-wide">{label}</h5>
            {!isEmpty && value && <p className="text-sm text-slate-800 leading-relaxed">{value}</p>}
        </div>
    );

    return (
        <div ref={ref} className="p-8 bg-white text-slate-900 font-sans max-w-[210mm] mx-auto print:w-full">
            {/* Header */}
            <div className="border-b-2 border-slate-900 pb-4 mb-6">
                <div className="flex justify-between items-start mb-6">
                    <div className="flex items-center gap-4">
                        <img src={logo} alt="Logo" className="h-12 w-auto object-contain" />
                        <div>
                            <h1 className="text-lg font-bold">DERMOKOZMETİK ANAMNEZ FORMU</h1>
                            <p className="text-[10px] text-slate-500 uppercase">PharmaLog Otomasyon Sistemi</p>
                        </div>
                    </div>
                    <div className="text-right">
                        <div className="text-[10px] text-slate-500">{format(new Date(), "d MMMM yyyy", { locale: tr })}</div>
                    </div>
                </div>

                {/* Patient Info Fields */}
                <div className="flex justify-between gap-6 mb-4">
                    <div className="flex-1 border-b border-slate-400 pb-1">
                        <span className="block text-[11px] font-bold text-black uppercase mb-4">Adı Soyadı</span>
                        <div className="h-4"></div>
                    </div>
                    <div className="flex-1 border-b border-slate-400 pb-1">
                        <span className="block text-[11px] font-bold text-black uppercase mb-4">Doğum Tarihi / Yaş</span>
                        <div className="h-4"></div>
                    </div>
                    <div className="flex-1 border-b border-slate-400 pb-1">
                        <span className="block text-[11px] font-bold text-black uppercase mb-4">Telefon Numarası</span>
                        <div className="h-4"></div>
                    </div>
                </div>
            </div>

            {/* CİLT */}
            <h3 className="text-sm font-bold bg-slate-100 p-2 uppercase mb-4 border-l-4 border-slate-800">CİLT</h3>
            <div className="grid grid-cols-2 gap-6 mb-2">
                <BoxSection
                    title="Cilt Tipi"
                    options={["Normal Cilt", "Kuru Cilt", "Yağlı Cilt", "Karma Cilt"]}
                    selected={isEmpty ? [] : (formData.skinType ? [formData.skinType] : [])}
                />
                <BoxSection
                    title="Cilt Durumu"
                    options={[
                        "Alerjik", "Atopik", "Gözenekli", "Kırışık", "Nemsiz",
                        "Sarkma Sıklık Kaybı", "Seboroik Dermatit", "Sivilce",
                        "Siyah Nokta", "Parlama", "Rosecea", "Yara-Çatlak-İrrite", "Lekeli"
                    ]}
                    selected={formData.skinCondition}
                />
            </div>

            {/* GÖZ / SAÇ / VÜCUT */}
            <h3 className="text-sm font-bold bg-slate-100 p-2 uppercase mb-4 border-l-4 border-slate-800">BÖLGESEL DURUM</h3>
            <div className="grid grid-cols-3 gap-4 mb-2">
                <BoxSection
                    title="Göz Çevresi"
                    options={["Nemsiz", "Kırışık", "Kahverengi Halka", "Gözaltı Torbaları", "Alerjik Hassas"]}
                    selected={formData.eyeCondition}
                />
                <BoxSection
                    title="Saçlı Deri"
                    options={["Yağlı", "Kuru", "Kuru Kepek", "Yağlı Kepek", "Seboroid Dermatit", "Dökülme", "Yoğun Dökülme", "Hassas"]}
                    selected={formData.hairCondition}
                />
                <BoxSection
                    title="Vücut"
                    options={["Nemsizlik", "Atopik Dermatit", "Egzama", "Selülit"]}
                    selected={formData.bodyCondition}
                />
            </div>

            {/* ÖZEL */}
            <h3 className="text-sm font-bold bg-slate-100 p-2 uppercase mb-4 border-l-4 border-slate-800">ÖZEL DURUMLAR & ALIŞKANLIKLAR</h3>
            <div className="grid grid-cols-2 gap-6 mb-4">
                <BoxSection
                    title="Özel Durumlar"
                    options={["Gebelik", "Lohusalık", "Menapoz", "Yoğun Akne", "Kemoterapi", "Radyoterapi", "Estetik", "Lazer", "Kimyasal Peeling"]}
                    selected={formData.specialCondition}
                />
                <BoxSection
                    title="Alışkanlıklar"
                    options={["SİGARA", "ALKOL"]}
                    selected={formData.habits}
                />
            </div>

            {/* DİĞER */}
            <div className="break-before-page mt-12">
                <h3 className="text-sm font-bold bg-slate-100 p-2 uppercase mb-4 border-l-4 border-slate-800">DETAYLAR</h3>
                <div className="flex flex-col gap-2">
                    <TextAreaBox label="CİLT RAHATSIZLIĞI / ŞİKAYET" value={formData.complaint} height="h-32" />
                    <TextAreaBox label="BEKLENTİLER (PARLAKLIK, LEKE AÇMA VB.)" value={formData.expectation} height="h-32" />
                    <TextAreaBox label="AYRILABİLECEK ZAMAN" value={formData.careTime} height="h-24" />
                    <TextAreaBox label="GENEL NOTLAR / UZMAN GÖRÜŞÜ" value={formData.notes} height="h-40" />
                </div>
            </div>

            {/* KVKK & Signatures */}
            <div className="mt-8 pt-4 border-t border-slate-300 break-inside-avoid">
                <p className="text-[10px] text-justify text-slate-600 mb-4 leading-tight">
                    6698 sayılı Kişisel Verilerin Korunması Kanunu (KVKK) kapsamında; yukarıda paylaştığım kimlik, iletişim ve sağlık verilerimin,
                    Irmak Eczanesi tarafından sunulan hizmetlerin (cilt analizi, ürün önerisi, ilaç takibi vb.) yerine getirilmesi amacıyla işlenmesine,
                    eczanenin kullandığı PharmaLog danışan takip yazılımına kaydedilmesine ve saklanmasına, tarafımla iletişim kurulmasına özgür irademle
                    <strong> AÇIK RIZA</strong> gösteriyorum. Eczanede asılı bulunan veya tarafıma sunulan detaylı KVKK Aydınlatma Metnini okudum ve anladım.
                </p>

                <div className="flex justify-between items-end mt-6">
                    <div className="flex-1 flex flex-col gap-3">
                        <p className="text-xs font-bold text-slate-800 tracking-wide">
                            Tarih: ..... / ..... / 20..
                        </p>
                        <p className="text-xs font-bold text-slate-800 tracking-wide">
                            Adı Soyadı: .................................................
                        </p>
                        <p className="text-xs font-bold text-slate-800 tracking-wide">
                            İmza: ..............................
                        </p>
                    </div>
                    <div className="text-center min-w-[150px]">
                        <div className="h-8"></div>
                        <p className="text-[10px] font-bold border-t border-slate-400 px-4 pt-1">UZMAN İMZA</p>
                    </div>
                </div>
            </div>
        </div>
    );
});

export default PrintableDermoForm;
