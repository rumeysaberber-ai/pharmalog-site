@echo off
del "%~dp0terminal_adres.txt" >nul 2>nul
echo Terminal adresi sifirlandi.
echo terminal_program_ac.bat tekrar acildiginda ana bilgisayar adresini soracak.
pause
