$ErrorActionPreference = "Stop"

Set-Location -LiteralPath $PSScriptRoot

$tokenPath = Join-Path $PSScriptRoot "pharmalog_import_token.txt"

if (-not (Test-Path -LiteralPath $tokenPath)) {
    $bytes = New-Object byte[] 32
    [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
    $token = ([System.BitConverter]::ToString($bytes)).Replace("-", "").ToLowerInvariant()
    Set-Content -LiteralPath $tokenPath -Value $token -Encoding UTF8
} else {
    $token = (Get-Content -LiteralPath $tokenPath -Raw -Encoding UTF8).Trim()
}

Write-Host ""
Write-Host "PharmaLog aktarim anahtari:" -ForegroundColor Cyan
Write-Host $token -ForegroundColor Green
Write-Host ""
Write-Host "Bu anahtari Botanik aktarim kurulumu ilk calistiginda sorulan alana yapistirin." -ForegroundColor Yellow
