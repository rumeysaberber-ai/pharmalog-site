@echo off
title Botanik -> PharmaLog Aktarim
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0botanik_pharmalog_aktar.ps1"
pause
