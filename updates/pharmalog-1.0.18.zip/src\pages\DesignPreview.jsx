import React, { useState } from 'react';
import { Shield, Activity, Users, Calendar, ArrowRight, Check, Search, Bell, Settings } from 'lucide-react';

export default function DesignPreview() {
    const [activeTab, setActiveTab] = useState('overview');

    return (
        <div className="min-h-screen bg-slate-50 dark:bg-slate-950 p-8 font-sans transition-colors duration-300">

            {/* --- HEADER SECTION --- */}
            <div className="max-w-6xl mx-auto mb-12">
                <div className="flex items-center justify-between mb-2">
                    <h1 className="text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                        Design System <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-500 to-indigo-600">v2.0</span>
                    </h1>
                    <div className="flex gap-2">
                        <span className="px-3 py-1 rounded-full bg-teal-100 dark:bg-teal-900/40 text-teal-700 dark:text-teal-300 text-xs font-bold uppercase tracking-wider">
                            Preview
                        </span>
                    </div>
                </div>
                <p className="text-lg text-slate-500 dark:text-slate-400 max-w-2xl">
                    Aesthetically refined interface features customized for Dermokozmetik.
                    Focusing on <span className="font-semibold text-slate-700 dark:text-slate-200">Glassmorphism</span>,
                    <span className="font-semibold text-slate-700 dark:text-slate-200"> Soft Shadows</span>, and
                    <span className="font-semibold text-slate-700 dark:text-slate-200"> Vivid Gradients</span>.
                </p>
            </div>

            <div className="max-w-6xl mx-auto space-y-12">

                {/* --- 1. CARDS & GLASSMORPHISM --- */}
                <section>
                    <h2 className="text-xl font-bold text-slate-800 dark:text-slate-200 mb-6 flex items-center gap-2">
                        <Activity className="text-indigo-500" />
                        Cards & Glass Effects
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {/* Standard Card */}
                        <div className="group relative bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm hover:shadow-xl transition-all duration-300 border border-slate-200 dark:border-slate-800 hover:-translate-y-1">
                            <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity rounded-2xl" />
                            <div className="relative">
                                <div className="w-12 h-12 rounded-xl bg-indigo-50 dark:bg-indigo-900/30 flex items-center justify-center text-indigo-600 dark:text-indigo-400 mb-4 group-hover:scale-110 transition-transform duration-300">
                                    <Users size={24} />
                                </div>
                                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">Standard Card</h3>
                                <p className="text-slate-500 dark:text-slate-400 text-sm">
                                    Clean, minimal, with a subtle lift and gradient glow on hover.
                                </p>
                            </div>
                        </div>

                        {/* Glass Gradient Card */}
                        <div className="relative overflow-hidden rounded-2xl p-6 shadow-2xl transition-transform duration-300 hover:-translate-y-1">
                            <div className="absolute inset-0 bg-gradient-to-br from-indigo-600 to-violet-700" />
                            <div className="absolute top-0 right-0 -mt-8 -mr-8 w-32 h-32 bg-white/20 blur-3xl rounded-full" />
                            <div className="absolute bottom-0 left-0 -mb-8 -ml-8 w-32 h-32 bg-black/10 blur-3xl rounded-full" />

                            <div className="relative z-10 text-white">
                                <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white mb-4 border border-white/10">
                                    <Shield size={24} />
                                </div>
                                <h3 className="text-lg font-bold mb-1">Premium Glass</h3>
                                <p className="text-indigo-100 text-sm">
                                    High-impact areas. Uses deep gradients and backdrop blur overlays.
                                </p>
                            </div>
                        </div>

                        {/* Neumorphic/Clean Card */}
                        <div className="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 flex flex-col justify-between">
                            <div className="space-y-4">
                                <div className="flex items-center justify-between">
                                    <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-800" />
                                    <div className="w-16 h-4 rounded-full bg-slate-200 dark:bg-slate-800" />
                                </div>
                                <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-800" />
                                <div className="w-2/3 h-2 rounded-full bg-slate-200 dark:bg-slate-800" />
                            </div>
                            <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-800">
                                <p className="text-xs font-mono text-slate-400 text-center">Ghost / Loading State</p>
                            </div>
                        </div>
                    </div>
                </section>

                {/* --- 2. BUTTONS & ACTIONS --- */}
                <section>
                    <h2 className="text-xl font-bold text-slate-800 dark:text-slate-200 mb-6 flex items-center gap-2">
                        <Check className="text-teal-500" />
                        Buttons & Micro-interactions
                    </h2>
                    <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-wrap gap-6 items-center">

                        {/* Primary Gradient */}
                        <button className="relative group overflow-hidden px-6 py-3 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 text-white font-semibold shadow-lg shadow-teal-500/30 hover:shadow-teal-500/50 transition-all duration-300 hover:-translate-y-0.5">
                            <span className="relative z-10 flex items-center gap-2">
                                Primary Action <ArrowRight size={18} />
                            </span>
                            <div className="absolute inset-0 bg-gradient-to-r from-emerald-500 to-teal-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                        </button>

                        {/* Secondary Outline */}
                        <button className="px-6 py-3 rounded-xl border-2 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-semibold hover:border-slate-400 dark:hover:border-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800 transition-all duration-300">
                            Secondary
                        </button>

                        {/* Ghost/Glass */}
                        <button className="px-6 py-3 rounded-xl bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 font-semibold hover:bg-indigo-100 dark:hover:bg-indigo-900/40 transition-all duration-300 flex items-center gap-2">
                            <Settings size={18} />
                            Ghost Button
                        </button>

                        {/* Icon Only */}
                        <button className="p-3 rounded-xl bg-white dark:bg-slate-800 text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/20 border border-slate-200 dark:border-slate-800 hover:border-rose-200 dark:hover:border-rose-800 transition-all duration-300 shadow-sm">
                            <Bell size={20} />
                        </button>
                    </div>
                </section>

                {/* --- 3. COLORS & GRADIENTS --- */}
                <section>
                    <h2 className="text-xl font-bold text-slate-800 dark:text-slate-200 mb-6">
                        Color Palette (Zinc + Vibrant Accents)
                    </h2>
                    <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
                        <div className="h-24 rounded-2xl bg-slate-950 shadow-lg flex items-end p-3 text-white text-xs font-mono">Slate-950</div>
                        <div className="h-24 rounded-2xl bg-slate-900 shadow-lg flex items-end p-3 text-white text-xs font-mono">Slate-900</div>
                        <div className="h-24 rounded-2xl bg-slate-800 shadow-lg flex items-end p-3 text-white text-xs font-mono">Slate-800</div>
                        <div className="h-24 rounded-2xl bg-teal-600 shadow-lg shadow-teal-500/30 flex items-end p-3 text-white text-xs font-mono">Teal-600</div>
                        <div className="h-24 rounded-2xl bg-indigo-600 shadow-lg shadow-indigo-500/30 flex items-end p-3 text-white text-xs font-mono">Indigo-600</div>
                        <div className="h-24 rounded-2xl bg-rose-500 shadow-lg shadow-rose-500/30 flex items-end p-3 text-white text-xs font-mono">Rose-500</div>
                    </div>
                </section>

            </div>
        </div>
    );
}
