﻿import { useEffect, useState } from "react";
import { DataService } from "../lib/data";
import { Clock, AlertCircle, CheckCircle, Smartphone, List, X, Calendar, ArrowUpDown, Search, Filter, Users as UsersIcon, ChevronRight } from "lucide-react";
import { format, parseISO, differenceInDays } from "date-fns";
import { tr } from "date-fns/locale";
import { Link } from "react-router-dom";

export default function DashboardModern() {
    const FOLLOW_UP_FILTERS = [
        { id: "all", label: "Aktif Takipler" },
        { id: "besin", label: "Besin Destek Takip" },
        { id: "dermo", label: "Dermokozmetik Takip" },
        { id: "raporlu", label: "Raporlu Danışan Takip" }
    ];

    const [stats, setStats] = useState({ totalPatients: 0, activeReminders: 0 });
    const [reminders, setReminders] = useState([]);

    // All Follow Ups Modal State
    const [isAllFollowUpsModalOpen, setIsAllFollowUpsModalOpen] = useState(false);
    const [allFollowUps, setAllFollowUps] = useState([]);
    const [noDateCallQueue, setNoDateCallQueue] = useState([]);
    const [allUserNames, setAllUserNames] = useState([]);
    const [activeReminderFilter, setActiveReminderFilter] = useState("all");
    const [selectedCreatorFilter, setSelectedCreatorFilter] = useState("all");
    const [followUpSearchTerm, setFollowUpSearchTerm] = useState("");
    const [followUpSortOrder, setFollowUpSortOrder] = useState("desc");
    const currentUserName = (() => {
        try {
            return (JSON.parse(localStorage.getItem("user_details") || "{}")?.name || "").trim();
        } catch (e) {
            return "";
        }
    })();
    const currentUsername = (() => {
        try {
            return (JSON.parse(localStorage.getItem("user_details") || "{}")?.username || "").trim();
        } catch (e) {
            return "";
        }
    })();
    const currentUserGroup = (() => {
        try {
            return JSON.parse(localStorage.getItem("user_details") || "{}")?.group || null;
        } catch (e) {
            return null;
        }
    })();

    useEffect(() => {
        // Load data
        const load = async () => {
            const patients = await DataService.getPatients();
            const remindersList = await DataService.getReminders();
            const users = await DataService.getUsers().catch(() => []);

            setStats({
                totalPatients: patients.length,
                activeReminders: remindersList.length
            });
            setReminders(remindersList);
            setNoDateCallQueue(await DataService.getNoDateCallQueue());
            const effectiveGroup =
                currentUserGroup ||
                (Array.isArray(users) ? users.find((u) => (u?.username || "").trim() === currentUsername)?.group : null) ||
                null;
            setAllUserNames(
                (Array.isArray(users) ? users : [])
                    .filter((u) => !effectiveGroup || u?.group === effectiveGroup)
                    .map((u) => (u?.name || u?.username || "").trim())
                    .filter(Boolean)
            );

            // Process all follow ups
            let allF = [];
            patients.forEach(p => {
                if (p.followUps) {
                    p.followUps.forEach(f => {
                        allF.push({
                            ...f,
                            patientName: p.fullName,
                            patientId: p.id,
                            createdBy: f.createdBy || f.updatedBy || p.updatedBy || p.createdBy || "Bilinmiyor"
                        });
                    });
                }
            });
            setAllFollowUps(allF);
        };
        load();
    }, []);

    const reminderMatchesCategory = (item, category) => {
        if (category === "all") return true;
        if (!Array.isArray(item.followUpCategories)) return false;

        const aliases = {
            besin: ["besin", "besin_destek"],
            dermo: ["dermo", "dermokozmetik"],
            raporlu: ["raporlu", "raporlu_hasta"]
        };

        const accepted = aliases[category] || [category];
        return item.followUpCategories.some((c) => accepted.includes(c));
    };

    const creatorFilterOptions = Array.from(new Set(allUserNames.filter(Boolean))).sort((a, b) => a.localeCompare(b, "tr"));
    const finalCreatorFilterOptions = Array.from(
        new Set([
            ...creatorFilterOptions,
            currentUserName
        ].filter(Boolean))
    ).sort((a, b) => a.localeCompare(b, "tr"));

    const reminderMatchesCreator = (item) => {
        if (selectedCreatorFilter === "all") return true;
        return (item?.createdBy || "") === selectedCreatorFilter;
    };

    const filteredReminders = reminders.filter(
        (r) => reminderMatchesCategory(r, activeReminderFilter) && reminderMatchesCreator(r)
    );

    const getFilterFollowUpCount = (category) => {
        return reminders.filter((r) => reminderMatchesCategory(r, category) && reminderMatchesCreator(r)).length;
    };

    return (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
            {/* --- HEADER --- */}
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-slate-900 to-slate-700 dark:from-white dark:to-slate-300">
                        Genel Bakış
                    </h1>
                    <p className="text-slate-500 dark:text-slate-400 mt-1 font-medium">
                        Bugünün özetine hoş geldiniz.
                    </p>
                </div>
            </div>

            {/* --- STATS GRID --- */}
            <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                {/* Stat 1: Patients */}
                <div className="group relative overflow-hidden rounded-2xl bg-white/60 dark:bg-slate-900/60 backdrop-blur-xl border border-white/20 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-black/50 transition-all hover:scale-[1.02] hover:shadow-2xl hover:border-teal-500/30">
                    <div className="absolute top-0 right-0 -mt-4 -mr-4 w-24 h-24 bg-teal-500/10 rounded-full blur-xl group-hover:bg-teal-500/20 transition-all"></div>
                    <div className="p-6 relative z-10">
                        <div className="flex items-center justify-between mb-4">
                            <div className="p-3 rounded-xl bg-teal-50 dark:bg-teal-900/30 text-teal-600 dark:text-teal-400 group-hover:rotate-12 transition-transform duration-300 shadow-sm">
                                <UsersIcon size={24} />
                            </div>
                            <span className="flex items-center text-xs font-bold text-teal-600 dark:text-teal-400 bg-teal-100 dark:bg-teal-900/50 px-2 py-1 rounded-full">
                                Aktif
                            </span>
                        </div>
                        <h3 className="text-slate-500 dark:text-slate-400 text-sm font-semibold tracking-wide uppercase">Toplam Danışan</h3>
                        <p className="text-4xl font-black text-slate-800 dark:text-white mt-1 group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors">
                            {stats.totalPatients}
                        </p>
                    </div>
                </div>

                {FOLLOW_UP_FILTERS.map((filter) => {
                    const isActive = activeReminderFilter === filter.id;
                    const count = getFilterFollowUpCount(filter.id);
                    return (
                        <button
                            key={filter.id}
                            onClick={() => setActiveReminderFilter(filter.id)}
                            className={`group relative overflow-hidden rounded-2xl backdrop-blur-xl border shadow-xl transition-all text-left ${isActive
                                ? "bg-indigo-50/80 dark:bg-indigo-900/30 border-indigo-200 dark:border-indigo-700 shadow-indigo-200/40 dark:shadow-indigo-900/30"
                                : "bg-white/60 dark:bg-slate-900/60 border-white/20 dark:border-slate-800 shadow-slate-200/50 dark:shadow-black/50 hover:scale-[1.02] hover:shadow-2xl hover:border-indigo-500/30"}`}
                        >
                            <div className="p-6 relative z-10">
                                <div className="flex items-center justify-between mb-4">
                                    <div className={`p-3 rounded-xl transition-colors ${isActive
                                        ? "bg-indigo-100 dark:bg-indigo-800/60 text-indigo-700 dark:text-indigo-200"
                                        : "bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400"}`}>
                                        <Clock size={22} />
                                    </div>
                                    <span className={`flex items-center text-xs font-bold px-2 py-1 rounded-full ${isActive
                                        ? "text-indigo-700 dark:text-indigo-200 bg-indigo-100 dark:bg-indigo-800/60"
                                        : "text-indigo-600 dark:text-indigo-400 bg-indigo-100 dark:bg-indigo-900/50"}`}>
                                        {count} Takip
                                    </span>
                                </div>
                                <h3 className="text-slate-500 dark:text-slate-400 text-sm font-semibold tracking-wide uppercase">{filter.label}</h3>
                                <p className="text-3xl font-black text-slate-800 dark:text-white mt-1 transition-colors">
                                    {count}
                                </p>
                            </div>
                        </button>
                    );
                })}
            </div>

            {/* --- REMINDERS LIST --- */}
            <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-2xl rounded-2xl border border-white/20 dark:border-slate-800 shadow-2xl shadow-slate-200/50 dark:shadow-black/50 overflow-hidden">
                <div className="px-6 py-5 border-b border-slate-100 dark:border-slate-700/50 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-50/50 dark:bg-slate-900/50">
                    <div>
                        <h3 className="text-lg font-bold text-slate-800 dark:text-white flex items-center gap-2">
                            <div className="p-2 bg-rose-100 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400 rounded-lg">
                                <Smartphone size={18} />
                            </div>
                            Arama Listesi
                        </h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400 ml-1 mt-1">
                            Seçili listede {filteredReminders.length} takip kaydı var.
                        </p>

                    </div>
                    <div className="flex items-center gap-3">
                        <select
                            value={selectedCreatorFilter}
                            onChange={(e) => setSelectedCreatorFilter(e.target.value)}
                            className="px-3 py-2 text-xs font-semibold border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200"
                        >
                            <option value="all">Tüm Kullanıcılar</option>
                            {finalCreatorFilterOptions.map((name) => (
                                <option key={name} value={name}>{name}</option>
                            ))}
                        </select>
                        <button
                            onClick={async () => {
                                if (filteredReminders.length === 0) {
                                    alert("Temizlenecek takip kaydı bulunamadı.");
                                    return;
                                }
                                if (window.confirm(`Seçili listedeki ${filteredReminders.length} takip kaydını arama listesinden kaldırmak istediğinize emin misiniz?`)) {
                                    const removedCount = await DataService.removeFollowUps(filteredReminders);
                                    if (removedCount > 0) {
                                        alert(`${removedCount} takip kaydı listeden kaldırıldı.`);
                                        window.location.reload();
                                    } else {
                                        alert("Temizlenecek takip kaydı bulunamadı.");
                                    }
                                }
                            }}
                            className="px-4 py-2 text-xs font-semibold text-rose-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-lg transition-colors"
                        >
                            Listeyi Temizle
                        </button>
                        <button
                            onClick={() => setIsAllFollowUpsModalOpen(true)}
                            className="px-4 py-2 bg-slate-800 dark:bg-white text-white dark:text-slate-900 rounded-lg text-xs font-bold hover:bg-slate-700 dark:hover:bg-slate-200 transition-all shadow-lg shadow-slate-300/20 dark:shadow-none flex items-center gap-2"
                        >
                            <List size={14} />
                            Tüm Kayıtlar
                        </button>
                    </div>
                </div>

                <div className="divide-y divide-slate-100 dark:divide-slate-800/50">
                    {filteredReminders.length === 0 ? (
                        <div className="p-12 text-center text-slate-400 dark:text-slate-500 flex flex-col items-center">
                            <div className="w-16 h-16 bg-slate-50 dark:bg-slate-800/50 rounded-full flex items-center justify-center mb-4">
                                <CheckCircle className="h-8 w-8 text-slate-300 dark:text-slate-600" />
                            </div>
                            <h4 className="text-lg font-semibold text-slate-600 dark:text-slate-300">Harika İş!</h4>
                            <p className="max-w-xs mx-auto mt-1">Bugün için yapmanız gereken bir arama veya takip bulunmuyor.</p>
                        </div>
                    ) : (
                        filteredReminders.map((reminder, idx) => (
                            <div key={idx} className="p-4 sm:px-6 hover:bg-indigo-50/50 dark:hover:bg-indigo-900/10 transition-colors flex items-center justify-between group">
                                <div className="flex items-start gap-4">
                                    <div className="relative mt-2">
                                        <div className={`h-3 w-3 rounded-full ${reminder.status === 'expired' ? 'bg-rose-500 shadow-rose-500/50' : 'bg-amber-500 shadow-amber-500/50'} shadow-lg animate-pulse`} />
                                    </div>
                                    <div>
                                        <div className="flex items-center gap-3 flex-wrap">
                                            <h4 className="font-bold text-slate-800 dark:text-slate-100 text-lg mb-0">{reminder.patientName}</h4>

                                            {/* BADGES NEXT TO NAME */}
                                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md uppercase tracking-wide ${reminder.daysLeft < 0 ? 'bg-rose-100 dark:bg-rose-900/30 text-rose-700 dark:text-rose-300' : 'bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300'}`}>
                                                {reminder.daysLeft < 0 ? `${Math.abs(reminder.daysLeft)} GÜN GECİKTİ` : `${reminder.daysLeft} GÜN KALDI`}
                                            </span>

                                            {reminder.isPharmacistFollowUp && (
                                                <span className="text-[10px] bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 px-2 py-0.5 rounded-md font-bold border border-purple-200 dark:border-purple-800 uppercase tracking-wide">
                                                    ECZACI TAKİBİ
                                                </span>
                                            )}
                                            {Array.isArray(reminder.followUpCategories) && reminder.followUpCategories.some((c) => ["besin", "besin_destek"].includes(c)) && (
                                                <span className="text-[10px] bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 px-2 py-0.5 rounded-md font-bold border border-emerald-200 dark:border-emerald-800 uppercase tracking-wide">
                                                    BESİN DESTEK
                                                </span>
                                            )}
                                            {Array.isArray(reminder.followUpCategories) && reminder.followUpCategories.some((c) => ["dermo", "dermokozmetik"].includes(c)) && (
                                                <span className="text-[10px] bg-sky-100 dark:bg-sky-900/30 text-sky-700 dark:text-sky-300 px-2 py-0.5 rounded-md font-bold border border-sky-200 dark:border-sky-800 uppercase tracking-wide">
                                                    DERMOKOZMETİK
                                                </span>
                                            )}
                                            {Array.isArray(reminder.followUpCategories) && reminder.followUpCategories.some((c) => ["raporlu", "raporlu_hasta"].includes(c)) && (
                                                <span className="text-[10px] bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300 px-2 py-0.5 rounded-md font-bold border border-amber-200 dark:border-amber-800 uppercase tracking-wide">
                                                    RAPORLU
                                                </span>
                                            )}
                                        </div>

                                        {reminder.type === 'followUp' ? (
                                            <>
                                                <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                                                    <span className="font-bold text-indigo-600 dark:text-indigo-400">Not:</span> {reminder.note}
                                                </p>
                                                <div className="flex items-center gap-3 mt-2">
                                                    <span className="text-xs text-slate-400 dark:text-slate-500 font-medium">
                                                        {format(parseISO(reminder.expiryDate), "d MMMM yyyy", { locale: tr })}
                                                    </span>
                                                    <span className="text-xs text-slate-500 dark:text-slate-400 font-semibold">
                                                        Oluşturan: {reminder.createdBy || "Bilinmiyor"}
                                                    </span>
                                                </div>
                                            </>
                                        ) : (
                                            <>
                                                <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                                                    <span className="font-bold text-slate-800 dark:text-slate-200">{reminder.productName}</span> bitmek üzere.
                                                </p>
                                                <div className="flex items-center gap-3 mt-2">
                                                    <span className="text-xs text-slate-400 dark:text-slate-500 font-medium">
                                                        {format(parseISO(reminder.expiryDate), "d MMMM yyyy", { locale: tr })}
                                                    </span>
                                                </div>
                                            </>
                                        )}
                                    </div>
                                </div>
                                <div className="flex items-center gap-2">
                                    <Link
                                        to={`/patients/${reminder.patientId}?${new URLSearchParams({
                                            openCallPanel: "1",
                                            reminderId: String(reminder.id || ""),
                                            reminderNote: reminder.note || ""
                                        }).toString()}`}
                                        state={{ from: "/dashboard-new" }}
                                        className="group/btn relative overflow-hidden bg-emerald-50 dark:bg-emerald-900/20 border-2 border-emerald-100 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 px-4 py-2 rounded-xl text-sm font-bold hover:border-emerald-500 dark:hover:border-emerald-400 hover:text-emerald-800 dark:hover:text-emerald-200 transition-all flex items-center gap-2"
                                    >
                                        <CheckCircle size={15} />
                                        <span>Arandı</span>
                                    </Link>
                                    <Link
                                    to={`/patients/${reminder.patientId}`}
                                    state={{ from: "/dashboard-new" }}
                                    className="group/btn relative overflow-hidden bg-white dark:bg-slate-800 border-2 border-slate-100 dark:border-slate-700 text-slate-600 dark:text-slate-300 px-4 py-2 rounded-xl text-sm font-bold hover:border-indigo-500 dark:hover:border-indigo-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-all flex items-center gap-2"
                                >
                                    <span>İncele</span>
                                    <ChevronRight size={16} className="transition-transform group-hover/btn:translate-x-1" />
                                </Link>
                                </div>
                            </div>
                        ))
                    )}
                </div>
            </div>

            {/* --- NO-DATE CALL QUEUE --- */}
            <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-2xl rounded-2xl border border-white/20 dark:border-slate-800 shadow-2xl shadow-slate-200/50 dark:shadow-black/50 overflow-hidden">
                <div className="px-6 py-5 border-b border-slate-100 dark:border-slate-700/50 bg-slate-50/50 dark:bg-slate-900/50">
                    <h3 className="text-lg font-bold text-slate-800 dark:text-white flex items-center gap-2">
                        <div className="p-2 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-lg">
                            <AlertCircle size={18} />
                        </div>
                        Tarih Verilmeden Arananlar
                    </h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400 ml-1 mt-1">
                        Arandı olarak işaretlenen ama yeni takip tarihi verilmeyen {noDateCallQueue.length} kayıt.
                    </p>
                </div>
                <div className="divide-y divide-slate-100 dark:divide-slate-800/50">
                    {noDateCallQueue.length === 0 ? (
                        <div className="p-6 text-sm text-slate-500 dark:text-slate-400">Bekleyen kayıt yok.</div>
                    ) : (
                        noDateCallQueue.map((item) => (
                            <div key={item.id} className="p-4 sm:px-6 flex items-center justify-between gap-3 hover:bg-amber-50/30 dark:hover:bg-amber-900/10 transition-colors">
                                <div>
                                    <div className="font-bold text-slate-800 dark:text-slate-100">{item.patientName}</div>
                                    <div className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                                        {item.note || "Not girilmemiş"}
                                    </div>
                                </div>
                                <Link
                                    to={`/patients/${item.patientId}?${new URLSearchParams({
                                        openFollowUpModal: "1",
                                        followUpId: String(item.id || "")
                                    }).toString()}`}
                                    state={{ from: "/dashboard-new" }}
                                    className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-300 px-4 py-2 rounded-xl text-sm font-bold hover:bg-amber-100 dark:hover:bg-amber-900/30 transition-colors"
                                >
                                    Tarih Ver
                                </Link>
                            </div>
                        ))
                    )}
                </div>
            </div>

            {/* ALL FOLLOW UPS MODAL */}
            {isAllFollowUpsModalOpen && (
                <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-300">
                    <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl w-full max-w-4xl h-[85vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-300 border border-white/20 dark:border-slate-700 ring-1 ring-black/5">

                        {/* Header */}
                        <div className="px-8 py-6 border-b border-slate-100 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-sm flex items-center justify-between flex-shrink-0">
                            <div>
                                <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
                                    <div className="p-2 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-xl">
                                        <List size={22} />
                                    </div>
                                    Tüm Takip Kayıtları
                                </h3>
                                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 ml-1">
                                    Toplam {allFollowUps.length} kayıt veritabanında saklanıyor.
                                </p>
                            </div>
                            <button
                                onClick={() => setIsAllFollowUpsModalOpen(false)}
                                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors bg-slate-100 dark:bg-slate-800 p-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700"
                            >
                                <X size={24} />
                            </button>
                        </div>

                        {/* Controls */}
                        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row gap-4 bg-slate-50/50 dark:bg-slate-900/30">
                            <div className="relative flex-1">
                                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                                <input
                                    type="text"
                                    placeholder="Danışan adı veya notlarda ara..."
                                    className="w-full pl-12 pr-4 py-3 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/50 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 shadow-sm"
                                    value={followUpSearchTerm}
                                    onChange={(e) => setFollowUpSearchTerm(e.target.value)}
                                />
                            </div>
                            <select
                                value={selectedCreatorFilter}
                                onChange={(e) => setSelectedCreatorFilter(e.target.value)}
                                className="px-3 py-3 text-sm font-semibold border border-slate-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200"
                            >
                                <option value="all">Tüm Kullanıcılar</option>
                                {finalCreatorFilterOptions.map((name) => (
                                    <option key={name} value={name}>{name}</option>
                                ))}
                            </select>
                            <div className="flex bg-white dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                                <button
                                    onClick={() => setFollowUpSortOrder("desc")}
                                    className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-all ${followUpSortOrder === 'desc' ? 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700/50'}`}
                                >
                                    <ArrowUpDown size={16} />
                                    En Yeni
                                </button>
                                <div className="w-px bg-slate-200 dark:bg-slate-700 my-1 mx-1"></div>
                                <button
                                    onClick={() => setFollowUpSortOrder("asc")}
                                    className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-all ${followUpSortOrder === 'asc' ? 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700/50'}`}
                                >
                                    <ArrowUpDown size={16} />
                                    En Eski
                                </button>
                            </div>
                        </div>

                        {/* List */}
                        <div className="flex-1 overflow-y-auto p-6 bg-slate-50/30 dark:bg-black/20">
                            {allFollowUps.length > 0 ? (
                                <div className="grid grid-cols-1 gap-4">
                                    {allFollowUps
                                        .filter(item =>
                                            (
                                                (item.patientName || "").toLowerCase().includes(followUpSearchTerm.toLowerCase()) ||
                                                (item.note || "").toLowerCase().includes(followUpSearchTerm.toLowerCase())
                                            ) &&
                                            reminderMatchesCreator(item)
                                        )
                                        .sort((a, b) => {
                                            const dateA = new Date(a.date);
                                            const dateB = new Date(b.date);
                                            return followUpSortOrder === 'asc' ? dateA - dateB : dateB - dateA;
                                        })
                                        .map((item, idx) => {
                                            if (!item.date) return null;
                                            let date;
                                            try {
                                                date = parseISO(item.date);
                                                if (isNaN(date.getTime())) return null;
                                            } catch (e) {
                                                return null;
                                            }

                                            const isPast = differenceInDays(date, new Date()) < 0;
                                            const isToday = differenceInDays(date, new Date()) === 0;

                                            return (
                                                <div key={idx} className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-200 dark:border-slate-700/50 shadow-sm hover:shadow-lg hover:shadow-indigo-500/5 hover:border-indigo-200 dark:hover:border-indigo-800 transition-all group">
                                                    <div className="flex items-start justify-between gap-6">
                                                        <div className="flex-1">
                                                            <div className="flex items-center gap-3 mb-2">
                                                                <h4 className="font-bold text-slate-900 dark:text-white text-lg">{item.patientName}</h4>
                                                                {isPast ? (
                                                                    <span className="text-[10px] bg-rose-50 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400 px-2 py-0.5 rounded-full font-bold border border-rose-100 dark:border-rose-800 uppercase tracking-wide">Geçmiş</span>
                                                                ) : isToday ? (
                                                                    <span className="text-[10px] bg-teal-50 dark:bg-teal-900/20 text-teal-600 dark:text-teal-400 px-2 py-0.5 rounded-full font-bold border border-teal-100 dark:border-teal-800 uppercase tracking-wide">Bugün</span>
                                                                ) : (
                                                                    <span className="text-[10px] bg-sky-50 dark:bg-sky-900/20 text-sky-600 dark:text-sky-400 px-2 py-0.5 rounded-full font-bold border border-sky-100 dark:border-sky-800 uppercase tracking-wide">Gelecek</span>
                                                                )}
                                                                {item.isPharmacistFollowUp && (
                                                                    <span className="text-[10px] bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400 px-2 py-0.5 rounded-full font-bold border border-purple-100 dark:border-purple-800 uppercase tracking-wide">Eczacı Takibi</span>
                                                                )}
                                                            </div>
                                                            <p className="text-slate-600 dark:text-slate-300 font-medium mb-3 leading-relaxed">{item.note}</p>
                                                            <div className="flex items-center gap-6 text-xs text-slate-400 dark:text-slate-500 font-semibold tracking-wide uppercase">
                                                                <span className="flex items-center gap-1.5">
                                                                    <Calendar size={14} className="text-indigo-400" />
                                                                    {format(date, "d MMMM yyyy", { locale: tr })}
                                                                </span>
                                                                <span className="flex items-center gap-1.5">
                                                                    <Clock size={14} className="text-indigo-400" />
                                                                    {differenceInDays(date, new Date())} Gün Sonra
                                                                </span>
                                                                <span className="normal-case tracking-normal text-slate-500 dark:text-slate-400">
                                                                    Oluşturan: {item.createdBy || "Bilinmiyor"}
                                                                </span>
                                                            </div>
                                                        </div>
                                                        <Link
                                                            to={`/patients/${item.patientId}`}
                                                            state={{ from: "/dashboard-new" }}
                                                            className="flex-shrink-0 w-10 h-10 rounded-xl bg-slate-50 dark:bg-slate-700 flex items-center justify-center text-slate-400 group-hover:bg-indigo-600 group-hover:text-white transition-all shadow-sm"
                                                        >
                                                            <ChevronRight size={20} />
                                                        </Link>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                </div>
                            ) : (
                                <div className="h-full flex flex-col items-center justify-center text-slate-400">
                                    <div className="w-24 h-24 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mb-6 opacity-80">
                                        <List size={48} className="text-slate-300 dark:text-slate-600" />
                                    </div>
                                    <h3 className="text-lg font-bold text-slate-700 dark:text-slate-300 mb-1">Kayıt Bulunamadı</h3>
                                    <p className="text-sm">Henüz sistemde hiç takip kaydı bulunmuyor.</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
    )
}

