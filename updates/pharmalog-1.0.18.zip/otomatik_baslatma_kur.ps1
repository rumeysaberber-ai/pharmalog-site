$projectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$startup = [Environment]::GetFolderPath("Startup")
if (-not $startup) {
    $startup = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Startup"
}
if (-not (Test-Path $startup)) {
    New-Item -ItemType Directory -Force -Path $startup | Out-Null
}

$shortcutPath = Join-Path $startup "PharmaLog Sunucu Otomatik Baslat.lnk"
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = "$env:SystemRoot\System32\wscript.exe"
$shortcut.Arguments = "`"$(Join-Path $projectDir "pharmalog_sunucu_gizli_baslat.vbs")`""
$shortcut.WorkingDirectory = $projectDir
$shortcut.IconLocation = "$env:SystemRoot\System32\shell32.dll,220"
$shortcut.Save()

Write-Host "PharmaLog sunucusu Windows baslangicina eklendi."
Write-Host $shortcutPath
