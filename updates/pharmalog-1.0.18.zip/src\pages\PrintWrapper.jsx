import { useEffect } from 'react';

export default function PrintWrapper({ children, title }) {
    useEffect(() => {
        if (title) {
            document.title = title;
        }

        // Small delay to ensure styles are loaded
        const timer = setTimeout(() => {
            window.print();
        }, 500);

        return () => clearTimeout(timer);
    }, [title]);

    return (
        <div className="print-page w-full min-h-screen bg-white">
            {children}
        </div>
    );
}
