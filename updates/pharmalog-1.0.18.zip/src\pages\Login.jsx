﻿
import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Lock, User, Loader2 } from 'lucide-react';
import pharmaLogo from '../assets/pharmalog_logo.png';

export default function Login() {
    const [username, setUsername] = useState(() => localStorage.getItem('pharmalog_last_username') || '');
    const [password, setPassword] = useState('');
    const [rememberMe, setRememberMe] = useState(() => localStorage.getItem('pharmalog_remember_me') !== 'false');
    const [error, setError] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    const { login } = useAuth();
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setIsSubmitting(true);

        const result = await login(username, password, rememberMe);

        if (result.success) {
            if (rememberMe) {
                localStorage.setItem('pharmalog_last_username', username);
                localStorage.setItem('pharmalog_remember_me', 'true');
            } else {
                localStorage.removeItem('pharmalog_last_username');
                localStorage.setItem('pharmalog_remember_me', 'false');
            }
            navigate('/');
        } else {
            setError(result.error);
        }
        setIsSubmitting(false);
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-slate-950 relative overflow-hidden">
            {/* Arka plan efektleri */}
            <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-cyan-950/30 to-slate-950 z-0"></div>
            <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-cyan-600/10 rounded-full blur-[120px] animate-pulse"></div>
            <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-600/10 rounded-full blur-[120px] animate-pulse delay-1000"></div>
            <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 brightness-100 contrast-150 z-0"></div>

            <div className="relative w-full max-w-md p-8 bg-white/5 backdrop-blur-2xl border border-white/10 rounded-3xl shadow-2xl z-10 animate-in fade-in zoom-in-95 duration-500">
                <div className="text-center mb-10">
                    <div className="flex flex-col items-center justify-center gap-6 mb-6">
                        <div className="relative">
                            <img
                                src={pharmaLogo}
                                alt="PharmaLog Logo"
                                className="w-96 h-auto object-contain drop-shadow-2xl"
                            />
                        </div>
                    </div>
                </div>

                {error && (
                    <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-xl text-red-200 text-sm flex items-center justify-center gap-2 animate-in fade-in slide-in-from-top-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-red-500 inline-block"></span>
                        {error}
                    </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="space-y-2">
                        <label className="text-xs font-semibold text-slate-400 ml-1 uppercase tracking-wider">Kullanıcı Adı</label>
                        <div className="relative group">
                            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                <User className="h-5 w-5 text-slate-500 group-focus-within:text-cyan-400 transition-colors" />
                            </div>
                            <input
                                type="text"
                                required
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                className="block w-full pl-11 pr-4 py-4 bg-slate-900/50 border border-slate-800 rounded-2xl text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-transparent transition-all font-medium text-sm hover:bg-slate-900/70"
                                placeholder="Kullanıcı adınızı giriniz"
                            />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <label className="text-xs font-semibold text-slate-400 ml-1 uppercase tracking-wider">Şifre</label>
                        <div className="relative group">
                            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                <Lock className="h-5 w-5 text-slate-500 group-focus-within:text-cyan-400 transition-colors" />
                            </div>
                            <input
                                type="password"
                                required
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="block w-full pl-11 pr-4 py-4 bg-slate-900/50 border border-slate-800 rounded-2xl text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-transparent transition-all font-medium text-sm hover:bg-slate-900/70"
                                placeholder="••••••••"
                            />
                        </div>
                    </div>

                    <label className="flex items-center gap-3 text-sm font-semibold text-slate-300">
                        <input
                            type="checkbox"
                            checked={rememberMe}
                            onChange={(e) => setRememberMe(e.target.checked)}
                            className="h-4 w-4 rounded border-slate-700 bg-slate-900 text-cyan-500 focus:ring-cyan-500"
                        />
                        Bu bilgisayarda girişimi hatırla
                    </label>

                    <button
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full flex items-center justify-center py-4 px-4 bg-gradient-to-r from-cyan-700 to-blue-700 hover:from-cyan-600 hover:to-blue-600 text-white rounded-2xl font-bold text-sm tracking-wide shadow-lg shadow-cyan-900/20 transform hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-70 disabled:cursor-not-allowed disabled:transform-none mt-8 border border-white/10"
                    >
                        {isSubmitting ? (
                            <>
                                <Loader2 className="animate-spin -ml-1 mr-2 h-5 w-5" />
                                Giriş Yapılıyor...
                            </>
                        ) : (
                            'Güvenli Giriş'
                        )}
                    </button>


                </form>
            </div>

            <div className="absolute bottom-6 text-center w-full z-10">
                <p className="text-xs text-slate-600 font-medium">© 2024 PharmaLog v1.0 • Tüm Hakları Saklıdır</p>
            </div>
        </div>
    );
}


