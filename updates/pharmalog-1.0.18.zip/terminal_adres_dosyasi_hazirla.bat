@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0terminal_adres_dosyasi_hazirla.ps1"
pause
