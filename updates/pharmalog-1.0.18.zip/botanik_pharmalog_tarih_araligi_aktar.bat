@echo off
title Botanik -> PharmaLog Tarih Araligi Aktarim
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0botanik_pharmalog_aktar.ps1" -ManualRange
pause
