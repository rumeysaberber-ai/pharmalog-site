$projectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$pidFile = Join-Path $projectDir "pharmalog_server.pid"
$outLog = Join-Path $projectDir "local_server.out.log"
$errLog = Join-Path $projectDir "local_server.err.log"

Set-Location $projectDir

$running = $false
if (Test-Path $pidFile) {
    $oldPid = (Get-Content $pidFile -ErrorAction SilentlyContinue | Select-Object -First 1)
    if ($oldPid -match '^\d+$') {
        $process = Get-Process -Id ([int]$oldPid) -ErrorAction SilentlyContinue
        if ($process -and $process.ProcessName -eq "node") {
            $running = $true
        }
    }
}

if (-not $running) {
    $portOwners = Get-NetTCPConnection -LocalPort 3001 -ErrorAction SilentlyContinue |
        Where-Object { $_.State -eq "Listen" } |
        Select-Object -ExpandProperty OwningProcess -Unique

    foreach ($ownerPid in $portOwners) {
        $process = Get-Process -Id $ownerPid -ErrorAction SilentlyContinue
        if ($process -and $process.ProcessName -eq "node") {
            Set-Content -Path $pidFile -Value $ownerPid -Encoding ASCII
            $running = $true
            break
        }
    }
}

if (-not $running) {
    $env:HOST = "0.0.0.0"
    $env:PORT = "3001"
    $node = Start-Process -WindowStyle Hidden -FilePath "node" -ArgumentList "server.js" -WorkingDirectory $projectDir -RedirectStandardOutput $outLog -RedirectStandardError $errLog -PassThru
    Set-Content -Path $pidFile -Value $node.Id -Encoding ASCII
}
