@echo off
title PharmaLog Yerel Ag Sunucusu
color 0A
cls

echo.
echo ========================================================
echo   PharmaLog Yerel Ag Sunucusu Baslatiliyor
echo ========================================================
echo.
echo Bu bilgisayar ANA BILGISAYAR olacak.
echo Diger bilgisayarlar ayni Wi-Fi/ag icindeyse asagidaki IPv4 adreslerinden
echo biri ile baglanabilir:
echo.
for /f "tokens=2 delims=:" %%A in ('ipconfig ^| findstr /R /C:"IPv4"') do echo   http://%%A:3001
echo.
echo Ana bilgisayarda acilacak adres:
echo   http://localhost:3001
echo.
echo Bu pencere acik kaldigi surece program calisir.
echo Kapatirsaniz terminaller baglanamaz.
echo.

start /min cmd /c "timeout /t 4 >nul && call pharmalog_app_ac.bat http://localhost:3001"
set HOST=0.0.0.0
set PORT=3001
node server.js

echo.
echo Sunucu kapandi.
pause
