$ErrorActionPreference = "Stop"

function Test-Admin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Convert-PrefixToMask {
    param([int]$PrefixLength)
    $mask = [uint32]0
    for ($i = 0; $i -lt $PrefixLength; $i++) {
        $mask = $mask -bor ([uint32]1 -shl (31 - $i))
    }
    return (@(
        ($mask -shr 24) -band 255
        ($mask -shr 16) -band 255
        ($mask -shr 8) -band 255
        $mask -band 255
    ) -join ".")
}

if (-not (Test-Admin)) {
    Write-Host "Bu islem yonetici yetkisi gerektirir. Yonetici olarak tekrar aciliyor..."
    Start-Process -FilePath "powershell.exe" -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

$projectDir = Split-Path -Parent $MyInvocation.MyCommand.Path

$config = Get-NetIPConfiguration |
    Where-Object {
        $_.IPv4Address -and
        $_.IPv4DefaultGateway -and
        $_.NetAdapter.Status -eq "Up" -and
        $_.IPv4Address.IPAddress -notlike "169.254.*"
    } |
    Sort-Object { if ($_.NetAdapter.MediaConnectionState -eq "Connected") { 0 } else { 1 } } |
    Select-Object -First 1

if (-not $config) {
    throw "Aktif internet ag baglantisi bulunamadi. Wi-Fi/Ethernet baglantisini kontrol edin."
}

$adapterName = $config.InterfaceAlias
$ipAddress = $config.IPv4Address.IPAddress
$prefixLength = [int]$config.IPv4Address.PrefixLength
$subnetMask = Convert-PrefixToMask $prefixLength
$gateway = $config.IPv4DefaultGateway.NextHop

$dnsServers = @()
if ($config.DNSServer.ServerAddresses) {
    $dnsServers = $config.DNSServer.ServerAddresses | Where-Object { $_ -match '^\d{1,3}(\.\d{1,3}){3}$' } | Select-Object -First 2
}
if ($dnsServers.Count -eq 0) {
    $dnsServers = @($gateway, "8.8.8.8")
} elseif ($dnsServers.Count -eq 1) {
    $dnsServers = @($dnsServers[0], "8.8.8.8")
}

Write-Host ""
Write-Host "PharmaLog ana bilgisayar IP sabitleme"
Write-Host "Ag baglantisi : $adapterName"
Write-Host "Sabit IP      : $ipAddress"
Write-Host "Alt ag maskesi: $subnetMask"
Write-Host "Ag gecidi     : $gateway"
Write-Host "DNS           : $($dnsServers -join ', ')"
Write-Host ""

$backupPath = Join-Path $projectDir "sabit_ip_onceki_ayarlar.txt"
@"
Tarih: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
Ag baglantisi: $adapterName
IP: $ipAddress
Prefix: $prefixLength
Mask: $subnetMask
Gateway: $gateway
DNS: $($dnsServers -join ", ")
"@ | Set-Content -LiteralPath $backupPath -Encoding UTF8

netsh interface ipv4 set address name="$adapterName" static $ipAddress $subnetMask $gateway 1 | Out-Host
netsh interface ipv4 set dnsservers name="$adapterName" static $($dnsServers[0]) primary | Out-Host
if ($dnsServers.Count -gt 1) {
    netsh interface ipv4 add dnsservers name="$adapterName" address=$($dnsServers[1]) index=2 | Out-Host
}

$terminalAddress = "http://${ipAddress}:3001"
Set-Content -LiteralPath (Join-Path $projectDir "ana_bilgisayar_sabit_adresi.txt") -Value $terminalAddress -Encoding UTF8

$terminalAddressTargets = @(
    (Join-Path $projectDir "terminal_adres.txt"),
    (Join-Path $projectDir "SIFIR_KURULUM_PAKETLERI\PharmaLog_Terminal\terminal_adres.txt")
)
foreach ($target in $terminalAddressTargets) {
    $targetDir = Split-Path -Parent $target
    if (Test-Path $targetDir) {
        Set-Content -LiteralPath $target -Value $terminalAddress -Encoding ASCII
    }
}

Write-Host ""
Write-Host "TAMAMLANDI."
Write-Host "Ana bilgisayar artik bu yerel IP ile sabitlendi:"
Write-Host $ipAddress
Write-Host ""
Write-Host "Terminallerde girilecek adres:"
Write-Host $terminalAddress
Write-Host ""
Write-Host "Terminal adres dosyasi da hazirlandi: terminal_adres.txt"
Write-Host ""
Write-Host "Bir sorun olursa dhcp_otomatik_ipye_don.bat dosyasini calistirabilirsiniz."
