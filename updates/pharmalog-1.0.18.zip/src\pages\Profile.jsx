import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { DataService } from '../lib/data';
import { Shield, Key, UserPlus, Users, Trash2, Edit2, Check, X, AlertTriangle, Save, LogOut, User } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Profile() {
    const { user, logout } = useAuth();
    const isSuperAdmin = user?.role === 'super-admin';
    const canViewAllGroups = user?.role === 'super-admin' || user?.role === 'admin';
    const canManageUsers = ['super-admin', 'admin', 'manager'].includes(user?.role);
    const roleLabel = user?.role === 'super-admin'
        ? 'Super Yonetici'
        : user?.role === 'admin'
            ? 'Yonetici'
            : user?.role === 'manager'
                ? 'Grup Yoneticisi'
                : 'Personel';

    // Password Change State
    const [passForm, setPassForm] = useState({ current: "", new: "", confirm: "" });
    const [passMsg, setPassMsg] = useState({ type: "", text: "" });

    // Admin: User Management State
    const [users, setUsers] = useState([]);
    const [isUserModalOpen, setIsUserModalOpen] = useState(false);
    const [editingUser, setEditingUser] = useState(null); // String (username) if editing
    const [userForm, setUserForm] = useState({ username: "", password: "", name: "", role: "staff" });
    const [loadingUsers, setLoadingUsers] = useState(false);

    useEffect(() => {
        if (canManageUsers) {
            loadUsers();
        }
    }, [canManageUsers]);

    const loadUsers = async () => {
        setLoadingUsers(true);
        try {
            const data = await DataService.getUsers();
            if (data) setUsers(data);
        } catch (err) {
            console.error(err);
        }
        setLoadingUsers(false);
    };

    // --- PASSWORD CHANGE HANDLER ---
    const handlePasswordChange = async (e) => {
        e.preventDefault();
        setPassMsg({ type: "", text: "" });

        if (passForm.new !== passForm.confirm) {
            setPassMsg({ type: "error", text: "Yeni şifreler uyuşmuyor." });
            return;
        }

        try {
            await DataService.changePassword(passForm.current, passForm.new);
            setPassMsg({ type: "success", text: "Şifreniz başarıyla değiştirildi." });
            setPassForm({ current: "", new: "", confirm: "" });
        } catch (err) {
            setPassMsg({ type: "error", text: err.message });
        }
    };

    // --- ADMIN: USER MANAGEMENT HANDLERS ---
    const handleOpenUserModal = (userToEdit = null) => {
        if (userToEdit) {
            setEditingUser(userToEdit.username);
            setUserForm({
                username: userToEdit.username,
                password: "", // Don't show current password
                name: userToEdit.name,
                role: userToEdit.role
            });
        } else {
            setEditingUser(null);
            setUserForm({ username: "", password: "", name: "", role: "staff" });
        }
        setIsUserModalOpen(true);
    };

    const handleSaveUser = async (e) => {
        e.preventDefault();
        try {
            if (editingUser) {
                // Update
                const updates = {};
                if (userForm.password) updates.password = userForm.password;
                updates.name = userForm.name;
                updates.role = userForm.role;
                if (userForm.username !== editingUser) {
                    updates.newUsername = userForm.username;
                }

                await DataService.updateUser(editingUser, updates);

                // If I updated myself and changed username, RE-LOGIN is required because frontend state is stale.
                if (editingUser === user.username && updates.newUsername) {
                    alert("Kullanıcı adınızı değiştirdiniz. Güvenlik gereği tekrar giriş yapmalısınız.");
                    logout();
                    return;
                }

                alert("Kullanıcı güncellendi.");
            } else {
                // Add
                if (!userForm.password) return alert("Şifre gereklidir.");
                await DataService.addUser(userForm);
                alert("Kullanıcı eklendi.");
            }
            setIsUserModalOpen(false);
            loadUsers();
        } catch (err) {
            alert("Hata: " + err.message);
        }
    };

    const handleDeleteUser = async (username) => {
        if (!window.confirm(`${username} kullanıcısını silmek istediğinize emin misiniz?`)) return;
        try {
            await DataService.deleteUser(username);
            loadUsers();
        } catch (err) {
            alert("Silinemedi: " + err.message);
        }
    };

    return (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
            <div>
                <h1 className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-slate-900 to-slate-700 dark:from-white dark:to-slate-300 flex items-center gap-3">
                    <Shield size={32} className="text-slate-800 dark:text-slate-200" />
                    Profil ve Güvenlik
                </h1>
                <p className="text-slate-500 dark:text-slate-400 mt-2 font-medium">Hesap ayarlarınızı ve güvenlik tercihlerinizi buradan yönetebilirsiniz.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* --- My Profile Card --- */}
                <div className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-xl rounded-2xl border border-white/40 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-black/20 p-8 transition-colors hover:scale-[1.01] duration-300">
                    <div className="flex items-center gap-4 mb-6">
                        <div className="p-3 bg-indigo-50 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400 rounded-2xl shadow-sm">
                            <Key size={24} />
                        </div>
                        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Şifre Değiştir</h2>
                    </div>

                    <div className="mb-8 bg-gradient-to-br from-indigo-50 to-slate-50 dark:from-indigo-900/10 dark:to-slate-900/50 p-6 rounded-2xl border border-indigo-100 dark:border-indigo-800/30 flex items-center justify-between shadow-inner">
                        <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-indigo-100/50 dark:bg-indigo-900/30 rounded-full flex items-center justify-center text-indigo-600 dark:text-indigo-400">
                                <User size={24} />
                            </div>
                            <div>
                                <div className="text-sm font-bold text-indigo-900 dark:text-indigo-300 uppercase tracking-wide opacity-70">Mevcut Oturum</div>
                                <div className="text-lg font-bold text-slate-800 dark:text-white mt-1">
                                    {user?.name}
                                </div>
                                <div className="text-xs font-medium text-indigo-600 dark:text-indigo-400 opacity-80 mt-0.5">
                                    @{user?.username} • {roleLabel}
                                </div>
                            </div>
                        </div>
                        <button
                            onClick={logout}
                            className="bg-white/80 dark:bg-slate-800/80 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800 hover:bg-rose-50 dark:hover:bg-rose-900/20 px-4 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2 shadow-sm hover:shadow-md hover:-translate-y-0.5"
                            title="Güvenli Çıkış"
                        >
                            <LogOut size={16} />
                            Çıkış
                        </button>
                    </div>

                    <form onSubmit={handlePasswordChange} className="space-y-5">
                        <div className="space-y-2">
                            <label className="text-sm font-bold text-slate-700 dark:text-slate-300 ml-1">Mevcut Şifre</label>
                            <input
                                type="password"
                                required
                                value={passForm.current}
                                onChange={e => setPassForm({ ...passForm, current: e.target.value })}
                                className="w-full px-4 py-3 border border-slate-200 dark:border-slate-700/50 bg-slate-50/50 dark:bg-slate-800/50 text-slate-900 dark:text-white rounded-xl focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 transition-all shadow-sm"
                            />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <label className="text-sm font-bold text-slate-700 dark:text-slate-300 ml-1">Yeni Şifre</label>
                                <input
                                    type="password"
                                    required
                                    value={passForm.new}
                                    onChange={e => setPassForm({ ...passForm, new: e.target.value })}
                                    className="w-full px-4 py-3 border border-slate-200 dark:border-slate-700/50 bg-slate-50/50 dark:bg-slate-800/50 text-slate-900 dark:text-white rounded-xl focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 transition-all shadow-sm"
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-sm font-bold text-slate-700 dark:text-slate-300 ml-1">Tekrar</label>
                                <input
                                    type="password"
                                    required
                                    value={passForm.confirm}
                                    onChange={e => setPassForm({ ...passForm, confirm: e.target.value })}
                                    className="w-full px-4 py-3 border border-slate-200 dark:border-slate-700/50 bg-slate-50/50 dark:bg-slate-800/50 text-slate-900 dark:text-white rounded-xl focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 transition-all shadow-sm"
                                />
                            </div>
                        </div>

                        {passMsg.text && (
                            <div className={cn(
                                "p-4 rounded-xl text-sm font-medium flex items-center gap-3 animate-in fade-in slide-in-from-top-2",
                                passMsg.type === 'success' ? "bg-green-50 text-green-700 border border-green-100" : "bg-red-50 text-red-700 border border-red-100"
                            )}>
                                {passMsg.type === 'success' ? <Check size={18} className="text-green-600" /> : <AlertTriangle size={18} className="text-red-600" />}
                                {passMsg.text}
                            </div>
                        )}

                        <div className="flex justify-end pt-2">
                            <button
                                type="submit"
                                className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-xl font-bold transition-all shadow-lg shadow-indigo-500/30 hover:shadow-indigo-500/50 flex items-center gap-2 hover:-translate-y-0.5"
                            >
                                <Save size={20} />
                                Şifreyi Güncelle
                            </button>
                        </div>
                    </form>
                </div>

                {/* --- Admin: User Management --- */}
                {canManageUsers && (
                    <div className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-xl rounded-2xl border border-white/40 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-black/20 p-8 transition-colors hover:scale-[1.01] duration-300 flex flex-col h-full">
                        <div className="flex items-center justify-between mb-8">
                            <div className="flex items-center gap-4">
                                <div className="p-3 bg-teal-50 text-teal-600 dark:bg-teal-900/30 dark:text-teal-400 rounded-2xl shadow-sm">
                                    <Users size={24} />
                                </div>
                                <h2 className="text-xl font-bold text-slate-900 dark:text-white">Kullanıcılar</h2>
                            </div>
                            <button
                                onClick={() => handleOpenUserModal()}
                                className="flex items-center gap-2 bg-teal-50 hover:bg-teal-100 text-teal-700 dark:bg-teal-900/20 dark:hover:bg-teal-900/30 dark:text-teal-400 px-4 py-2.5 rounded-xl transition-all font-bold border border-teal-100 dark:border-teal-800 shadow-sm"
                            >
                                <UserPlus size={18} />
                                <span className="hidden sm:inline">Yeni Ekle</span>
                            </button>
                        </div>

                        <div className="overflow-hidden bg-white/50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-700/50 flex-1">
                            <table className="w-full text-sm text-left">
                                <thead className="bg-slate-50 dark:bg-slate-700/50 text-slate-500 dark:text-slate-400 border-b border-slate-100 dark:border-slate-700">
                                    <tr>
                                        <th className="px-5 py-3 font-bold uppercase text-xs tracking-wider">Kullanıcı</th>
                                        {canViewAllGroups && (
                                            <th className="px-5 py-3 font-bold uppercase text-xs tracking-wider">Grup / Durum</th>
                                        )}
                                        <th className="px-5 py-3 font-bold uppercase text-xs tracking-wider">İsim</th>
                                        <th className="px-5 py-3 font-bold uppercase text-xs tracking-wider text-center">Rol / Danışan</th>
                                        <th className="px-5 py-3 font-bold uppercase text-xs tracking-wider text-right">İşlemler</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100 dark:divide-slate-700/50">
                                    {users.map(u => (
                                        <tr key={u.username} className="hover:bg-indigo-50/50 dark:hover:bg-indigo-900/20 transition-colors group">
                                            <td className="px-5 py-4 font-bold text-slate-700 dark:text-slate-200">
                                                {u.username}
                                                {u.isIsolated && <div className="text-[10px] text-orange-500 font-bold uppercase mt-0.5">İzole Grup</div>}
                                            </td>
                                            {canViewAllGroups && (
                                                <td className="px-5 py-4 text-xs font-mono text-slate-500">
                                                    {u.group === 'main_group' ? <span className="text-emerald-500 font-bold">Ana Ekip</span> :
                                                        u.group === 'admin_group' ? <span className="text-purple-500 font-bold">Yönetim</span> :
                                                            <span className="text-orange-400">Harici ({u.group.substring(0, 8)}...)</span>}
                                                </td>
                                            )}
                                            <td className="px-5 py-4 text-slate-600 dark:text-slate-300 font-medium">{u.name}</td>
                                            <td className="px-5 py-4 text-center">
                                                <div className="flex flex-col items-center gap-1">
                                                    <span className={cn(
                                                        "px-2.5 py-0.5 rounded-lg text-xs font-bold border",
                                                        (u.role === 'super-admin' || u.role === 'admin' || u.role === 'manager')
                                                            ? "bg-purple-100 text-purple-700 border-purple-200 dark:bg-purple-900/30 dark:text-purple-300 dark:border-purple-800"
                                                            : "bg-slate-100 text-slate-600 border-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700"
                                                    )}>
                                                        {u.role === 'super-admin'
                                                            ? 'Super Yonetici'
                                                            : u.role === 'admin'
                                                                ? 'Yonetici'
                                                                : u.role === 'manager'
                                                                    ? 'Grup Yoneticisi'
                                                                    : 'Personel'}
                                                    </span>
                                                    <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500" title="Kayıtlı Danışan Sayısı">
                                                        {u.patientCount} Danışan
                                                    </span>
                                                </div>
                                            </td>
                                            <td className="px-5 py-4 text-right">
                                                <div className="flex items-center justify-end gap-2 opacity-50 group-hover:opacity-100 transition-opacity">
                                                    <button
                                                        onClick={() => handleOpenUserModal(u)}
                                                        className="text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 p-1.5 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                                                        title="Düzenle"
                                                    >
                                                        <Edit2 size={16} />
                                                    </button>
                                                    {u.username !== user.username && (
                                                        <button
                                                            onClick={() => handleDeleteUser(u.username)}
                                                            className="text-slate-400 hover:text-red-600 dark:hover:text-red-400 p-1.5 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                                                            title="Sil"
                                                        >
                                                            <Trash2 size={16} />
                                                        </button>
                                                    )}
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                    {users.length === 0 && !loadingUsers && (
                                        <tr><td colSpan="5" className="text-center py-8 text-slate-400 font-medium">Kullanıcı bulunamadı.</td></tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                )}
            </div>

            {/* --- User Add/Edit Modal (Admin) --- */}
            {isUserModalOpen && (
                <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in duration-300">
                    <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-300 border border-white/20 dark:border-slate-800 ring-1 ring-black/5">
                        <div className="px-8 py-6 border-b border-slate-100 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-sm flex items-center justify-between">
                            <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                                {editingUser ? "Kullanıcıyı Düzenle" : "Yeni Kullanıcı Ekle"}
                            </h3>
                            <button onClick={() => setIsUserModalOpen(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 bg-slate-100 dark:bg-slate-800 p-2 rounded-full hover:bg-slate-200 transition-colors">
                                <X size={20} />
                            </button>
                        </div>

                        <form onSubmit={handleSaveUser} className="p-8 space-y-6">
                            {!editingUser && (
                                <div>
                                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Kullanıcı Adı</label>
                                    <input
                                        type="text"
                                        required
                                        value={userForm.username}
                                        onChange={e => setUserForm({ ...userForm, username: e.target.value })}
                                        className="w-full px-4 py-3 border border-slate-200 dark:border-slate-700/50 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white rounded-xl focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500 transition-all font-medium"
                                        placeholder="ornek_kullanici"
                                    />
                                    <p className="text-xs text-slate-400 mt-2 font-medium">Giriş yaparken kullanılacak benzersiz isim.</p>
                                </div>
                            )}

                            {editingUser && (
                                <div>
                                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Kullanıcı Adı</label>
                                    <input
                                        type="text"
                                        required
                                        value={userForm.username}
                                        onChange={e => setUserForm({ ...userForm, username: e.target.value })}
                                        className="w-full px-4 py-3 border border-slate-200 dark:border-slate-700/50 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white rounded-xl focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500 transition-all font-medium"
                                    />
                                </div>
                            )}

                            <div>
                                <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Görünecek İsim</label>
                                <input
                                    type="text"
                                    required
                                    value={userForm.name}
                                    onChange={e => setUserForm({ ...userForm, name: e.target.value })}
                                    className="w-full px-4 py-3 border border-slate-200 dark:border-slate-700/50 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white rounded-xl focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500 transition-all font-medium"
                                    placeholder="Örn: Asistan Ayşe"
                                />
                            </div>

                            <div>
                                <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">
                                    {editingUser ? "Yeni Şifre (Değiştirmek istemiyorsanız boş bırakın)" : "Şifre"}
                                </label>
                                <input
                                    type="password"
                                    required={!editingUser}
                                    value={userForm.password}
                                    onChange={e => setUserForm({ ...userForm, password: e.target.value })}
                                    className="w-full px-4 py-3 border border-slate-200 dark:border-slate-700/50 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white rounded-xl focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500 transition-all font-medium"
                                />
                            </div>

                            <div>
                                <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Yetki Rolü</label>
                                <select
                                    value={userForm.role}
                                    onChange={e => setUserForm({ ...userForm, role: e.target.value })}
                                    className="w-full px-4 py-3 border border-slate-200 dark:border-slate-700/50 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white rounded-xl focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500 transition-all font-medium appearance-none"
                                >
                                    <option value="staff">Personel (Standart)</option>
                                    {(user?.role === 'admin' || user?.role === 'super-admin') && (
                                        <option value="manager">Grup Yonetici</option>
                                    )}
                                    {user?.role === 'super-admin' && (
                                        <option value="admin">Yonetici (Tam Yetki)</option>
                                    )}
                                </select>
                            </div>

                            {/* SUPER ADMIN OPTION */}
                            {canViewAllGroups && !editingUser && (
                                <div className="p-4 bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-100 dark:border-indigo-800 rounded-xl">
                                    <label className="flex items-start gap-3 cursor-pointer">
                                        <div className="relative flex items-center">
                                            <input
                                                type="checkbox"
                                                className="w-5 h-5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 transition-all cursor-pointer mt-0.5"
                                                checked={userForm.createIsolatedGroup || false}
                                                onChange={e => setUserForm({ ...userForm, createIsolatedGroup: e.target.checked })}
                                            />
                                        </div>
                                        <div>
                                            <span className="block text-sm font-bold text-indigo-900 dark:text-indigo-300">
                                                Yeni İzole Ekip Oluştur
                                            </span>
                                            <p className="text-xs text-indigo-700/80 dark:text-indigo-400 mt-1">
                                                Bu seçeneği işaretlerseniz, bu kullanıcı <strong>sizin ekibinizden tamamen bağımsız</strong> yeni bir boş sayfa ile başlar.
                                                Kendi ekibini kurabilir ama sizi göremez.
                                            </p>
                                        </div>
                                    </label>
                                </div>
                            )}

                            <div className="flex justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
                                <button
                                    type="button"
                                    onClick={() => setIsUserModalOpen(false)}
                                    className="px-6 py-3 text-slate-600 dark:text-slate-300 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
                                >
                                    İptal
                                </button>
                                <button
                                    type="submit"
                                    className="bg-teal-600 hover:bg-teal-700 text-white px-6 py-3 rounded-xl font-bold transition-all hover:shadow-lg hover:shadow-teal-500/30 hover:-translate-y-0.5"
                                >
                                    Kaydet
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}
