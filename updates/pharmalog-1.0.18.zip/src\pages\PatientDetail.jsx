import React from 'react';
import { useState, useEffect, useRef } from "react";
import { useParams, Link, useLocation } from "react-router-dom";
import { ArrowLeft, Phone, Calendar, Clock, Plus, Package, FileText, AlertTriangle, Search, Check, Trash2, ChevronDown, ChevronRight, History, Edit2, X, ArrowUpDown, Paperclip, Image, File, PhoneOutgoing, CalendarPlus, Activity, Scale, Cigarette, Wine, Shield, Ban, Repeat, Info, Heart, CalendarHeart, Bell, UserCog, CheckCircle, Printer } from "lucide-react";
import { format, parseISO, addDays, differenceInDays } from "date-fns";
import { tr } from "date-fns/locale";
import { DataService } from "../lib/data";
import { cn, normalizeString, formatPhoneNumber } from "../lib/utils";
import { canUseCommercialChannel, getIntegrationMeta, getKvkkConsent, isKvkkPending } from "../lib/compliance";
import { useAuth } from "../context/AuthContext";

import DetailedAnamnesisModal from "../components/DetailedAnamnesisModal";
import DermoAnamnesisModal from "../components/DermoAnamnesisModal";
import AnamnesisReportModal from "../components/AnamnesisReportModal";
import DermoAnamnesisReportModal from "../components/DermoAnamnesisReportModal";
import SkinCareModal from "../components/SkinCareModal";
import PrintablePatientDetail from "../components/PrintablePatientDetail";


class ErrorBoundary extends React.Component {
    constructor(props) {
        super(props);
        this.state = { hasError: false, error: null, errorInfo: null };
    }

    static getDerivedStateFromError(error) {
        return { hasError: true };
    }

    componentDidCatch(error, errorInfo) {
        this.setState({ error, errorInfo });
        console.error("ErrorBoundary caught error:", error, errorInfo);
    }

    render() {
        if (this.state.hasError) {
            return (
                <div className="p-8 bg-red-50 border border-red-200 rounded-lg m-4">
                    <h2 className="text-xl font-bold text-red-800 mb-4">Bir Sorun Oluştu!</h2>
                    <details className="whitespace-pre-wrap font-mono text-sm text-red-700 p-4 bg-white rounded border border-red-100">
                        {this.state.error && this.state.error.toString()}
                        <br />
                        {this.state.errorInfo && this.state.errorInfo.componentStack}
                    </details>
                </div>
            );
        }

        return this.props.children;
    }
}

export default function PatientDetailWrapper() {
    return (
        <ErrorBoundary>
            <PatientDetailInner />
        </ErrorBoundary>
    );
}



function PatientDetailInner() {
    const FOLLOW_UP_CATEGORY_OPTIONS = [
        { id: "besin_destek", label: "Besin Destek Takip" },
        { id: "dermokozmetik", label: "Dermokozmetik Takip" },
        { id: "raporlu_hasta", label: "Raporlu Danışan Takip" }
    ];
    const REPORT_PATIENTS_GROUP_ID = "REPORT_PATIENTS";
    const REPORT_PATIENTS_GROUP_LABEL = "Raporlu Danışanlar";

    const { user } = useAuth();
    const { id } = useParams();
    const location = useLocation();
    const [patient, setPatient] = useState(null);

    // Sort State
    const [sortOrder, setSortOrder] = useState("desc"); // "desc" (Newest first) or "asc" (Oldest first)
    const [showAudit, setShowAudit] = useState(false); // Audit UI Toggle

    // Modals
    const [isProductModalOpen, setIsProductModalOpen] = useState(false);
    const [isVisitModalOpen, setIsVisitModalOpen] = useState(false);
    const [editMode, setEditMode] = useState("full"); // "full" | "date" | "note"

    // Edit Product Modal State
    const [isProductEditModalOpen, setIsProductEditModalOpen] = useState(false);
    const [editingProduct, setEditingProduct] = useState(null);
    const [editProductForm, setEditProductForm] = useState({ productId: "", productName: "", type: "given", notes: "" });
    const [editSearchTerm, setEditSearchTerm] = useState("");
    const [isEditDropdownOpen, setIsEditDropdownOpen] = useState(false);

    // Attachment States
    const [isAttachmentModalOpen, setIsAttachmentModalOpen] = useState(false);
    const [attachmentTarget, setAttachmentTarget] = useState(null); // { type: 'patient' | 'visit', id: string }
    const [attachmentForm, setAttachmentForm] = useState({ name: "", file: null });
    const [isInterestModalOpen, setIsInterestModalOpen] = useState(false);
    const [isAnamnesisModalOpen, setIsAnamnesisModalOpen] = useState(false);
    const [isDermoAnamnesisModalOpen, setIsDermoAnamnesisModalOpen] = useState(false);
    const [isReportModalOpen, setIsReportModalOpen] = useState(false);
    const [isDermoReportModalOpen, setIsDermoReportModalOpen] = useState(false);
    const [isSkinCareModalOpen, setIsSkinCareModalOpen] = useState(false);

    // Invite State
    const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);
    const [upcomingEvents, setUpcomingEvents] = useState([]);

    // Follow Up State
    const [isFollowUpModalOpen, setIsFollowUpModalOpen] = useState(false);
    const [followUpForm, setFollowUpForm] = useState({
        date: "",
        note: "",
        followUpCategories: [],
        isPharmacistFollowUp: false
    });
    const [editingFollowUpId, setEditingFollowUpId] = useState(null);

    // Database
    const [dbProducts, setDbProducts] = useState([]);
    const [companies, setCompanies] = useState([]); // All companies for interest selection

    // Autocomplete State
    const [searchTerm, setSearchTerm] = useState("");
    const [bulkMatches, setBulkMatches] = useState([]); // Array of {line, product}
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const dropdownRef = useRef(null);
    const productInputRef = useRef(null);

    // Form States
    const [activeVisitId, setActiveVisitId] = useState(null); // ID of the visit we are adding product to
    const [editingVisitId, setEditingVisitId] = useState(null); // ID of the visit being edited
    const [followUpToConvert, setFollowUpToConvert] = useState(null); // ID of the follow-up being converted to a visit
    const [selectedProduct, setSelectedProduct] = useState(null);
    const [productForm, setProductForm] = useState({
        durationDays: 30,
        notes: "",
        type: "given" // given | recommended
    });

    const filteredProducts = dbProducts.filter(p => {
        if (!p) return false;
        const term = normalizeString(searchTerm || "");
        const product = normalizeString(p.productName || "");
        const barcode = String(p.barcode || "").toLowerCase();
        const searchWords = term.split(/\s+/).filter(word => word.length > 0);
        return searchWords.every(word => product.includes(word)) || barcode.includes(term);
    });

    // Initial Data Load
    useEffect(() => {
        const load = async () => {
            try {
                const data = await DataService.getPatient(id);
                if (data) {
                    setPatient(data);
                    // Pre-fetch other data needed
                    const prods = await DataService.getDbProducts();
                    setDbProducts(prods || []);
                    const comps = await DataService.getCompanies();
                    setCompanies(comps || []);
                    const events = await DataService.getUpcomingExpertDays();
                    setUpcomingEvents(events || []);
                }
            } catch (error) {
                console.error("PatientDetail Load Error:", error);
            }
        };
        load();
    }, [id]);

    // --- RESTORED MISSING HANDLERS ---
    const [visitForm, setVisitForm] = useState({ date: "", note: "", type: "Kontrol" });

    const handleOpenVisitModal = (visit, mode = "full", type = "Kontrol") => {
        setEditMode(mode);
        if (visit) {
            setEditingVisitId(visit.id);
            setVisitForm({
                date: visit.date ? format(parseISO(visit.date), "yyyy-MM-dd") : "",
                note: visit.note || "",
                type: visit.type || "Kontrol"
            });
        } else {
            setEditingVisitId(null);
            setVisitForm({
                date: format(new Date(), "yyyy-MM-dd"),
                note: "",
                type: type
            });
        }
        setIsVisitModalOpen(true);
    };

    const handleOpenCallVisitModal = () => {
        if (!canUseCommercialChannel(patient, "ARAMA")) {
            alert("Ticari arama engellendi.\n\nÖnce danışan profilinde KVKK aydınlatması, açık rıza ve Arama izni işaretlenmelidir.");
            return;
        }
        handleOpenVisitModal(null, "full", "Arama");
    };

    const handleSaveVisit = async (e) => {
        e.preventDefault();
        try {
            if (editingVisitId) {
                await DataService.updateVisit(patient.id, editingVisitId, {
                    date: new Date(visitForm.date).toISOString(),
                    note: visitForm.note,
                    type: visitForm.type
                });
            } else {
                await DataService.addVisit(patient.id, {
                    date: new Date(visitForm.date).toISOString(),
                    note: visitForm.note,
                    type: visitForm.type,
                    products: []
                });
            }
            const updated = await DataService.getPatient(patient.id);
            setPatient({ ...updated });
            setIsVisitModalOpen(false);
        } catch (err) {
            console.error(err);
            alert("Hata oluştu: " + err.message);
        }
    };

    const handleDeleteVisit = async (visitId) => {
        if (window.confirm("Bu paneli/ziyareti silmek istediğinize emin misiniz? İçindeki ürünler de silinecektir.")) {
            await DataService.deleteVisit(patient.id, visitId);
            const updated = await DataService.getPatient(patient.id);
            setPatient({ ...updated });
        }
    };

    const handleQuickDateUpdate = async (visitId, newDate) => {
        if (!newDate) return;
        await DataService.updateVisit(patient.id, visitId, {
            date: new Date(newDate).toISOString()
        });
        const updated = await DataService.getPatient(patient.id);
        setPatient({ ...updated });
    };
    // --------------------------------

    const handleSaveFollowUp = async (e) => {
        e.preventDefault();
        if (!followUpForm.date) {
            alert("Lütfen takip tarihi seçin.");
            return;
        }

        const normalizeFollowUpDate = (rawDate) => {
            const value = String(rawDate || "").trim();
            if (!value) return null;

            if (/^\d{4}-\d{2}-\d{2}$/.test(value)) {
                const dateObj = new Date(`${value}T00:00:00`);
                return Number.isNaN(dateObj.getTime()) ? null : dateObj.toISOString();
            }

            if (/^\d{2}\.\d{2}\.\d{4}$/.test(value)) {
                const [day, month, year] = value.split(".");
                const dateObj = new Date(`${year}-${month}-${day}T00:00:00`);
                return Number.isNaN(dateObj.getTime()) ? null : dateObj.toISOString();
            }

            const fallback = new Date(value);
            return Number.isNaN(fallback.getTime()) ? null : fallback.toISOString();
        };

        const isoDate = normalizeFollowUpDate(followUpForm.date);
        if (!isoDate) {
            alert("Takip tarihi geçersiz görünüyor. Lütfen takvimden tekrar seçin.");
            return;
        }

        const targetDay = new Date(isoDate).toISOString().slice(0, 10);
        const hasSameDayFollowUp = (Array.isArray(patient?.followUps) ? patient.followUps : []).some((fu) => {
            if (!fu?.date) return false;
            if (editingFollowUpId && fu.id === editingFollowUpId) return false;
            const fuDay = new Date(fu.date).toISOString().slice(0, 10);
            return fuDay === targetDay;
        });
        if (hasSameDayFollowUp) {
            alert("Bu danışan icin ayni tarihte zaten bir takip kaydi var.");
            return;
        }

        try {
            let updated;
            if (editingFollowUpId) {
                updated = await DataService.updateFollowUp(patient.id, editingFollowUpId, {
                    date: isoDate,
                    note: followUpForm.note,
                    followUpCategories: Array.isArray(followUpForm.followUpCategories) ? followUpForm.followUpCategories : [],
                    isPharmacistFollowUp: followUpForm.isPharmacistFollowUp
                });
            } else {
                updated = await DataService.addFollowUp(patient.id, {
                    date: isoDate,
                    note: followUpForm.note,
                    followUpCategories: Array.isArray(followUpForm.followUpCategories) ? followUpForm.followUpCategories : [],
                    isPharmacistFollowUp: followUpForm.isPharmacistFollowUp
                });
            }

            setPatient({ ...updated }); // Spread to force re-render
            setIsFollowUpModalOpen(false);
            setFollowUpForm({ date: "", note: "", followUpCategories: [], isPharmacistFollowUp: false });
            setEditingFollowUpId(null);
        } catch (err) {
            console.error(err);
            alert("Takip kaydedilirken hata oluştu: " + (err?.message || "Bilinmeyen hata"));
        }
    };

    const handleOpenInviteModal = async () => {
        const events = await DataService.getUpcomingExpertDays();
        setUpcomingEvents(events);
        setIsInviteModalOpen(true);
    };

    const handleInviteConfirm = async (event) => {
        await DataService.addPatientToExpertDay(event.companyId, event.id, id);
        // Refresh events list
        const events = await DataService.getUpcomingExpertDays();
        setUpcomingEvents(events);
    };

    const handleInviteRemove = async (event) => {
        if (!window.confirm("Bu daveti iptal etmek istediğinize emin misiniz?")) return;
        await DataService.removePatientFromExpertDay(event.companyId, event.id, id);
        const events = await DataService.getUpcomingExpertDays();
        setUpcomingEvents(events);
    };

    const handleUpdateAnamnesis = async (anamnesisData) => {
        // 1. Anamnezi Güncelle
        let updatedPatient = await DataService.updatePatient(patient.id, { detailedAnamnesis: anamnesisData });

        // 2. Ürünleri Günlük Panele Eşitle
        // 2. Otomatik Panel Oluşturma DEVRE DIŞI
        /*
        try {
            // ... (Logic removed per user request)
        } catch (error) {
            console.error("Otomatik panel eşitleme hatası:", error);
        }
        */

        setPatient(updatedPatient);
        setIsAnamnesisModalOpen(false);
    };

    const handleSelectProduct = (product) => {
        setSelectedProduct(product);
        setSearchTerm(product.productName);
        setIsDropdownOpen(false);
    };

    const openAddProductModal = (visitId) => {
        setActiveVisitId(visitId);
        setProductForm({ notes: "", type: "given", durationDays: 30 });
        setSearchTerm("");
        setBulkMatches([]);
        setSelectedProduct(null);
        setIsProductModalOpen(true);
        // Focus input after render
        setTimeout(() => {
            if (productInputRef.current) {
                productInputRef.current.focus();
            }
        }, 100);
    };

    const handleUpdateDermoAnamnesis = async (dermoData) => {
        const updatedPatient = await DataService.updatePatient(patient.id, { dermoAnamnesis: dermoData });
        setPatient(updatedPatient);
        setIsDermoAnamnesisModalOpen(false);
    };

    const handleUpdateSkinCare = async (skinCareData) => {
        // 0. Clean Incoming Data (Deduplicate Transactions by ID)
        // This fixes the issue where previous bugs might have duplicated transactions in the array
        const uniqueTransactions = [];
        const seenIds = new Set();

        const allTransactions = skinCareData.transactions || [];
        for (const t of allTransactions) {
            if (!seenIds.has(t.id)) {
                seenIds.add(t.id);
                uniqueTransactions.push(t);
            }
        }
        skinCareData.transactions = uniqueTransactions;

        // 1. Save Deduplicated Skin Care Data
        let updatedPatient = await DataService.updatePatient(patient.id, { skinCareData });

        // 2. Consolidate Skin Care Transactions by Date
        // We use the CLEAN uniqueTransactions list which represents the entire history
        const newTransactions = skinCareData.transactions;

        // Identify all affected dates
        const getDateFormat = (dateStr) => {
            try { return format(parseISO(dateStr), 'yyyy-MM-dd'); } catch { return null; }
        };

        const affectedDates = new Set();
        newTransactions.forEach(t => {
            const date = getDateFormat(t.date);
            if (date) affectedDates.add(date);
        });

        // 3. Fetch latest state from server
        updatedPatient = await DataService.getPatient(patient.id);
        const currentVisits = updatedPatient.visits || [];

        // FIX: Also add dates from existing Skin Care visits to ensure we check them for deletion if transactions are gone
        currentVisits.forEach(v => {
            if (
                v.type === 'Cilt Bakım' ||
                v.type === 'Cilt Bakım Takibi' ||
                v.type === 'Hak Tanımlama' ||
                v.type === 'Hak Kullanımı' ||
                v.type === 'Ücretli İşlem' ||
                (v.note && (
                    v.note.includes('bakım hakkı tanımlanmıştır') ||
                    v.note.includes('Bakım hakkı kullanıldı') ||
                    v.note.includes('ücretli bakım yapıldı')
                ))
            ) {
                const date = getDateFormat(v.date);
                if (date) affectedDates.add(date);
            }
        });

        for (const dateStr of affectedDates) {
            // Get all transactions for this specific date from the CLEAN list
            const daysTransactions = newTransactions.filter(t => getDateFormat(t.date) === dateStr)
                .sort((a, b) => new Date(a.date) - new Date(b.date));

            // Find ALL existing visits for this date that are related to Skin Care
            const existingVisits = currentVisits.filter(v => getDateFormat(v.date) === dateStr && (
                v.type === 'Cilt Bakım' ||
                v.type === 'Cilt Bakım Takibi' ||
                v.type === 'Hak Tanımlama' ||
                v.type === 'Hak Kullanımı' ||
                v.type === 'Ücretli İşlem' ||
                (v.note && (
                    v.note.includes('bakım hakkı tanımlanmıştır') ||
                    v.note.includes('Bakım hakkı kullanıldı') ||
                    v.note.includes('ücretli bakım yapıldı')
                ))
            ));

            if (daysTransactions.length > 0) {
                // Generate Summary Note FROM SCRATCH using only unique transactions
                const noteLines = daysTransactions.map(t => {
                    if (t.type === 'add_right') return `• ${t.description} istinaden ${t.value} adet bakım hakkı tanımlanmıştır.`;
                    if (t.type === 'use_right') return `• Bakım hakkı kullanıldı, danışana ücretsiz bakım yapıldı. (${t.description})`;
                    if (t.type === 'paid_service') return `• Danışana ücretli bakım yapıldı. ${t.description}. Tutar: ${t.amount} TL.`;
                    if (t.type === 'appointment_created') return `• Bakım hakkına istinaden randevu oluşturuldu. (${t.description})`;
                    return "";
                });

                // Extra safety: Deduplicate lines in the note itself
                const uniqueNoteLines = [...new Set(noteLines)];
                const summaryNote = uniqueNoteLines.join('\n');

                if (existingVisits.length > 0) {
                    // Update the first one found (Main)
                    const mainVisit = existingVisits[0];
                    await DataService.updateVisit(patient.id, mainVisit.id, {
                        note: summaryNote,
                        type: 'Cilt Bakım Takibi'
                    });

                    // Delete duplicates (Rest)
                    for (let i = 1; i < existingVisits.length; i++) {
                        await DataService.deleteVisit(patient.id, existingVisits[i].id);
                    }
                } else {
                    // Create new
                    const firstTx = daysTransactions[0];
                    await DataService.addVisit(patient.id, {
                        date: firstTx.date,
                        note: summaryNote,
                        type: 'Cilt Bakım Takibi',
                        products: []
                    });
                }
            } else {
                // No transactions left for this date
                for (const v of existingVisits) {
                    await DataService.deleteVisit(patient.id, v.id);
                }
            }
        }

        // 4. Final Refresh
        updatedPatient = await DataService.getPatient(patient.id);
        setPatient(updatedPatient);
        // setIsSkinCareModalOpen(false); // REMOVED: Keep modal open for auto-save workflow
    };



    const handleAddProduct = async (e) => {
        e.preventDefault();
        if ((!selectedProduct && bulkMatches.length === 0) || !activeVisitId) return;

        // Bulk Add Logic
        if (searchTerm.includes('\n') && bulkMatches.length > 0) {
            const productsToAdd = bulkMatches.filter(m => m.product).map(m => m.product);

            for (const prod of productsToAdd) {
                await DataService.addVisitProduct(id, activeVisitId, {
                    productName: prod.productName,
                    productId: prod.id,
                    givenDate: new Date().toISOString(),
                    durationDays: parseInt(productForm.durationDays),
                    notes: productForm.notes,
                    type: productForm.type || 'given'
                });
            }
        }
        // Single Add Logic
        else if (selectedProduct) {
            await DataService.addVisitProduct(id, activeVisitId, {
                productName: selectedProduct.productName,
                productId: selectedProduct.id,
                givenDate: new Date().toISOString(),
                durationDays: parseInt(productForm.durationDays),
                notes: productForm.notes,
                type: productForm.type || 'given'
            });
        }

        // Refresh data
        const updated = await DataService.getPatient(id);
        setPatient({ ...updated });

        // Reset Form
        setIsProductModalOpen(false);
        setProductForm({ durationDays: 30, notes: "", type: "given" });
        setSelectedProduct(null);
        setSearchTerm("");
        setBulkMatches([]);
        setActiveVisitId(null);
    };

    const handleRemoveProduct = async (visitId, productId) => {
        if (window.confirm("Bu ürünü silmek istediğinize emin misiniz?")) {
            const updatedPatient = await DataService.removeProductFromVisit(id, visitId, productId);
            setPatient({ ...updatedPatient });
        }
    };

    // Patient Edit State
    const [isPatientEditModalOpen, setIsPatientEditModalOpen] = useState(false);
    const [patientEditForm, setPatientEditForm] = useState({
        fullName: "",
        description: "",
        phone: "",
        age: "",
        birthDate: "",
        kvkkConsent: {
            enlightenmentDone: false,
            explicitConsent: false,
            dataProcessing: false,
            sms: false,
            phoneCall: false,
            email: false,
            iysResponsibilityAccepted: false,
            consentDate: "",
            consentSource: "Eczane içi bilgilendirme"
        }
    });

    const openPatientEditModal = () => {
        setPatientEditForm({
            fullName: patient.fullName || "",
            description: patient.description || "",
            phone: patient.phone || "",
            age: patient.age || "",
            birthDate: patient.birthDate || "",
            kvkkConsent: getKvkkConsent(patient)
        });
        setIsPatientEditModalOpen(true);
    };

    const handleUpdatePatient = async (e) => {
        e.preventDefault();

        // Phone Validation: formatPhoneNumber handles cleaning and formatting.
        // If further strict validation is needed, it should be added here.
        // For now, we trust formatPhoneNumber to return a clean or empty string.

        await DataService.updatePatient(patient.id, {
            ...patientEditForm,
            age: parseInt(patientEditForm.age) || 0,
            kvkkConsent: getKvkkConsent(patientEditForm)
        });

        const updated = await DataService.getPatient(id);
        setPatient(updated);
        setIsPatientEditModalOpen(false);
    };

    const handleEditProductClick = (visitId, product) => {
        setEditingProduct({ visitId, product });
        setEditProductForm({
            productName: product.productName,
            productId: product.productId || product.id, // Fallback if productId missing
            notes: product.notes || "",
            type: product.type || "given",
            durationDays: product.durationDays || 30
        });
        setEditSearchTerm(product.productName);
        setIsProductEditModalOpen(true);
    };

    const handleUpdateProductFull = async (e) => {
        e.preventDefault();
        if (!editingProduct) return;

        const { visitId, product } = editingProduct;

        // If user cleared the search or didn't select a valid product from list when changing name:
        // We generally want to enforce selection. 
        // But if they just kept the same name, productId remains valid.

        await DataService.updateVisitProduct(id, visitId, product.id, {
            productName: editProductForm.productName,
            productId: editProductForm.productId,
            notes: editProductForm.notes,
            type: editProductForm.type,
            durationDays: editProductForm.durationDays
        });

        // Refresh
        const updated = await DataService.getPatient(id);
        setPatient(updated);

        setIsProductEditModalOpen(false);
        setEditingProduct(null);
        setEditProductForm({ productName: "", productId: "", notes: "", type: "given", durationDays: 30 });
        setEditSearchTerm("");
    };

    const handleToggleProductType = async (visitId, product) => {
        // If type is not set, it is considered 'given' by default in the UI logic.
        // So if it is 'recommended', switch to 'given'. Otherwise (given or undefined), switch to 'recommended'.

        const currentType = product.type || 'given';
        const newType = (currentType === 'recommended') ? 'given' : 'recommended';

        await DataService.updateVisitProduct(id, visitId, product.id || product.productId, {
            ...product,
            type: newType
        });

        // Refresh
        const updated = await DataService.getPatient(id);
        setPatient(updated);
    };

    // --- ATTACHMENT HANDLERS ---
    const openAttachmentModal = (type, targetId) => {
        setAttachmentTarget({ type, id: targetId });
        setAttachmentForm({ name: "", file: null });
        setIsAttachmentModalOpen(true);
    };

    const handleFileChange = (e) => {
        if (e.target.files && e.target.files[0]) {
            setAttachmentForm({ ...attachmentForm, file: e.target.files[0] });
        }
    };

    const handleSaveAttachment = (e) => {
        e.preventDefault();
        if (!attachmentForm.file || !attachmentTarget) return;

        const reader = new FileReader();
        reader.onloadend = async () => {
            const base64String = reader.result;
            const attachmentData = {
                name: attachmentForm.name || attachmentForm.file.name,
                type: attachmentForm.file.type.startsWith('image/') ? 'image' : 'doc',
                content: base64String,
                fileName: attachmentForm.file.name
            };

            if (attachmentTarget.type === 'patient') {
                await DataService.addPatientAttachment(attachmentTarget.id, attachmentData);
            } else {
                await DataService.addVisitAttachment(id, attachmentTarget.id, attachmentData);
            }

            const updated = await DataService.getPatient(id);
            setPatient({ ...updated });
            setIsAttachmentModalOpen(false);
        };
        reader.readAsDataURL(attachmentForm.file);
    };

    const handleRemoveAttachment = async (type, targetId, attachmentId) => {
        if (window.confirm("Bu dosyayı silmek istediğinize emin misiniz?")) {
            if (type === 'patient') {
                await DataService.removePatientAttachment(targetId, attachmentId);
            } else {
                await DataService.removeVisitAttachment(id, targetId, attachmentId);
            }
            const updated = await DataService.getPatient(id);
            setPatient({ ...updated });
        }
    };

    const renderAttachments = (attachments, type, targetId) => {
        if (!attachments || attachments.length === 0) return null;
        return (
            <div className="flex flex-wrap gap-2 mt-3">
                {attachments.map(att => (
                    <div key={att.id} className="relative group bg-slate-100 border border-slate-200 rounded-lg p-2 pr-8 flex items-center gap-2 text-sm text-slate-700 hover:bg-slate-200 transition-colors">
                        {att.type === 'image' ? <Image size={16} className="text-purple-500" /> : <File size={16} className="text-blue-500" />}

                        {att.type === 'image' ? (
                            <a href={att.content} target="_blank" rel="noopener noreferrer" className="hover:underline truncate max-w-[150px]" title="Görüntüle">
                                {att.name}
                            </a>
                        ) : (
                            <a href={att.content} download={att.fileName} className="hover:underline truncate max-w-[150px]" title="İndir">
                                {att.name}
                            </a>
                        )}

                        <button
                            onClick={() => handleRemoveAttachment(type, targetId, att.id)}
                            className="absolute right-1 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-red-500"
                        >
                            <X size={14} />
                        </button>
                    </div>
                ))}
            </div>
        );
    };

    const handleSelectInterestAndClose = async (companyId) => {
        // Current state
        const currentInterests = patient.interestedCompanies || [];
        const exists = currentInterests.some(id => String(id) === String(companyId));

        // New list
        let newInterests;
        if (exists) {
            newInterests = currentInterests.filter(id => String(id) !== String(companyId));
        } else {
            newInterests = [...currentInterests, companyId];
        }

        // Save immediately
        const updated = await DataService.updatePatient(patient.id, {
            interestedCompanies: newInterests
        });
        setPatient(updated);
        // setIsInterestModalOpen(false); // See Patients.jsx logic
    };

    const handleToggleDoNotCall = async () => {
        const newValue = !patient.isDoNotCall;
        const patientUpdates = newValue
            ? { isDoNotCall: true, interestedCompanies: [] }
            : { isDoNotCall: false };

        const updated = await DataService.updatePatient(patient.id, patientUpdates);
        setPatient(updated);
    };

    if (!patient) return <div className="p-8 text-center">Yükleniyor...</div>;

    const kvkkConsent = getKvkkConsent(patient);
    const integrationMeta = getIntegrationMeta(patient);
    const kvkkPending = isKvkkPending(patient);

    // SORTING LOGIC
    const visits = (Array.isArray(patient.visits) ? [...patient.visits] : [])
        .filter(v => v && typeof v === 'object')
        .sort((a, b) => {
            if (!a.date || !b.date) return 0;
            const dateA = new Date(a.date);
            const dateB = new Date(b.date);
            return sortOrder === "desc" ? dateB - dateA : dateA - dateB;
        });

    return (
        <>
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-700 space-y-8 pb-20 print:hidden">
                {/* Header & Actions */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 pb-6 border-b border-slate-200 dark:border-slate-800">
                    <Link
                        to={location.state?.from || "/patients"}
                        state={location.state?.returnDayId ? { openDayId: location.state.returnDayId, highlightPatientId: id } : null}
                        className="inline-flex items-center gap-2 text-slate-500 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 transition-colors font-medium group"
                    >
                        <div className="p-2 bg-white dark:bg-slate-800 rounded-full border border-slate-200 dark:border-slate-700 group-hover:border-indigo-200 dark:group-hover:border-indigo-800 transition-colors shadow-sm">
                            <ArrowLeft size={18} className="transition-transform group-hover:-translate-x-1" />
                        </div>
                        {location.state?.from === "/" || location.state?.from === "/dashboard-new"
                            ? "Genel Bakışa Dön"
                            : (location.state?.from ? "Geri Dön" : "Danışan Listesine Dön")}
                    </Link>

                    <div className="flex items-center gap-3">
                        <button
                            onClick={() => setSortOrder(prev => prev === "desc" ? "asc" : "desc")}
                            className="flex items-center gap-2 text-slate-600 hover:text-slate-900 bg-white dark:bg-slate-800 dark:text-slate-300 dark:hover:text-white border border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 px-4 py-2.5 rounded-xl transition-all font-bold text-sm shadow-sm"
                        >
                            <ArrowUpDown size={16} />
                            {sortOrder === "desc" ? "Yeniden Eskiye" : "Eskiden Yeniye"}
                        </button>

                        <button
                            onClick={() => window.print()}
                            className="bg-purple-600 hover:bg-purple-700 text-white border border-purple-500 dark:border-purple-700 px-4 py-2.5 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-sm"
                            title="Danışan Kartını Yazdır"
                        >
                            <Printer size={18} />
                            <span className="hidden sm:inline">Yazdır</span>
                        </button>

                        <button
                            onClick={handleOpenCallVisitModal}
                            className="bg-cyan-600 hover:bg-cyan-700 text-white border border-cyan-500 dark:border-cyan-700 px-4 py-2.5 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-sm"
                        >
                            <PhoneOutgoing size={18} />
                            <span className="hidden sm:inline">Yeni Arama</span>
                        </button>

                        <button
                            onClick={() => handleOpenVisitModal(null, "full")}
                            className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-bold transition-transform hover:scale-105 shadow-lg shadow-indigo-500/30 flex items-center justify-center gap-2"
                        >
                            <Plus size={20} />
                            Yeni Ziyaret
                        </button>
                    </div>
                </div>

                {/* Patient Info Card */}
                <div className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-xl rounded-2xl border border-white/40 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-black/20 p-8 mb-8 relative overflow-hidden group">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none"></div>

                    <div className="relative z-10 flex flex-col xl:flex-row xl:items-start justify-between gap-8">
                        <div className="flex-1">
                            <div className="flex items-center gap-4 mb-2">
                                <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">{patient.fullName}</h1>
                                {(user?.role === 'admin' || user?.role === 'super-admin') && (
                                    <button
                                        onClick={() => setShowAudit(!showAudit)}
                                        className="p-1.5 text-slate-400 hover:text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded-full transition-colors"
                                        title="Kayıt Geçmişi Bilgisi"
                                    >
                                        <Info size={18} />
                                    </button>
                                )}
                            </div>

                            {showAudit && (
                                <div className="mb-4 p-4 bg-slate-50/80 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-600 dark:text-slate-300 animate-in fade-in slide-in-from-top-1 backdrop-blur-sm">
                                    <div className="grid grid-cols-2 gap-x-8 gap-y-2">
                                        <div className="flex justify-between border-b border-slate-200 dark:border-slate-700 pb-1">
                                            <span className="font-bold text-slate-700 dark:text-slate-200">Oluşturan</span>
                                            <span className="font-mono">{patient.createdBy || "-"}</span>
                                        </div>
                                        <div className="flex justify-between border-b border-slate-200 dark:border-slate-700 pb-1">
                                            <span className="font-bold text-slate-700 dark:text-slate-200">Güncelleyen</span>
                                            <span className="font-mono">{patient.updatedBy || "-"}</span>
                                        </div>
                                        <div className="text-right text-slate-400 text-[10px] mt-1 col-span-2">
                                            {patient.createdAt ? format(parseISO(patient.createdAt), "dd.MM.yyyy HH:mm") : "-"}
                                        </div>
                                    </div>
                                </div>
                            )}

                            {patient.description && (
                                <div className="mb-4 p-3 bg-amber-50/50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-800/30 rounded-lg text-sm text-slate-600 dark:text-slate-300 italic flex items-start gap-2 max-w-2xl">
                                    <Info size={16} className="text-amber-500 mt-0.5 flex-shrink-0" />
                                    {patient.description}
                                </div>
                            )}

                            <div className="flex flex-wrap items-center gap-6 text-slate-500 dark:text-slate-400 mt-2 font-medium">
                                <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-100 dark:border-slate-700">
                                    <Phone size={16} className="text-indigo-500" />
                                    {formatPhoneNumber(patient.phone)}
                                </div>
                                {patient.age > 0 && (
                                    <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-100 dark:border-slate-700">
                                        <Calendar size={16} className="text-teal-500" />
                                        {patient.age} Yaş
                                    </div>
                                )}
                            </div>

                            {kvkkPending && (
                                <div className="mt-4 p-4 rounded-xl border border-amber-300 dark:border-amber-800 bg-amber-50 dark:bg-amber-900/20 text-amber-800 dark:text-amber-200 flex items-start gap-3 max-w-3xl">
                                    <AlertTriangle size={20} className="mt-0.5 flex-shrink-0" />
                                    <div>
                                        <div className="font-extrabold">KVKK Bekliyor</div>
                                        <div className="text-sm mt-1">
                                            Bu danışan eczane otomasyonundan otomatik aktarıldı. Ticari SMS, arama ve e-posta işlemleri; KVKK aydınlatması, açık rıza ve ilgili iletişim izni tamamlanana kadar engellenir.
                                        </div>
                                        <div className="text-xs font-semibold mt-2">
                                            {integrationMeta.importNote || "Eczane otomasyonundan aktarıldı"}
                                        </div>
                                    </div>
                                </div>
                            )}

                            <div className="mt-4 flex flex-wrap gap-2">
                                <div className={cn(
                                    "inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold border",
                                    kvkkConsent.dataProcessing
                                        ? "bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800"
                                        : "bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800"
                                )}>
                                    <Shield size={14} />
                                    {kvkkConsent.dataProcessing ? "KVKK izni kayıtlı" : "KVKK izni yok"}
                                </div>
                                {kvkkPending && <span className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-bold bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300 border border-amber-300 dark:border-amber-800">KVKK Bekliyor</span>}
                                {kvkkConsent.sms && <span className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-bold bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">SMS izinli</span>}
                                {kvkkConsent.phoneCall && <span className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-bold bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">Arama izinli</span>}
                                {kvkkConsent.email && <span className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-bold bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">E-posta izinli</span>}
                            </div>

                            {/* Invitations Badge */}
                            <div className="mt-4 flex flex-wrap gap-2">
                                {upcomingEvents.filter(e => e.invitations?.some(i => i.patientId === id)).map(e => (
                                    <div key={e.id} className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold bg-gradient-to-r from-indigo-500 to-purple-500 text-white shadow-md shadow-indigo-500/20">
                                        <CalendarPlus size={14} />
                                        {e.companyName} Davetlisi
                                        <span className="bg-white/20 w-px h-3 mx-1"></span>
                                        {e.date && !isNaN(new Date(e.date).getTime()) ? new Date(e.date).toLocaleDateString("tr-TR", { day: 'numeric', month: 'short' }) : ""}
                                    </div>
                                ))}
                            </div>
                        </div>

                        <div className="flex flex-wrap items-start gap-3 justify-end max-w-3xl">
                            {/* ANAMNESIS ACTIONS */}
                            <div className="flex flex-col gap-2">
                                <button
                                    onClick={() => setIsAnamnesisModalOpen(true)}
                                    className={cn(
                                        "flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-bold text-sm transition-all border w-52 shadow-sm",
                                        patient.detailedAnamnesis
                                            ? "bg-teal-50 dark:bg-teal-900/20 text-teal-700 dark:text-teal-400 border-teal-200 dark:border-teal-800 hover:bg-teal-100"
                                            : "bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-teal-300 dark:hover:border-teal-700"
                                    )}
                                >
                                    <Activity size={18} />
                                    Anamnez Formu
                                    {patient.detailedAnamnesis && <CheckCircle size={14} className="ml-1 text-teal-500" />}
                                </button>
                                <button
                                    onClick={() => setIsReportModalOpen(true)}
                                    disabled={!patient.detailedAnamnesis}
                                    className={cn(
                                        "px-4 py-2 rounded-xl font-bold text-xs flex items-center justify-center gap-2 w-52 transition-colors",
                                        patient.detailedAnamnesis
                                            ? "text-teal-600 dark:text-teal-400 hover:bg-teal-50 dark:hover:bg-teal-900/20 bg-transparent border border-transparent hover:border-teal-200"
                                            : "text-slate-300 dark:text-slate-600 cursor-not-allowed"
                                    )}
                                >
                                    <FileText size={14} />
                                    Raporu Görüntüle
                                </button>
                            </div>

                            {/* DERMO ACTIONS */}
                            <div className="flex flex-col gap-2">
                                <button
                                    onClick={() => setIsDermoAnamnesisModalOpen(true)}
                                    className={cn(
                                        "flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-bold text-sm transition-all border w-56 shadow-sm",
                                        patient.dermoAnamnesis
                                            ? "bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-400 border-purple-200 dark:border-purple-800 hover:bg-purple-100"
                                            : "bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-purple-300 dark:hover:border-purple-700"
                                    )}
                                >
                                    <Activity size={18} />
                                    Dermo Anamnez
                                    {patient.dermoAnamnesis && <CheckCircle size={14} className="ml-1 text-purple-500" />}
                                </button>
                                <button
                                    onClick={() => setIsDermoReportModalOpen(true)}
                                    disabled={!patient.dermoAnamnesis}
                                    className={cn(
                                        "px-4 py-2 rounded-xl font-bold text-xs flex items-center justify-center gap-2 w-56 transition-colors",
                                        patient.dermoAnamnesis
                                            ? "text-purple-600 dark:text-purple-400 hover:bg-purple-50 dark:hover:bg-purple-900/20 bg-transparent border border-transparent hover:border-purple-200"
                                            : "text-slate-300 dark:text-slate-600 cursor-not-allowed"
                                    )}
                                >
                                    <FileText size={14} />
                                    Dermo Raporu Görüntüle
                                </button>
                            </div>

                            {/* UTILS ACTIONS */}
                            <div className="flex flex-col gap-2">
                                <button
                                    onClick={() => openAttachmentModal('patient', patient.id)}
                                    className="bg-white dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 text-slate-600 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-400 border border-slate-200 dark:border-slate-700 hover:border-indigo-200 dark:hover:border-indigo-800 px-4 py-2.5 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 w-48 shadow-sm"
                                >
                                    <Paperclip size={18} />
                                    Dosya / Resim
                                </button>
                                <button
                                    onClick={openPatientEditModal}
                                    className="bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 px-4 py-2.5 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 w-48 shadow-sm"
                                >
                                    <Edit2 size={18} />
                                    Düzenle
                                </button>
                            </div>

                            {/* TRACKING ACTIONS */}
                            {/* TRACKING ACTIONS */}
                            <div className="flex flex-col gap-2">
                                <button
                                    onClick={() => {
                                        setFollowUpForm({ date: "", note: "", followUpCategories: [], isPharmacistFollowUp: false });
                                        setEditingFollowUpId(null);
                                        setIsFollowUpModalOpen(true);
                                    }}
                                    className="bg-orange-50 dark:bg-orange-900/20 hover:bg-orange-100 dark:hover:bg-orange-900/30 text-orange-700 dark:text-orange-400 border border-orange-200 dark:border-orange-800 hover:border-orange-300 px-4 py-2.5 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 w-48 shadow-sm"
                                >
                                    <Clock size={18} />
                                    Takip Et
                                </button>

                                <button
                                    onClick={() => setIsSkinCareModalOpen(true)}
                                    className="bg-teal-50 dark:bg-teal-900/20 hover:bg-teal-100 text-teal-700 dark:text-teal-400 border border-teal-200 dark:border-teal-800 px-4 py-2.5 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 w-48 shadow-sm relative group"
                                    title="Cilt Bakımı"
                                >
                                    <Shield size={18} />
                                    Cilt Bakımı
                                    {(() => {
                                        const txs = patient.skinCareData?.transactions || [];
                                        const calculatedRights = txs.reduce((acc, t) => {
                                            if (t.type === 'add_right') return acc + (parseInt(t.value) || 0);
                                            if (t.type === 'use_right') return acc - 1;
                                            return acc;
                                        }, 0);

                                        return calculatedRights > 0 && (
                                            <span className="absolute -top-2 -right-2 bg-teal-600 text-white text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full shadow-md z-10 animate-pulse">
                                                {calculatedRights}
                                            </span>
                                        );
                                    })()}
                                </button>

                                <div className="flex gap-2 w-48">
                                    <button
                                        onClick={handleOpenInviteModal}
                                        className="flex-1 bg-indigo-50 dark:bg-indigo-900/20 hover:bg-indigo-100 text-indigo-700 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800 px-2 py-2.5 rounded-xl font-bold text-[13px] transition-all flex items-center justify-center gap-1.5 shadow-sm"
                                        title="Etkinliğe Davet Et"
                                    >
                                        <CalendarPlus size={16} />
                                        Davet
                                    </button>
                                    <button
                                        onClick={() => setIsInterestModalOpen(true)}
                                        className="flex-1 bg-pink-50 dark:bg-pink-900/20 hover:bg-pink-100 text-pink-700 dark:text-pink-400 border border-pink-200 dark:border-pink-800 hover:border-pink-300 px-2 py-2.5 rounded-xl font-bold text-[13px] transition-all flex items-center justify-center gap-1.5 shadow-sm"
                                        title="Firma Takibi"
                                    >
                                        <Package size={16} />
                                        Firma
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    {renderAttachments(patient.attachments, 'patient', patient.id)}
                </div>

                <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-700">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Company Interests */}
                        <div>
                            <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-2">
                                <Package size={16} className="text-pink-500" />
                                İlgilendiği / Takip Ettiği Firmalar
                            </h4>
                            <div className="flex flex-wrap gap-2">
                                {patient.isDoNotCall ? (
                                    <span className="inline-flex items-center gap-1 px-3 py-1 rounded-md text-xs font-bold border bg-red-100 dark:bg-red-900/30 border-red-300 dark:border-red-800 text-red-600 dark:text-red-400 whitespace-nowrap">
                                        <Ban size={12} />
                                        BİRDAHA ARANMAYACAK
                                    </span>
                                ) : (
                                    patient.interestedCompanies && patient.interestedCompanies.length > 0 ? (
                                        <>
                                            {patient.interestedCompanies.some(id => String(id) === REPORT_PATIENTS_GROUP_ID) && (
                                                <span
                                                    className="px-3 py-1 rounded-full text-xs font-medium border bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-400 flex items-center gap-1"
                                                >
                                                    <FileText size={12} />
                                                    {REPORT_PATIENTS_GROUP_LABEL}
                                                </span>
                                            )}
                                            {companies.filter(c => patient.interestedCompanies.includes(c.id)).map(comp => (
                                                <span
                                                    key={comp.id}
                                                    className="px-3 py-1 rounded-full text-xs font-medium border bg-pink-50 dark:bg-pink-900/20 border-pink-200 dark:border-pink-800 text-pink-700 dark:text-pink-400 flex items-center gap-1"
                                                >
                                                    <Check size={12} />
                                                    {comp.name}
                                                </span>
                                            ))}
                                        </>
                                    ) : (
                                        <span className="text-xs text-slate-400">Henüz firma takibi eklenmemiş.</span>
                                    )
                                )}
                            </div>
                        </div>

                        {/* Active Follow-ups */}
                        <div>
                            <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-2">
                                <Clock size={16} className="text-orange-500" />
                                Aktif Takipler / Hatırlatmalar
                            </h4>
                            <div className="flex flex-col gap-2">
                                {patient.followUps && patient.followUps.length > 0 ? (
                                    patient.followUps.map(fu => (
                                        <div key={fu.id} className="flex items-start justify-between bg-orange-50 dark:bg-orange-900/20 border border-orange-100 dark:border-orange-900/30 p-2 rounded-lg text-sm">
                                            <div>
                                                <div className="font-semibold text-orange-800 dark:text-orange-300 flex items-center gap-2">
                                                    {(() => {
                                                        try {
                                                            return fu.date ? format(parseISO(fu.date), "d MMMM yyyy", { locale: tr }) : "";
                                                        } catch { return ""; }
                                                    })()}
                                                    {(() => {
                                                        try {
                                                            return fu.date && differenceInDays(parseISO(fu.date), new Date()) < 0;
                                                        } catch { return false; }
                                                    })() && <span className="text-xs bg-red-100 text-red-600 px-1 rounded">Geçmiş</span>}
                                                    {fu.isPharmacistFollowUp && <span className="text-[10px] bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 px-1.5 py-0.5 rounded-full font-bold border border-purple-200 dark:border-purple-800">Eczacının Takibinde</span>}
                                                </div>
                                                <p className="text-orange-700 dark:text-orange-300/80 mt-1">{fu.note}</p>
                                            </div>
                                            <div className="flex items-center gap-1">
                                                <button
                                                    onClick={() => {
                                                        setVisitForm({ ...visitForm, type: "Arama" });
                                                        setFollowUpToConvert(fu.id);
                                                        setIsVisitModalOpen(true);
                                                    }}
                                                    className="text-teal-500 hover:text-teal-700 p-1 hover:bg-teal-50 dark:hover:bg-teal-900/30 rounded"
                                                    title="Arandı / İşlem Yapıldı"
                                                >
                                                    <Phone size={14} />
                                                </button>
                                                <button
                                                    onClick={() => {
                                                        setFollowUpForm({
                                                            date: fu.date.split('T')[0],
                                                            note: fu.note,
                                                            followUpCategories: Array.isArray(fu.followUpCategories) ? fu.followUpCategories : [],
                                                            isPharmacistFollowUp: fu.isPharmacistFollowUp || false
                                                        });
                                                        setEditingFollowUpId(fu.id);
                                                        setIsFollowUpModalOpen(true);
                                                    }}
                                                    className="text-slate-400 hover:text-indigo-500 p-1 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded"
                                                    title="Düzenle"
                                                >
                                                    <Edit2 size={14} />
                                                </button>
                                                <button
                                                    onClick={async () => {
                                                        if (window.confirm("Bu takibi silmek istediğinize emin misiniz?")) {
                                                            const updated = await DataService.removeFollowUp(patient.id, fu.id);
                                                            setPatient({ ...updated });
                                                        }
                                                    }}
                                                    className="text-orange-400 hover:text-red-500 p-1 hover:bg-red-50 dark:hover:bg-red-900/30 rounded"
                                                >
                                                    <X size={14} />
                                                </button>
                                            </div>
                                        </div>
                                    ))
                                ) : (
                                    <span className="text-xs text-slate-400">Aktif takip bulunmuyor.</span>
                                )}
                            </div>
                        </div>
                    </div>
                </div>

                {/* DETAILED ANAMNESIS SUMMARY CARD */}
                {patient.detailedAnamnesis && typeof patient.detailedAnamnesis === 'object' && (
                    <div className="mt-8 mb-12 relative overflow-hidden rounded-2xl border border-teal-100 dark:border-teal-900 bg-teal-50/30 dark:bg-teal-900/10 p-6">
                        <div className="absolute top-0 right-0 p-24 bg-teal-500/5 rounded-full blur-3xl -mr-12 -mt-12 pointer-events-none"></div>

                        <h4 className="text-lg font-bold text-slate-800 dark:text-slate-200 mb-6 flex items-center gap-3">
                            <div className="p-2 bg-teal-100 dark:bg-teal-900/30 rounded-lg text-teal-600 dark:text-teal-400">
                                <Activity size={20} />
                            </div>
                            Detaylı Anamnez Özeti
                        </h4>

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 relative z-10">
                            <div className="bg-white/60 dark:bg-slate-800/60 backdrop-blur-sm p-4 rounded-xl border border-white/50 dark:border-slate-700 shadow-sm hover:shadow-md transition-shadow">
                                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider block mb-2">Vücut Kitle İndeksi</span>
                                <div className="flex items-center gap-3">
                                    <Scale className="text-indigo-500" size={24} />
                                    <div>
                                        <span className="text-2xl font-black text-slate-800 dark:text-slate-200">{patient.detailedAnamnesis.bmi || "--"}</span>
                                        <span className="text-xs text-slate-400 block ml-0.5">({patient.detailedAnamnesis.height}cm / {patient.detailedAnamnesis.weight}kg)</span>
                                    </div>
                                </div>
                            </div>
                            <div className="bg-white/60 dark:bg-slate-800/60 backdrop-blur-sm p-4 rounded-xl border border-white/50 dark:border-slate-700 shadow-sm hover:shadow-md transition-shadow">
                                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider block mb-2">Alışkanlıklar</span>
                                <div className="flex gap-4 mt-2">
                                    <div className={cn("flex flex-col items-center gap-1 text-sm font-medium p-2 rounded-lg transition-colors w-16", patient.detailedAnamnesis.smoking ? "bg-red-50 text-red-600 dark:bg-red-900/20 dark:text-red-400" : "bg-slate-50 text-slate-400 dark:bg-slate-800 dark:text-slate-600 grayscale")}>
                                        <Cigarette size={20} />
                                        <span className="text-[10px]">Sigara</span>
                                    </div>
                                    <div className={cn("flex flex-col items-center gap-1 text-sm font-medium p-2 rounded-lg transition-colors w-16", patient.detailedAnamnesis.alcohol ? "bg-amber-50 text-amber-600 dark:bg-amber-900/20 dark:text-amber-400" : "bg-slate-50 text-slate-400 dark:bg-slate-800 dark:text-slate-600 grayscale")}>
                                        <Wine size={20} />
                                        <span className="text-[10px]">Alkol</span>
                                    </div>
                                </div>
                            </div>
                            {(patient.detailedAnamnesis.activeMedicines || patient.detailedAnamnesis.chronicDiseases) && (
                                <div className="bg-white/60 dark:bg-slate-800/60 backdrop-blur-sm p-4 rounded-xl border border-white/50 dark:border-slate-700 shadow-sm hover:shadow-md transition-shadow md:col-span-2">
                                    <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider block mb-3">Önemli Tıbbi Notlar</span>
                                    <div className="space-y-3">
                                        <div className="flex items-start gap-2 text-sm text-slate-700 dark:text-slate-300">
                                            <div className="mt-0.5 min-w-[60px] font-bold text-red-500">Kronik:</div>
                                            <div className="bg-red-50 dark:bg-red-900/10 px-2 py-0.5 rounded text-red-800 dark:text-red-300 w-full">
                                                {patient.detailedAnamnesis.chronicDiseases || "Yok"}
                                            </div>
                                        </div>
                                        <div className="flex items-start gap-2 text-sm text-slate-700 dark:text-slate-300">
                                            <div className="mt-0.5 min-w-[60px] font-bold text-blue-500">İlaçlar:</div>
                                            <div className="bg-blue-50 dark:bg-blue-900/10 px-2 py-0.5 rounded text-blue-800 dark:text-blue-300 w-full">
                                                {patient.detailedAnamnesis.activeMedicines || "Yok"}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {/* Visits / Panels Stream */}
                <div className="relative space-y-12">
                    {/* Vertical Line */}
                    <div className="absolute left-8 top-4 bottom-0 w-0.5 bg-gradient-to-b from-teal-500 via-teal-200 to-transparent dark:from-teal-700 dark:via-teal-900 dark:to-transparent -z-10 hidden md:block"></div>

                    {
                        visits.length > 0 ? (
                            visits.map((visit, index) => (
                                <div key={visit.id} className="relative md:pl-24 animate-in fade-in slide-in-from-bottom-8 duration-700" style={{ animationDelay: `${index * 100}ms` }}>
                                    {/* Timeline Dot & Date Badge (Desktop) */}
                                    <div className="absolute left-0 top-0 hidden md:flex flex-col items-center">
                                        <div className="w-16 h-16 rounded-2xl bg-white dark:bg-slate-800 border-2 border-teal-500 shadow-lg shadow-teal-500/20 flex flex-col items-center justify-center z-10 font-bold text-slate-800 dark:text-white leading-tight">
                                            <span className="text-2xl">{visit.date ? new Date(visit.date).getDate() : "-"}</span>
                                            <span className="text-[10px] uppercase text-teal-600 dark:text-teal-400">{visit.date ? new Date(visit.date).toLocaleDateString("tr-TR", { month: 'short' }) : ""}</span>
                                        </div>
                                        <div className="text-[10px] text-slate-400 mt-2 font-mono">{visit.date ? new Date(visit.date).getFullYear() : ""}</div>
                                    </div>

                                    {/* Panel Card - Improved Glass */}
                                    <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-xl shadow-slate-200/50 dark:shadow-black/20 overflow-hidden group transition-all hover:shadow-2xl hover:border-teal-200 dark:hover:border-teal-800">
                                        {/* Panel Header */}
                                        <div className="px-6 py-5 bg-gradient-to-r from-slate-50 to-white dark:from-slate-800 dark:to-slate-800/50 border-b border-slate-100 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                                            <div className="flex items-center gap-4">
                                                {/* Mobile Date Badge */}
                                                <div className="md:hidden flex flex-col items-center justify-center w-12 h-12 rounded-xl bg-teal-50 dark:bg-teal-900/20 text-teal-700 dark:text-teal-300 font-bold border border-teal-100 dark:border-teal-800">
                                                    <span className="text-lg">{visit.date ? new Date(visit.date).getDate() : "-"}</span>
                                                    <span className="text-[9px] uppercase">{visit.date ? new Date(visit.date).toLocaleDateString("tr-TR", { month: 'short' }) : ""}</span>
                                                </div>

                                                <div>
                                                    <div className="flex items-center gap-2">
                                                        <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                                                            {visit.type || "Ziyaret"}
                                                        </h3>
                                                        <div className="relative group/date">
                                                            <button className="p-1 text-slate-400 hover:text-teal-600 transition-colors">
                                                                <Edit2 size={12} />
                                                            </button>
                                                            <input
                                                                type="date"
                                                                className="absolute inset-0 opacity-0 cursor-pointer"
                                                                value={(() => {
                                                                    try {
                                                                        return visit.date ? format(parseISO(visit.date), 'yyyy-MM-dd') : "";
                                                                    } catch { return ""; }
                                                                })()}
                                                                onChange={(e) => handleQuickDateUpdate(visit.id, e.target.value)}
                                                                onClick={(e) => e.stopPropagation()}
                                                            />
                                                        </div>
                                                    </div>
                                                    <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1">
                                                        <Clock size={12} />
                                                        {visit.date ? format(parseISO(visit.date), "EEEE", { locale: tr }) : ""}
                                                    </p>
                                                </div>
                                            </div>

                                            <div className="flex items-center gap-2">
                                                <button
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        openAddProductModal(visit.id);
                                                    }}
                                                    className="bg-indigo-600 text-white hover:bg-indigo-700 px-4 py-2 rounded-xl text-sm font-bold transition-all shadow-md shadow-indigo-200 dark:shadow-none flex items-center gap-2"
                                                >
                                                    <Package size={16} />
                                                    <span className="hidden sm:inline">Ürün Ekle</span>
                                                </button>

                                                <div className="bg-slate-100 dark:bg-slate-700 h-8 w-px mx-1"></div>

                                                <button
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        handleOpenVisitModal(visit, "note");
                                                    }}
                                                    className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                                                    title="Notları Düzenle"
                                                >
                                                    <FileText size={18} />
                                                </button>
                                                <button
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        openAttachmentModal('visit', visit.id);
                                                    }}
                                                    className="p-2 text-slate-500 hover:text-purple-600 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                                                    title="Dosya / Resim Ekle"
                                                >
                                                    <Paperclip size={18} />
                                                </button>
                                                <button
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        handleDeleteVisit(visit.id);
                                                    }}
                                                    className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                                                    title="Paneli Sil"
                                                >
                                                    <Trash2 size={18} />
                                                </button>
                                            </div>
                                        </div>

                                        {/* Panel Content */}
                                        <div className="p-6 sm:p-8 space-y-8">

                                            {/* Attachments */}
                                            {renderAttachments(visit.attachments, 'visit', visit.id)}

                                            {/* Notes Section */}
                                            {visit.note && (
                                                <div className="relative pl-6 border-l-4 border-amber-300 dark:border-amber-600 bg-amber-50/50 dark:bg-amber-900/10 p-4 rounded-r-xl">
                                                    <div className="absolute -left-2.5 top-4 bg-white dark:bg-slate-800 rounded-full p-1 border border-amber-300 dark:border-amber-600">
                                                        <Info size={12} className="text-amber-500" />
                                                    </div>
                                                    <h5 className="text-xs font-bold text-amber-700 dark:text-amber-500 uppercase tracking-widest mb-2">Seans Notları / Anamnez</h5>
                                                    <p className="text-slate-700 dark:text-slate-300 text-sm leading-relaxed whitespace-pre-wrap">
                                                        {visit.note}
                                                    </p>
                                                </div>
                                            )}

                                            {/* Products Section */}
                                            <div>
                                                {(() => {
                                                    const givenProducts = visit.products?.filter(p => p && (!p.type || p.type === 'given')) || [];
                                                    const recommendedProducts = visit.products?.filter(p => p && p.type === 'recommended') || [];

                                                    const renderProductItem = (product, isRecommended = false) => (
                                                        <div key={product.id} className={cn(
                                                            "group relative flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl border transition-all duration-300",
                                                            isRecommended
                                                                ? "bg-amber-50/40 dark:bg-amber-900/5 border-amber-100 dark:border-amber-900/30 hover:bg-amber-50 dark:hover:bg-amber-900/10 hover:border-amber-200"
                                                                : "bg-teal-50/20 dark:bg-teal-900/5 border-teal-100 dark:border-teal-900/30 hover:bg-teal-50/50 dark:hover:bg-teal-900/10 hover:border-teal-200"
                                                        )}>
                                                            <div className="flex items-start gap-4">
                                                                <div className={cn(
                                                                    "p-3 rounded-xl shadow-sm",
                                                                    isRecommended ? "bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400" : "bg-teal-100 dark:bg-teal-900/30 text-teal-600 dark:text-teal-400"
                                                                )}>
                                                                    <Package size={20} />
                                                                </div>
                                                                <div>
                                                                    <div className="font-bold text-slate-800 dark:text-slate-100 text-base">{product.productName}</div>
                                                                    <div className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                                                                        {product.notes ? (
                                                                            <span className="italic flex items-center gap-1">
                                                                                <Info size={12} />
                                                                                {product.notes}
                                                                            </span>
                                                                        ) : <span className="opacity-50 text-xs">Not yok</span>}
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div className="flex items-center gap-2 self-end sm:self-center opacity-0 group-hover:opacity-100 transition-opacity bg-white dark:bg-slate-800 shadow-md rounded-lg p-1 border border-slate-100 dark:border-slate-700 absolute right-4 top-4 sm:static sm:bg-transparent sm:shadow-none sm:border-0">
                                                                <button
                                                                    onClick={(e) => {
                                                                        e.stopPropagation();
                                                                        handleToggleProductType(visit.id, product);
                                                                    }}
                                                                    className={cn(
                                                                        "p-2 rounded-lg transition-colors",
                                                                        isRecommended ? "text-teal-400 hover:text-teal-600 hover:bg-teal-50" : "text-amber-400 hover:text-amber-600 hover:bg-amber-50"
                                                                    )}
                                                                    title={isRecommended ? "Verilenlere Taşı" : "Önerilenlere Taşı"}
                                                                >
                                                                    <Repeat size={16} />
                                                                </button>
                                                                <button
                                                                    onClick={(e) => {
                                                                        e.stopPropagation();
                                                                        handleEditProductClick(visit.id, product);
                                                                    }}
                                                                    className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                                                                    title="Düzenle"
                                                                >
                                                                    <Edit2 size={16} />
                                                                </button>
                                                                <button
                                                                    onClick={(e) => {
                                                                        e.stopPropagation();
                                                                        handleRemoveProduct(visit.id, product.id);
                                                                    }}
                                                                    className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                                                                    title="Sil"
                                                                >
                                                                    <Trash2 size={16} />
                                                                </button>
                                                            </div>
                                                        </div>
                                                    );

                                                    if (givenProducts.length === 0 && recommendedProducts.length === 0) {
                                                        return (
                                                            <div className="flex flex-col items-center justify-center py-12 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-2xl bg-slate-50/50 dark:bg-slate-900/50 text-slate-400">
                                                                <Package size={32} className="mb-2 opacity-50" />
                                                                <p className="text-sm font-medium">Bu ziyarette henüz ürün kaydı yok.</p>
                                                                <button
                                                                    onClick={() => openAddProductModal(visit.id)}
                                                                    className="mt-4 text-indigo-600 hover:underline text-sm font-semibold"
                                                                >
                                                                    Şimdi Ekle
                                                                </button>
                                                            </div>
                                                        );
                                                    }

                                                    return (
                                                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                                            {/* Given Products Column */}
                                                            <div className="space-y-4">
                                                                <div className="flex items-center gap-2 pb-2 border-b border-teal-100 dark:border-teal-900/30">
                                                                    <div className="w-2 h-2 rounded-full bg-teal-500"></div>
                                                                    <h5 className="text-sm font-bold text-teal-700 dark:text-teal-400 uppercase tracking-widest">Verilen Ürünler</h5>
                                                                </div>
                                                                <div className="space-y-3">
                                                                    {givenProducts.length > 0 ? (
                                                                        givenProducts.map(p => renderProductItem(p, false))
                                                                    ) : (
                                                                        <div className="text-sm text-slate-400 italic py-2">Verilen ürün yok.</div>
                                                                    )}
                                                                </div>
                                                            </div>

                                                            {/* Recommended Products Column */}
                                                            <div className="space-y-4">
                                                                <div className="flex items-center gap-2 pb-2 border-b border-amber-100 dark:border-amber-900/30">
                                                                    <div className="w-2 h-2 rounded-full bg-amber-500"></div>
                                                                    <h5 className="text-sm font-bold text-amber-700 dark:text-amber-400 uppercase tracking-widest">Önerilen Ürünler</h5>
                                                                </div>
                                                                <div className="space-y-3">
                                                                    {recommendedProducts.length > 0 ? (
                                                                        recommendedProducts.map(p => renderProductItem(p, true))
                                                                    ) : (
                                                                        <div className="text-sm text-slate-400 italic py-2">Önerilen ürün yok.</div>
                                                                    )}
                                                                </div>
                                                            </div>
                                                        </div>
                                                    );
                                                })()}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))
                        ) : (
                            <div className="flex flex-col items-center justify-center py-20 text-slate-400 dark:text-slate-500">
                                <div className="w-24 h-24 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mb-4">
                                    <Activity size={40} className="opacity-50" />
                                </div>
                                <h3 className="text-xl font-bold text-slate-600 dark:text-slate-300">Henüz Kayıt Yok</h3>
                                <p className="max-w-xs text-center mt-2">Bu danışan için henüz bir ziyaret veya işlem kaydı oluşturulmamış.</p>
                                <button
                                    onClick={() => handleOpenVisitModal(null, "full")}
                                    className="mt-6 bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-xl font-bold shadow-lg shadow-indigo-500/20 transition-all"
                                >
                                    İlk Kaydı Oluştur
                                </button>
                            </div>
                        )
                    }
                </div >

                {/* NEW PANEL (VISIT) MODAL */}
                {
                    isVisitModalOpen && (
                        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-300">
                            <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border border-white/20 dark:border-slate-700 animate-in zoom-in-95 duration-200">
                                <div className="px-6 py-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 flex justify-between items-center">
                                    <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                        <Edit2 size={20} className="text-indigo-500" />
                                        {editMode === "date" ? "Tarihi Değiştir" : (editMode === "note" ? "Notları Düzenle" : (editingVisitId ? "Paneli Düzenle" : "Yeni Panel (Ziyaret)"))}
                                    </h3>
                                    <button
                                        onClick={() => setIsVisitModalOpen(false)}
                                        className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
                                    >
                                        <X size={20} />
                                    </button>
                                </div>
                                <form onSubmit={handleSaveVisit} className="p-6 space-y-5">
                                    <div className="grid grid-cols-1 gap-5">
                                        {editMode !== "note" && (
                                            <div>
                                                <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Tarih</label>
                                                <div className="relative">
                                                    <input
                                                        required
                                                        type="date"
                                                        className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-indigo-500 focus:border-indigo-500 shadow-sm"
                                                        value={visitForm.date}
                                                        onChange={e => setVisitForm({ ...visitForm, date: e.target.value })}
                                                    />
                                                    <Calendar className="absolute right-4 top-3.5 text-slate-400 pointer-events-none" size={20} />
                                                </div>
                                            </div>
                                        )}
                                    </div>

                                    {/* Type Selection Warning */}
                                    {visitForm.type === 'Arama' && (
                                        <div className="p-4 bg-sky-50 dark:bg-sky-900/20 border border-sky-100 dark:border-sky-800/50 rounded-xl text-sky-700 dark:text-sky-400 text-sm flex items-center gap-3">
                                            <div className="p-2 bg-sky-100 dark:bg-sky-900/40 rounded-lg text-sky-600 dark:text-sky-300">
                                                <PhoneOutgoing size={20} />
                                            </div>
                                            <span>Bu kayıt <strong>Arama / Görüşme</strong> olarak eklenecektir.</span>
                                        </div>
                                    )}

                                    {editMode !== "date" && (
                                        <div>
                                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">
                                                Ziyaret Notları / Anamnez
                                                <span className="font-normal text-slate-400 text-xs ml-2">(Opsiyonel)</span>
                                            </label>
                                            <div className="relative">
                                                <textarea
                                                    rows={5}
                                                    className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-indigo-500 focus:border-indigo-500 pr-10 shadow-sm resize-none"
                                                    placeholder="Danışan şikayeti, gözlemler, yapılan işlemler hakkında detaylar..."
                                                    value={visitForm.note}
                                                    onChange={e => setVisitForm({ ...visitForm, note: e.target.value })}
                                                />
                                                {visitForm.note && (
                                                    <button
                                                        type="button"
                                                        onClick={() => setVisitForm({ ...visitForm, note: "" })}
                                                        className="absolute top-3 right-3 text-slate-400 hover:text-red-500 p-1.5 bg-slate-50 dark:bg-slate-700 rounded-full hover:bg-red-50 dark:hover:bg-red-900/30 transition-colors"
                                                        title="Temizle"
                                                    >
                                                        <X size={14} />
                                                    </button>
                                                )}
                                            </div>
                                        </div>
                                    )}

                                    <div className="pt-4 flex justify-end gap-3 border-t border-slate-100 dark:border-slate-800 mt-2">
                                        <button
                                            type="button"
                                            onClick={() => setIsVisitModalOpen(false)}
                                            className="px-5 py-2.5 text-slate-700 dark:text-slate-300 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
                                        >
                                            İptal
                                        </button>
                                        <button
                                            type="submit"
                                            className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold shadow-lg shadow-indigo-500/30 transition-transform hover:scale-[1.02] active:scale-[0.98]"
                                        >
                                            {editingVisitId ? "Değişiklikleri Kaydet" : "Paneli Oluştur"}
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    )
                }

                {/* ADD PRODUCT MODAL */}
                {
                    isProductModalOpen && (
                        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-300">
                            <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border border-white/20 dark:border-slate-700 animate-in zoom-in-95 duration-200 max-h-[90vh] flex flex-col">
                                <div className="px-6 py-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 flex justify-between items-center flex-shrink-0">
                                    <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                        <Package size={20} className="text-teal-500" />
                                        Ürün Ekle
                                    </h3>
                                    <button
                                        onClick={() => setIsProductModalOpen(false)}
                                        className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
                                    >
                                        <X size={20} />
                                    </button>
                                </div>

                                <div className="p-6 overflow-y-auto flex-1 custom-scrollbar">
                                    <form id="add-product-form" onSubmit={handleAddProduct} className="space-y-5">

                                        {/* Product Selection Autocomplete */}
                                        <div className="relative" ref={dropdownRef}>
                                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Ürün Seçimi</label>
                                            <div className="relative group">
                                                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                    <Search size={18} className="text-slate-400 group-focus-within:text-teal-500 transition-colors" />
                                                </div>
                                                <textarea
                                                    ref={productInputRef}
                                                    rows={searchTerm.includes('\n') ? 6 : 1}
                                                    className={cn(
                                                        "w-full pl-10 pr-10 rounded-xl border px-3 py-3 text-slate-900 dark:text-white bg-white dark:bg-slate-800 focus:ring-teal-500 focus:border-teal-500 resize-none shadow-sm transition-all",
                                                        selectedProduct || (searchTerm.includes('\n') && bulkMatches.some(m => m.product)) ? "border-teal-500 bg-teal-50/10 dark:bg-teal-900/20 ring-1 ring-teal-500/20" : "border-slate-300 dark:border-slate-600"
                                                    )}
                                                    placeholder="Ürün adı veya barkod... (Çoklu giriş için liste yapıştırın)"
                                                    value={searchTerm}
                                                    onChange={e => {
                                                        const val = e.target.value;
                                                        setSearchTerm(val);
                                                        setIsDropdownOpen(true);
                                                        setSelectedProduct(null);

                                                        // Bulk Detection
                                                        if (val.includes('\n')) {
                                                            const lines = val.split('\n').filter(l => l.trim().length > 0);
                                                            const matches = lines.map(line => {
                                                                const cleanLine = normalizeString(line);
                                                                // Exact barcode match first
                                                                let found = dbProducts.find(p => p.barcode === line.trim());
                                                                // Then exact name
                                                                if (!found) found = dbProducts.find(p => normalizeString(p.productName) === cleanLine);
                                                                // Then fuzzy name (contains)
                                                                if (!found) found = dbProducts.find(p => normalizeString(p.productName).includes(cleanLine));
                                                                return { line: line.trim(), product: found || null };
                                                            });
                                                            setBulkMatches(matches);
                                                        } else {
                                                            setBulkMatches([]);
                                                        }
                                                    }}
                                                    onFocus={() => setIsDropdownOpen(true)}
                                                />
                                                {searchTerm && (
                                                    <button
                                                        type="button"
                                                        onClick={() => {
                                                            setSearchTerm("");
                                                            setSelectedProduct(null);
                                                        }}
                                                        className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
                                                    >
                                                        <X size={16} />
                                                    </button>
                                                )}
                                            </div>

                                            {/* Bulk Match Results UI */}
                                            {bulkMatches.length > 0 && searchTerm.includes('\n') ? (
                                                <div className="mt-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden max-h-60 overflow-y-auto custom-scrollbar">
                                                    <div className="px-4 py-2 border-b border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-700/50 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase flex justify-between sticky top-0 backdrop-blur-sm">
                                                        <span>Bulunanlar ({bulkMatches.filter(m => m.product).length})</span>
                                                        <span>Bulunamayanlar ({bulkMatches.filter(m => !m.product).length})</span>
                                                    </div>
                                                    <div className="divide-y divide-slate-100 dark:divide-slate-700/50">
                                                        {bulkMatches.map((match, idx) => (
                                                            <div key={idx} className="px-4 py-2.5 text-sm flex items-center justify-between hover:bg-white dark:hover:bg-slate-700/50 transition-colors">
                                                                <span className={cn("truncate max-w-[50%] font-medium", match.product ? "text-slate-700 dark:text-slate-300" : "text-red-500 line-through opacity-70")}>
                                                                    {match.line}
                                                                </span>
                                                                {match.product ? (
                                                                    <span className="flex items-center gap-1.5 text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-900/30 px-2.5 py-1 rounded-full text-xs font-bold truncate max-w-[45%] border border-teal-100 dark:border-teal-800">
                                                                        <Check size={12} strokeWidth={3} />
                                                                        {match.product.productName}
                                                                    </span>
                                                                ) : (
                                                                    <span className="text-red-500 text-xs font-bold italic flex items-center gap-1">
                                                                        <X size={12} /> Eşleşmedi
                                                                    </span>
                                                                )}
                                                            </div>
                                                        ))}
                                                    </div>
                                                </div>
                                            ) : (
                                                /* Single Search UI - Dropdown */
                                                <div className="relative">
                                                    {/* Dropdown List */}
                                                    {isDropdownOpen && searchTerm && !selectedProduct && (
                                                        <div className="absolute z-50 mt-2 w-full bg-white dark:bg-slate-800 shadow-2xl max-h-72 rounded-xl py-2 text-sm border border-slate-100 dark:border-slate-700 overflow-auto focus:outline-none custom-scrollbar animate-in fade-in zoom-in-95 duration-100">
                                                            {filteredProducts.length > 0 ? (
                                                                filteredProducts.map((product) => (
                                                                    <div
                                                                        key={product.id}
                                                                        className="cursor-pointer select-none relative py-3 pl-4 pr-4 hover:bg-teal-50 dark:hover:bg-teal-900/20 transition-colors group border-b border-slate-50 dark:border-slate-700/50 last:border-0"
                                                                        onClick={() => handleSelectProduct(product)}
                                                                    >
                                                                        <div className="flex flex-col gap-0.5">
                                                                            <span className="font-bold text-slate-800 dark:text-slate-200 group-hover:text-teal-700 dark:group-hover:text-teal-300 transition-colors">{product.productName}</span>
                                                                            <div className="flex items-center justify-between">
                                                                                <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">{product.companyName}</span>
                                                                                <span className="text-[10px] font-mono bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-1.5 py-0.5 rounded opacity-70 group-hover:opacity-100 transition-opacity">{product.barcode}</span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                ))
                                                            ) : (
                                                                <div className="py-8 px-4 text-center">
                                                                    <div className="w-12 h-12 bg-slate-50 dark:bg-slate-700 rounded-full flex items-center justify-center mx-auto mb-2 text-slate-400">
                                                                        <Search size={20} />
                                                                    </div>
                                                                    <p className="text-slate-500 dark:text-slate-400 font-medium">Ürün bulunamadı.</p>
                                                                    <p className="text-xs text-slate-400 mt-1">Lütfen yazımı kontrol edin veya veritabanına ekleyin.</p>
                                                                </div>
                                                            )}
                                                        </div>
                                                    )}
                                                </div>
                                            )}
                                        </div>

                                        <div>
                                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Ürün Durumu</label>
                                            <div className="grid grid-cols-2 gap-3 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                                                <button
                                                    type="button"
                                                    onClick={() => setProductForm({ ...productForm, type: 'given' })}
                                                    className={cn(
                                                        "py-2.5 text-sm font-bold rounded-lg transition-all flex items-center justify-center gap-2",
                                                        productForm.type === 'given'
                                                            ? "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-400 shadow-sm ring-1 ring-slate-200 dark:ring-slate-600"
                                                            : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300 hover:bg-white/50"
                                                    )}
                                                >
                                                    <div className={cn("w-2 h-2 rounded-full", productForm.type === 'given' ? "bg-teal-500" : "bg-slate-300 dark:bg-slate-600")}></div>
                                                    Verilen Ürün
                                                </button>
                                                <button
                                                    type="button"
                                                    onClick={() => setProductForm({ ...productForm, type: 'recommended' })}
                                                    className={cn(
                                                        "py-2.5 text-sm font-bold rounded-lg transition-all flex items-center justify-center gap-2",
                                                        productForm.type === 'recommended'
                                                            ? "bg-white dark:bg-slate-700 text-amber-600 dark:text-amber-400 shadow-sm ring-1 ring-slate-200 dark:ring-slate-600"
                                                            : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300 hover:bg-white/50"
                                                    )}
                                                >
                                                    <div className={cn("w-2 h-2 rounded-full", productForm.type === 'recommended' ? "bg-amber-500" : "bg-slate-300 dark:bg-slate-600")}></div>
                                                    Önerilen Ürün
                                                </button>
                                            </div>
                                        </div>

                                        <div>
                                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">
                                                Özel Notlar
                                                <span className="font-normal text-slate-400 text-xs ml-2">(Kullanım talimatı vb.)</span>
                                            </label>
                                            <div className="relative">
                                                <textarea
                                                    rows={2}
                                                    className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-teal-500 focus:border-teal-500 pr-10 shadow-sm resize-none"
                                                    placeholder="Örn: Sabah akşam tok karna..."
                                                    value={productForm.notes}
                                                    onChange={e => setProductForm({ ...productForm, notes: e.target.value })}
                                                />
                                                {productForm.notes && (
                                                    <button
                                                        type="button"
                                                        onClick={() => setProductForm({ ...productForm, notes: "" })}
                                                        className="absolute top-3 right-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 p-1.5 bg-slate-50 dark:bg-slate-700 rounded-full hover:bg-slate-100 dark:hover:bg-slate-600 transition-colors"
                                                        title="Temizle"
                                                    >
                                                        <X size={14} />
                                                    </button>
                                                )}
                                            </div>
                                        </div>

                                    </form>
                                </div>

                                <div className="px-6 py-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 flex justify-end gap-3 flex-shrink-0">
                                    <button
                                        type="button"
                                        onClick={() => setIsProductModalOpen(false)}
                                        className="px-5 py-2.5 text-slate-700 dark:text-slate-300 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
                                    >
                                        İptal
                                    </button>
                                    <button
                                        type="submit"
                                        form="add-product-form"
                                        disabled={(!selectedProduct && bulkMatches.filter(m => m.product).length === 0)}
                                        className={cn(
                                            "px-6 py-2.5 text-white font-bold rounded-xl transition-all shadow-lg active:scale-95",
                                            (selectedProduct || bulkMatches.filter(m => m.product).length > 0)
                                                ? "bg-teal-600 hover:bg-teal-700 shadow-teal-500/30 hover:shadow-teal-500/40"
                                                : "bg-slate-300 dark:bg-slate-700 cursor-not-allowed shadow-none"
                                        )}
                                    >
                                        {bulkMatches.length > 0 && searchTerm.includes('\n')
                                            ? `${bulkMatches.filter(m => m.product).length} Ürünü Ekle`
                                            : "Ürünü Ekle"}
                                    </button>
                                </div>
                            </div>
                        </div>
                    )
                }

                {/* EDIT PRODUCT MODAL (FULL EDIT) */}
                {
                    isProductEditModalOpen && (
                        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-300">
                            <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border border-white/20 dark:border-slate-700 animate-in zoom-in-95 duration-200">
                                <div className="px-6 py-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 flex justify-between items-center">
                                    <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                        <Edit2 size={20} className="text-indigo-500" />
                                        Ürünü Düzenle
                                    </h3>
                                    <button onClick={() => setIsProductEditModalOpen(false)} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors">
                                        <X size={20} />
                                    </button>
                                </div>
                                <form onSubmit={handleUpdateProductFull} className="p-6 space-y-5">

                                    {/* Product Selection (Autocomplete) */}
                                    <div className="relative">
                                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Ürün</label>
                                        <div className="relative group">
                                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                <Search size={18} className="text-slate-400 group-focus-within:text-teal-500 transition-colors" />
                                            </div>
                                            <input
                                                type="text"
                                                className="w-full pl-10 pr-10 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white px-4 py-3 focus:ring-teal-500 focus:border-teal-500 shadow-sm"
                                                placeholder="Ürün adı veya barkod..."
                                                value={editSearchTerm}
                                                onChange={e => {
                                                    setEditSearchTerm(e.target.value);
                                                    setIsEditDropdownOpen(true);
                                                }}
                                                onFocus={() => setIsEditDropdownOpen(true)}
                                            />
                                            {editSearchTerm && (
                                                <button
                                                    type="button"
                                                    onClick={() => {
                                                        setEditSearchTerm("");
                                                        setEditProductForm(prev => ({ ...prev, productId: "", productName: "" }));
                                                    }}
                                                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
                                                >
                                                    <X size={16} />
                                                </button>
                                            )}
                                        </div>

                                        {/* Dropdown for Edit Modal */}
                                        {isEditDropdownOpen && editSearchTerm && (
                                            <div className="absolute z-50 mt-2 w-full bg-white dark:bg-slate-800 shadow-2xl max-h-60 rounded-xl py-2 text-sm border border-slate-100 dark:border-slate-700 overflow-auto focus:outline-none custom-scrollbar animate-in fade-in zoom-in-95 duration-100">
                                                {(() => {
                                                    const filteredForEdit = dbProducts.filter(p => {
                                                        const term = normalizeString(editSearchTerm);
                                                        const product = normalizeString(p.productName);
                                                        const barcode = String(p.barcode || "").toLowerCase();
                                                        const searchWords = term.split(/\s+/).filter(word => word.length > 0);
                                                        return searchWords.every(word => product.includes(word)) || barcode.includes(term);
                                                    });

                                                    if (filteredForEdit.length > 0) {
                                                        return filteredForEdit.map((product) => (
                                                            <div
                                                                key={product.id}
                                                                className="cursor-pointer select-none relative py-3 pl-4 pr-4 hover:bg-teal-50 dark:hover:bg-teal-900/20 transition-colors group border-b border-slate-50 dark:border-slate-700/50 last:border-0"
                                                                onClick={() => {
                                                                    setEditProductForm(prev => ({
                                                                        ...prev,
                                                                        productName: product.productName,
                                                                        productId: product.id
                                                                    }));
                                                                    setEditSearchTerm(product.productName);
                                                                    setIsEditDropdownOpen(false);
                                                                }}
                                                            >
                                                                <div className="flex flex-col gap-0.5">
                                                                    <span className="font-bold text-slate-800 dark:text-slate-200 group-hover:text-teal-700 dark:group-hover:text-teal-300 transition-colors">{product.productName}</span>
                                                                    <span className="text-xs text-slate-500 dark:text-slate-400">{product.companyName}</span>
                                                                </div>
                                                            </div>
                                                        ));
                                                    } else {
                                                        return (
                                                            <div className="py-4 px-4 text-center text-slate-500 dark:text-slate-400">
                                                                Ürün bulunamadı.
                                                            </div>
                                                        );
                                                    }
                                                })()}
                                            </div>
                                        )}
                                    </div>

                                    {/* Type Selection */}
                                    <div>
                                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Ürün Durumu</label>
                                        <div className="grid grid-cols-2 gap-3 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                                            <button
                                                type="button"
                                                onClick={() => setEditProductForm({ ...editProductForm, type: 'given' })}
                                                className={cn(
                                                    "py-2.5 text-sm font-bold rounded-lg transition-all flex items-center justify-center gap-2",
                                                    editProductForm.type === 'given'
                                                        ? "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-400 shadow-sm ring-1 ring-slate-200 dark:ring-slate-600"
                                                        : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300 hover:bg-white/50"
                                                )}
                                            >
                                                <div className={cn("w-2 h-2 rounded-full", editProductForm.type === 'given' ? "bg-teal-500" : "bg-slate-300 dark:bg-slate-600")}></div>
                                                Verilen Ürün
                                            </button>
                                            <button
                                                type="button"
                                                onClick={() => setEditProductForm({ ...editProductForm, type: 'recommended' })}
                                                className={cn(
                                                    "py-2.5 text-sm font-bold rounded-lg transition-all flex items-center justify-center gap-2",
                                                    editProductForm.type === 'recommended'
                                                        ? "bg-white dark:bg-slate-700 text-amber-600 dark:text-amber-400 shadow-sm ring-1 ring-slate-200 dark:ring-slate-600"
                                                        : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300 hover:bg-white/50"
                                                )}
                                            >
                                                <div className={cn("w-2 h-2 rounded-full", editProductForm.type === 'recommended' ? "bg-amber-500" : "bg-slate-300 dark:bg-slate-600")}></div>
                                                Önerilen Ürün
                                            </button>
                                        </div>
                                    </div>

                                    <div>
                                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">
                                            Notlar
                                        </label>
                                        <div className="relative">
                                            <textarea
                                                rows={4}
                                                className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-indigo-500 focus:border-indigo-500 pr-10 shadow-sm resize-none"
                                                placeholder="Kullanım talimatı, dozaj vb..."
                                                value={editProductForm.notes}
                                                onChange={e => setEditProductForm({ ...editProductForm, notes: e.target.value })}
                                            />
                                            {editProductForm.notes && (
                                                <button
                                                    type="button"
                                                    onClick={() => setEditProductForm({ ...editProductForm, notes: "" })}
                                                    className="absolute top-3 right-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 p-1.5 bg-slate-50 dark:bg-slate-700 rounded-full hover:bg-slate-100 dark:hover:bg-slate-600 transition-colors"
                                                    title="Temizle"
                                                >
                                                    <X size={14} />
                                                </button>
                                            )}
                                        </div>
                                    </div>
                                    <div className="pt-4 flex justify-end gap-3 border-t border-slate-100 dark:border-slate-800 mt-2">
                                        <button type="button" onClick={() => setIsProductEditModalOpen(false)} className="px-5 py-2.5 text-slate-700 dark:text-slate-300 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors">İptal</button>
                                        <button type="submit" className="px-6 py-2.5 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-500/30 transition-transform hover:scale-[1.02] active:scale-[0.98]">
                                            Değişiklikleri Kaydet
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    )
                }

                {/* ATTACHMENT MODAL */}
                {
                    isAttachmentModalOpen && (
                        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-300">
                            <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border border-white/20 dark:border-slate-700 animate-in zoom-in-95 duration-200">
                                <div className="px-6 py-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 flex justify-between items-center">
                                    <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                        <Paperclip size={20} className="text-indigo-500" />
                                        Dosya / Resim Ekle
                                    </h3>
                                    <button onClick={() => setIsAttachmentModalOpen(false)} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors">
                                        <X size={20} />
                                    </button>
                                </div>
                                <form onSubmit={handleSaveAttachment} className="p-6 space-y-5">
                                    <div>
                                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Dosya Adı (Opsiyonel)</label>
                                        <input
                                            type="text"
                                            className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-indigo-500 focus:border-indigo-500 shadow-sm"
                                            placeholder="Örn: Kan Tahlili, Yüz Fotoğrafı..."
                                            value={attachmentForm.name}
                                            onChange={e => setAttachmentForm({ ...attachmentForm, name: e.target.value })}
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Dosya Seçin</label>
                                        <div className="relative group">
                                            <input
                                                type="file"
                                                required
                                                className="w-full text-sm text-slate-500 file:mr-4 file:py-2.5 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-bold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 dark:file:bg-indigo-900/30 dark:file:text-indigo-300 transition-all cursor-pointer border border-slate-200 dark:border-slate-700 rounded-xl p-1"
                                                onChange={handleFileChange}
                                            />
                                        </div>
                                        <p className="text-xs text-slate-400 mt-2 ml-1">Görsel (jpg, png) veya belge (pdf) yükleyebilirsiniz.</p>
                                    </div>

                                    <div className="pt-4 flex justify-end gap-3 border-t border-slate-100 dark:border-slate-800 mt-2">
                                        <button type="button" onClick={() => setIsAttachmentModalOpen(false)} className="px-5 py-2.5 text-slate-700 dark:text-slate-300 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors">İptal</button>
                                        <button type="submit" className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold shadow-lg shadow-indigo-500/30 transition-transform hover:scale-[1.02] active:scale-[0.98]">
                                            Yükle
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    )
                }

                {/* PATIENT EDIT MODAL */}
                {
                    isPatientEditModalOpen && (
                        <div className="fixed inset-0 z-[80] flex items-start justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-300 overflow-y-auto">
                            <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-2xl shadow-2xl w-full max-w-lg max-h-[calc(100vh-2rem)] overflow-hidden border border-white/20 dark:border-slate-700 animate-in zoom-in-95 duration-200 my-auto flex flex-col">
                                <div className="px-6 py-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 flex justify-between items-center flex-shrink-0">
                                    <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                        <UserCog size={20} className="text-teal-500" />
                                        Danışan Bilgilerini Düzenle
                                    </h3>
                                    <button onClick={() => setIsPatientEditModalOpen(false)} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors">
                                        <X size={20} />
                                    </button>
                                </div>
                                <form onSubmit={handleUpdatePatient} className="p-6 space-y-5 overflow-y-auto">
                                    <div>
                                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Ad Soyad</label>
                                        <input
                                            required
                                            type="text"
                                            className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-teal-500 focus:border-teal-500 shadow-sm"
                                            value={patientEditForm.fullName}
                                            onChange={e => setPatientEditForm({ ...patientEditForm, fullName: e.target.value })}
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Danışan Tanımı</label>
                                        <input
                                            type="text"
                                            className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-teal-500 focus:border-teal-500 shadow-sm"
                                            placeholder="Örn: Ayşe Hanım'ın arkadaşı..."
                                            value={patientEditForm.description}
                                            onChange={e => setPatientEditForm({ ...patientEditForm, description: e.target.value })}
                                        />
                                    </div>

                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="col-span-2 sm:col-span-1">
                                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">
                                                Doğum Tarihi <span className="text-xs text-slate-400 font-normal ml-1">(Gün.Ay.Yıl veya Yıl)</span>
                                            </label>
                                            <input
                                                type="text"
                                                placeholder="Örn: 1990 veya 15.05.1985"
                                                className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-teal-500 focus:border-teal-500 shadow-sm"
                                                value={patientEditForm.birthDate || ""}
                                                onChange={e => {
                                                    const val = e.target.value;
                                                    let newAge = patientEditForm.age;

                                                    // Year or Full Date Logic
                                                    if (/^\d{4}$/.test(val)) {
                                                        const year = parseInt(val);
                                                        const currentYear = new Date().getFullYear();
                                                        if (year > 1900 && year <= currentYear) {
                                                            newAge = currentYear - year;
                                                        }
                                                    } else {
                                                        const parts = val.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/);
                                                        if (parts) {
                                                            const day = parseInt(parts[1]);
                                                            const month = parseInt(parts[2]) - 1;
                                                            const year = parseInt(parts[3]);
                                                            const birthDate = new Date(year, month, day);
                                                            const today = new Date();
                                                            let age = today.getFullYear() - birthDate.getFullYear();
                                                            const m = today.getMonth() - birthDate.getMonth();
                                                            if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                                                                age--;
                                                            }
                                                            newAge = age > 0 ? age : 0;
                                                        }
                                                    }
                                                    setPatientEditForm({ ...patientEditForm, birthDate: val, age: newAge });
                                                }}
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Yaş</label>
                                            <input
                                                type="number"
                                                className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-teal-500 focus:border-teal-500 shadow-sm"
                                                value={patientEditForm.age}
                                                onChange={e => setPatientEditForm({ ...patientEditForm, age: e.target.value })}
                                            />
                                        </div>
                                    </div>

                                    <div>
                                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">
                                            Telefon <span className="text-xs text-slate-400 font-normal ml-1">(5xx xxx xx xx)</span>
                                        </label>
                                        <input
                                            type="tel"
                                            maxLength={15}
                                            placeholder="5** *** ** **"
                                            className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border px-4 py-3 focus:ring-teal-500 focus:border-teal-500 shadow-sm"
                                            value={patientEditForm.phone}
                                            onChange={e => setPatientEditForm({ ...patientEditForm, phone: formatPhoneNumber(e.target.value) })}
                                        />
                                    </div>

                                    <div className="bg-amber-50 dark:bg-amber-900/10 p-4 rounded-xl border border-amber-200 dark:border-amber-800/40 space-y-3">
                                        <div className="flex items-start gap-3">
                                            <Shield className="h-5 w-5 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0" />
                                            <div>
                                                <h4 className="font-bold text-slate-900 dark:text-white">İletişim İzinleri / KVKK</h4>
                                                <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                                                    Bu bölüm, danışandan alınan izinlerin kaydı içindir. İYS entegrasyonu veya izin kontrolü yapılmadan ticari elektronik ileti gönderilmesi halinde sorumluluk kullanıcı eczacıya aittir.
                                                </p>
                                            </div>
                                        </div>

                                        <div className="grid grid-cols-1 gap-2">
                                            {[
                                                ["enlightenmentDone", "Danışana KVKK aydınlatması yapıldı."],
                                                ["explicitConsent", "Kişisel verilerin kaydı/saklanması için açık rıza alındı."]
                                            ].map(([key, label]) => (
                                                <label key={key} className="flex items-start gap-2 text-sm text-slate-700 dark:text-slate-300">
                                                    <input
                                                        type="checkbox"
                                                        className="mt-1 rounded border-slate-300 text-teal-600 focus:ring-teal-500"
                                                        checked={!!patientEditForm.kvkkConsent?.[key]}
                                                        onChange={e => {
                                                            const nextConsent = {
                                                                ...patientEditForm.kvkkConsent,
                                                                [key]: e.target.checked,
                                                                consentDate: e.target.checked && !patientEditForm.kvkkConsent?.consentDate ? new Date().toISOString() : patientEditForm.kvkkConsent?.consentDate
                                                            };
                                                            nextConsent.dataProcessing = !!nextConsent.enlightenmentDone && !!nextConsent.explicitConsent;
                                                            setPatientEditForm({ ...patientEditForm, kvkkConsent: nextConsent });
                                                        }}
                                                    />
                                                    {label}
                                                </label>
                                            ))}
                                        </div>

                                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                                            {[
                                                ["sms", "SMS izni"],
                                                ["phoneCall", "Arama izni"],
                                                ["email", "E-posta izni"]
                                            ].map(([key, label]) => (
                                                <label key={key} className="flex items-center gap-2 text-sm bg-white/70 dark:bg-slate-800/70 border border-amber-100 dark:border-amber-900/40 rounded-lg px-3 py-2 text-slate-700 dark:text-slate-300">
                                                    <input
                                                        type="checkbox"
                                                        className="rounded border-slate-300 text-teal-600 focus:ring-teal-500"
                                                        checked={!!patientEditForm.kvkkConsent?.[key]}
                                                        onChange={e => setPatientEditForm({ ...patientEditForm, kvkkConsent: { ...patientEditForm.kvkkConsent, [key]: e.target.checked, consentDate: e.target.checked && !patientEditForm.kvkkConsent?.consentDate ? new Date().toISOString() : patientEditForm.kvkkConsent?.consentDate } })}
                                                    />
                                                    {label}
                                                </label>
                                            ))}
                                        </div>

                                        <label className="flex items-start gap-2 text-xs text-amber-800 dark:text-amber-300 font-medium">
                                            <input
                                                type="checkbox"
                                                className="mt-0.5 rounded border-amber-300 text-amber-600 focus:ring-amber-500"
                                                checked={!!patientEditForm.kvkkConsent?.iysResponsibilityAccepted}
                                                onChange={e => setPatientEditForm({ ...patientEditForm, kvkkConsent: { ...patientEditForm.kvkkConsent, iysResponsibilityAccepted: e.target.checked } })}
                                            />
                                            İYS entegrasyonu yapılmadığı veya izinler İYS üzerinden doğrulanmadığı durumlarda, mevzuata uygun hareket etme ve gerekli kontrolleri yapma sorumluluğunun kullanıcı eczacıda olduğunu kabul ederim.
                                        </label>
                                    </div>

                                    <div className="pt-4 flex justify-end gap-3 border-t border-slate-100 dark:border-slate-800 mt-2">
                                        <button
                                            type="button"
                                            onClick={() => setIsPatientEditModalOpen(false)}
                                            className="px-5 py-2.5 text-slate-700 dark:text-slate-300 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
                                        >
                                            İptal
                                        </button>
                                        <button
                                            type="submit"
                                            className="px-6 py-2.5 bg-teal-600 text-white font-bold rounded-xl hover:bg-teal-700 transition-all shadow-lg shadow-teal-500/30 hover:scale-[1.02] active:scale-[0.98]"
                                        >
                                            Kaydet
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    )
                }
                {/* INVITE MODAL */}
                {
                    isInviteModalOpen && (
                        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-300">
                            <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border border-white/20 dark:border-slate-700 animate-in zoom-in-95 duration-200">
                                <div className="px-6 py-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 flex items-center justify-between">
                                    <div>
                                        <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                            <CalendarHeart size={20} className="text-pink-500" />
                                            Etkinliğe Davet Et
                                        </h3>
                                        <p className="text-sm font-medium text-slate-500 dark:text-slate-400 mt-0.5">{patient.fullName}</p>
                                    </div>
                                    <button
                                        onClick={() => setIsInviteModalOpen(false)}
                                        className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
                                    >
                                        <X size={20} />
                                    </button>
                                </div>

                                <div className="p-4 max-h-[60vh] overflow-y-auto space-y-3 custom-scrollbar">
                                    <p className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 px-1">Yaklaşan Uzman Günleri</p>
                                    {upcomingEvents.length > 0 ? (
                                        upcomingEvents.map(event => {
                                            // Check if already invited
                                            const isInvited = event.invitations?.some(i => i.patientId === id);

                                            return (
                                                <div
                                                    key={event.id}
                                                    onClick={() => {
                                                        if (!isInvited) {
                                                            handleInviteConfirm(event);
                                                            setIsInviteModalOpen(false);
                                                        }
                                                    }}
                                                    className={cn(
                                                        "w-full flex items-center justify-between p-4 rounded-xl border transition-all text-left group",
                                                        isInvited
                                                            ? "bg-slate-50/50 dark:bg-slate-700/30 border-slate-200 dark:border-slate-700 cursor-default"
                                                            : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-teal-500 dark:hover:border-teal-500 hover:shadow-md cursor-pointer hover:bg-teal-50/10"
                                                    )}
                                                >
                                                    <div>
                                                        <div className={cn("font-bold text-base", isInvited ? "text-slate-500 dark:text-slate-500" : "text-slate-900 dark:text-slate-100 group-hover:text-teal-700 dark:group-hover:text-teal-400")}>
                                                            {event.companyName}
                                                        </div>
                                                        <div className="text-sm text-slate-500 dark:text-slate-400 mt-0.5 flex items-center gap-1.5">
                                                            <Calendar size={14} />
                                                            {new Date(event.date).toLocaleDateString("tr-TR", { day: 'numeric', month: 'long', weekday: 'long' })}
                                                        </div>
                                                        {event.note && (
                                                            <div className="text-xs text-slate-400 mt-1 italic">{event.note}</div>
                                                        )}
                                                    </div>

                                                    {isInvited ? (
                                                        <div className="flex items-center gap-2">
                                                            <span className="text-xs bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 px-2.5 py-1 rounded-full font-bold">Davetli</span>
                                                            <button
                                                                onClick={(e) => {
                                                                    e.stopPropagation();
                                                                    handleInviteRemove(event);
                                                                }}
                                                                className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-full transition-colors"
                                                                title="Daveti Kaldır"
                                                            >
                                                                <Trash2 size={16} />
                                                            </button>
                                                        </div>
                                                    ) : (
                                                        <div className="h-9 w-9 rounded-full bg-teal-50 dark:bg-teal-900/20 text-teal-600 dark:text-teal-400 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                                            <Plus size={20} strokeWidth={2.5} />
                                                        </div>
                                                    )}
                                                </div>
                                            );
                                        })
                                    ) : (
                                        <div className="text-center py-12 text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700">
                                            <Calendar size={32} className="mx-auto mb-3 opacity-30" />
                                            <p className="font-medium">Planlanmış uzman günü bulunmuyor.</p>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    )
                }
                {/* INTEREST SELECTION MODAL */}
                {
                    isInterestModalOpen && (
                        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-300">
                            <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border border-white/20 dark:border-slate-700 animate-in zoom-in-95 duration-200">
                                <div className="px-6 py-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 flex items-center justify-between">
                                    <div>
                                        <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                            <Heart size={20} className="text-pink-500" />
                                            Firma Takibi
                                        </h3>
                                        <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">İlgilendiği firmaları seçiniz</p>
                                    </div>
                                    <button
                                        onClick={() => setIsInterestModalOpen(false)}
                                        className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
                                    >
                                        <X size={20} />
                                    </button>
                                </div>

                                <div className="p-4 max-h-[60vh] overflow-y-auto space-y-3 custom-scrollbar">

                                    {/* Do Not Call Toggle */}
                                    <div
                                        onClick={handleToggleDoNotCall}
                                        className={cn(
                                            "w-full flex items-center justify-between p-4 rounded-xl border transition-all cursor-pointer mb-4",
                                            patient.isDoNotCall
                                                ? "bg-red-50 dark:bg-red-900/30 border-red-200 dark:border-red-700 text-red-800 dark:text-red-200 ring-1 ring-red-200"
                                                : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-red-300 dark:hover:border-red-700 hover:bg-red-50/50 dark:hover:bg-red-900/10 text-slate-700 dark:text-slate-300"
                                        )}
                                    >
                                        <span className="font-bold flex items-center gap-3">
                                            <div className={cn("p-2 rounded-full", patient.isDoNotCall ? "bg-red-100 dark:bg-red-800 text-red-600 dark:text-red-200" : "bg-slate-100 dark:bg-slate-700 text-slate-400 dark:text-slate-500")}>
                                                <Ban size={20} />
                                            </div>
                                            <span className="text-red-600 dark:text-red-400">BİR DAHA ARANMAYACAK</span>
                                        </span>
                                        {patient.isDoNotCall && <div className="bg-red-600 text-white rounded-full p-1"><Check size={14} strokeWidth={3} /></div>}
                                    </div>

                                    <div className="h-px bg-slate-100 dark:bg-slate-800 my-4"></div>

                                    <p className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 px-1">İlgilendiği Firmaları Seçin</p>
                                    <button
                                        onClick={() => handleSelectInterestAndClose(REPORT_PATIENTS_GROUP_ID)}
                                        className={cn(
                                            "w-full flex items-center justify-between p-4 rounded-xl border transition-all text-left group mb-2",
                                            patient.interestedCompanies?.some(id => String(id) === REPORT_PATIENTS_GROUP_ID)
                                                ? "bg-amber-50 dark:bg-amber-900/30 border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200"
                                                : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-amber-300 dark:hover:border-amber-700 hover:shadow-sm text-slate-700 dark:text-slate-200"
                                        )}
                                    >
                                        <div className="font-bold flex items-center gap-3">
                                            <div className={cn("p-2 rounded-lg transition-colors", patient.interestedCompanies?.some(id => String(id) === REPORT_PATIENTS_GROUP_ID) ? "bg-white/60 dark:bg-amber-900/50 text-amber-600 dark:text-amber-300" : "bg-slate-100 dark:bg-slate-700/50 text-slate-400 dark:text-slate-500 group-hover:bg-amber-50 dark:group-hover:bg-amber-900/20 group-hover:text-amber-500")}>
                                                <FileText size={18} />
                                            </div>
                                            {REPORT_PATIENTS_GROUP_LABEL}
                                        </div>

                                        <div className={cn(
                                            "w-6 h-6 rounded-full flex items-center justify-center border transition-all scale-100",
                                            patient.interestedCompanies?.some(id => String(id) === REPORT_PATIENTS_GROUP_ID)
                                                ? "bg-amber-500 border-amber-500 text-white shadow-sm"
                                                : "bg-transparent border-slate-300 dark:border-slate-600 text-transparent group-hover:border-amber-400 dark:group-hover:border-amber-500"
                                        )}>
                                            <Check size={14} strokeWidth={3} />
                                        </div>
                                    </button>

                                    {/* No Group Option */}
                                    <div
                                        onClick={async () => {
                                            const updated = await DataService.updatePatient(patient.id, {
                                                interestedCompanies: []
                                            });
                                            setPatient(updated);
                                            setIsInterestModalOpen(false);
                                        }}
                                        className={cn(
                                            "w-full flex items-center justify-between p-4 rounded-xl border transition-all cursor-pointer mb-2",
                                            (!patient.interestedCompanies || patient.interestedCompanies.length === 0) && !patient.isDoNotCall
                                                ? "bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-600 text-slate-900 dark:text-slate-100 ring-1 ring-slate-300 dark:ring-slate-600"
                                                : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-500 hover:bg-slate-50 dark:hover:bg-slate-700/50 text-slate-500 dark:text-slate-400"
                                        )}
                                    >
                                        <span className="font-bold flex items-center gap-3">
                                            <div className={cn("p-2 rounded-lg", (!patient.interestedCompanies || patient.interestedCompanies.length === 0) ? "bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300" : "bg-slate-100 dark:bg-slate-700/50 text-slate-400 dark:text-slate-500")}>
                                                <Ban size={20} />
                                            </div>
                                            Firma Seçilmemiş
                                        </span>
                                        {(!patient.interestedCompanies || patient.interestedCompanies.length === 0) && !patient.isDoNotCall && <div className="bg-slate-600 text-white rounded-full p-1"><Check size={14} strokeWidth={3} /></div>}
                                    </div>
                                    {companies.length > 0 ? (
                                        companies.map(comp => {
                                            const isInterested = patient.interestedCompanies?.includes(comp.id);
                                            return (
                                                <button
                                                    key={comp.id}
                                                    onClick={() => handleSelectInterestAndClose(comp.id)}
                                                    className={cn(
                                                        "w-full flex items-center justify-between p-4 rounded-xl border transition-all text-left group",
                                                        isInterested
                                                            ? "bg-pink-50 dark:bg-pink-900/30 border-pink-200 dark:border-pink-800 text-pink-900 dark:text-pink-200 relative overflow-hidden"
                                                            : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-pink-300 dark:hover:border-pink-700 hover:shadow-sm text-slate-700 dark:text-slate-200"
                                                    )}
                                                >
                                                    {isInterested && <div className="absolute left-0 top-0 bottom-0 w-1 bg-pink-500"></div>}
                                                    <div className="font-bold flex items-center gap-3">
                                                        <div className={cn("p-2 rounded-lg transition-colors", isInterested ? "bg-white/50 dark:bg-pink-900/50 text-pink-600 dark:text-pink-300" : "bg-slate-100 dark:bg-slate-700/50 text-slate-400 dark:text-slate-500 group-hover:bg-pink-50 dark:group-hover:bg-pink-900/20 group-hover:text-pink-500")}>
                                                            <Package size={18} />
                                                        </div>
                                                        {comp.name}
                                                    </div>

                                                    <div className={cn(
                                                        "w-6 h-6 rounded-full flex items-center justify-center border transition-all scale-100",
                                                        isInterested
                                                            ? "bg-pink-500 border-pink-500 text-white shadow-sm"
                                                            : "bg-transparent border-slate-300 dark:border-slate-600 text-transparent group-hover:border-pink-400 dark:group-hover:border-pink-500"
                                                    )}>
                                                        <Check size={14} strokeWidth={3} />
                                                    </div>
                                                </button>
                                            );
                                        })
                                    ) : (
                                        <div className="text-center py-8 text-slate-500 dark:text-slate-400">
                                            <p>Sistemde kayıtlı firma bulunamadı.</p>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    )
                }
                {/* ANAMNESIS MODAL */}
                {
                    isAnamnesisModalOpen && (
                        <DetailedAnamnesisModal
                            isOpen={isAnamnesisModalOpen}
                            onClose={() => setIsAnamnesisModalOpen(false)}
                            onSave={handleUpdateAnamnesis}
                            initialData={patient.detailedAnamnesis}
                        />
                    )
                }

                {/* DERMO ANAMNESIS MODAL */}
                {
                    isDermoAnamnesisModalOpen && (
                        <DermoAnamnesisModal
                            isOpen={isDermoAnamnesisModalOpen}
                            onClose={() => setIsDermoAnamnesisModalOpen(false)}
                            onSave={handleUpdateDermoAnamnesis}
                            initialData={patient.dermoAnamnesis}
                        />
                    )
                }

                <AnamnesisReportModal
                    isOpen={isReportModalOpen}
                    onClose={() => setIsReportModalOpen(false)}
                    patient={patient}
                    anamnesis={patient?.detailedAnamnesis}
                />

                <DermoAnamnesisReportModal
                    isOpen={isDermoReportModalOpen}
                    onClose={() => setIsDermoReportModalOpen(false)}
                    patient={patient}
                    dermoAnamnesis={patient?.dermoAnamnesis}
                />

                {
                    isSkinCareModalOpen && (
                        <SkinCareModal
                            isOpen={isSkinCareModalOpen}
                            onClose={() => setIsSkinCareModalOpen(false)}
                            initialData={patient.skinCareData}
                            onSave={handleUpdateSkinCare}
                        />
                    )
                }

                {/* Follow Up Modal */}
                {
                    isFollowUpModalOpen && (
                        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-300">
                            <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border border-white/20 dark:border-slate-700 animate-in zoom-in-95 duration-200">
                                <div className="px-6 py-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 flex justify-between items-center">
                                    <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                        <Bell size={20} className="text-orange-500" />
                                        {editingFollowUpId ? "Takibi Düzenle" : "Yeni Takip Ekle"}
                                    </h3>
                                    <button onClick={() => setIsFollowUpModalOpen(false)} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors">
                                        <X size={20} />
                                    </button>
                                </div>
                                <form onSubmit={handleSaveFollowUp} className="p-6 space-y-5">
                                    <div>
                                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Takip Tarihi</label>
                                        <div className="relative">
                                            <input
                                                type="date"
                                                required
                                                value={followUpForm.date}
                                                onChange={e => setFollowUpForm({ ...followUpForm, date: e.target.value })}
                                                className="w-full px-4 py-3 border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl focus:ring-orange-500 focus:border-orange-500 shadow-sm"
                                            />
                                            <Calendar className="absolute right-4 top-3.5 text-slate-400 pointer-events-none" size={20} />
                                        </div>
                                    </div>
                                    <div>
                                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Not / Açıklama</label>
                                        <div className="relative">
                                            <textarea
                                                rows={3}
                                                value={followUpForm.note}
                                                onChange={e => setFollowUpForm({ ...followUpForm, note: e.target.value })}
                                                placeholder="Neden takip edilecek? (Örn: 1 ay sonra kontrol, tahlil sonucu vb.)"
                                                className="w-full px-4 py-3 border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white rounded-xl focus:ring-orange-500 focus:border-orange-500 pr-10 shadow-sm resize-none"
                                            />
                                            {followUpForm.note && (
                                                <button
                                                    type="button"
                                                    onClick={() => setFollowUpForm({ ...followUpForm, note: "" })}
                                                    className="absolute top-3 right-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 p-1.5 bg-slate-50 dark:bg-slate-700 rounded-full hover:bg-slate-100 dark:hover:bg-slate-600 transition-colors"
                                                    title="Temizle"
                                                >
                                                    <X size={14} />
                                                </button>
                                            )}
                                        </div>
                                    </div>
                                    <div>
                                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Takip Kategorisi</label>
                                        <div className="grid grid-cols-1 gap-2">
                                            {FOLLOW_UP_CATEGORY_OPTIONS.map((option) => (
                                                <label key={option.id} className="flex items-center gap-3 p-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer">
                                                    <input
                                                        type="checkbox"
                                                        checked={Array.isArray(followUpForm.followUpCategories) && followUpForm.followUpCategories.includes(option.id)}
                                                        onChange={(e) => {
                                                            const current = Array.isArray(followUpForm.followUpCategories) ? followUpForm.followUpCategories : [];
                                                            const next = e.target.checked
                                                                ? [...new Set([...current, option.id])]
                                                                : current.filter((c) => c !== option.id);
                                                            setFollowUpForm({ ...followUpForm, followUpCategories: next });
                                                        }}
                                                        className="w-4 h-4 text-orange-600 rounded border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800"
                                                    />
                                                    <span className="text-sm font-semibold text-slate-700 dark:text-slate-300">{option.label}</span>
                                                </label>
                                            ))}
                                        </div>
                                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Birden fazla kategori seçebilirsiniz.</p>
                                    </div>
                                    <div className="flex items-center gap-3 pt-1">
                                        <div className="relative flex items-center">
                                            <input
                                                type="checkbox"
                                                id="pharmaFollow"
                                                checked={followUpForm.isPharmacistFollowUp}
                                                onChange={e => setFollowUpForm({ ...followUpForm, isPharmacistFollowUp: e.target.checked })}
                                                className="w-5 h-5 text-purple-600 rounded focus:ring-purple-500 border-gray-300 dark:border-gray-600 bg-white dark:bg-slate-800 cursor-pointer"
                                            />
                                        </div>
                                        <label htmlFor="pharmaFollow" className="text-sm font-bold text-slate-700 dark:text-slate-300 cursor-pointer select-none">
                                            Eczacının Takibinde
                                            <p className="text-xs text-slate-500 dark:text-slate-400 font-normal">Sadece eczacı yetkisine sahip kullanıcılar görebilir</p>
                                        </label>
                                    </div>
                                    <div className="flex justify-end gap-3 mt-4 pt-4 border-t border-slate-100 dark:border-slate-800">
                                        <button
                                            type="button"
                                            onClick={() => setIsFollowUpModalOpen(false)}
                                            className="px-5 py-2.5 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 border border-transparent rounded-xl transition-colors font-bold"
                                        >
                                            İptal
                                        </button>
                                        <button
                                            type="submit"
                                            className="bg-orange-600 hover:bg-orange-700 text-white px-6 py-2.5 rounded-xl font-bold transition-all shadow-lg shadow-orange-500/30 hover:shadow-orange-500/40 active:scale-95"
                                        >
                                            {editingFollowUpId ? "Güncelle" : "Takip Başlat"}
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    )
                }
            </div >
            <PrintablePatientDetail patient={patient} />
        </>
    );
}


