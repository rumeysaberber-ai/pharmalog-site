$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$VersionFile = Join-Path $Root "pharmalog_version.json"
$ServerFile = Join-Path $Root "server.js"
$DistIndex = Join-Path $Root "dist\index.html"
$DatabaseFile = Join-Path $Root "database.sqlite"
$UploadsDir = Join-Path $Root "uploads"

Write-Host ""
Write-Host "PharmaLog guncelleme kontrolu" -ForegroundColor Cyan
Write-Host "Klasor: $Root"
Write-Host ""

if (-not (Test-Path -LiteralPath $VersionFile)) {
    Write-Host "[HATA] pharmalog_version.json bulunamadi. Bu klasor PharmaLog ana klasoru olmayabilir." -ForegroundColor Red
    exit 1
}

$Version = (Get-Content -LiteralPath $VersionFile -Raw | ConvertFrom-Json).version
Write-Host "Program dosya surumu: $Version" -ForegroundColor Green

if (-not (Test-Path -LiteralPath $ServerFile)) {
    Write-Host "[HATA] server.js bulunamadi. Guncelleme eksik kopyalanmis." -ForegroundColor Red
    exit 1
}

$ServerText = Get-Content -LiteralPath $ServerFile -Raw
if ($ServerText -notmatch "/api/update/apply") {
    Write-Host "[HATA] server.js eski gorunuyor. Otomatik guncelleyici bu klasore gelmemis." -ForegroundColor Red
    Write-Host "Cozum: Guncelleme zipinin icindeki tum dosya ve klasorleri bu klasorun icine yeniden kopyalayin." -ForegroundColor Yellow
    exit 1
}

if (-not (Test-Path -LiteralPath $DistIndex)) {
    Write-Host "[HATA] dist\index.html bulunamadi. Arayuz dosyalari eksik." -ForegroundColor Red
    exit 1
}

if (Test-Path -LiteralPath $DatabaseFile) {
    Write-Host "database.sqlite bulundu; danisan verileri yerinde." -ForegroundColor Green
} else {
    Write-Host "[UYARI] database.sqlite bulunamadi. Bos kurulumsa normal olabilir." -ForegroundColor Yellow
}

if (Test-Path -LiteralPath $UploadsDir) {
    Write-Host "uploads klasoru bulundu." -ForegroundColor Green
} else {
    Write-Host "[UYARI] uploads klasoru bulunamadi. Bos kurulumsa normal olabilir." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Kontrol tamam. Simdi PharmaLog Sunucuyu Durdur'u calistirip programi yeniden acin." -ForegroundColor Cyan
