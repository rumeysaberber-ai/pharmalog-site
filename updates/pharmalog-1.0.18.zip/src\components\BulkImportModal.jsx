import { useState } from "react";
import { X, Upload, FileText, Check, AlertCircle, Loader2 } from "lucide-react";
import { DataService } from "../lib/data";
import { normalizeString, generateUUID } from "../lib/utils";
import { format, parse, isValid } from "date-fns";
import * as XLSX from "xlsx";

export default function BulkImportModal({ isOpen, onClose, onImportComplete }) {
    const [rawText, setRawText] = useState("");
    const [parsedData, setParsedData] = useState([]);
    const [step, setStep] = useState(1); // 1: Input, 2: Preview, 3: Importing
    const [importing, setImporting] = useState(false);
    const [progress, setProgress] = useState({ current: 0, total: 0 });
    const [conflicts, setConflicts] = useState([]);
    const [currentConflictIndex, setCurrentConflictIndex] = useState(0);
    const [safeToImport, setSafeToImport] = useState([]);

    if (!isOpen) return null;

    const parseText = () => {
        if (!rawText.trim()) return;

        const lines = rawText.split(/\r?\n/);
        const parsed = [];

        let currentPatient = null;
        let currentVisit = null;

        const finalizeVisit = () => {
            if (currentPatient && currentVisit) {
                const noteText = currentVisit.notes.join("\n").trim();
                if (noteText || currentVisit.date) {
                    currentPatient.history.push({
                        date: currentVisit.date,
                        note: noteText
                    });
                }
                currentVisit = null;
            }
        };

        const finalizePatient = () => {
            finalizeVisit();
            if (currentPatient) {
                if (currentPatient.fullName && currentPatient.fullName.length > 2) {
                    parsed.push(currentPatient);
                }
                currentPatient = null;
            }
        };

        const dateRegex = /(\d{1,2}[./]\d{1,2}[./]\d{2,4})/;
        const phoneRegex = /(?:0\s*)?5\d{2}\s*\d{3}\s*\d{2}\s*\d{2}|(?:0\s*)?5\d{9}/;

        lines.forEach(line => {
            const trimmed = line.trim();
            if (!trimmed) return;

            const isCheckbox = /^[#☐\[\]*•\-■□]/.test(line);
            const hasPhone = phoneRegex.test(trimmed);
            const hasDate = dateRegex.test(trimmed);
            const isNewPatient = isCheckbox || (hasPhone && !hasDate);

            if (isNewPatient) {
                finalizePatient();
                let working = trimmed
                    .replace(phoneRegex, '')
                    .replace(/-.*/, '')
                    .replace(/★.*/, '')
                    .replace(/\(.*\)/, '');
                const nameStartMatch = working.match(/[a-zA-Z\u00C0-\u017F]/);
                let cleanName = "";
                if (nameStartMatch && nameStartMatch.index !== undefined) {
                    cleanName = working.substring(nameStartMatch.index).trim();
                } else {
                    cleanName = working.trim();
                }
                if (cleanName && !cleanName.endsWith("*")) {
                    cleanName = `${cleanName} *`;
                }
                const pMatch = trimmed.match(phoneRegex);
                const cleanPhone = pMatch ? pMatch[0].replace(/\s/g, '') : "";
                currentPatient = {
                    fullName: cleanName || "İsimsiz Danışan",
                    phone: cleanPhone,
                    history: []
                };
                return;
            }

            if (!currentPatient) return;

            const dateMatch = trimmed.match(dateRegex);
            if (dateMatch) {
                finalizeVisit();
                let d = parse(dateMatch[1], "d.M.yyyy", new Date());
                if (!isValid(d)) d = parse(dateMatch[1], "dd.MM.yyyy", new Date());
                if (!isValid(d)) d = new Date();
                let restOfLine = trimmed
                    .replace(dateMatch[1], '')
                    .replace(/^Notes:\s*/i, '')
                    .replace(/^-/, '')
                    .trim();
                currentVisit = {
                    date: d.toISOString(),
                    notes: restOfLine ? [restOfLine] : []
                };
            } else {
                if (!currentVisit) {
                    currentVisit = {
                        date: new Date().toISOString(),
                        notes: []
                    };
                }
                currentVisit.notes.push(trimmed);
            }
        });

        finalizePatient();
        setParsedData(parsed);
        setStep(2);
    };

    const handleFileUpload = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const data = await file.arrayBuffer();
        const workbook = XLSX.read(data);
        const worksheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { defval: "" });

        const parsed = [];

        jsonData.forEach(row => {
            const keys = Object.keys(row);
            const nameKey = keys.find(k => k.toLowerCase().includes("ad soyad")) || "Ad Soyad";
            const phoneKey = keys.find(k => k.toLowerCase().includes("telefon")) || "Telefon";
            const name = row[nameKey];
            if (!name) return;
            let phone = row[phoneKey] ? String(row[phoneKey]).replace(/\D/g, '') : "";
            if (phone.length === 10) phone = "0" + phone;
            if (phone.length === 11 && phone.startsWith("90")) phone = "0" + phone.substring(2);
            const patient = {
                fullName: String(name).trim() + " *",
                phone: phone,
                history: []
            };
            let i = 1;
            while (true) {
                const dateKey = keys.find(k => normalizeString(k).includes(`tarih ${i}`) || normalizeString(k) === `tarih${i}`);
                const noteKey = keys.find(k => normalizeString(k).includes(`islem ${i}`) || normalizeString(k) === `islem${i}`);
                if (!dateKey) break;
                const dateVal = row[dateKey];
                const noteVal = row[noteKey];
                if (dateVal) {
                    let d = new Date();
                    if (typeof dateVal === 'number') {
                        d = new Date(Math.round((dateVal - 25569) * 86400 * 1000));
                    } else {
                        const ds = String(dateVal).trim();
                        let p = parse(ds, "d.M.yyyy", new Date());
                        if (!isValid(p)) p = parse(ds, "dd.MM.yyyy", new Date());
                        if (!isValid(p)) p = new Date(ds);
                        if (isValid(p)) d = p;
                    }
                    patient.history.push({
                        date: d.toISOString(),
                        note: noteVal ? String(noteVal).trim() : "İşlem detayı yok."
                    });
                } else if (noteVal) {
                    patient.history.push({
                        date: new Date().toISOString(),
                        note: String(noteVal).trim()
                    });
                }
                i++;
            }
            parsed.push(patient);
        });

        setParsedData(parsed);
        setStep(2);
    };

    const handleImport = async () => {
        const existingPatients = await DataService.getPatients();
        const newConflicts = [];
        const safe = [];
        for (const pt of parsedData) {
            const duplicate = existingPatients.find(existing => {
                if (pt.phone && existing.phone && pt.phone.replace(/\s/g, '') === existing.phone.replace(/\s/g, '')) return true;
                if (pt.fullName.toLowerCase().trim() === existing.fullName.toLowerCase().trim()) return true;
                return false;
            });
            if (duplicate) {
                newConflicts.push({ newData: pt, existingData: duplicate });
            } else {
                safe.push(pt);
            }
        }
        setConflicts(newConflicts);
        setSafeToImport(safe);
        if (newConflicts.length > 0) {
            setStep(4);
            setCurrentConflictIndex(0);
        } else {
            await executeImport(safe);
        }
    };

    const executeImport = async (patientsToImport) => {
        setImporting(true);
        setStep(3);
        let count = 0;
        const dbProducts = await DataService.getDbProducts();
        const sortedProducts = [...dbProducts].sort((a, b) => b.productName.length - a.productName.length);

        try {
            for (const pt of patientsToImport) {
                if (count >= patientsToImport.length) break;
                setProgress({ current: count + 1, total: patientsToImport.length });

                let newPatient;
                if (pt.existingId) {
                    newPatient = { id: pt.existingId };
                } else {
                    newPatient = await DataService.addPatient({
                        fullName: pt.fullName,
                        phone: pt.phone,
                        category: "Yeni Danışan",
                        anamnesis: "Otomatik içe aktarıldı.",
                        skipInitialVisit: true
                    });
                }

                for (const visit of pt.history) {
                    if (visit.note) {
                        const originalNote = visit.note;
                        const visitProducts = [];

                        // USER REQUEST: Split by both newlines AND semicolons (;)
                        const lines = originalNote.split(/[\r\n;]+/);
                        const keptLines = [];
                        const extractedProducts = [];
                        let finalNoteContent = ""; // Initialize variable

                        lines.forEach(line => {
                            if (!line.trim()) return;

                            const matches = extractProductsFromRawText(line, sortedProducts);
                            if (matches.length === 0) {
                                keptLines.push(line);
                                return;
                            }

                            // Build Blocks
                            let blocks = [];
                            let lastIndex = 0;
                            matches.forEach(m => {
                                if (m.start > lastIndex) {
                                    blocks.push({ type: 'text', content: line.substring(lastIndex, m.start) });
                                }
                                blocks.push({ type: 'match', data: m });
                                lastIndex = m.end;
                            });
                            if (lastIndex < line.length) {
                                blocks.push({ type: 'text', content: line.substring(lastIndex) });
                            }

                            // Analyze Substantial Text
                            const isTextSentence = (text) => {
                                // 1. Hard Check: Punctuation (., !, ?) is a sentence terminator.
                                if (/[.!?]/.test(text)) return true; // Has a dot? Sentence.

                                // 2. Check Length: If SHORT (< 12 words), assume Attribute/List Item.
                                const wordCount = text.trim().split(/\s+/).length;
                                if (wordCount < 12) return false;

                                // 3. Fallback to Content Check
                                // Filter out Units/Attributes
                                let clean = text
                                    .replace(/\d+(ml|gr|g|mg|l|oz|%)/gi, '')
                                    .replace(/adet|tane|kapsül|kapsul|tablet|şase|sase|fıs|pump|doz|box|kutu|set|kit|pack/gi, '')
                                    .replace(/krem|cream|losyon|lotion|serum|jel|gel|maske|mask|peeling|tonik|tonic|temizleyici|cleanser|spf|nemlendirici|moisturizer|ampul|ampoule|köpük|foam/gi, '')
                                    // Remove specific brands/keywords that might appear as text
                                    .replace(/ipek|pamuk|disk|ya da|veya/gi, '')
                                    .replace(/water|su|eau|mist|thermal|termal|ped|pedi|disk|pamuk|cotton|ceramide|seramid|sod|zinc|çinko|b5|niacinamide|retinol|acid|asit/gi, '')
                                    .replace(/intense|repair|onarıcı|bakım|care|gece|night|gündüz|day|göz|eye|çevre|contour|hydra|hydrate|nem|saf|pure/gi, '')
                                    .replace(/temizleme|yıkama|wash|cleaning|makyaj|makeup|remover|micellar|miselar|solüsyon|solution/gi, '')
                                    .replace(/anti[- ]?aging|leke|spot|akne|acne|siyah|nokta|blackhead|gözenek|pore/gi, '')
                                    // Remove known connectors
                                    .replace(/\b(ve|ile|veya|and|with|&|\+)\b/gi, '')
                                    // Remove punctuation/digits
                                    .replace(/[0-9\s.,;:\-*•_+()!?'"/]+/g, '')
                                    .trim();

                                return clean.length > 0;
                            };

                            // Backwards Line Processing
                            let cursor = blocks.length - 1;
                            let tailIsClean = true;
                            const decisions = new Array(blocks.length).fill('keep');

                            // Map to store "Gap Text" for each match
                            const gapMap = {}; // matchIndex -> string

                            while (cursor >= 0) {
                                const blk = blocks[cursor];
                                if (blk.type === 'match') {
                                    if (tailIsClean) {
                                        decisions[cursor] = 'extract';
                                    } else {
                                        decisions[cursor] = 'keep';
                                    }
                                } else {
                                    // Text block
                                    if (isTextSentence(blk.content)) {
                                        tailIsClean = false;
                                        decisions[cursor] = 'keep';
                                    } else {
                                        // Insubstantial (Separators, Attributes, Short Text)
                                        if (tailIsClean) {
                                            decisions[cursor] = 'remove';
                                            // Assign this text to the PREVIOUS match (visually, the match BEFORE this text in the loop, which is actually the match AFTER in reading order??)
                                            // Loop is backwards.
                                            // Cursor N = Text. Cursor N-1 = Match (presumably).
                                            // Wait, usually: Match [Text] Match [Text].
                                            // Backwards: [Text] -> assign to Match (N-1)? No, Match (N-1) is BEFORE the text. 
                                            // Reading order: Match A -> Text -> Match B.
                                            // If Text is attribute of Match A? Usually yes. "Caudalie [Grape Water]".
                                            // So Text at Cursor should be attached to Match at Cursor-1 ?

                                            // BUT, iterating backwards:
                                            // We meet Text at block 5.
                                            // If we extract Match at block 4, we want block 5 appended to Match 4.
                                            // So, store this text to be picked up by the NEXT match we encounter (which is technically previous in index).

                                            // Let's store it temporarily.
                                            // Actually, we can do this in the Decisions phase? 
                                            // No, we need to know WHICH match gets it.
                                        } else {
                                            decisions[cursor] = 'keep';
                                        }
                                    }
                                }
                                cursor--;
                            }

                            // Execute Decisions & Gap Merging
                            let pendingGapText = ""; // Accumulates text from Right to Left

                            // We need to process from Right to Left to attach text correctly to the match on its LEFT?
                            // "Match [Attribute]" -> Attribute belongs to Match.
                            // So if we iterate Backwards, we see Attribute first.
                            // We save Attribute. Then we see Match. We attach Attribute to Match.

                            for (let i = blocks.length - 1; i >= 0; i--) {
                                const blk = blocks[i];
                                const action = decisions[i];

                                if (blk.type === 'match') {
                                    if (action === 'extract') {
                                        // It absorbs the pending gap text
                                        let combinedNote = blk.data.note;
                                        // original note from extractProductsFromRawText is "extracted attributes"
                                        // pendingGapText is "raw text" (e.g. " GRAPE WATER 200ML ")

                                        // Optimization: Don't duplicate. 
                                        // If pendingGapText contains the attributes, just use pendingGapText.
                                        // Actually, let's just Append.
                                        // Cleaning: trim
                                        if (pendingGapText.trim()) {
                                            combinedNote = pendingGapText.trim();
                                        }

                                        // Push to extracted list
                                        extractedProducts.unshift({
                                            ...blk.data,
                                            note: combinedNote
                                        });

                                        // Reset pending
                                        pendingGapText = "";
                                    } else {
                                        // Kept match. 
                                        // Reset pending gap text? 
                                        // If we keep the match, the text following it (pendingGapText) was 'remove'??
                                        // If decision[i+1] was remove, but decision[i] is keep.
                                        // That implies tailIsClean became false at some point.
                                        // Wait, if tailIsClean became false, decision[i+1] would be 'keep' (unless it was already processed as remove?).
                                        // decisions array is static.
                                        // If blocks[i+1] was remove, then blocks[i] MUST be extract.
                                        // Because if blocks[i] is keep, tailIsClean must have been false.
                                        // If tailIsClean was false, blocks[i+1] would have been keep (because text check sets flag BEFORE setting decision).

                                        // So this case (Keep Match, Remove Text) shouldn't happen with current logic.
                                        // We can safely ignore pendingGapText here (it should be empty).
                                        pendingGapText = "";
                                    }
                                } else {
                                    if (action === 'remove') {
                                        // Accumulate text
                                        // Since we go backwards, " 70 ADET" comes first, then " PEDİ", etc.
                                        // We prepend to pendingGapText.
                                        pendingGapText = blk.content + pendingGapText;
                                    } else {
                                        // Action Keep.
                                        pendingGapText = "";
                                    }
                                }
                            }

                            // Reconstruct Line
                            let finalLineText = "";
                            decisions.forEach((action, idx) => {
                                const blk = blocks[idx];
                                // If action is keep, add to finalLineText
                                // If action is extract or remove, do NOT add.
                                if (action === 'keep') {
                                    if (blk.type === 'match') {
                                        finalLineText += line.substring(blk.data.start, blk.data.end);
                                    } else {
                                        finalLineText += blk.content;
                                    }
                                }
                            });

                            // Rescue Orphaned Gap Text (Text at start of line that was 'removed' but had no matched product to attach to)
                            if (pendingGapText) {
                                finalLineText = pendingGapText + finalLineText;
                            }

                            if (finalLineText.trim()) {
                                keptLines.push(finalLineText);
                            }
                        });


                        if (extractedProducts.length > 0) {
                            extractedProducts.forEach(match => {
                                // USER REQUEST: Treat attributes as part of the Product Name.
                                // "Caudalie Grape Water" should be the name, not Name: Caudalie, Note: Grape Water.
                                const fullDisplay = match.note
                                    ? `${match.product.productName} ${match.note}`
                                    : match.product.productName;

                                // UUID Polyfill for older browsers/environments
                                const safeId = generateUUID();

                                visitProducts.push({
                                    id: safeId,
                                    productName: fullDisplay, // Safe string
                                    productId: match.product.id,
                                    durationDays: 0,
                                    givenDate: visit.date,
                                    notes: ""
                                });
                            });
                        }

                        // Reassemble note
                        finalNoteContent = keptLines.join("\n");
                        // Protection against null/undefined
                        if (!finalNoteContent && visitProducts.length > 0) {
                            finalNoteContent = "";
                        }

                        await DataService.addVisit(newPatient.id, {
                            date: visit.date,
                            type: "Geçmiş Kayıt",
                            note: finalNoteContent || "",
                            products: visitProducts
                        });
                    }
                }
                count++;
            }
        } catch (error) {
            console.error("Bulk Import Error:", error);
            // Show detailed error to user
            alert(`Bir hata oluştu: ${error.message || error}. Lütfen teknik destek ile iletişime geçin.`);
        } finally {
            setImporting(false);
            onImportComplete();
            onClose();
        }
    };

    const resolveConflict = async (decision) => {
        const currentConflict = conflicts[currentConflictIndex];
        const { newData, existingData } = currentConflict;
        const nextQueue = [...safeToImport];

        if (decision === 'overwrite') {
            await DataService.deletePatient(existingData.id);
            nextQueue.push(newData);
        } else if (decision === 'keep_both') {
            nextQueue.push(newData);
        } else if (decision === 'merge') {
            newData.existingId = existingData.id;
            nextQueue.push(newData);
        }
        if (currentConflictIndex < conflicts.length - 1) {
            setSafeToImport(nextQueue);
            setCurrentConflictIndex(prev => prev + 1);
        } else {
            await executeImport(nextQueue);
        }
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <div className="bg-white rounded-xl shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col">
                <div className="p-6 border-b flex justify-between items-center">
                    <h2 className="text-xl font-bold text-slate-800">Toplu Danışan Aktarımı v5</h2>
                    <button onClick={onClose}><X size={24} className="text-slate-400 hover:text-slate-600" /></button>
                </div>

                <div className="flex-1 overflow-hidden p-6">
                    {step === 1 && (
                        <div className="h-full flex flex-col gap-4">
                            <div className="bg-blue-50 p-4 rounded-lg flex gap-3 text-blue-700 text-sm">
                                <InfoIcon />
                                <div>
                                    <p className="font-bold">Nasıl Kullanılır?</p>
                                    <ul className="list-disc pl-4 mt-1 space-y-1 opacity-90">
                                        <li>İster aşağıdaki alana kopyalayın, ister <strong>Excel</strong> dosyası yükleyin.</li>
                                        <li>Excel Formatı: <code>Ad Soyad</code>, <code>Telefon</code>, <code>Tarih 1</code>, <code>İşlem 1</code>, <code>Tarih 2</code>, <code>İşlem 2</code>...</li>
                                    </ul>
                                </div>
                            </div>

                            {/* File Import */}
                            <div className="flex items-center justify-center w-full">
                                <label htmlFor="dropzone-file" className="flex flex-col items-center justify-center w-full h-32 border-2 border-slate-300 border-dashed rounded-lg cursor-pointer bg-slate-50 hover:bg-slate-100 transition-colors">
                                    <div className="flex flex-col items-center justify-center pt-5 pb-6">
                                        <Upload className="w-8 h-8 mb-3 text-slate-400" />
                                        <p className="mb-2 text-sm text-slate-500"><span className="font-semibold">Excel Dosyası Seçmek İçin Tıkla</span> veya sürükle</p>
                                        <p className="text-xs text-slate-500">.XLSX veya .XLS</p>
                                    </div>
                                    <input id="dropzone-file" type="file" className="hidden" accept=".xlsx, .xls" onChange={handleFileUpload} />
                                </label>
                            </div>

                            <div className="relative flex py-2 items-center">
                                <div className="flex-grow border-t border-slate-300"></div>
                                <span className="flex-shrink-0 mx-4 text-slate-400 text-sm">veya Manuel Gir</span>
                                <div className="flex-grow border-t border-slate-300"></div>
                            </div>

                            <textarea
                                className="flex-1 w-full border rounded-lg p-4 font-mono text-sm focus:ring-2 focus:ring-teal-500"
                                placeholder="Buraya yapıştırın...&#10;☐ Örnek Danışan 05551234567&#10;12.05.2023&#10;Cilt bakımı yapıldı."
                                value={rawText}
                                onChange={e => setRawText(e.target.value)}
                            />
                        </div>
                    )}

                    {step === 2 && (
                        <div className="h-full overflow-y-auto border rounded-lg">
                            <div className="p-2 bg-slate-100 border-b text-xs flex justify-between items-center sticky top-0">
                                <span className="font-bold text-slate-700">Toplam {parsedData.length} Danışan Bulundu</span>
                                <button onClick={() => setStep(1)} className="text-blue-600 hover:underline">Düzenle</button>
                            </div>
                            <table className="w-full text-sm text-left">
                                <thead className="bg-slate-50 sticky top-8">
                                    <tr>
                                        <th className="p-3 border-b">Danışan Adı</th>
                                        <th className="p-3 border-b">Telefon</th>
                                        <th className="p-3 border-b">Geçmiş Kayıt</th>
                                        <th className="p-3 border-b">Son Not</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y">
                                    {parsedData.map((row, i) => (
                                        <tr key={i} className="hover:bg-slate-50">
                                            <td className="p-3 font-medium">{row.fullName}</td>
                                            <td className="p-3 text-slate-500">{row.phone || <span className="text-red-400 italic">Yok</span>}</td>
                                            <td className="p-3 text-center w-32">
                                                <span className="px-2 py-1 bg-teal-100 text-teal-700 rounded-full text-xs font-bold">{row.history.length}</span>
                                            </td>
                                            <td className="p-3 text-xs text-slate-500 max-w-xs truncate">
                                                {row.history.length > 0 ? row.history[row.history.length - 1].note.substring(0, 40) + "..." : "-"}
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                            {parsedData.length === 0 && <div className="p-10 text-center text-slate-400">Veri ayrıştırılamadı. Kopyaladığınız metinde telefon numarası olduğundan emin olun.</div>}
                        </div>
                    )}

                    {step === 3 && (
                        <div className="h-full flex flex-col items-center justify-center text-center">
                            <Loader2 size={48} className="animate-spin text-teal-600 mb-4" />
                            <h3 className="text-xl font-bold text-slate-800">Aktarılıyor...</h3>
                            <p className="text-slate-500 mt-2">
                                {progress.current} / {progress.total} danışan işleniyor.
                            </p>
                        </div>
                    )}

                    {step === 4 && conflicts.length > 0 && (
                        <div className="h-full flex flex-col">
                            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-4 flex items-center gap-3">
                                <AlertCircle className="text-amber-600" size={24} />
                                <div>
                                    <h3 className="font-bold text-amber-800">Mükerrer Kayıt Bulundu</h3>
                                    <p className="text-sm text-amber-700">
                                        Şu an işlenen kayıt veritabanında zaten mevcut. Nasıl ilerlemek istersiniz?
                                        <span className="font-mono ml-2 font-bold bg-amber-100 px-2 rounded">
                                            {currentConflictIndex + 1} / {conflicts.length}
                                        </span>
                                    </p>
                                </div>
                            </div>

                            <div className="flex-1 grid grid-cols-2 gap-4 overflow-hidden">
                                {/* Existing Record */}
                                <div className="border rounded-xl p-4 bg-slate-50 flex flex-col">
                                    <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Mevcut Kayıt (Eski)</div>
                                    <h4 className="font-bold text-lg text-slate-800">{conflicts[currentConflictIndex].existingData.fullName}</h4>
                                    <p className="text-sm text-slate-600">{conflicts[currentConflictIndex].existingData.phone}</p>
                                    <div className="mt-4 flex-1 overflow-y-auto">
                                        <p className="text-xs text-slate-400 mb-1">Geçmiş Ziyaretler:</p>
                                        <ul className="space-y-2">
                                            {conflicts[currentConflictIndex].existingData.visits?.map((v, i) => (
                                                <li key={i} className="text-xs bg-white p-2 rounded border border-slate-200">
                                                    <span className="font-bold block">{new Date(v.date).toLocaleDateString()}</span>
                                                    {v.note}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                </div>

                                {/* New Record */}
                                <div className="border rounded-xl p-4 bg-teal-50 border-teal-100 flex flex-col">
                                    <div className="text-xs font-bold text-teal-600 uppercase tracking-wider mb-2">Yeni Eklenecek</div>
                                    <h4 className="font-bold text-lg text-teal-900">{conflicts[currentConflictIndex].newData.fullName}</h4>
                                    <p className="text-sm text-teal-700">{conflicts[currentConflictIndex].newData.phone}</p>
                                    <div className="mt-4 flex-1 overflow-y-auto">
                                        <p className="text-xs text-teal-400 mb-1">Geçmiş (İçe Aktarılacak):</p>
                                        <ul className="space-y-2">
                                            {conflicts[currentConflictIndex].newData.history?.map((h, i) => (
                                                <li key={i} className="text-xs bg-white p-2 rounded border border-teal-100">
                                                    <span className="font-bold block">{h.date}</span>
                                                    {h.note}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                </div>
                            </div>

                        </div>

                    )}
                </div>

                <div className="p-4 border-t bg-slate-50 flex justify-end gap-3">
                    {step === 1 && (
                        <button
                            onClick={parseText}
                            disabled={!rawText.trim()}
                            className="bg-teal-600 text-white px-6 py-2 rounded-lg font-bold hover:bg-teal-700 disabled:opacity-50 transition-colors flex items-center gap-2"
                        >
                            <FileText size={18} /> Ayrıştır ve Önizle
                        </button>
                    )}
                    {step === 2 && (
                        <>
                            <button onClick={() => setStep(1)} className="text-slate-600 px-4 py-2 hover:bg-slate-200 rounded-lg">Geri Dön</button>
                            <button
                                onClick={handleImport}
                                className="bg-teal-600 text-white px-6 py-2 rounded-lg font-bold hover:bg-teal-700 transition-colors flex items-center gap-2"
                            >
                                <Upload size={18} /> {parsedData.length} Kaydı İçe Aktar
                            </button>
                        </>
                    )}
                    {step === 4 && (
                        <div className="flex w-full justify-center gap-4">
                            <button
                                onClick={() => resolveConflict('skip')}
                                className="px-5 py-2 rounded-lg border border-slate-300 text-slate-600 font-bold hover:bg-slate-100 transition-colors"
                            >
                                Atla
                            </button>
                            <button
                                onClick={() => resolveConflict('merge')}
                                className="px-5 py-2 rounded-lg bg-amber-500 text-white font-bold hover:bg-amber-600 transition-colors"
                            >
                                Birleştir
                            </button>
                            <button
                                onClick={() => resolveConflict('keep_both')}
                                className="px-5 py-2 rounded-lg bg-teal-600 text-white font-bold hover:bg-teal-700 transition-colors"
                            >
                                İkisini de Tut
                            </button>
                            <button
                                onClick={() => resolveConflict('overwrite')}
                                className="px-5 py-2 rounded-lg bg-red-600 text-white font-bold hover:bg-red-700 transition-colors"
                            >
                                Üzerine Yaz (Değiştir)
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div >
    );
}

function InfoIcon() {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-info"><circle cx="12" cy="12" r="10" /><path d="M12 16v-4" /><path d="M12 8h.01" /></svg>
    )
}

function extractProductsFromRawText(rawText, sortedProducts) {
    if (!rawText || typeof rawText !== "string") return [];

    const matches = [];
    const occupied = [];

    const escapeRegExp = (string) => string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

    for (const prod of sortedProducts) {
        if (!prod.productName) continue;
        const patternStr = escapeRegExp(prod.productName.trim()).replace(/\s+/g, '\\s+');
        const regex = new RegExp(patternStr, 'gi');

        let match;
        while ((match = regex.exec(rawText)) !== null) {
            const index = match.index;
            const matchText = match[0];
            const end = index + matchText.length;

            const isOverlap = occupied.some(range =>
                (index >= range.start && index < range.end) ||
                (end > range.start && end <= range.end) ||
                (index <= range.start && end >= range.end)
            );

            if (!isOverlap) {
                matches.push({
                    product: prod,
                    start: index,
                    end: end,
                    nameLength: matchText.length,
                    note: "" // Will be populated later
                });
                occupied.push({ start: index, end: end });
            }
        }
    }
    matches.sort((a, b) => a.start - b.start);
    return matches;
}
