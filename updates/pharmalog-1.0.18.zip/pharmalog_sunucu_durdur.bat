@echo off
title PharmaLog Sunucuyu Durdur
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0pharmalog_sunucu_durdur.ps1"
