import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { X, Printer, Activity, Package, Check, AlertTriangle, FileText } from 'lucide-react';
import { format } from 'date-fns';
import { tr } from 'date-fns/locale';
import { cn } from '../lib/utils';

export default function AnamnesisReportModal({ isOpen, onClose, patient, anamnesis }) {
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        setMounted(true);
        return () => setMounted(false);
    }, []);

    if (!isOpen || !anamnesis || !mounted) return null;

    const handlePrint = () => {
        window.print();
    };

    const LabelValue = ({ label, value, fullWidth = false }) => {
        if (!value) return null;
        return (
            <div className={cn("mb-3", fullWidth ? "col-span-full" : "")}>
                <span className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-0.5">{label}</span>
                <span className="text-sm font-medium text-slate-800 dark:text-slate-200 whitespace-pre-wrap">{value}</span>
            </div>
        );
    };

    const Section = ({ title, icon: Icon, children }) => (
        <div className="mb-6 break-inside-avoid">
            <h4 className="flex items-center gap-2 text-base font-bold text-teal-800 dark:text-teal-400 border-b border-teal-100 dark:border-teal-800/50 pb-2 mb-3">
                {Icon && <Icon size={18} />}
                {title}
            </h4>
            <div className="grid grid-cols-2 gap-4">
                {children}
            </div>
        </div>
    );

    const content = (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm print:p-0 print:bg-white print:fixed print:inset-0 print:z-[10000] animate-in fade-in duration-300">
            {/* Global Print Styles */}
            <style>
                {`
                    @media print {
                        body > *:not(#anamnesis-portal-root) {
                            display: none !important;
                        }
                        #anamnesis-portal-root {
                            display: block !important;
                        }
                        @page {
                            margin: 1cm;
                        }
                        /* Force light mode for print */
                        .dark {
                            color-scheme: light;
                        }
                    }
                `}
            </style>

            <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-2xl shadow-2xl w-full max-w-3xl overflow-hidden flex flex-col max-h-[90vh] border border-white/20 dark:border-slate-700 animate-in zoom-in-95 duration-200 print:shadow-none print:max-h-none print:w-full print:max-w-none print:rounded-none print:border-none px-0">

                {/* Header (Screen Only) */}
                <div className="px-6 py-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 flex items-center justify-between print:hidden flex-shrink-0">
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                        <div className="p-2 bg-teal-100 dark:bg-teal-900/30 text-teal-600 dark:text-teal-400 rounded-lg">
                            <Activity size={20} />
                        </div>
                        Anamnez Raporu
                    </h3>
                    <div className="flex items-center gap-2">
                        <button
                            onClick={handlePrint}
                            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all text-sm font-bold shadow-md shadow-indigo-500/20 active:scale-95"
                        >
                            <Printer size={16} />
                            Yazdır
                        </button>
                        <button
                            onClick={onClose}
                            className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
                        >
                            <X size={20} />
                        </button>
                    </div>
                </div>

                {/* Content */}
                <div className="p-8 overflow-y-auto custom-scrollbar print:p-8 print:overflow-visible h-full bg-transparent dark:bg-transparent">

                    {/* Print Header */}
                    <div className="mb-8 border-b-2 border-teal-600 pb-4">
                        <div className="flex justify-between items-start">
                            <div>
                                <h1 className="text-3xl font-bold text-slate-900 dark:text-white mb-1">{patient.fullName}</h1>
                                <div className="text-sm text-slate-500 dark:text-slate-400 space-y-0.5 font-medium">
                                    <p>Telefon: {patient.phone}</p>
                                    <p>Yaş: {patient.age}</p>
                                </div>
                            </div>
                            <div className="text-right">
                                <div className="text-sm font-bold text-teal-700 dark:text-teal-200 bg-teal-50 dark:bg-teal-900/30 px-3 py-1.5 rounded-lg inline-block border border-teal-100 dark:border-teal-800">
                                    Rapor Tarihi: {format(new Date(), 'dd.MM.yyyy', { locale: tr })}
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Body */}

                    {/* 1. Fiziksel */}
                    <Section title="Fiziksel Ölçümler" icon={Activity}>
                        <LabelValue label="Boy" value={anamnesis.height ? `${anamnesis.height} cm` : "-"} />
                        <LabelValue label="Kilo" value={anamnesis.weight ? `${anamnesis.weight} kg` : "-"} />
                        <LabelValue label="Vücut Kitle İndeksi (VKİ)" value={anamnesis.bmi || "-"} />
                    </Section>

                    {/* 2. Alışkanlıklar */}
                    <Section title="Alışkanlıklar" icon={AlertTriangle}>
                        <div className="col-span-full flex gap-6">
                            <div className={cn("flex items-center gap-2 px-3 py-1.5 rounded-lg border text-sm font-bold shadow-sm", anamnesis.smoking ? "bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800 text-red-700 dark:text-red-400" : "bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400")}>
                                Sigara: {anamnesis.smoking ? "KULLANIYOR" : "Kullanmıyor"}
                            </div>
                            <div className={cn("flex items-center gap-2 px-3 py-1.5 rounded-lg border text-sm font-bold shadow-sm", anamnesis.alcohol ? "bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-400" : "bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400")}>
                                Alkol: {anamnesis.alcohol ? "KULLANIYOR" : "Kullanmıyor"}
                            </div>
                        </div>
                    </Section>

                    {/* 3. Tıbbi Geçmiş */}
                    <Section title="Tıbbi Geçmiş" icon={Activity}>
                        <LabelValue label="Kronik Hastalıklar" value={anamnesis.chronicDiseases} fullWidth />
                        <LabelValue label="Önceden Görülmüş Tedaviler" value={anamnesis.previousTreatments} fullWidth />
                        <LabelValue label="Aktif Kullanılan İlaçlar" value={anamnesis.activeMedicines} fullWidth />
                        <LabelValue label="Takviyeler" value={anamnesis.supplements} fullWidth />
                    </Section>

                    {/* 4. Şikayetler */}
                    <Section title="Şikayetler ve Durum" icon={Activity}>
                        <LabelValue label="Güncel Şikayetler" value={anamnesis.complaints} fullWidth />
                        <LabelValue label="Bağırsak Problemleri" value={anamnesis.bowelProblems} fullWidth />
                    </Section>

                    {/* 5. Ürünler */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 break-inside-avoid">
                        <div className="border border-slate-200 dark:border-slate-700 rounded-xl p-5 bg-slate-50/50 dark:bg-slate-800/30 print:bg-white print:border-gray-300 shadow-sm relative overflow-hidden">
                            <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
                                <Package size={48} />
                            </div>
                            <h4 className="font-bold text-slate-800 dark:text-slate-200 mb-3 flex items-center gap-2">
                                <Package size={16} className="text-orange-500" />
                                Önerilen Ürünler
                            </h4>
                            {anamnesis.recommendedProducts && anamnesis.recommendedProducts.length > 0 ? (
                                <ul className="list-disc list-inside text-sm text-slate-700 dark:text-slate-300 space-y-1 font-medium">
                                    {anamnesis.recommendedProducts.map(p => (
                                        <li key={p.id}>{p.productName}</li>
                                    ))}
                                </ul>
                            ) : (
                                <span className="text-xs text-slate-400 italic font-medium">Ürün yok.</span>
                            )}
                        </div>

                        <div className="border border-slate-200 dark:border-slate-700 rounded-xl p-5 bg-slate-50/50 dark:bg-slate-800/30 print:bg-white print:border-gray-300 shadow-sm relative overflow-hidden">
                            <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
                                <Check size={48} />
                            </div>
                            <h4 className="font-bold text-slate-800 dark:text-slate-200 mb-3 flex items-center gap-2">
                                <div className="w-5 h-5 rounded-full bg-teal-100 dark:bg-teal-900/30 text-teal-600 dark:text-teal-400 flex items-center justify-center">
                                    <Check size={12} strokeWidth={3} />
                                </div>
                                Verilen Ürünler
                            </h4>
                            {anamnesis.givenProducts && anamnesis.givenProducts.length > 0 ? (
                                <ul className="list-disc list-inside text-sm text-slate-700 dark:text-slate-300 space-y-1 font-medium">
                                    {anamnesis.givenProducts.map(p => (
                                        <li key={p.id}>{p.productName}</li>
                                    ))}
                                </ul>
                            ) : (
                                <span className="text-xs text-slate-400 italic font-medium">Ürün yok.</span>
                            )}
                        </div>
                    </div>

                    {/* 6. Notlar */}
                    {anamnesis.notes && (
                        <div className="mt-6 break-inside-avoid">
                            <Section title="Notlar" icon={FileText}>
                                <div className="col-span-full text-sm text-slate-800 dark:text-slate-200 whitespace-pre-wrap font-medium">
                                    {anamnesis.notes}
                                </div>
                            </Section>
                        </div>
                    )}



                </div>
            </div>
        </div>
    );

    // Create portal root if not exists
    let portalRoot = document.getElementById('anamnesis-portal-root');
    if (!portalRoot) {
        portalRoot = document.createElement('div');
        portalRoot.id = 'anamnesis-portal-root';
        document.body.appendChild(portalRoot);
    }

    return createPortal(content, portalRoot);
}
