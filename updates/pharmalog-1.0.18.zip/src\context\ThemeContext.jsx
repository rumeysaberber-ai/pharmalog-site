import { createContext, useContext, useEffect, useState } from "react";

const ThemeContext = createContext();

export function ThemeProvider({ children }) {
    const [theme, setTheme] = useState(() => {
        const savedTheme = localStorage.getItem("theme");
        return savedTheme || "light";
    });

    const [primaryColor, setPrimaryColor] = useState(() => {
        return localStorage.getItem("primaryColor") || "rose";
    });

    useEffect(() => {
        const root = window.document.documentElement;

        // Remove 'dark' class first
        root.classList.remove("dark");

        // If theme is dark, add it back
        if (theme === "dark") {
            root.classList.add("dark");
        }

        console.log(`[THEME DEBUG] Current theme: ${theme}, ClassList: ${root.className}`);
        localStorage.setItem("theme", theme);
    }, [theme]);

    useEffect(() => {
        localStorage.setItem("primaryColor", primaryColor);
        // In a real advanced setup, we might inject CSS variables here for primary colors
        // For now we will expose it to components to choose utility classes
    }, [primaryColor]);

    const value = {
        theme,
        setTheme,
        primaryColor,
        setPrimaryColor
    };

    return (
        <ThemeContext.Provider value={value}>
            {children}
        </ThemeContext.Provider>
    );
}

export function useTheme() {
    const context = useContext(ThemeContext);
    if (context === undefined) {
        throw new Error("useTheme must be used within a ThemeProvider");
    }
    return context;
}
