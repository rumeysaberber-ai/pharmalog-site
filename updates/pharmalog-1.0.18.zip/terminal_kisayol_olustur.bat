@echo off
title PharmaLog Terminal Kisayol Olustur
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0terminal_kisayol_olustur.ps1"
pause
