import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { Search, Plus, Package, Tag, Building2, Barcode, Trash2, Upload, X, ArrowLeft, Edit } from "lucide-react";
import { DataService } from "../lib/data";
import { normalizeString } from "../lib/utils";
import * as XLSX from 'xlsx';

const PRODUCT_TYPES = [
    "Dermokozmetik",
    "Saç sağlığı",
    "Besin destek",
    "Aromaterapi"
];

export default function Products() {
    const [products, setProducts] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");
    const [selectedType, setSelectedType] = useState("Tümü");
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const fileInputRef = useRef(null);

    // Form State
    const [formData, setFormData] = useState({
        barcode: "",
        companyName: "",
        productName: "",
        type: PRODUCT_TYPES[0]
    });
    const [editingId, setEditingId] = useState(null);

    const [currentPage, setCurrentPage] = useState(1);
    const ITEMS_PER_PAGE = 50;

    useEffect(() => {
        DataService.getDbProducts().then(setProducts);
    }, []);

    // Reset page when filters change
    useEffect(() => {
        setCurrentPage(1);
    }, [searchTerm, selectedType]);

    const handleFileUpload = (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = async (evt) => {
            const bstr = evt.target.result;
            const wb = XLSX.read(bstr, { type: 'binary' });
            const wsname = wb.SheetNames[0];
            const ws = wb.Sheets[wsname];
            const data = XLSX.utils.sheet_to_json(ws);

            let addedCount = 0;
            let skippedCount = 0;
            const stats = {};
            PRODUCT_TYPES.forEach(t => stats[t] = 0);
            const newProductsBatch = [];

            // Existing barcodes for fast lookup
            const existingBarcodes = new Set(products.map(p => p.barcode));
            const batchBarcodes = new Set(); // To check duplicates within the excel file itself

            // Helper for case-insensitive key lookup (Turkish aware)
            const getValue = (row, keys) => {
                const rowKeys = Object.keys(row);
                for (const key of rowKeys) {
                    const normalizedKey = key.trim().toLocaleLowerCase('tr-TR');
                    if (keys.includes(normalizedKey)) {
                        return row[key];
                    }
                }
                return undefined;
            };

            data.forEach(row => {
                // Robust mapping
                const barcode = getValue(row, ['barkod', 'barcode', 'barkod no', 'barkod_no']);
                const productName = getValue(row, ['ilaç adı', 'ilac adi', 'ürün adı', 'urun adi', 'ürün ismi', 'isim', 'productname', 'name']);
                const companyName = getValue(row, ['firma', 'firma adı', 'marka', 'company', 'companyname']);
                const rawType = getValue(row, ['kategori', 'tür', 'tur', 'type', 'category']);

                if (barcode && productName) {
                    const strBarcode = String(barcode).trim();

                    // CHECK DUPLICATE
                    if (existingBarcodes.has(strBarcode) || batchBarcodes.has(strBarcode)) {
                        skippedCount++;
                        return; // Skip this product
                    }

                    // Smart Category Matching
                    let type = PRODUCT_TYPES[0]; // Default to Dermokozmetik
                    if (rawType) {
                        const normalizedRaw = String(rawType).trim().toLocaleLowerCase('tr-TR');
                        // Try exact match first
                        const exactMatch = PRODUCT_TYPES.find(t => t.toLocaleLowerCase('tr-TR') === normalizedRaw);
                        if (exactMatch) {
                            type = exactMatch;
                        } else {
                            // Fuzzy/Keyword matching
                            if (normalizedRaw.includes('saç') || normalizedRaw.includes('sac')) type = "Saç sağlığı";
                            else if (normalizedRaw.includes('besin') || normalizedRaw.includes('takviye') || normalizedRaw.includes('vitamin') || normalizedRaw.includes('mineral') || normalizedRaw.includes('gıda') || normalizedRaw.includes('gida')) type = "Besin destek";
                            else if (normalizedRaw.includes('aroma')) type = "Aromaterapi";
                            // Fallback remains the default (Dermokozmetik)
                        }
                    }

                    newProductsBatch.push({
                        barcode: strBarcode,
                        productName: String(productName).trim(),
                        companyName: String(companyName || "").trim(),
                        type: type
                    });

                    batchBarcodes.add(strBarcode);
                    stats[type]++;
                    addedCount++;
                }
            });

            if (addedCount > 0 || skippedCount > 0) {
                if (addedCount > 0) {
                    await DataService.addDbProductsBulk(newProductsBatch);
                    const updated = await DataService.getDbProducts();
                    setProducts(updated); // Refresh list
                }

                const statsMsg = Object.entries(stats)
                    .filter(([_, count]) => count > 0)
                    .map(([type, count]) => `${type}: ${count}`)
                    .join('\n');

                let message = `İşlem Tamamlandı.\n\n`;
                message += `✅ Eklendi: ${addedCount} ürün\n`;
                message += `⚠️ Atlandı (Zaten Kayıtlı): ${skippedCount} ürün\n`;

                if (addedCount > 0) {
                    message += `\nEklenenlerin Dağılımı:\n${statsMsg}`;
                }

                alert(message);
            } else {
                alert("Ürün eklenemedi. Dosyada uygun ürün bulunamadı veya tüm ürünler zaten kayıtlıydı.");
            }

            // Clear input for same file selection
            e.target.value = null;
        };
        reader.readAsBinaryString(file);
    };

    const handleDeleteAll = async () => {
        if (window.confirm("DİKKAT! Tüm ürün veritabanı silinecek. Bu işlem geri alınamaz.\n\nDevam etmek istiyor musunuz?")) {
            if (window.confirm("Gerçekten emin misiniz? Tüm veriler kaybolacak.")) {
                await DataService.deleteAllDbProducts();
                setProducts([]);
                alert("Tüm ürünler silindi.");
            }
        }
    };

    const getCount = (type) => {
        if (type === "Tümü") return products.length;
        if (type === "Tanımsız") return products.filter(p => !PRODUCT_TYPES.includes(p.type)).length;
        return products.filter(p => p.type === type).length;
    };

    // Filters
    const filteredProducts = products.filter(p => {
        const term = normalizeString(searchTerm);
        const productName = normalizeString(p.productName);
        const companyName = normalizeString(p.companyName);
        const barcode = p.barcode.toLowerCase(); // Barcode usually numeric or basic ascii

        // Multi-word search logic
        const searchWords = term.split(/\s+/).filter(word => word.length > 0);
        const nameMatch = searchWords.every(word => productName.includes(word));
        const companyMatch = searchWords.every(word => companyName.includes(word));

        const matchesSearch = nameMatch || barcode.includes(term) || companyMatch;

        let matchesType = true;
        if (selectedType === "Tümü") matchesType = true;
        else if (selectedType === "Tanımsız") matchesType = !PRODUCT_TYPES.includes(p.type);
        else matchesType = p.type === selectedType;

        return matchesSearch && matchesType;
    });

    // Pagination Logic
    const totalPages = Math.ceil(filteredProducts.length / ITEMS_PER_PAGE);
    const currentItems = filteredProducts.slice(
        (currentPage - 1) * ITEMS_PER_PAGE,
        currentPage * ITEMS_PER_PAGE
    );

    const handleDeleteProduct = async (e, id) => {
        e.stopPropagation();
        if (window.confirm("Bu ürünü silmek istediğinize emin misiniz?")) {
            const updated = await DataService.deleteDbProduct(id);
            setProducts([...updated]); // Create new reference to force re-render
        }
    };

    const handleSaveProduct = async (e) => {
        e.preventDefault();
        if (!formData.productName) return;

        // Check for duplicate barcode (exclude current product if editing)
        const existingProduct = products.find(p => p.barcode === formData.barcode && p.id !== editingId);
        if (existingProduct) {
            alert(`Bu barkod numarası (${formData.barcode}) zaten "${existingProduct.productName}" adıyla kayıtlı!`);
            return;
        }

        try {
            if (editingId) {
                // Update
                await DataService.updateDbProduct(editingId, formData);
                // Refresh list to ensure consistency
                const updatedList = await DataService.getDbProducts();
                setProducts(updatedList);
            } else {
                // Add
                const newProduct = await DataService.addDbProduct(formData);
                setProducts([newProduct, ...products]);
            }

            closeModal();
        } catch (error) {
            alert(error?.message || "Ürün kaydedilemedi.");
        }
    };

    const openEditModal = (product) => {
        setFormData({
            barcode: product.barcode,
            companyName: product.companyName,
            productName: product.productName,
            type: product.type
        });
        setEditingId(product.id);
        setIsAddModalOpen(true);
    };

    const closeModal = () => {
        setIsAddModalOpen(false);
        setEditingId(null);
        setFormData({ barcode: "", companyName: "", productName: "", type: PRODUCT_TYPES[0] });
    };

    return (
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
            {/* Header & Actions */}
            <Link to="/" className="inline-flex items-center text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 transition-colors mb-6 group">
                <div className="p-2 rounded-full bg-white dark:bg-slate-800 group-hover:bg-indigo-50 dark:group-hover:bg-indigo-900/30 mr-2 transition-colors shadow-sm">
                    <ArrowLeft size={18} />
                </div>
                <span className="font-medium">Ana Ekrana Dön</span>
            </Link>
            <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-6 mb-8">
                <div>
                    <h1 className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-slate-900 to-slate-700 dark:from-white dark:to-slate-300">Ürün Veritabanı</h1>
                    <p className="text-slate-500 dark:text-slate-400 mt-1 font-medium">
                        Stoktaki veya sistemdeki tüm ürünlerin listesi.
                        <span className="font-bold text-teal-600 dark:text-teal-400 ml-2 bg-teal-50 dark:bg-teal-900/30 px-2 py-0.5 rounded-md">
                            {products.length} Ürün
                        </span>
                    </p>
                </div>

                <div className="flex flex-wrap gap-3">
                    <input
                        type="file"
                        accept=".xlsx, .xls"
                        ref={fileInputRef}
                        onChange={handleFileUpload}
                        className="hidden"
                    />
                    <button
                        onClick={handleDeleteAll}
                        className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm border border-red-200 dark:border-red-900/30 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 px-4 py-2.5 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-sm hover:shadow-md"
                    >
                        <Trash2 size={20} />
                        <span className="hidden sm:inline">Tümünü Sil</span>
                    </button>
                    <button
                        onClick={() => fileInputRef.current.click()}
                        className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 px-4 py-2.5 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-sm hover:shadow-md"
                    >
                        <Upload size={20} />
                        <span className="hidden sm:inline">Excel ile Yükle</span>
                    </button>
                    <button
                        onClick={() => {
                            setEditingId(null);
                            setFormData({ barcode: "", companyName: "", productName: "", type: PRODUCT_TYPES[0] });
                            setIsAddModalOpen(true);
                        }}
                        className="bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 text-white px-5 py-2.5 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-lg shadow-teal-500/30 hover:shadow-teal-500/50 hover:-translate-y-0.5"
                    >
                        <Plus size={20} strokeWidth={3} />
                        <span className="hidden sm:inline">Yeni Ürün</span>
                    </button>
                </div>
            </div>

            {/* Category Tabs */}
            <div className="flex overflow-x-auto pb-4 gap-3 mb-4 no-scrollbar">
                <button
                    onClick={() => setSelectedType("Tümü")}
                    className={`px-5 py-2.5 rounded-full text-sm font-bold whitespace-nowrap transition-all flex items-center gap-2 shadow-sm ${selectedType === "Tümü"
                        ? "bg-slate-800 text-white shadow-slate-500/20 scale-105"
                        : "bg-white dark:bg-slate-900 text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800"
                        }`}
                >
                    Tümü
                    <span className={`px-2 py-0.5 rounded-full text-[10px] ${selectedType === "Tümü" ? "bg-slate-600 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"}`}>
                        {getCount("Tümü")}
                    </span>
                </button>
                {PRODUCT_TYPES.map(type => (
                    <button
                        key={type}
                        onClick={() => setSelectedType(type)}
                        className={`px-5 py-2.5 rounded-full text-sm font-bold whitespace-nowrap transition-all flex items-center gap-2 shadow-sm ${selectedType === type
                            ? "bg-teal-600 text-white shadow-teal-500/30 scale-105"
                            : "bg-white dark:bg-slate-900 text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800"
                            }`}
                    >
                        {type}
                        <span className={`px-2 py-0.5 rounded-full text-[10px] ${selectedType === type ? "bg-teal-500 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"}`}>
                            {getCount(type)}
                        </span>
                    </button>
                ))}

                {/* Dynamically show Undefined category if exists */}
                {getCount("Tanımsız") > 0 && (
                    <button
                        onClick={() => setSelectedType("Tanımsız")}
                        className={`px-5 py-2.5 rounded-full text-sm font-bold whitespace-nowrap transition-all flex items-center gap-2 shadow-sm ${selectedType === "Tanımsız"
                            ? "bg-rose-600 text-white shadow-rose-500/30 scale-105"
                            : "bg-white dark:bg-slate-900 text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800"
                            }`}
                    >
                        Tanımsız
                        <span className={`px-2 py-0.5 rounded-full text-[10px] ${selectedType === "Tanımsız" ? "bg-rose-500 text-white" : "bg-rose-100 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400"}`}>
                            {getCount("Tanımsız")}
                        </span>
                    </button>
                )}
            </div>

            {/* Search Bar */}
            <div className="flex flex-col sm:flex-row gap-4 mb-6 p-4 bg-white/40 dark:bg-slate-900/40 backdrop-blur-xl rounded-2xl border border-white/20 dark:border-slate-800 shadow-sm">
                <div className="relative flex-1">
                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <Search className="h-5 w-5 text-slate-400" />
                    </div>
                    <input
                        type="text"
                        className="block w-full pl-11 pr-4 py-3 bg-white/60 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 rounded-xl leading-5 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 transition-all shadow-sm backdrop-blur-sm"
                        placeholder="Ürün adı, barkod veya firma ile arama..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                    {searchTerm && (
                        <button
                            onClick={() => setSearchTerm("")}
                            className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600"
                        >
                            <X size={20} />
                        </button>
                    )}
                </div>
            </div>

            {/* Products List */}
            <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl rounded-2xl border border-white/20 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-black/20 overflow-hidden flex flex-col">
                {currentItems.length > 0 ? (
                    <>
                        <div className="overflow-x-auto bg-transparent">
                            <table className="min-w-full divide-y divide-slate-100/50 dark:divide-slate-800/50">
                                <thead className="bg-slate-50/50 dark:bg-slate-900/50">
                                    <tr>
                                        <th className="px-6 py-4 text-left text-xs font-bold text-slate-400 uppercase tracking-widest w-1/3">Ürün Bilgisi</th>
                                        <th className="px-6 py-4 text-left text-xs font-bold text-slate-400 uppercase tracking-widest">Firma</th>
                                        <th className="px-6 py-4 text-left text-xs font-bold text-slate-400 uppercase tracking-widest">Tür</th>
                                        <th className="px-6 py-4 text-left text-xs font-bold text-slate-400 uppercase tracking-widest">Barkod</th>
                                        <th className="px-6 py-4 text-right text-xs font-bold text-slate-400 uppercase tracking-widest">İşlem</th>
                                    </tr>
                                </thead>
                                <tbody className="bg-transparent divide-y divide-slate-100/50 dark:divide-slate-800/50">
                                    {currentItems.map((product) => (
                                        <tr key={product.id} className="hover:bg-indigo-50/30 dark:hover:bg-indigo-900/10 transition-colors group">
                                            <td className="px-6 py-4 whitespace-normal">
                                                <div className="flex items-start">
                                                    <div className="flex-shrink-0 h-10 w-10 bg-white dark:bg-slate-800 rounded-lg flex items-center justify-center text-teal-500 border border-slate-100 dark:border-slate-700 shadow-sm mt-1">
                                                        <Package size={20} />
                                                    </div>
                                                    <div className="ml-4">
                                                        <div className="text-sm font-bold text-slate-900 dark:text-white break-words">{product.productName}</div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td className="px-6 py-4 whitespace-normal">
                                                <div className="flex items-center text-sm text-slate-600 dark:text-slate-300 gap-2 font-medium">
                                                    <Building2 size={16} className="text-slate-300 dark:text-slate-600 flex-shrink-0" />
                                                    <span className="break-words">{product.companyName}</span>
                                                </div>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap">
                                                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                                                    {product.type}
                                                </span>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400 font-mono tracking-wide">
                                                <div className="flex items-center gap-2">
                                                    <Barcode size={16} className="text-slate-300" />
                                                    {product.barcode}
                                                </div>
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                                <button
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        openEditModal(product);
                                                    }}
                                                    className="p-2 text-slate-300 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-full transition-colors mr-1"
                                                    title="Düzenle"
                                                >
                                                    <Edit size={18} />
                                                </button>
                                                <button
                                                    onClick={(e) => handleDeleteProduct(e, product.id)}
                                                    className="p-2 text-slate-300 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-full transition-colors"
                                                    title="Ürünü Sil"
                                                >
                                                    <Trash2 size={18} />
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                        {/* Pagination Controls */}
                        {totalPages > 1 && (
                            <div className="px-6 py-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between bg-white/50 dark:bg-slate-900/50 gap-4">
                                <button
                                    onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                                    disabled={currentPage === 1}
                                    className="px-4 py-2 text-sm font-bold text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed hidden sm:block shadow-sm"
                                >
                                    Önceki
                                </button>

                                <div className="flex items-center gap-1 overflow-x-auto no-scrollbar justify-center flex-1">
                                    {(() => {
                                        let pages = [];
                                        if (totalPages <= 7) {
                                            pages = Array.from({ length: totalPages }, (_, i) => i + 1);
                                        } else {
                                            if (currentPage <= 4) {
                                                pages = [1, 2, 3, 4, 5, '...', totalPages];
                                            } else if (currentPage >= totalPages - 3) {
                                                pages = [1, '...', totalPages - 4, totalPages - 3, totalPages - 2, totalPages - 1, totalPages];
                                            } else {
                                                pages = [1, '...', currentPage - 1, currentPage, currentPage + 1, '...', totalPages];
                                            }
                                        }

                                        return pages.map((page, idx) => (
                                            <button
                                                key={idx}
                                                onClick={() => typeof page === 'number' && setCurrentPage(page)}
                                                disabled={page === '...'}
                                                className={`min-w-[36px] h-9 flex items-center justify-center text-sm font-bold rounded-xl transition-all ${page === currentPage
                                                    ? "bg-teal-600 text-white shadow-lg shadow-teal-500/30"
                                                    : page === '...'
                                                        ? "text-slate-400 cursor-default"
                                                        : "bg-transparent text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                                                    }`}
                                            >
                                                {page}
                                            </button>
                                        ));
                                    })()}
                                </div>

                                <button
                                    onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                                    disabled={currentPage === totalPages}
                                    className="px-4 py-2 text-sm font-bold text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed hidden sm:block shadow-sm"
                                >
                                    Sonraki
                                </button>
                            </div>
                        )}
                    </>
                ) : (
                    <div className="p-16 text-center flex flex-col items-center justify-center">
                        <div className="w-20 h-20 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center mb-6">
                            <Package className="h-10 w-10 text-slate-300 dark:text-slate-600" />
                        </div>
                        <h3 className="text-xl font-bold text-slate-900 dark:text-white">Ürün Bulunamadı</h3>
                        <p className="text-slate-500 dark:text-slate-400 mt-2 max-w-sm mx-auto">
                            {searchTerm ? "Aradığınız kriterlere uygun ürün bulunamadı." : "Henüz veritabanına ürün eklenmemiş."}
                        </p>
                    </div>
                )}
            </div>

            {/* Add Product Modal */}
            {
                isAddModalOpen && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-300">
                        <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden animate-in zoom-in-95 duration-300 border border-white/20 dark:border-slate-800 ring-1 ring-black/5">
                            <div className="px-8 py-6 border-b border-slate-100 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-sm flex items-center justify-between">
                                <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                                    {editingId ? "Ürünü Düzenle" : "Yeni Ürün Ekle"}
                                </h3>
                                <button
                                    onClick={closeModal}
                                    className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 bg-slate-100 dark:bg-slate-800 p-2 rounded-full hover:bg-slate-200 transition-colors"
                                >
                                    <X size={20} />
                                </button>
                            </div>

                            <form onSubmit={handleSaveProduct} className="p-8 space-y-6">

                                <div>
                                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Barkod No</label>
                                    <div className="relative">
                                        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                            <Barcode size={18} className="text-slate-400" />
                                        </div>
                                        <input
                                            required
                                            type="text"
                                            className="w-full pl-12 rounded-xl border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white border px-4 py-3 focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500 transition-all font-medium placeholder:font-normal"
                                            placeholder="869..."
                                            value={formData.barcode}
                                            onChange={e => setFormData({ ...formData, barcode: e.target.value })}
                                        />
                                    </div>
                                </div>

                                <div>
                                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Firma Adı</label>
                                    <div className="relative">
                                        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                            <Building2 size={18} className="text-slate-400" />
                                        </div>
                                        <input
                                            required
                                            type="text"
                                            className="w-full pl-12 rounded-xl border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white border px-4 py-3 focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500 transition-all font-medium placeholder:font-normal"
                                            placeholder="Örn: DermaCo"
                                            value={formData.companyName}
                                            onChange={e => setFormData({ ...formData, companyName: e.target.value })}
                                        />
                                    </div>
                                </div>

                                <div>
                                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Ürün Adı</label>
                                    <div className="relative">
                                        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                            <Package size={18} className="text-slate-400" />
                                        </div>
                                        <input
                                            required
                                            type="text"
                                            className="w-full pl-12 rounded-xl border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white border px-4 py-3 focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500 transition-all font-medium placeholder:font-normal"
                                            placeholder="Örn: Yüz Yıkama Jeli"
                                            value={formData.productName}
                                            onChange={e => setFormData({ ...formData, productName: e.target.value })}
                                        />
                                    </div>
                                </div>

                                <div>
                                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Tür</label>
                                    <div className="relative">
                                        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                            <Tag size={18} className="text-slate-400" />
                                        </div>
                                        <select
                                            className="w-full pl-12 rounded-xl border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white border px-4 py-3 focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500 transition-all font-medium appearance-none"
                                            value={formData.type}
                                            onChange={e => setFormData({ ...formData, type: e.target.value })}
                                        >
                                            {PRODUCT_TYPES.map(type => (
                                                <option key={type} value={type}>{type}</option>
                                            ))}
                                        </select>
                                    </div>
                                </div>

                                <div className="pt-4 flex justify-end gap-3">
                                    <button
                                        type="button"
                                        onClick={closeModal}
                                        className="px-6 py-3 text-slate-600 dark:text-slate-400 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
                                    >
                                        İptal
                                    </button>
                                    <button
                                        type="submit"
                                        className="px-6 py-3 bg-gradient-to-r from-teal-500 to-emerald-600 text-white font-bold rounded-xl hover:shadow-lg hover:shadow-teal-500/30 transition-all hover:-translate-y-0.5"
                                    >
                                        {editingId ? "Güncelle" : "Kaydet"}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                )
            }
        </div >
    )
}
