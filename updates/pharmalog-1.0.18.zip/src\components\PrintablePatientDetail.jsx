import React from 'react';
import { format, parseISO } from "date-fns";
import { tr } from "date-fns/locale";
import { formatPhoneNumber } from "../lib/utils";

import logo from "../assets/pharmalog_logo.png";

export default function PrintablePatientDetail({ patient }) {
    if (!patient) return null;

    // Safe helpers to prevent crashes
    const formatDate = (dateStr) => {
        if (!dateStr) return "-";
        try {
            return format(parseISO(dateStr), "d MMMM yyyy", { locale: tr });
        } catch (e) {
            return dateStr;
        }
    };

    // Helper to check if object has any valid keys for a section
    const hasData = (obj, keys) => keys.some(k => obj && obj[k]);

    const safeVisits = Array.isArray(patient.visits) ? [...patient.visits].sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0)) : [];
    const anamnesis = patient.detailedAnamnesis || {};
    const dermo = patient.dermoAnamnesis || {};
    const skinCare = patient.skinCareData || {};
    const transactions = Array.isArray(skinCare.transactions) ? skinCare.transactions : [];

    // Data Presence Checks
    const hasPhysical = hasData(anamnesis, ['height', 'weight', 'bmi', 'smoking', 'alcohol']);
    const hasMedical = hasData(anamnesis, ['chronicDiseases', 'previousTreatments', 'activeMedicines']);
    const hasComplaints = hasData(anamnesis, ['complaints', 'supplements', 'bowelProblems']);
    const hasDermo = dermo.complaint || dermo.expectation || (dermo.skinType && dermo.skinType.length > 0) || (dermo.skinCondition && dermo.skinCondition.length > 0) || (dermo.specialCondition && dermo.specialCondition.length > 0);
    const hasGivenProducts = Array.isArray(anamnesis.givenProducts) && anamnesis.givenProducts.length > 0;
    const hasRecProducts = Array.isArray(anamnesis.recommendedProducts) && anamnesis.recommendedProducts.length > 0;


    return (
        <div className="hidden print:block print:absolute print:top-0 print:left-0 print:w-full print:bg-white print:z-[9999] font-sans text-slate-900 bg-white w-full max-w-[210mm] mx-auto p-8 leading-relaxed text-xs">
            {/* Header */}
            <div className="flex justify-between items-center border-b-2 border-slate-800 pb-4 mb-6">
                <div className="flex items-center gap-4">
                    <img src={logo} alt="PharmaLog Logo" className="h-16 w-auto object-contain" />
                    <div>
                        <h1 className="text-xl font-bold text-slate-900 tracking-tight">PharmaLog</h1>
                        <p className="text-xs font-medium text-slate-500 uppercase tracking-widest">Gelişmiş Danışan Takip Sistemi</p>
                    </div>
                </div>
                <div className="text-right">
                    <div className="text-xs text-slate-500 font-medium">Rapor Tarihi</div>
                    <div className="text-base font-bold text-slate-800">{format(new Date(), "d MMMM yyyy", { locale: tr })}</div>
                </div>
            </div>

            {/* Patient Header Card */}
            <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 mb-6 flex justify-between items-start gap-4">
                <div>
                    <h2 className="text-2xl font-black text-slate-900 mb-1">{patient.fullName}</h2>
                    <div className="flex items-center gap-4 text-xs text-slate-600 font-medium uppercase tracking-wide">
                        {patient.birthDate && (
                            <>
                                <span>DOĞUM: {formatDate(patient.birthDate)}</span>
                                <span className="w-1 h-1 bg-slate-400 rounded-full"></span>
                            </>
                        )}
                        {patient.age && <span>YAŞ: {patient.age}</span>}
                    </div>
                </div>
                <div className="text-right">
                    {patient.phone && (
                        <>
                            <div className="text-lg font-bold text-slate-800 font-mono">{formatPhoneNumber(patient.phone)}</div>
                            <div className="text-[10px] text-slate-500 font-medium uppercase mt-0.5">İletişim</div>
                        </>
                    )}
                </div>
            </div>

            {/* --- BLOCK 1: PHYSICAL & HABITS (Detailed Anamnesis) --- */}
            {hasPhysical && (
                <div className="mb-6">
                    <h3 className="text-xs font-bold text-slate-900 border-b border-slate-300 pb-1 mb-3 uppercase tracking-wider">Fiziksel Durum ve Alışkanlıklar</h3>
                    <div className="grid grid-cols-4 gap-4">
                        {(anamnesis.height || anamnesis.weight) && (
                            <div className="bg-slate-50 p-2 rounded border border-slate-100">
                                <span className="block text-[10px] text-slate-500 uppercase">Boy / Kilo</span>
                                <span className="font-bold text-slate-900">
                                    {anamnesis.height ? `${anamnesis.height} cm` : ''}
                                    {anamnesis.height && anamnesis.weight ? ' / ' : ''}
                                    {anamnesis.weight ? `${anamnesis.weight} kg` : ''}
                                </span>
                            </div>
                        )}
                        {anamnesis.bmi && (
                            <div className="bg-slate-50 p-2 rounded border border-slate-100">
                                <span className="block text-[10px] text-slate-500 uppercase">VKİ</span>
                                <span className="font-bold text-slate-900">{anamnesis.bmi}</span>
                            </div>
                        )}
                        {anamnesis.smoking && (
                            <div className="bg-slate-50 p-2 rounded border border-slate-100">
                                <span className="block text-[10px] text-slate-500 uppercase">Sigara</span>
                                <span className="font-bold text-slate-900">EVET</span>
                            </div>
                        )}
                        {anamnesis.alcohol && (
                            <div className="bg-slate-50 p-2 rounded border border-slate-100">
                                <span className="block text-[10px] text-slate-500 uppercase">Alkol</span>
                                <span className="font-bold text-slate-900">EVET</span>
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* --- BLOCK 2: MEDICAL INFO (Detailed Anamnesis) --- */}
            {(hasMedical || hasComplaints) && (
                <div className="mb-6 grid grid-cols-2 gap-6">
                    {hasMedical && (
                        <div>
                            <h3 className="text-xs font-bold text-slate-900 border-b border-slate-300 pb-1 mb-3 uppercase tracking-wider">Tıbbi Geçmiş</h3>
                            <ul className="space-y-2 text-xs">
                                {anamnesis.chronicDiseases && (
                                    <li className="flex flex-col">
                                        <span className="text-[10px] font-bold text-slate-500 uppercase">Kronik Rahatsızlıklar</span>
                                        <span className="text-slate-900 border-l-2 border-slate-300 pl-2">{anamnesis.chronicDiseases}</span>
                                    </li>
                                )}
                                {anamnesis.previousTreatments && (
                                    <li className="flex flex-col">
                                        <span className="text-[10px] font-bold text-slate-500 uppercase">Daha Önceki Tedaviler</span>
                                        <span className="text-slate-900 border-l-2 border-slate-300 pl-2">{anamnesis.previousTreatments}</span>
                                    </li>
                                )}
                                {anamnesis.activeMedicines && (
                                    <li className="flex flex-col">
                                        <span className="text-[10px] font-bold text-slate-500 uppercase">Kullanılan İlaçlar</span>
                                        <span className="text-slate-900 border-l-2 border-slate-300 pl-2">{anamnesis.activeMedicines}</span>
                                    </li>
                                )}
                            </ul>
                        </div>
                    )}
                    {hasComplaints && (
                        <div>
                            <h3 className="text-xs font-bold text-slate-900 border-b border-slate-300 pb-1 mb-3 uppercase tracking-wider">Şikayet ve Durum</h3>
                            <ul className="space-y-2 text-xs">
                                {anamnesis.complaints && (
                                    <li className="flex flex-col">
                                        <span className="text-[10px] font-bold text-slate-500 uppercase">Şikayetler</span>
                                        <span className="text-slate-900 border-l-2 border-slate-300 pl-2">{anamnesis.complaints}</span>
                                    </li>
                                )}
                                {anamnesis.supplements && (
                                    <li className="flex flex-col">
                                        <span className="text-[10px] font-bold text-slate-500 uppercase">Takviyeler</span>
                                        <span className="text-slate-900 border-l-2 border-slate-300 pl-2">{anamnesis.supplements}</span>
                                    </li>
                                )}
                                {anamnesis.bowelProblems && (
                                    <li className="flex flex-col">
                                        <span className="text-[10px] font-bold text-slate-500 uppercase">Bağırsak Problemleri</span>
                                        <span className="text-slate-900 border-l-2 border-slate-300 pl-2">{anamnesis.bowelProblems}</span>
                                    </li>
                                )}
                            </ul>
                        </div>
                    )}
                </div>
            )}

            {/* --- BLOCK 3: DERMO ANALYSIS --- */}
            {hasDermo && (
                <div className="mb-6 break-inside-avoid">
                    <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
                        <h3 className="text-xs font-bold text-teal-700 mb-3 uppercase tracking-wider flex items-center gap-2">
                            Dermokozmetik Analiz
                        </h3>
                        <div className="grid grid-cols-2 gap-x-8 gap-y-4 text-xs">
                            {dermo.complaint && (
                                <div className="col-span-2">
                                    <span className="font-bold text-slate-600 mr-2">Ana Şikayet:</span>
                                    <span>{dermo.complaint}</span>
                                </div>
                            )}
                            {dermo.expectation && (
                                <div className="col-span-2">
                                    <span className="font-bold text-slate-600 mr-2">Beklenti:</span>
                                    <span>{dermo.expectation}</span>
                                </div>
                            )}

                            {/* Cilt Tipi */}
                            {(dermo.skinType && (typeof dermo.skinType === 'string' || dermo.skinType.length > 0)) && (
                                <div>
                                    <span className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Cilt Tipi</span>
                                    <div className="flex flex-wrap gap-1">
                                        {Array.isArray(dermo.skinType)
                                            ? dermo.skinType.map((t, i) => <span key={i} className="bg-white border text-slate-700 px-2 py-0.5 rounded">{t}</span>)
                                            : <span className="bg-white border text-slate-700 px-2 py-0.5 rounded">{dermo.skinType}</span>
                                        }
                                    </div>
                                </div>
                            )}

                            {/* Cilt Durumu */}
                            {Array.isArray(dermo.skinCondition) && dermo.skinCondition.length > 0 && (
                                <div>
                                    <span className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Cilt Durumu</span>
                                    <div className="flex flex-wrap gap-1">
                                        {dermo.skinCondition.map((t, i) => <span key={i} className="bg-white border text-slate-700 px-2 py-0.5 rounded">{t}</span>)}
                                    </div>
                                </div>
                            )}

                            {/* Göz Çevresi */}
                            {Array.isArray(dermo.eyeCondition) && dermo.eyeCondition.length > 0 && (
                                <div>
                                    <span className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Göz Çevresi</span>
                                    <div className="flex flex-wrap gap-1">
                                        {dermo.eyeCondition.map((t, i) => <span key={i} className="bg-white border text-slate-700 px-2 py-0.5 rounded">{t}</span>)}
                                    </div>
                                </div>
                            )}

                            {/* Saç Durumu */}
                            {Array.isArray(dermo.hairCondition) && dermo.hairCondition.length > 0 && (
                                <div>
                                    <span className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Saç Durumu</span>
                                    <div className="flex flex-wrap gap-1">
                                        {dermo.hairCondition.map((t, i) => <span key={i} className="bg-white border text-slate-700 px-2 py-0.5 rounded">{t}</span>)}
                                    </div>
                                </div>
                            )}

                            {/* Vücut Durumu */}
                            {Array.isArray(dermo.bodyCondition) && dermo.bodyCondition.length > 0 && (
                                <div>
                                    <span className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Vücut Durumu</span>
                                    <div className="flex flex-wrap gap-1">
                                        {dermo.bodyCondition.map((t, i) => <span key={i} className="bg-white border text-slate-700 px-2 py-0.5 rounded">{t}</span>)}
                                    </div>
                                </div>
                            )}

                            {/* Özel Durumlar */}
                            {Array.isArray(dermo.specialCondition) && dermo.specialCondition.length > 0 && (
                                <div className="col-span-2">
                                    <span className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Özel Durumlar</span>
                                    <div className="flex flex-wrap gap-1">
                                        {dermo.specialCondition.map((t, i) => <span key={i} className="bg-white border text-slate-700 px-2 py-0.5 rounded">{t}</span>)}
                                    </div>
                                </div>
                            )}

                            {/* Alışkanlıklar (Dermo sekmesinden gelenler) */}
                            {Array.isArray(dermo.habits) && dermo.habits.length > 0 && (
                                <div className="col-span-2">
                                    <span className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Alışkanlıklar</span>
                                    <div className="flex flex-wrap gap-1">
                                        {dermo.habits.map((t, i) => <span key={i} className="bg-white border text-slate-700 px-2 py-0.5 rounded">{t}</span>)}
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}



            {/* --- BLOCK 5: SKIN CARE TRACKING --- */}
            {transactions.length > 0 && (
                <div className="mb-8 break-inside-avoid">
                    <h3 className="text-xs font-bold text-slate-900 border-b border-slate-300 pb-1 mb-3 uppercase tracking-wider flex justify-between">
                        <span>Cilt Bakım Geçmişi</span>
                        <span>Kalan Hak: {skinCare.freeRights || 0}</span>
                    </h3>
                    <table className="w-full text-xs text-left border border-slate-200">
                        <thead className="bg-slate-100 text-slate-600 uppercase font-bold">
                            <tr>
                                <th className="p-2 border-r border-slate-200">Tarih</th>
                                <th className="p-2 border-r border-slate-200">İşlem</th>
                                <th className="p-2 border-r border-slate-200">Açıklama</th>
                                <th className="p-2 text-right">Değer</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {transactions.slice(0, 10).map((t, idx) => {
                                let dateDisplay = "-";
                                try {
                                    if (t.date) {
                                        dateDisplay = format(parseISO(t.date), "dd.MM.yyyy");
                                    }
                                } catch (err) {
                                    dateDisplay = "-";
                                }

                                return (
                                    <tr key={t.id || `tx-${idx}`}>
                                        <td className="p-2 border-r border-slate-100 font-mono text-slate-500 w-24">{dateDisplay}</td>
                                        <td className="p-2 border-r border-slate-100 w-32 font-bold">
                                            {t.type === 'add_right' ? 'Hak Tanımlama' :
                                                t.type === 'use_right' ? 'Hak Kullanımı' :
                                                    t.type === 'paid_service' ? 'Ücretli İşlem' : 'Diğer'}
                                        </td>
                                        <td className="p-2 border-r border-slate-100">{t.description}</td>
                                        <td className="p-2 text-right font-mono">
                                            {t.type === 'add_right' ? `+${t.value}` :
                                                t.type === 'use_right' ? '-1' :
                                                    t.type === 'paid_service' ? `${t.amount} TL` : '-'}
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            )}

            {/* --- BLOCK 6: GENERAL VISITS --- */}
            {safeVisits.length > 0 && (
                <div>
                    <h3 className="text-xs font-bold text-slate-900 border-b-2 border-slate-900 pb-2 mb-4 uppercase tracking-wider">
                        Genel Ziyaret Geçmişi ({safeVisits.length})
                    </h3>
                    <div className="space-y-4">
                        {safeVisits.slice(0, 15).map((visit, idx) => (
                            <div key={visit.id || `visit-${idx}`} className="flex gap-4 border-b border-slate-100 pb-4 break-inside-avoid">
                                <div className="w-24 flex-shrink-0">
                                    <div className="font-bold text-slate-900">{formatDate(visit.date)}</div>
                                    <div className="text-[10px] text-slate-500 uppercase">{visit.type}</div>
                                </div>
                                <div className="flex-1">
                                    {visit.note && (
                                        <div className="text-xs text-slate-700 bg-slate-50 p-2 rounded mb-2">
                                            {visit.note}
                                        </div>
                                    )}
                                    {Array.isArray(visit.products) && visit.products.length > 0 && (
                                        <div className="flex flex-col gap-1 mt-1">
                                            {visit.products.map((p, i) => (
                                                <div key={i} className="text-[10px] border border-slate-200 px-2 py-1 rounded text-slate-700 bg-white">
                                                    <span className="font-bold text-slate-800">{p.productName}</span>
                                                    {p.notes && <span className="text-slate-500 italic ml-2">- {p.notes}</span>}
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* Footer */}
            <div className="mt-8 pt-4 border-t border-slate-200 flex justify-between items-center text-[8px] text-slate-400 uppercase tracking-wider">
                <div>PharmaLog Otomasyon Sistemi</div>
                <div>{new Date().toLocaleString('tr-TR')}</div>
            </div>
        </div>
    );
}
