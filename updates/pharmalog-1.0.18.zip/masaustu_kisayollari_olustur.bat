@echo off
title PharmaLog Kisayol Olustur
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0masaustu_kisayollari_olustur.ps1"
pause
