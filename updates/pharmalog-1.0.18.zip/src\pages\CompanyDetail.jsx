import React, { useState, useEffect, useRef } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import {
    Calendar as CalendarIcon, Clock, MapPin, Phone, Mail, Globe, User, Plus, Search,
    Filter, ArrowUpDown, MoreVertical, Edit2, Trash2, CheckCircle, XCircle,
    AlertCircle, ChevronRight, Share2, CalendarClock, MessageCircle, Ban, History, X,
    ArrowLeft, Info, Printer, ArrowRight, Package, Calendar, Star, Link as LinkIcon
} from 'lucide-react';
import { DataService } from "../lib/data";
import { cn, normalizeString, formatPhoneNumber, copyToClipboard, generateUUID } from "../lib/utils";
import { format, parseISO } from "date-fns";
import { tr } from "date-fns/locale";
import InvitationModal from "../components/InvitationModal";

// Simple Error Boundary Implementation
class ErrorBoundary extends React.Component {
    constructor(props) {
        super(props);
        this.state = { hasError: false, error: null };
    }

    static getDerivedStateFromError(error) {
        return { hasError: true, error };
    }

    componentDidCatch(error, errorInfo) {
        console.error("ErrorBoundary caught an error:", error, errorInfo);
    }

    render() {
        if (this.state.hasError) {
            return (
                <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm flex flex-col items-center justify-center h-full min-h-[100px]">
                    <h4 className="font-bold mb-1">Bir hata oluştu</h4>
                    <p className="mb-2 max-w-xs text-center">{this.state.error?.message || "Bilinmeyen bir hata."}</p>
                    <div className="flex gap-2">
                        <button
                            onClick={() => this.setState({ hasError: false })}
                            className="bg-red-100 hover:bg-red-200 px-3 py-1 rounded transition-colors text-xs font-bold"
                        >
                            Tekrar Dene
                        </button>
                        {this.props.onClose && (
                            <button
                                onClick={() => {
                                    this.setState({ hasError: false });
                                    this.props.onClose();
                                }}
                                className="bg-white border border-red-200 hover:bg-red-50 text-red-600 px-3 py-1 rounded transition-colors text-xs font-bold"
                            >
                                Kapat
                            </button>
                        )}
                    </div>
                </div>
            );
        }

        return this.props.children;
    }
}

export default function CompanyDetail() {
    // Nuclear option removed, attempting normal safe render.
    const { id } = useParams();
    const navigate = useNavigate();
    const location = useLocation();
    const [company, setCompany] = useState(null);
    const [patients, setPatients] = useState([]);
    const scrollProcessed = useRef(false);

    // Expert Day Management
    const [isAddDayModalOpen, setIsAddDayModalOpen] = useState(false);
    const [dayForm, setDayForm] = useState({ date: "", note: "", startHour: "09:00", endHour: "18:00", slotDuration: 30 });

    // Invitation Management
    const [selectedDay, setSelectedDay] = useState(null); // The day currently being managed
    const [inviteSearchTerm, setInviteSearchTerm] = useState("");
    const [invitedSearchTerm, setInvitedSearchTerm] = useState("");
    const [filterInterested, setFilterInterested] = useState(false);
    const [sortOption, setSortOption] = useState("date_new"); // "date_new", "date_old", "alphabetical_asc", "alphabetical_desc"

    // Quick Add Patient State
    const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);
    const [quickAddForm, setQuickAddForm] = useState({ fullName: "", phone: "", description: "" });

    // Appointment Settings
    const [slotSettings, setSlotSettings] = useState({
        startHour: "09:00",
        endHour: "18:00",
        slotDuration: 30
    });

    // Appointment Selection Modal
    const [isAppointmentModalOpen, setIsAppointmentModalOpen] = useState(false);
    const [appointmentTargetPatientId, setAppointmentTargetPatientId] = useState(null);

    // Transfer Logic
    const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
    const [transferSourceDay, setTransferSourceDay] = useState(null);
    const [transferTargetDay, setTransferTargetDay] = useState(null);
    const [transferConfig, setTransferConfig] = useState({
        transferUncalled: true,
        transferPostponed: true,
        transferUnreachable: true,
        transferAttended: false,
        transferNoShow: false
    });

    // Multi-Select Appointment State
    const [isMultiSelect, setIsMultiSelect] = useState(false);
    const [selectedSlots, setSelectedSlots] = useState([]);

    // Initial Load & Real-time Subscription
    useEffect(() => {
        loadData();

        const handleDataChange = () => {
            console.log("Real-time update received, reloading...");
            loadData();
        };

        window.addEventListener('data-change', handleDataChange);
        return () => window.removeEventListener('data-change', handleDataChange);
    }, [id]);

    useEffect(() => {
        if (selectedDay) {
            setSlotSettings({
                startHour: selectedDay.startHour || "09:00",
                endHour: selectedDay.endHour || "18:00",
                slotDuration: selectedDay.slotDuration || 30
            });
        }
    }, [selectedDay]);

    // Scroll to patient if returning from detail
    // Scroll to patient if returning from detail
    useEffect(() => {
        if (selectedDay && location.state?.highlightPatientId && !scrollProcessed.current) {
            scrollProcessed.current = true;

            // Slight delay to allow rendering
            setTimeout(() => {
                const el = document.getElementById(`invitation-card-${location.state.highlightPatientId}`);
                if (el) {
                    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    el.classList.add('ring-2', 'ring-teal-500', 'ring-offset-2');
                    setTimeout(() => el.classList.remove('ring-2', 'ring-teal-500', 'ring-offset-2'), 2000);

                    // Clear state to prevent scroll on every render
                    navigate(".", { replace: true, state: {} });
                }
            }, 500);
        }
    }, [selectedDay, location.state, navigate]);

    const generateTimeSlots = () => {
        try {
            const slots = [];
            const safeStart = slotSettings?.startHour || "09:00";
            const safeEnd = slotSettings?.endHour || "18:00";
            const duration = Math.max(parseInt(slotSettings?.slotDuration) || 30, 5); // Minimum 5 mins to prevent infinite loop

            let current = parseISO(`2000-01-01T${safeStart}`);
            const end = parseISO(`2000-01-01T${safeEnd}`);

            if (isNaN(current.getTime()) || isNaN(end.getTime())) return [];

            // Safety counter to prevent infinite loops
            let iterations = 0;
            while (current < end && iterations < 100) {
                const timeString = format(current, "HH:mm");
                slots.push(timeString);
                current = new Date(current.getTime() + duration * 60000);
                iterations++;
            }
            return slots;
        } catch (e) {
            console.error("Error generating time slots", e);
            return [];
        }
    };

    const saveSlotSettings = async () => {
        if (!selectedDay) return;
        const updatedDays = company.expertDays.map(d => {
            if (d.id === selectedDay.id) {
                return { ...d, ...slotSettings };
            }
            return d;
        });
        await DataService.updateCompany(company.id, { expertDays: updatedDays });
        const freshCompany = await DataService.getCompany(company.id);
        setCompany(freshCompany);
        setSelectedDay(freshCompany.expertDays.find(d => d.id === selectedDay.id));
    };

    const loadData = async () => {
        try {
            const c = await DataService.getCompany(id);
            const p = await DataService.getPatients();

            if (!c) {
                navigate("/companies");
                return;
            }

            // AGGRESSIVE SANITIZATION
            // Ensure expertDays is an array
            if (!Array.isArray(c.expertDays)) {
                c.expertDays = [];
            }
            // Ensure invitations are arrays for each day
            c.expertDays.forEach(day => {
                if (!day) return;

                if (!Array.isArray(day.invitations)) {
                    day.invitations = [];
                } else {
                    // Sanitize individual invitations
                    day.invitations.forEach(inv => {
                        if (!inv) return;
                        // Fix appointmentTimes if it exists but is not an array
                        if (inv.appointmentTimes && !Array.isArray(inv.appointmentTimes)) {
                            if (typeof inv.appointmentTimes === 'string') {
                                inv.appointmentTimes = [inv.appointmentTimes];
                            } else {
                                inv.appointmentTimes = [];
                            }
                        }

                        // Fix appointmentTime (singular) - MUST be string
                        if (inv.appointmentTime && typeof inv.appointmentTime !== 'string') {
                            inv.appointmentTime = "";
                        }
                    });
                }
            });

            console.log("Loaded Company Data:", c);
            if (c.expertDays?.length > 0) {
                console.log(`Found ${c.expertDays.length} expert days for ${c.name}`);
            } else {
                console.warn(`No expert days found for ${c.name}`, c);
            }

            setCompany(c);
            setPatients(Array.isArray(p) ? p : []);

            // Check for return link state
            if (location.state?.openDayId) {
                const dayToOpen = c.expertDays.find(d => d.id === location.state.openDayId);
                if (dayToOpen) setSelectedDay(dayToOpen);
            }
        } catch (error) {
            console.error("Critical error in loadData:", error);
            // Fallback to avoid white screen
            setCompany({ id: "error", name: "Veri Hatası", description: error.toString(), expertDays: [] });
            setPatients([]);
        }
    };

    // Güvenli tarih formatlayıcı
    const safeFormatDate = (dateStr, formatStr, options) => {
        if (!dateStr) return "";
        try {
            const date = parseISO(dateStr);
            if (isNaN(date.getTime())) return "";
            return format(date, formatStr, options);
        } catch (e) {
            return "";
        }
    };

    const handleAddDay = async (e) => {
        e.preventDefault();
        if (!dayForm.date) return;

        // Auto-Transfer Logic: Find latest previous event
        let transferredInvitations = [];
        let autoTransferNote = "";

        if (company.expertDays && company.expertDays.length > 0) {
            // Sort days by date descending to find the latest one
            const sortedDays = [...company.expertDays].sort((a, b) => new Date(b.date) - new Date(a.date));
            const latestDay = sortedDays[0];

            // Only transfer if the new date is actually after the latest day (logic check)
            if (latestDay && new Date(dayForm.date) > new Date(latestDay.date)) {
                const postponed = latestDay.invitations?.filter(i => i.isPostponed) || [];

                if (postponed.length > 0) {
                    transferredInvitations = postponed.map(i => ({
                        patientId: i.patientId,
                        invitedAt: new Date().toISOString(),
                        isCalled: false,
                        isReached: false,
                        isConfirmed: false,
                        isAttended: false,
                        isPostponed: false,
                        isRejected: false,
                        note: `Otomatik aktarım (${format(parseISO(latestDay.date), "d MMM", { locale: tr })} etkinliğinden ertelendi).`,
                        transferFromStatus: 'postponed',
                        transferFromDate: latestDay.date
                    }));
                    autoTransferNote = `${postponed.length} ertelenen danışan otomatik eklendi.`;
                }
            }
        }

        const newDay = {
            id: generateUUID(),
            date: dayForm.date,
            note: dayForm.note,
            startHour: dayForm.startHour,
            endHour: dayForm.endHour,
            slotDuration: parseInt(dayForm.slotDuration),
            invitations: transferredInvitations
        };

        const updatedCompany = {
            ...company,
            expertDays: [newDay, ...(company.expertDays || [])]
        };

        await DataService.updateCompany(company.id, { expertDays: updatedCompany.expertDays });
        setCompany(await DataService.getCompany(company.id));
        setIsAddDayModalOpen(false);
        setDayForm({ date: "", note: "", startHour: "09:00", endHour: "18:00", slotDuration: 30 });

        if (autoTransferNote) {
            alert(`Yeni etkinlik oluşturuldu. ${autoTransferNote}`);
        }
    };

    const handleTransferClick = (sourceDay) => {
        // Find the next future event
        const sourceDate = parseISO(sourceDay.date);
        const futureDays = company.expertDays
            .filter(d => d.id !== sourceDay.id && parseISO(d.date) > sourceDate)
            .sort((a, b) => parseISO(a.date) - parseISO(b.date));

        if (futureDays.length === 0) {
            alert("Aktarım yapılabilecek gelecek tarihli bir etkinlik bulunamadı. Lütfen önce yeni bir etkinlik ekleyin.");
            return;
        }

        setTransferSourceDay(sourceDay);
        setTransferTargetDay(futureDays[0]); // Default to nearest future day
        setIsTransferModalOpen(true);
    };

    const getTransferCandidateCounts = () => {
        if (!transferSourceDay) return { uncalled: 0, postponed: 0, unreachable: 0 };
        const invs = transferSourceDay.invitations || [];
        return {
            uncalled: invs.filter(i => !i.isCalled).length,
            postponed: invs.filter(i => i.isPostponed).length,
            unreachable: invs.filter(i => i.isCalled && !i.isReached).length,
            attended: invs.filter(i => i.isAttended).length,
            noShow: invs.filter(i => i.isNoShow).length
        };
    };

    const executeTransfer = async () => {
        if (!transferSourceDay || !transferTargetDay) return;

        const candidates = transferSourceDay.invitations.filter(i => {
            if (transferConfig.transferUncalled && !i.isCalled) return true;
            if (transferConfig.transferPostponed && i.isPostponed) return true;
            if (transferConfig.transferUnreachable && (i.isCalled && !i.isReached)) return true;
            if (transferConfig.transferAttended && i.isAttended) return true;
            if (transferConfig.transferNoShow && i.isNoShow) return true;
            return false;
        });

        if (candidates.length === 0) {
            alert("Aktarılacak danışan seçilmedi veya kriterlere uygun danışan yok.");
            return;
        }

        const addedCount = candidates.length;

        // Prepare Target Day Updates
        const targetDayId = transferTargetDay.id;
        const targetExistingIds = new Set((transferTargetDay.invitations || []).map(i => i.patientId));

        const newInvitations = candidates
            .filter(i => !targetExistingIds.has(i.patientId)) // Prevent duplicates
            .map(i => {
                let status = 'unknown';
                if (i.isAttended) status = 'attended';
                else if (i.isNoShow) status = 'noShow';
                else if (i.isPostponed) status = 'postponed';
                else if (i.isCalled && !i.isReached) status = 'unreachable';
                else if (!i.isCalled) status = 'uncalled';

                return {
                    patientId: i.patientId,
                    invitedAt: new Date().toISOString(),
                    isCalled: false,
                    isReached: false,
                    isConfirmed: false,
                    isAttended: false,
                    isPostponed: false,
                    isRejected: false,
                    note: `Transfer: ${transferSourceDay.date} etkinliğinden aktarıldı.`,
                    transferFromStatus: status,
                    transferFromDate: transferSourceDay.date
                };
            });

        if (newInvitations.length === 0) {
            alert("Seçilen danışanlar zaten hedef etkinlikte mevcut.");
            setIsTransferModalOpen(false);
            return;
        }

        const updatedDays = company.expertDays.map(d => {
            if (d.id === targetDayId) {
                return {
                    ...d,
                    invitations: [...newInvitations, ...(d.invitations || [])]
                };
            }
            return d;
        });

        await DataService.updateCompany(company.id, { expertDays: updatedDays });
        const freshCompany = await DataService.getCompany(company.id);
        setCompany(freshCompany);
        alert(`${newInvitations.length} danışan, ${format(parseISO(transferTargetDay.date), "d MMMM yyyy", { locale: tr })} etkinliğine başarıyla aktarıldı.`);
        setIsTransferModalOpen(false);
    };

    // Edit Day Logic
    const [dayToEdit, setDayToEdit] = useState(null);
    const [editForm, setEditForm] = useState({ date: "", note: "", startHour: "09:00", endHour: "18:00", slotDuration: 30 });

    const handleEditClick = (e, day) => {
        if (e && e.stopPropagation) e.stopPropagation();
        try {
            setDayToEdit(day);
            setEditForm({
                date: day.date ? format(parseISO(day.date), "yyyy-MM-dd") : "",
                note: day.note || "",
                startHour: day.startHour || "09:00",
                endHour: day.endHour || "18:00",
                slotDuration: day.slotDuration || 30
            });
        } catch (error) {
            console.error("Error preparing edit form:", error);
            // Fallback for bad dates
            setDayToEdit(day);
            setEditForm({
                date: "",
                note: day.note || ""
            });
        }
    };

    const saveEditedDay = async () => {
        if (!dayToEdit) return;

        try {
            const updatedDays = company.expertDays.map(d => {
                if (d.id === dayToEdit.id) {
                    return {
                        ...d,
                        date: new Date(editForm.date).toISOString(),
                        note: editForm.note,
                        startHour: editForm.startHour,
                        endHour: editForm.endHour,
                        slotDuration: parseInt(editForm.slotDuration)
                    };
                }
                return d;
            });

            await DataService.updateCompany(company.id, { expertDays: updatedDays });
            const fresh = await DataService.getCompany(company.id);
            setCompany(fresh);
            setDayToEdit(null);
        } catch (error) {
            console.error("Edit failed:", error);
            alert("Düzenleme kaydedilirken hata oluştu.");
        }
    };

    // Delete Confirmation State
    const [dayToDelete, setDayToDelete] = useState(null);

    const handleDeleteClick = (e, day) => {
        if (e && e.stopPropagation) e.stopPropagation();
        // DEBUG: Confirm function call
        // alert("Silme isteği algılandı: " + (day ? day.date : "Bilinmeyen Tarih"));
        setDayToDelete(day);
    };

    const confirmDeleteDay = async () => {
        if (!dayToDelete) return;

        const dayId = dayToDelete.id;

        try {
            // 1. Optimistic Update (Update UI immediately)
            const currentDays = company.expertDays || [];
            const remainingDays = currentDays.filter(d => String(d.id) !== String(dayId));

            if (currentDays.length === remainingDays.length) {
                alert("Hata: Silinecek etkinlik bulunamadı.");
                setDayToDelete(null);
                return;
            }

            const optimisticCompany = { ...company, expertDays: remainingDays };
            setCompany(optimisticCompany);

            // 2. Perform Backend Update
            await DataService.updateCompany(company.id, { expertDays: remainingDays });

            console.log("Delete successful for day:", dayId);
        } catch (error) {
            console.error("Delete operation failed:", error);
            alert("Silme işlemi sırasında bir hata oluştu: " + error.message);
            loadData();
        } finally {
            setDayToDelete(null);
        }
    };

    // --- Invitation Logic ---

    // Helper to Create or Update Visit Panel
    const createOrUpdateVisit = async (patientId, relatedVisitId, note) => {
        if (relatedVisitId) {
            // Update existing visit
            const result = await DataService.updateVisit(patientId, relatedVisitId, {
                note: note,
                date: new Date().toISOString()
            });
            // If update successful, return the same ID
            if (result) return relatedVisitId;
        }

        // If no relatedVisitId, check if a visit already exists for TODAY to group them
        const patient = await DataService.getPatient(patientId);
        if (patient && patient.visits) {
            const todayStr = new Date().toISOString().split('T')[0];

            // Find a visit from today that seems to be related (e.g., created by System or same Company)
            // Or just ANY visit from today to keep it single-panel? User requested "tek panelde olmalıydı".
            const existingTodayVisit = patient.visits.find(v => {
                const vDate = v.date.split('T')[0];
                return vDate === todayStr;
            });

            if (existingTodayVisit) {
                // Append note to existing visit instead of creating new one
                const newNote = existingTodayVisit.note ? existingTodayVisit.note + "\n\n" + note : note;
                await DataService.updateVisit(patientId, existingTodayVisit.id, {
                    note: newNote,
                    date: new Date().toISOString() // Update timestamp to show latest activity
                });
                return existingTodayVisit.id;
            }
        }

        // Create new visit (if no ID or update failed/visit deleted)
        const newVisit = await DataService.addVisit(patientId, {
            type: "Arama", // Or "Uzman Günü"
            date: new Date().toISOString(),
            note: note,
            products: []
        });
        return newVisit.id;
    };

    const handleInvitePatient = async (patientId) => {
        if (!selectedDay) return;

        // Check if already invited
        const isAlreadyInvited = selectedDay.invitations?.some(i => i.patientId === patientId);
        if (isAlreadyInvited) {
            if (!confirm("Bu danışan zaten listede ekli. Aynı kişiye İKİNCİ bir kayıt açmak istiyor musunuz? (Örn: Arkadaşı için)")) {
                return;
            }
        }

        const newInvitation = {
            patientId,
            invitedAt: new Date().toISOString(),
            isCalled: false,
            isReached: false,
            isConfirmed: false,
            isAttended: false,
            isPostponed: false,
            isRejected: false,
            note: ""
        };

        const updatedDays = company.expertDays.map(d => {
            if (d.id === selectedDay.id) {
                return {
                    ...d,
                    invitations: [newInvitation, ...(d.invitations || [])]
                };
            }
            return d;
        });

        await DataService.updateCompany(company.id, { expertDays: updatedDays });
        const freshCompany = await DataService.getCompany(company.id);
        setCompany(freshCompany); // Re-render triggers

        // Update selectedDay reference to match the fresh data
        const freshDay = freshCompany.expertDays.find(d => d.id === selectedDay.id);
        setSelectedDay(freshDay);
    };

    const handleRemoveInvitation = async (patientId) => {
        if (!confirm("Danışanı davet listesinden çıkarmak istiyor musunuz?")) return;

        // 1. Find the invitation to get the relatedVisitId
        const latestCompany = await DataService.getCompany(company.id);
        const currentDay = latestCompany.expertDays.find(d => d.id === selectedDay.id);
        const invitation = currentDay?.invitations?.find(i => i.patientId === patientId);

        // 2. Delete the associated visit from Patient Data if it exists
        if (invitation && invitation.relatedVisitId) {
            try {
                await DataService.deleteVisit(patientId, invitation.relatedVisitId);
                console.log("Deleted related visit:", invitation.relatedVisitId);
            } catch (err) {
                console.error("Failed to delete related visit", err);
            }
        }

        // 3. Remove from Company Data
        const updatedDays = company.expertDays.map(d => {
            if (d.id === selectedDay.id) {
                return {
                    ...d,
                    invitations: d.invitations.filter(i => i.patientId !== patientId)
                };
            }
            return d;
        });

        await DataService.updateCompany(company.id, { expertDays: updatedDays });
        const freshCompany = await DataService.getCompany(company.id);
        setCompany(freshCompany);
        setSelectedDay(freshCompany.expertDays.find(d => d.id === selectedDay.id));
    };

    const handleToggleStatus = async (patientId, field) => {
        // 1. Get current info from FRESH data
        const latestCompany = await DataService.getCompany(company.id);
        const day = latestCompany.expertDays.find(d => d.id === selectedDay.id);
        const inv = day.invitations.find(i => i.patientId === patientId);

        if (!inv) return;

        let attendanceVisitId = inv.attendanceVisitId;
        const newValue = !inv[field];

        // Prepare updates with mutual exclusion
        let updates = { [field]: newValue };
        if (field === 'isAttended' && newValue) {
            updates.isNoShow = false;
        }
        if (field === 'isNoShow' && newValue) {
            updates.isAttended = false;
        }

        // 2. Handle Visit Update Logic
        const eventName = selectedDay.note || "Uzman Günü";
        let statusText = "";

        if (field === 'isAttended') {
            statusText = newValue ? "GELDİ (Katılım Sağladı)" : "Katılım Bilgisi Geri Alındı";
        } else if (field === 'isNoShow') {
            statusText = newValue ? "GELMEDİ (Randevusuna Gelmedi)" : "GELMEDİ Bilgisi Geri Alındı";
        }

        // Create/Update visit note if we have a new positive status, or just update existing if toggling off
        // For simplicity, we always update the visit note if it exists, or create if new positive status
        if (newValue || attendanceVisitId) {
            let fullNote = `Uzman Günü Katılım Durumu (${latestCompany.name} - ${eventName}): ${statusText}`;
            // For attendance, we don't necessarily need the invitation note again, but we can include it if desired.
            // User request implies separation: One for "Called", one for "Attended".

            // Create New Visit for Attendance or Update Eisting Attendance Visit
            attendanceVisitId = await createOrUpdateVisit(patientId, attendanceVisitId, fullNote);

            // If we just cancelled the attendance (newValue is false), we might want to delete the attendance visit
            if (!newValue && attendanceVisitId) {
                await DataService.deleteVisit(patientId, attendanceVisitId);
                attendanceVisitId = null;
            }
        }

        const updatedDays = latestCompany.expertDays.map(d => {
            if (d.id === selectedDay.id) {
                return {
                    ...d,
                    invitations: d.invitations.map(i => {
                        if (i.patientId === patientId) {
                            return {
                                ...i,
                                ...updates,
                                relatedVisitId: inv.relatedVisitId, // Keep original call visit ID
                                attendanceVisitId: attendanceVisitId // Store new attendance visit ID
                            };
                        }
                        return i;
                    })
                };
            }
            return d;
        });

        await DataService.updateCompany(company.id, { expertDays: updatedDays });
        const freshCompany = await DataService.getCompany(company.id);
        setCompany(freshCompany);
        setSelectedDay(freshCompany.expertDays.find(d => d.id === selectedDay.id));
    };

    const handleTogglePriority = async (patientId) => {
        // 1. Optimistic Update
        const updatedDays = company.expertDays.map(d => {
            if (d.id === selectedDay.id) {
                return {
                    ...d,
                    invitations: d.invitations.map(i => {
                        if (i.patientId === patientId) {
                            return { ...i, isPriority: !i.isPriority };
                        }
                        return i;
                    })
                };
            }
            return d;
        });

        const optimisticCompany = { ...company, expertDays: updatedDays };
        setCompany(optimisticCompany);

        // Update selectedDay reference immediately so the UI reflects it
        const newSelectedDay = updatedDays.find(d => d.id === selectedDay.id);
        setSelectedDay(newSelectedDay);

        // 2. Background Sync
        try {
            await DataService.updateCompany(company.id, { expertDays: updatedDays });

            // Optionally fetch fresh to ensure consistency, but usually not needed for simple toggle
            // const fresh = await DataService.getCompany(company.id);
            // setCompany(fresh);
        } catch (error) {
            console.error("Priority update failed", error);
            // Revert on error (optional, or just alert)
            alert("Öncelik durumu güncellenirken bir hata oluştu.");
            // Revert state logic could go here
        }
    };



    const updateInvitationState = async (patientId, updates) => {
        // 1. Fetch fresh data to ensure we have the latest state
        const latestCompany = await DataService.getCompany(company.id);
        const latestDay = latestCompany.expertDays.find(d => d.id === selectedDay.id);
        const currentInvitation = latestDay.invitations.find(i => i.patientId === patientId);

        if (!currentInvitation) return;

        // --- LOG ACTIVITY TO PATIENT TIMELINE ---
        const nextState = { ...currentInvitation, ...updates };

        let resultText = "";
        // Determine text with simplified logic
        // Determine text with simplified logic
        if (nextState.isConfirmed) {
            let timeInfo = "";
            if (nextState.appointmentTime) {
                timeInfo = ` - Saat: ${nextState.appointmentTime}`;
            } else if (nextState.appointmentTimes && nextState.appointmentTimes.length > 0) {
                timeInfo = ` - Saat: ${nextState.appointmentTimes.join(', ')}`;
            }
            resultText = `Görüşüldü, Randevu Verildi${timeInfo}`;
        } else if (currentInvitation.isConfirmed && !nextState.isConfirmed) {
            // Explicitly handle Cancellation (Unchecking Confirm)
            resultText = "Randevu İptal Edildi";
        } else if (nextState.isRejected) {
            resultText = "Reddedildi / Tekrar Aranmayacak";
        } else if (nextState.isPostponed) {
            resultText = "Bu etkinliğe katılmayacak. Bir sonraki etkinliğe davet edilecek.";
        } else if (nextState.isWillLetKnow) {
            resultText = "Haber Verecek / Düşünüyor";
        } else if (nextState.isCalled && nextState.hasOwnProperty('isReached') && !nextState.isReached) {
            resultText = "Ulaşılamadı";
        }

        // Check for "Eczacı Arayacak/Aradı" conditions
        if (nextState.calledBy === 'pharmacist' && nextState.isCalled) {
            if (!nextState.isConfirmed && !nextState.isRejected && !nextState.isPostponed && !nextState.isWillLetKnow) {
                resultText = "Eczacı Aradı";
            }
        } else if (nextState.pharmacistWillCall) {
            resultText = "Eczacı Arayacak";
        }

        let visitId = currentInvitation.relatedVisitId;

        // Filter out auto-transfer notes from creating "Manual Note" persistance
        const noteContent = nextState.note || "";
        const isAutoTransferNote = noteContent.startsWith("Transfer:") || noteContent.startsWith("Otomatik aktarım");
        const effectiveNote = isAutoTransferNote ? "" : noteContent;
        const hasEffectiveManualNote = !!effectiveNote;

        if (resultText || (hasEffectiveManualNote && visitId)) {
            let fullNote = resultText ? `Uzman Günü Daveti (${latestCompany.name}): ${resultText}` : "";

            if (!fullNote && visitId) {
                const patient = await DataService.getPatient(patientId);
                const existingVisit = patient?.visits?.find(v => String(v?.id || '') === String(visitId));
                const firstLine = String(existingVisit?.note || "").split('\n').find(line => line.trim().length > 0) || "";
                if (firstLine.startsWith("Uzman Günü Daveti")) {
                    fullNote = firstLine;
                }
            }

            if (hasEffectiveManualNote && fullNote) {
                fullNote += `\nNot: ${effectiveNote}`;
            }

            if (fullNote) {
                // Create or Update Visit using fresh data
                visitId = await createOrUpdateVisit(patientId, currentInvitation.relatedVisitId, fullNote);
            }
        } else if (visitId) {
            // Cancel/Delete visit if no status and no valid note
            // BUT: If it was a cancellation (resultText set), we wouldn't be here.
            // If we are here, it means everything was unchecked (reset).
            // In that case, deleting is probably correct to "undo" the action.
            await DataService.deleteVisit(patientId, visitId);
            visitId = null;
        }

        const updatedDays = latestCompany.expertDays.map(d => {
            if (d.id === selectedDay.id) {
                return {
                    ...d,
                    invitations: d.invitations.map(i => {
                        if (i.patientId === patientId) {
                            return { ...i, ...updates, relatedVisitId: visitId };
                        }
                        return i;
                    })
                };
            }
            return d;
        });

        await DataService.updateCompany(company.id, { expertDays: updatedDays });
        const freshCompany = await DataService.getCompany(company.id);
        setCompany(freshCompany);
        setSelectedDay(freshCompany.expertDays.find(d => d.id === selectedDay.id));
    };

    const handleConfirmAppointment = async (timeOrSlots) => {
        if (!appointmentTargetPatientId) return;

        let timesToConfirm = [];
        if (Array.isArray(timeOrSlots)) {
            timesToConfirm = timeOrSlots;
        } else {
            timesToConfirm = [timeOrSlots];
        }

        if (timesToConfirm.length === 0) return;

        // Validation: Check if ANY of the slots are taken by SOMEONE ELSE
        const takenSlots = selectedDay.invitations.filter(i => {
            if (!i.isConfirmed || i.patientId === appointmentTargetPatientId) return false;
            // Check legacy single time or new array times
            const times = i.appointmentTimes || (i.appointmentTime ? [i.appointmentTime] : []);
            return times.some(t => timesToConfirm.includes(t));
        });

        if (takenSlots.length > 0) {
            alert("Seçilen saatlerden bazıları dolu!");
            return;
        }

        // Get current invitation to find relatedVisitId
        const currentInvitation = selectedDay.invitations.find(i => i.patientId === appointmentTargetPatientId);

        // --- LOG APPOINTMENT TO TIMELINE ---
        const eventName = selectedDay.note || "Uzman Günü";
        const timeString = timesToConfirm.join(" - ");
        let fullNote = `Uzman Günü Daveti (${company.name} - ${eventName}): Görüşüldü, Randevu Verildi - Saat: ${timeString}`;

        if (timesToConfirm.length > 1) {
            fullNote += " (Yakını ile birlikte)";
        }

        // Filter out auto-transfer notes
        const noteContent = currentInvitation?.note || "";
        const isAutoTransferNote = noteContent.startsWith("Transfer:") || noteContent.startsWith("Otomatik aktarım");

        if (noteContent && !isAutoTransferNote) {
            fullNote += `\nNot: ${noteContent}`;
        }

        const visitId = await createOrUpdateVisit(appointmentTargetPatientId, currentInvitation?.relatedVisitId, fullNote);

        const updatedDays = company.expertDays.map(d => {
            if (d.id === selectedDay.id) {
                return {
                    ...d,
                    invitations: d.invitations.map(i => {
                        if (i.patientId === appointmentTargetPatientId) {
                            return {
                                ...i,
                                isCalled: true,
                                isReached: true,
                                isConfirmed: true,
                                isPostponed: false,
                                isRejected: false,
                                appointmentTime: timesToConfirm[0], // Primary time for sorting/display
                                appointmentTimes: timesToConfirm, // Store ALL times
                                relatedVisitId: visitId // Link to visit
                            };
                        }
                        return i;
                    })
                };
            }
            return d;
        });

        await DataService.updateCompany(company.id, { expertDays: updatedDays });

        const freshCompany = await DataService.getCompany(company.id);
        setCompany(freshCompany);
        setSelectedDay(freshCompany.expertDays.find(d => d.id === selectedDay.id));
        setIsAppointmentModalOpen(false);
        setAppointmentTargetPatientId(null);
        setSelectedSlots([]);
        setIsMultiSelect(false);
    };

    // Consolidated outcome setter
    const handleSetOutcome = async (patientId, outcome) => {
        if (outcome === 'confirmed') {
            setAppointmentTargetPatientId(patientId);
            setIsAppointmentModalOpen(true);
            return;
        }

        // 1. DETERMINE NEW VISIT CONTENT
        const eventName = selectedDay.note || "Uzman Günü";
        let fullNote = "";

        if (outcome === 'postponed') fullNote = `Uzman Günü Daveti (${company.name}): Bu etkinliğe katılmayacak. Bir sonraki etkinliğe davet edilecek.`;
        else if (outcome === 'rejected') fullNote = `Uzman Günü Daveti (${company.name}): Reddedildi / Tekrar Aranmayacak`;
        else if (outcome === 'unreachable') fullNote = `Uzman Günü Daveti (${company.name}): Ulaşılamadı`;
        else if (outcome === 'willLetKnow') fullNote = `Uzman Günü Daveti (${company.name}): Haber Verecek / Düşünüyor`;

        // 2. FIND EXISTING INVITATION AND UPDATE/CREATE VISIT
        // 2. FIND EXISTING INVITATION AND UPDATE/CREATE VISIT
        const currentInvitation = selectedDay.invitations.find(i => i.patientId === patientId);
        let visitId = currentInvitation?.relatedVisitId;

        if (fullNote) {
            // Filter out auto-transfer notes
            const noteContent = currentInvitation?.note || "";
            const isAutoTransferNote = noteContent.startsWith("Transfer:") || noteContent.startsWith("Otomatik aktarım");

            if (noteContent && !isAutoTransferNote) {
                fullNote += `\nNot: ${noteContent}`;
            }
            visitId = await createOrUpdateVisit(patientId, currentInvitation?.relatedVisitId, fullNote);
        } else if (outcome === 'none' && visitId) {
            // OPTIONAL: If clearing outcome, should we delete the visit?
            // User requirement is "don't create new panel". If we clear, maybe we keep it or delete it.
            // Let's delete it if we are fully resetting to "Not Called/None"
            await DataService.deleteVisit(patientId, visitId);
            visitId = null;
        }

        const updatedDays = company.expertDays.map(d => {
            if (d.id === selectedDay.id) {
                return {
                    ...d,
                    invitations: d.invitations.map(i => {
                        if (i.patientId === patientId) {
                            // Reset everything first
                            const resetState = {
                                isCalled: true, // If we strictly set an outcome, we assume they were called.
                                isReached: true,
                                isConfirmed: false,
                                isPostponed: false,
                                isRejected: false,
                                isWillLetKnow: false,
                                appointmentTime: null,
                                relatedVisitId: visitId // Link new visit (or null)
                            };

                            if (outcome === 'postponed') {
                                return { ...i, ...resetState, isPostponed: true };
                            } else if (outcome === 'rejected') {
                                return { ...i, ...resetState, isRejected: true };
                            } else if (outcome === 'willLetKnow') {
                                return { ...i, ...resetState, isWillLetKnow: true };
                            } else if (outcome === 'unreachable') {
                                return { ...i, ...resetState, isReached: false, isConfirmed: false };
                            } else if (outcome === 'none') {
                                // Reset to "Not Called" state
                                return { ...i, isCalled: false, isReached: false, isConfirmed: false, isPostponed: false, isRejected: false, isWillLetKnow: false, appointmentTime: null, relatedVisitId: null };
                            }
                        }
                        return i;
                    })
                };
            }
            return d;
        });

        await DataService.updateCompany(company.id, { expertDays: updatedDays });
        const freshCompany = await DataService.getCompany(company.id);
        setCompany(freshCompany);
        setSelectedDay(freshCompany.expertDays.find(d => d.id === selectedDay.id));
    };

    // Prepare Invited List with details
    let detailsOfInvited = [];
    try {
        detailsOfInvited = (selectedDay?.invitations || []).map(inv => {
            if (!inv) return null;
            // Safe access to patients
            const p = Array.isArray(patients) ? patients.find(px => px && String(px.id) === String(inv.patientId)) : null;
            if (!p) {
                // Fallback for orphaned invitations OR newly created patients not yet in patients list
                return {
                    ...inv,
                    id: inv.patientId || generateUUID(), // Ensure ID
                    fullName: inv.fullName || `Bilinmeyen Danışan (${inv.patientId})`,
                    phone: inv.phone || "",
                    description: "Otomatik kayıt veya silinmiş."
                };
            }
            return { ...p, ...inv };
        }).filter(p => {
            if (!p) return false;
            try {
                const term = normalizeString(String(invitedSearchTerm || ""));
                const name = p.fullName ? normalizeString(String(p.fullName)) : "";
                const phone = p.phone ? String(p.phone) : "";

                const matchesSearch = name.includes(term) || phone.includes(term);
                if (filterInterested) {
                    const isInterested = p.interestedCompanies?.includes(company.id);
                    return matchesSearch && isInterested;
                }
                return matchesSearch;
            } catch (err) {
                console.error("Error filtering invited patient:", err);
                return false;
            }
        }).sort((a, b) => {
            try {
                if (a.isPriority && !b.isPriority) return -1;
                if (!a.isPriority && b.isPriority) return 1;

                if (sortOption === "date_new") return new Date(b.invitedAt || 0) - new Date(a.invitedAt || 0);
                if (sortOption === "date_old") return new Date(a.invitedAt || 0) - new Date(b.invitedAt || 0);

                const nameA = a.fullName || "";
                const nameB = b.fullName || "";
                if (sortOption === "alphabetical_asc") return nameA.localeCompare(nameB, 'tr');
                if (sortOption === "alphabetical_desc") return nameB.localeCompare(nameA, 'tr');
                return 0;
            } catch (err) {
                console.error("Error sorting invited patients:", err);
                return 0;
            }
        }) || [];
    } catch (e) {
        console.error("Error calculating detailsOfInvited", e);
        detailsOfInvited = [];
    }

    // Slice for performance/limit
    detailsOfInvited = detailsOfInvited.slice(0, filterInterested ? 100 : 1000); // 1000 limit safety

    let uninvitedPatients = [];
    let filteredPatientsToInvite = [];

    try {
        uninvitedPatients = Array.isArray(patients) ? patients.filter(p => p && !selectedDay?.invitations?.some(i => i && i.patientId === p.id)) : [];

        filteredPatientsToInvite = uninvitedPatients.filter(p => {
            if (!p) return false;
            try {
                const term = normalizeString(inviteSearchTerm || "");
                const name = p.fullName ? normalizeString(p.fullName) : "";
                const phone = p.phone ? String(p.phone) : "";
                const matchesSearch = name.includes(term) || phone.includes(term);

                if (filterInterested) {
                    const isInterested = p.interestedCompanies?.includes(company.id);
                    return matchesSearch && isInterested;
                }
                return matchesSearch;
            } catch (err) {
                console.error("Error filtering patients to invite:", err);
                return false;
            }
        }).slice(0, filterInterested ? 100 : 5);
    } catch (e) {
        console.error("Error calculating uninvitedPatients or filteredPatientsToInvite", e);
        uninvitedPatients = [];
        filteredPatientsToInvite = [];
    }

    if (!company) return <div>Yükleniyor...</div>;

    if (company.id === 'error') {
        return (
            <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex items-center justify-center p-4">
                <div className="bg-white dark:bg-slate-800 p-8 rounded-2xl shadow-xl text-center max-w-md w-full animate-in zoom-in duration-300">
                    <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                        <AlertCircle className="h-8 w-8 text-red-600 dark:text-red-400" />
                    </div>
                    <h2 className="text-xl font-bold text-slate-800 dark:text-white mb-2">Veri Hatası</h2>
                    <p className="text-slate-600 dark:text-slate-400 mb-6">
                        Firma detayları ve uzman günleri yüklenirken bir sorun oluştu.
                        {company.description && (
                            <div className="mt-4 p-3 bg-red-50 dark:bg-red-900/10 rounded-lg text-left">
                                <p className="text-xs font-bold text-red-600 dark:text-red-400 mb-1">Hata Detayı:</p>
                                <p className="text-xs font-mono text-red-500 break-all">{company.description}</p>
                            </div>
                        )}
                    </p>
                    <button
                        onClick={() => navigate("/companies")}
                        className="inline-flex items-center gap-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white font-medium transition-colors"
                    >
                        <ArrowLeft size={20} />
                        Geri Dön
                    </button>
                    <button
                        onClick={() => window.location.reload()}
                        className="block w-full mt-3 py-2 text-sm text-teal-600 hover:underline"
                    >
                        Sayfayı Yenile
                    </button>
                </div>
            </div>
        );
    }

    return (
        <ErrorBoundary>
            <div className="space-y-6 animate-in fade-in duration-500">
                {/* Header */}
                <div className="flex items-center gap-4">
                    <button onClick={() => navigate("/companies")} className="flex items-center gap-2 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 transition-colors">
                        <ArrowLeft size={24} />
                        <span className="text-sm font-medium">Geri Dön</span>
                    </button>
                    <div>
                        <h2 className="text-2xl font-bold text-slate-800 dark:text-white">{company.name}</h2>
                        <p className="text-slate-500 dark:text-slate-400">{company.description || "Firma detayları ve uzman günleri"}</p>
                    </div>
                </div>

                {/* Expert Days List */}
                <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden transition-colors">
                    <div className="p-6 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between bg-slate-50/50 dark:bg-slate-700/50">
                        <h3 className="font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-2">
                            <Calendar className="text-teal-600 dark:text-teal-400" size={20} />
                            Uzman Günleri
                        </h3>
                        <button
                            onClick={() => setIsAddDayModalOpen(true)}
                            className="text-sm bg-teal-600 hover:bg-teal-700 text-white px-3 py-2 rounded-lg font-medium transition-colors flex items-center gap-2 shadow-sm"
                        >
                            <Plus size={16} />
                            Etkinlik Ekle
                        </button>
                    </div>

                    <div className="divide-y divide-slate-100 dark:divide-slate-700">
                        {company.expertDays?.length > 0 ? (
                            company.expertDays.map(day => (
                                <div key={day.id} className="p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors relative z-[5] group">
                                    <div>
                                        <h4 className="font-semibold text-slate-900 dark:text-white text-lg flex items-center gap-2">
                                            {safeFormatDate(day.date, "d MMMM yyyy, EEEE", { locale: tr })}
                                        </h4>
                                        {day.note && <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">{day.note}</p>}
                                        <div className="mt-2 flex items-center gap-4 text-sm text-slate-500 dark:text-slate-400">
                                            <span className="flex items-center gap-1">
                                                <User size={14} />
                                                {day.invitations?.length || 0} Davetli
                                            </span>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-3 relative z-[100] isolate pointer-events-auto">
                                        <button
                                            onClick={(e) => {
                                                if (e) e.stopPropagation();
                                                handleEditClick(e, day);
                                            }}
                                            className="p-2 text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors border border-transparent hover:border-blue-200 dark:hover:border-blue-800 cursor-pointer"
                                            title="Düzenle"
                                            type="button"
                                        >
                                            <Edit2 size={20} />
                                        </button>
                                        <button
                                            onClick={() => setSelectedDay(day)}
                                            className="px-4 py-2 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 hover:border-teal-500 dark:hover:border-teal-400 hover:text-teal-600 dark:hover:text-teal-400 text-slate-600 dark:text-slate-200 rounded-lg font-medium transition-all shadow-sm"
                                        >
                                            Davetleri Yönet
                                        </button>
                                        <button
                                            onClick={(e) => {
                                                if (e && e.stopPropagation) e.stopPropagation();
                                                handleTransferClick(day);
                                            }}
                                            className="p-2 text-slate-400 hover:text-teal-600 dark:hover:text-teal-400 hover:bg-teal-50 dark:hover:bg-teal-900/20 rounded-lg transition-colors cursor-pointer"
                                            title="Sonraki Etkinliğe Aktar"
                                            type="button"
                                        >
                                            <ArrowRight size={20} />
                                        </button>
                                        <button
                                            onClick={(e) => {
                                                if (e) e.stopPropagation();
                                                const url = `${window.location.origin}/book/${company.id}/${day.id}`;
                                                copyToClipboard(url).then(success => {
                                                    if (success) {
                                                        alert("Randevu linki kopyalandı:\n" + url);
                                                    }
                                                });
                                            }}
                                            className="p-2 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors border border-transparent hover:border-indigo-200 dark:hover:border-indigo-800 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-900/20 cursor-pointer"
                                            title="Randevu Linkini Kopyala"
                                            type="button"
                                        >
                                            <LinkIcon size={20} />
                                        </button>
                                        <button
                                            onClick={(e) => {
                                                if (e) e.stopPropagation();
                                                handleDeleteClick(e, day);
                                            }}
                                            className="p-2 text-slate-400 hover:text-red-500 dark:hover:text-red-400 transition-colors border border-transparent hover:border-red-200 dark:hover:border-red-800 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 cursor-pointer"
                                            title={`Sil: ${day.date}`}
                                            type="button"
                                        >
                                            <Trash2 size={20} />
                                        </button>
                                    </div>
                                </div>
                            ))
                        ) : (
                            <div className="p-12 text-center text-slate-400 dark:text-slate-500">
                                <CalendarIcon size={48} className="mx-auto mb-4 opacity-20" />
                                <p>Henüz planlanmış bir uzman günü yok.</p>
                                <button
                                    onClick={() => setIsAddDayModalOpen(true)}
                                    className="mt-4 text-teal-600 dark:text-teal-400 font-medium hover:underline"
                                >
                                    İlk Etkinliği Ekle
                                </button>
                            </div>
                        )}
                    </div>
                </div>

                {/* Edit Day Modal */}
                {dayToEdit && (
                    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
                        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-xl w-full max-w-sm p-6 animate-in zoom-in-95 duration-200 border border-slate-200 dark:border-slate-700">
                            <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-4">Etkinliği Düzenle</h3>
                            <div className="space-y-4">
                                <div>
                                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Tarih</label>
                                    <input
                                        type="date"
                                        className="w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-teal-500 bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-white"
                                        value={editForm.date}
                                        onChange={e => setEditForm({ ...editForm, date: e.target.value })}
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Not / Açıklama</label>
                                    <input
                                        type="text"
                                        className="w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-teal-500 bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-white"
                                        value={editForm.note}
                                    />
                                </div>
                                <div className="grid grid-cols-3 gap-3">
                                    <div>
                                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Başlangıç</label>
                                        <input
                                            type="time"
                                            className="w-full px-2 py-2 border border-slate-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-teal-500 bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-white text-sm"
                                            value={editForm.startHour}
                                            onChange={e => setEditForm({ ...editForm, startHour: e.target.value })}
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Bitiş</label>
                                        <input
                                            type="time"
                                            className="w-full px-2 py-2 border border-slate-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-teal-500 bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-white text-sm"
                                            value={editForm.endHour}
                                            onChange={e => setEditForm({ ...editForm, endHour: e.target.value })}
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Süre (Dk)</label>
                                        <input
                                            type="number"
                                            className="w-full px-2 py-2 border border-slate-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-teal-500 bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-white text-sm"
                                            value={editForm.slotDuration}
                                            onChange={e => setEditForm({ ...editForm, slotDuration: e.target.value })}
                                        />
                                    </div>
                                </div>
                                <div className="flex gap-3 pt-2">
                                    <button
                                        onClick={() => setDayToEdit(null)}
                                        className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 rounded-lg font-medium transition-colors"
                                    >
                                        Vazgeç
                                    </button>
                                    <button
                                        onClick={saveEditedDay}
                                        className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
                                    >
                                        Kaydet
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {/* Delete Confirmation Modal */}
                {dayToDelete && (
                    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
                        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-xl w-full max-w-sm p-6 animate-in zoom-in-95 duration-200 border border-slate-200 dark:border-slate-700">
                            <div className="mb-4 text-center">
                                <div className="mx-auto w-12 h-12 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mb-4">
                                    <Trash2 className="text-red-600 dark:text-red-400" size={24} />
                                </div>
                                <h3 className="text-lg font-bold text-slate-800 dark:text-white">Emin misiniz?</h3>
                                <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
                                    <strong>{dayToDelete.date ? format(parseISO(dayToDelete.date), "d MMMM yyyy", { locale: tr }) : "Bu"}</strong> tarihli etkinliği silmek üzeresiniz.
                                    <br />
                                    Bu işlem geri alınamaz.
                                </p>
                            </div>
                            <div className="flex gap-3">
                                <button
                                    onClick={() => setDayToDelete(null)}
                                    className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 rounded-lg font-medium transition-colors"
                                >
                                    Vazgeç
                                </button>
                                <button
                                    onClick={confirmDeleteDay}
                                    className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium transition-colors"
                                >
                                    Evet, Sil
                                </button>
                            </div>
                        </div>
                    </div>
                )}

                {/* Add Day Modal */}
                {isAddDayModalOpen && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
                        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-xl w-full max-w-sm p-6 border border-slate-200 dark:border-slate-700 animate-in zoom-in-95 duration-200">
                            <h3 className="text-lg font-semibold mb-4 text-slate-800 dark:text-white">Yeni Uzman Günü</h3>
                            <form onSubmit={handleAddDay} className="space-y-4">
                                <div>
                                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Tarih</label>
                                    <input
                                        required
                                        type="date"
                                        className="w-full rounded-lg border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white border px-3 py-2 focus:ring-2 focus:ring-teal-500"
                                        value={dayForm.date}
                                        onChange={e => setDayForm({ ...dayForm, date: e.target.value })}
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Not (Opsiyonel)</label>
                                    <input
                                        type="text"
                                        className="w-full rounded-lg border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white border px-3 py-2 focus:ring-2 focus:ring-teal-500"
                                        placeholder="Örn: Cilt Analizi Günü"
                                        value={dayForm.note}
                                    />
                                </div>
                                <div className="grid grid-cols-3 gap-3">
                                    <div>
                                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Başlangıç</label>
                                        <input
                                            type="time"
                                            className="w-full rounded-lg border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white border px-2 py-2 focus:ring-2 focus:ring-teal-500 text-sm"
                                            value={dayForm.startHour}
                                            onChange={e => setDayForm({ ...dayForm, startHour: e.target.value })}
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Bitiş</label>
                                        <input
                                            type="time"
                                            className="w-full rounded-lg border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white border px-2 py-2 focus:ring-2 focus:ring-teal-500 text-sm"
                                            value={dayForm.endHour}
                                            onChange={e => setDayForm({ ...dayForm, endHour: e.target.value })}
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Süre (Dk)</label>
                                        <input
                                            type="number"
                                            className="w-full rounded-lg border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white border px-2 py-2 focus:ring-2 focus:ring-teal-500 text-sm"
                                            value={dayForm.slotDuration}
                                            onChange={e => setDayForm({ ...dayForm, slotDuration: e.target.value })}
                                        />
                                    </div>
                                </div>
                                <div className="flex justify-end gap-2 pt-2">
                                    <button type="button" onClick={() => setIsAddDayModalOpen(false)} className="px-4 py-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors">İptal</button>
                                    <button type="submit" className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg transition-colors shadow-sm">Ekle</button>
                                </div>
                            </form>
                        </div>
                    </div>
                )}

                {/* Invitation Management Modal */}
                {selectedDay && !dayToEdit && !isTransferModalOpen && !dayToDelete && (
                    <InvitationModal
                        company={company}
                        dayId={selectedDay.id}
                        patients={patients}
                        onClose={() => setSelectedDay(null)}
                        onUpdateCompany={loadData}
                    />
                )}
            </div>
        </ErrorBoundary>
    );
}
