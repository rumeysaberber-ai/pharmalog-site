import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
    Calendar as CalendarIcon, Clock, MapPin, Phone, Mail, Globe, User, Plus, Search,
    Filter, ArrowUpDown, MoreVertical, Edit2, Trash2, CheckCircle, XCircle,
    AlertCircle, ChevronRight, Share2, CalendarClock, MessageCircle, Ban, History, X,
    ArrowLeft, Info, Printer, ArrowRight, Package, Calendar, Star, Check
} from 'lucide-react';
import { DataService } from "../lib/data";
import { cn, normalizeString, formatPhoneNumber, generateUUID } from "../lib/utils";
import { format, parseISO } from "date-fns";
import { tr } from "date-fns/locale";

// Error Boundary for the Modal content
class ModalErrorBoundary extends React.Component {
    constructor(props) {
        super(props);
        this.state = { hasError: false, error: null };
    }

    static getDerivedStateFromError(error) {
        return { hasError: true, error };
    }

    componentDidCatch(error, errorInfo) {
        console.error("InvitationModal Error:", error, errorInfo);
    }

    render() {
        if (this.state.hasError) {
            return (
                <div className="p-6 h-full flex flex-col items-center justify-center text-center">
                    <AlertCircle size={48} className="text-red-500 mb-4" />
                    <h3 className="text-lg font-bold text-slate-800 mb-2">Bir hata oluştu</h3>
                    <p className="text-slate-600 mb-4 max-w-md bg-slate-100 p-2 rounded text-xs font-mono text-left overflow-auto max-h-32">
                        {this.state.error?.message || "Bilinmeyen hata"}
                    </p>
                    <button
                        onClick={() => this.setState({ hasError: false })}
                        className="bg-teal-600 text-white px-4 py-2 rounded-lg"
                    >
                        Tekrar Dene
                    </button>
                    <button
                        onClick={this.props.onClose}
                        className="mt-2 text-slate-400 hover:text-slate-600 text-sm"
                    >
                        Kapat
                    </button>
                </div>
            );
        }
        return this.props.children;
    }
}

export default function InvitationModal({ company, dayId, patients, onClose, onUpdateCompany }) {
    const navigate = useNavigate();
    const [inviteSearchTerm, setInviteSearchTerm] = useState("");
    const [invitedSearchTerm, setInvitedSearchTerm] = useState("");
    const [filterInterested, setFilterInterested] = useState(false);
    const [sortOption, setSortOption] = useState("date_new");
    const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);
    const [quickAddForm, setQuickAddForm] = useState({ fullName: "", phone: "", description: "" });
    const [isAppointmentModalOpen, setIsAppointmentModalOpen] = useState(false);
    const [appointmentTargetPatientId, setAppointmentTargetPatientId] = useState(null);
    const [isMultiSelect, setIsMultiSelect] = useState(false);
    const [selectedSlots, setSelectedSlots] = useState([]);

    // Derive selectedDay from props
    const selectedDay = company?.expertDays?.find(d => d.id === dayId);

    const buildSlotSettings = (day) => ({
        startHour: day?.startHour || "09:00",
        endHour: day?.endHour || "18:00",
        slotDuration: Number.parseInt(day?.slotDuration, 10) || 30
    });

    // Slot Settings
    const [slotSettings, setSlotSettings] = useState(() => buildSlotSettings(selectedDay));

    useEffect(() => {
        if (!selectedDay) return;

        const next = buildSlotSettings(selectedDay);
        setSlotSettings(prev => {
            const sameStart = prev.startHour === next.startHour;
            const sameEnd = prev.endHour === next.endHour;
            const sameDuration = Number.parseInt(prev.slotDuration, 10) === next.slotDuration;
            return sameStart && sameEnd && sameDuration ? prev : next;
        });
    }, [dayId, selectedDay?.startHour, selectedDay?.endHour, selectedDay?.slotDuration]);

    if (!selectedDay) return null;

    // --- LOGIC ---

    const safeFormatDate = (dateStr, formatStr, options) => {
        if (!dateStr) return "";
        try {
            const date = parseISO(dateStr);
            if (isNaN(date.getTime())) return "";
            return format(date, formatStr, options);
        } catch (e) {
            return "";
        }
    };

    const generateTimeSlots = () => {
        try {
            const slots = [];
            const safeStart = slotSettings?.startHour || "09:00";
            const safeEnd = slotSettings?.endHour || "18:00";
            const duration = Math.max(parseInt(slotSettings?.slotDuration) || 30, 5);

            let current = parseISO(`2000-01-01T${safeStart}`);
            const end = parseISO(`2000-01-01T${safeEnd}`);

            if (isNaN(current.getTime()) || isNaN(end.getTime())) return [];

            let iterations = 0;
            while (current < end && iterations < 200) { // Increased limit slightly
                const timeString = format(current, "HH:mm");
                slots.push(timeString);
                current = new Date(current.getTime() + duration * 60000);
                iterations++;
            }
            return slots;
        } catch (e) {
            console.error("Error generating time slots", e);
            return [];
        }
    };

    const handlePrintAppointments = () => {
        const slots = generateTimeSlots();
        const win = window.open('', '', 'height=800,width=600');
        win.document.write('<html><head><title>Randevu Listesi Yazdır</title>');
        win.document.write(`
            <style>
                body { font-family: sans-serif; padding: 20px; }
                h2 { text-align: center; margin-bottom: 20px; }
                table { width: 100%; border-collapse: collapse; margin-top: 10px; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                th { background-color: #f2f2f2; font-weight: bold; }
                .time-col { width: 80px; text-align: center; font-weight: bold; }
                .name-col { width: 40%; }
                .note-col { }
                .empty { color: #ccc; font-style: italic; }
                @media print { button { display: none; } body { -webkit-print-color-adjust: exact; } }
            </style>
        `);
        win.document.write('</head><body>');

        const dateStr = selectedDay.date ? format(parseISO(selectedDay.date), "d MMMM yyyy", { locale: tr }) : "";
        win.document.write(`<h2>${company.name}<br><small>${dateStr}</small></h2>`);

        win.document.write('<table>');
        win.document.write('<thead><tr><th class="time-col">Saat</th><th class="name-col">İsim Soyisim</th><th class="note-col">Notlar</th></tr></thead>');
        win.document.write('<tbody>');

        slots.forEach(time => {
            const appt = selectedDay.invitations?.find(i => {
                if (!i.isConfirmed) return false;
                const times = i.appointmentTimes || (i.appointmentTime ? [i.appointmentTime] : []);
                return times.includes(time);
            });
            const p = appt ? patients?.find(px => px.id === appt.patientId) : null;

            win.document.write(`
                <tr>
                    <td class="time-col">${time}</td>
                    <td class="name-col ${!p ? 'empty' : ''}">${p ? p.fullName : 'Boş'}</td>
                    <td class="note-col">${appt?.note ? appt.note : ''}</td>
                </tr>
            `);
        });
        win.document.write('</tbody></table>');

        win.document.write('</body></html>');
        win.document.close();
        win.print();
    };

    const saveSlotSettings = async () => {
        const normalizedSettings = {
            startHour: slotSettings?.startHour || "09:00",
            endHour: slotSettings?.endHour || "18:00",
            slotDuration: Math.max(Number.parseInt(slotSettings?.slotDuration, 10) || 30, 5)
        };

        const updatedDays = company.expertDays.map(d => {
            if (d.id === selectedDay.id) {
                return { ...d, ...normalizedSettings };
            }
            return d;
        });
        await DataService.updateCompany(company.id, { expertDays: updatedDays });
        onUpdateCompany();
    };

    const createOrUpdateVisit = async (patientId, relatedVisitId, note) => {
        if (relatedVisitId) {
            const result = await DataService.updateVisit(patientId, relatedVisitId, {
                note: note,
                date: new Date().toISOString()
            });
            if (result) return relatedVisitId;
        }
        const newVisit = await DataService.addVisit(patientId, {
            type: "Arama",
            date: new Date().toISOString(),
            note: note,
            products: []
        });
        return newVisit.id;
    };

    const handleInvitePatient = async (patientId) => {
        const isAlreadyInvited = selectedDay.invitations?.some(i => i.patientId === patientId);
        if (isAlreadyInvited) {
            if (!confirm("Bu danışan zaten listede ekli. Aynı kişiye İKİNCİ bir kayıt açmak istiyor musunuz?")) {
                return;
            }
        }

        const newInvitation = {
            patientId,
            invitedAt: new Date().toISOString(),
            isCalled: false,
            isReached: false,
            isConfirmed: false,
            isAttended: false,
            isPostponed: false,
            isRejected: false,
            note: ""
        };

        const updatedDays = company.expertDays.map(d => {
            if (d.id === selectedDay.id) {
                return {
                    ...d,
                    invitations: [newInvitation, ...(d.invitations || [])]
                };
            }
            return d;
        });

        await DataService.updateCompany(company.id, { expertDays: updatedDays });
        onUpdateCompany();
    };

    const handleRemoveInvitation = async (patientId) => {
        if (!confirm("Danışanı davet listesinden çıkarmak istiyor musunuz?")) return;
        const updatedDays = company.expertDays.map(d => {
            if (d.id === selectedDay.id) {
                return {
                    ...d,
                    invitations: d.invitations.filter(i => i.patientId !== patientId)
                };
            }
            return d;
        });
        await DataService.updateCompany(company.id, { expertDays: updatedDays });
        onUpdateCompany();
    };

    const handleToggleStatus = async (patientId, field) => {
        // Fetch fresh data for consistency
        const latestCompany = await DataService.getCompany(company.id);
        const day = latestCompany.expertDays.find(d => d.id === selectedDay.id);
        const inv = day.invitations.find(i => i.patientId === patientId);

        if (!inv) return;

        let attendanceVisitId = inv.attendanceVisitId;
        const newValue = !inv[field];

        let updates = { [field]: newValue };
        if (field === 'isAttended' && newValue) updates.isNoShow = false;
        if (field === 'isNoShow' && newValue) updates.isAttended = false;

        const eventName = selectedDay.note || "Uzman Günü";
        let statusText = "";
        if (field === 'isAttended') statusText = newValue ? "GELDİ (Katılım Sağladı)" : "Katılım Bilgisi Geri Alındı";
        else if (field === 'isNoShow') statusText = newValue ? "GELMEDİ (Randevusuna Gelmedi)" : "GELMEDİ Bilgisi Geri Alındı";

        if (newValue || attendanceVisitId) {
            let fullNote = `Uzman Günü Katılım Durumu (${latestCompany.name} - ${eventName}): ${statusText}`;
            attendanceVisitId = await createOrUpdateVisit(patientId, attendanceVisitId, fullNote);
            if (!newValue && attendanceVisitId) {
                await DataService.deleteVisit(patientId, attendanceVisitId);
                attendanceVisitId = null;
            }
        }

        const updatedDays = latestCompany.expertDays.map(d => {
            if (d.id === selectedDay.id) {
                return {
                    ...d,
                    invitations: d.invitations.map(i => {
                        if (i.patientId === patientId) {
                            return { ...i, ...updates, relatedVisitId: inv.relatedVisitId, attendanceVisitId };
                        }
                        return i;
                    })
                };
            }
            return d;
        });

        await DataService.updateCompany(company.id, { expertDays: updatedDays });
        onUpdateCompany();
    };

    const handleTogglePriority = async (patientId) => {
        const updatedDays = company.expertDays.map(d => {
            if (d.id === selectedDay.id) {
                return {
                    ...d,
                    invitations: d.invitations.map(i => {
                        if (i.patientId === patientId) return { ...i, isPriority: !i.isPriority };
                        return i;
                    })
                };
            }
            return d;
        });
        await DataService.updateCompany(company.id, { expertDays: updatedDays });
        onUpdateCompany();
    };

    const updateInvitationState = async (patientId, updates) => {
        const latestCompany = await DataService.getCompany(company.id);
        const latestDay = latestCompany.expertDays.find(d => d.id === selectedDay.id);
        const currentInvitation = latestDay.invitations.find(i => i.patientId === patientId);

        if (!currentInvitation) return;

        const nextState = { ...currentInvitation, ...updates };
        let resultText = "";
        // Persist only explicit outcomes to patient card; avoid generic "called/reached" overwrite.
        if (nextState.isConfirmed) {
            let timeInfo = "";
            if (nextState.appointmentTime) {
                timeInfo = ` - Saat: ${nextState.appointmentTime}`;
            } else if (Array.isArray(nextState.appointmentTimes) && nextState.appointmentTimes.length > 0) {
                timeInfo = ` - Saat: ${nextState.appointmentTimes.join(', ')}`;
            }
            resultText = `Görüşüldü, Randevu Verildi${timeInfo}`;
        }
        else if (nextState.isRejected) resultText = "Reddedildi / Tekrar Aranmayacak";
        else if (nextState.isPostponed) resultText = "Bu etkinliğe katılmayacak. Bir sonraki etkinliğe davet edilecek.";
        else if (nextState.isWillLetKnow) resultText = "Haber Verecek / Düşünüyor";
        else if (nextState.isCalled && nextState.hasOwnProperty('isReached') && !nextState.isReached) resultText = "Ulaşılamadı";

        if (nextState.calledBy === 'pharmacist' && nextState.isCalled) {
            if (!nextState.isConfirmed && !nextState.isRejected && !nextState.isPostponed && !nextState.isWillLetKnow) resultText = "Eczacı Aradı";
        } else if (nextState.pharmacistWillCall) {
            resultText = "Eczacı Arayacak";
        }

        let visitId = currentInvitation.relatedVisitId;
        const noteContent = nextState.note || "";
        const isAutoTransferNote = noteContent.startsWith("Transfer:") || noteContent.startsWith("Otomatik aktarım");
        const effectiveNote = isAutoTransferNote ? "" : noteContent;
        const hasEffectiveManualNote = !!effectiveNote;

        if (resultText || (hasEffectiveManualNote && visitId)) {
            let fullNote = resultText ? `Uzman Günü Daveti (${latestCompany.name}): ${resultText}` : "";

            if (!fullNote && visitId) {
                const patient = await DataService.getPatient(patientId);
                const existingVisit = patient?.visits?.find(v => String(v?.id || '') === String(visitId));
                const firstLine = String(existingVisit?.note || "").split('\n').find(line => line.trim().length > 0) || "";
                if (firstLine.startsWith("Uzman Günü Daveti")) {
                    fullNote = firstLine;
                }
            }

            if (hasEffectiveManualNote && fullNote) {
                fullNote += `\nNot: ${effectiveNote}`;
            }

            if (fullNote) {
                visitId = await createOrUpdateVisit(patientId, currentInvitation.relatedVisitId, fullNote);
            }
        } else if (visitId) {
            await DataService.deleteVisit(patientId, visitId);
            visitId = null;
        }

        const updatedDays = latestCompany.expertDays.map(d => {
            if (d.id === selectedDay.id) {
                return {
                    ...d,
                    invitations: d.invitations.map(i => {
                        if (i.patientId === patientId) return { ...i, ...updates, relatedVisitId: visitId };
                        return i;
                    })
                };
            }
            return d;
        });

        await DataService.updateCompany(company.id, { expertDays: updatedDays });
        onUpdateCompany();
    };


    const handleNoShowTransition = async (patientId, targetOutcome) => {
        const currentInvitation = selectedDay.invitations.find(i => i.patientId === patientId);
        if (!currentInvitation) return;

        let visitId = currentInvitation.relatedVisitId;
        const eventName = selectedDay.note || "Uzman Günü";
        let statusText = "";
        let finalStateUpdates = {};

        if (targetOutcome === 'postponed') {
            statusText = "GELMEDİ (Randevusuna Gelmedi) - Bir sonraki etkinliğe davet edilecek.";
            finalStateUpdates = { isPostponed: true, isNoShow: false, isConfirmed: false, isAttended: false, isCalled: true, isReached: true };
        } else if (targetOutcome === 'rejected') {
            statusText = "GELMEDİ (Randevusuna Gelmedi) - İstemiyor / Tekrar Aranmayacak.";
            finalStateUpdates = { isRejected: true, isNoShow: false, isConfirmed: false, isAttended: false, isCalled: true, isReached: true };
        }

        const fullNote = `Uzman Günü Daveti (${company.name} - ${eventName}): ${statusText}`;

        // Append existing manual notes if any
        const noteContent = currentInvitation.note || "";
        const isAutoTransferNote = noteContent.startsWith("Transfer:") || noteContent.startsWith("Otomatik aktarım");
        if (noteContent && !isAutoTransferNote) {
            // Avoid duplicating if note already contains it
            if (!noteContent.includes(statusText)) {
                // We create a new note string, logic handled in createOrUpdateVisit usually but here we construct fullNote
                // Let's just pass fullNote + existing manual note
                visitId = await createOrUpdateVisit(patientId, visitId, `${fullNote}\nNot: ${noteContent}`);
            } else {
                visitId = await createOrUpdateVisit(patientId, visitId, fullNote);
            }
        } else {
            visitId = await createOrUpdateVisit(patientId, visitId, fullNote);
        }

        const updatedDays = company.expertDays.map(d => {
            if (d.id === selectedDay.id) {
                return {
                    ...d,
                    invitations: d.invitations.map(i => {
                        if (i.patientId === patientId) {
                            return {
                                ...i,
                                ...finalStateUpdates,
                                relatedVisitId: visitId
                            };
                        }
                        return i;
                    })
                };
            }
            return d;
        });

        await DataService.updateCompany(company.id, { expertDays: updatedDays });
        onUpdateCompany();
    };

    const handleSetOutcome = async (patientId, outcome) => {
        if (outcome === 'confirmed') {
            setAppointmentTargetPatientId(patientId);
            setIsAppointmentModalOpen(true);
            return;
        }

        const currentInvitation = selectedDay.invitations.find(i => i.patientId === patientId);
        let visitId = currentInvitation?.relatedVisitId;

        let fullNote = "";
        if (outcome === 'postponed') fullNote = `Uzman Günü Daveti (${company.name}): Bu etkinliğe katılmayacak. Bir sonraki etkinliğe davet edilecek.`;
        else if (outcome === 'rejected') fullNote = `Uzman Günü Daveti (${company.name}): Reddedildi / Tekrar Aranmayacak`;
        else if (outcome === 'unreachable') fullNote = `Uzman Günü Daveti (${company.name}): Ulaşılamadı`;
        else if (outcome === 'willLetKnow') fullNote = `Uzman Günü Daveti (${company.name}): Haber Verecek / Düşünüyor`;

        if (fullNote) {
            const noteContent = currentInvitation?.note || "";
            const isAutoTransferNote = noteContent.startsWith("Transfer:") || noteContent.startsWith("Otomatik aktarım");
            if (noteContent && !isAutoTransferNote) fullNote += `\nNot: ${noteContent}`;
            visitId = await createOrUpdateVisit(patientId, currentInvitation?.relatedVisitId, fullNote);
        } else if (outcome === 'none' && visitId) {
            await DataService.deleteVisit(patientId, visitId);
            visitId = null;
        }

        const updatedDays = company.expertDays.map(d => {
            if (d.id === selectedDay.id) {
                return {
                    ...d,
                    invitations: d.invitations.map(i => {
                        if (i.patientId === patientId) {
                            const resetState = {
                                isCalled: true, isReached: true, isConfirmed: false, isPostponed: false,
                                isRejected: false, isWillLetKnow: false, appointmentTime: null, relatedVisitId: visitId
                            };
                            if (outcome === 'postponed') return { ...i, ...resetState, isPostponed: true };
                            else if (outcome === 'rejected') return { ...i, ...resetState, isRejected: true };
                            else if (outcome === 'willLetKnow') return { ...i, ...resetState, isWillLetKnow: true };
                            else if (outcome === 'unreachable') return { ...i, ...resetState, isReached: false, isConfirmed: false };
                            else if (outcome === 'none') return { ...i, isCalled: false, isReached: false, isConfirmed: false, isPostponed: false, isRejected: false, isWillLetKnow: false, appointmentTime: null, relatedVisitId: null };
                        }
                        return i;
                    })
                };
            }
            return d;
        });
        await DataService.updateCompany(company.id, { expertDays: updatedDays });
        onUpdateCompany();
    };

    const handleConfirmAppointment = async (timeOrSlots) => {
        if (!appointmentTargetPatientId) return;
        const timesToConfirm = Array.isArray(timeOrSlots) ? timeOrSlots : [timeOrSlots];
        if (timesToConfirm.length === 0) return;

        const takenSlots = selectedDay.invitations.filter(i => {
            if (!i.isConfirmed || i.patientId === appointmentTargetPatientId) return false;
            const times = i.appointmentTimes || (i.appointmentTime ? [i.appointmentTime] : []);
            return times.some(t => timesToConfirm.includes(t));
        });

        if (takenSlots.length > 0) {
            alert("Seçilen saatlerden bazıları dolu!");
            return;
        }

        const currentInvitation = selectedDay.invitations.find(i => i.patientId === appointmentTargetPatientId);
        const eventName = selectedDay.note || "Uzman Günü";
        const timeString = timesToConfirm.join(" - ");
        let fullNote = `Uzman Günü Daveti (${company.name} - ${eventName}): Görüşüldü, Randevu Verildi - Saat: ${timeString}`;
        if (timesToConfirm.length > 1) fullNote += " (Yakını ile birlikte)";

        const noteContent = currentInvitation?.note || "";
        const isAutoTransferNote = noteContent.startsWith("Transfer:") || noteContent.startsWith("Otomatik aktarım");
        if (noteContent && !isAutoTransferNote) fullNote += `\nNot: ${noteContent}`;

        const visitId = await createOrUpdateVisit(appointmentTargetPatientId, currentInvitation?.relatedVisitId, fullNote);

        const updatedDays = company.expertDays.map(d => {
            if (d.id === selectedDay.id) {
                return {
                    ...d,
                    invitations: d.invitations.map(i => {
                        if (i.patientId === appointmentTargetPatientId) {
                            return {
                                ...i,
                                isCalled: true, isReached: true, isConfirmed: true, isPostponed: false,
                                isRejected: false, appointmentTime: timesToConfirm[0], appointmentTimes: timesToConfirm, relatedVisitId: visitId
                            };
                        }
                        return i;
                    })
                };
            }
            return d;
        });

        await DataService.updateCompany(company.id, { expertDays: updatedDays });
        onUpdateCompany();
        setIsAppointmentModalOpen(false);
        setAppointmentTargetPatientId(null);
        setSelectedSlots([]);
        setIsMultiSelect(false);
    };

    // --- CALCULATIONS ---

    let detailsOfInvited = [];
    try {
        detailsOfInvited = (selectedDay?.invitations || []).map(inv => {
            if (!inv) return null;
            const p = Array.isArray(patients) ? patients.find(px => px && String(px.id) === String(inv.patientId)) : null;
            if (!p) return { ...inv, id: inv.patientId || generateUUID(), fullName: inv.fullName || `Bilinmeyen Danışan (${inv.patientId})`, phone: inv.phone || "" };
            return { ...p, ...inv };
        }).filter(p => {
            if (!p) return false;
            const term = normalizeString(String(invitedSearchTerm || ""));
            const name = p.fullName ? normalizeString(String(p.fullName)) : "";
            const phone = p.phone ? String(p.phone) : "";
            const matchesSearch = name.includes(term) || phone.includes(term);
            if (filterInterested) return matchesSearch && p.interestedCompanies?.includes(company.id);
            return matchesSearch;
        }).sort((a, b) => {
            if (a.isPriority && !b.isPriority) return -1;
            if (!a.isPriority && b.isPriority) return 1;
            if (sortOption === "date_new") return new Date(b.invitedAt || 0) - new Date(a.invitedAt || 0);
            if (sortOption === "date_old") return new Date(a.invitedAt || 0) - new Date(b.invitedAt || 0);
            const nameA = a.fullName || "";
            const nameB = b.fullName || "";
            if (sortOption === "alphabetical_asc") return nameA.localeCompare(nameB, 'tr');
            if (sortOption === "alphabetical_desc") return nameB.localeCompare(nameA, 'tr');
            return 0;
        });
    } catch (e) { console.error("Filter error", e); detailsOfInvited = []; }

    detailsOfInvited = detailsOfInvited.slice(0, filterInterested ? 100 : 1000);

    let filteredPatientsToInvite = [];
    try {
        const uninvited = Array.isArray(patients) ? patients.filter(p => p && !selectedDay?.invitations?.some(i => i && i.patientId === p.id)) : [];
        filteredPatientsToInvite = uninvited.filter(p => {
            if (!p) return false;
            const term = normalizeString(inviteSearchTerm || "");
            const name = p.fullName ? normalizeString(p.fullName) : "";
            const phone = p.phone ? String(p.phone) : "";
            const matchesSearch = name.includes(term) || phone.includes(term);
            if (filterInterested) return matchesSearch && p.interestedCompanies?.includes(company.id);
            return matchesSearch;
        }).slice(0, filterInterested ? 100 : 5);
    } catch (e) { filteredPatientsToInvite = []; }


    // --- RENDER ---

    // --- RENDER ---
    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl w-full max-w-7xl h-[85vh] flex flex-col overflow-hidden animate-in fade-in zoom-in duration-200 border border-slate-200 dark:border-slate-800">
                <ModalErrorBoundary onClose={onClose}>

                    {/* Header */}
                    <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-900">
                        <div>
                            <h3 className="text-lg font-bold text-slate-800 dark:text-white">Davetli Listesi</h3>
                            <p className="text-sm text-slate-500 dark:text-slate-400">
                                {safeFormatDate(selectedDay.date, "d MMMM yyyy", { locale: tr })} - {selectedDay.note}
                            </p>
                        </div>
                        <button onClick={onClose} className="p-2 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-full dark:text-slate-400 dark:hover:text-slate-200 transition-colors">
                            <X size={20} />
                        </button>
                    </div>

                    <div className="flex-1 flex overflow-hidden">
                        {/* LEFT: Invite & Config */}
                        <div className="w-1/4 border-r border-slate-100 dark:border-slate-800 flex flex-col bg-slate-50/30 dark:bg-slate-900/50">
                            <div className="p-4 border-b border-slate-100 dark:border-slate-800">
                                <div className="relative">
                                    <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                                    <input
                                        type="text"
                                        className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:ring-teal-500 focus:border-teal-500 text-slate-900 dark:text-white placeholder:text-slate-400"
                                        placeholder="Yeni kişi eklemek için ara..."
                                        value={inviteSearchTerm}
                                        onChange={e => setInviteSearchTerm(e.target.value)}
                                    />
                                </div>
                                <div className="mt-3 flex items-center gap-2">
                                    <button onClick={() => setFilterInterested(!filterInterested)} className={cn("flex-1 py-1.5 px-3 rounded-lg text-xs font-medium border transition-colors flex items-center justify-center gap-1", filterInterested ? "bg-pink-50 dark:bg-pink-900/20 border-pink-200 dark:border-pink-800 text-pink-700 dark:text-pink-300" : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-600")}>
                                        <Package size={12} /> {filterInterested ? "Tümünü Göster" : "Sadece İlgilenenler"}
                                    </button>
                                    <button onClick={() => setIsQuickAddOpen(!isQuickAddOpen)} className={cn("py-1.5 px-3 rounded-lg text-xs font-medium border transition-colors flex items-center justify-center gap-1", isQuickAddOpen ? "bg-teal-50 dark:bg-teal-900/20 border-teal-200 dark:border-teal-800 text-teal-700 dark:text-teal-300" : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-600")}>
                                        <Plus size={12} /> Hızlı Ekle
                                    </button>
                                </div>
                            </div>

                            {/* Quick Add Form */}
                            {isQuickAddOpen && (
                                <div className="p-4 bg-teal-50/50 dark:bg-teal-900/20 border-b border-teal-100 dark:border-teal-800 animate-in slide-in-from-top-2">
                                    <h4 className="text-sm font-bold text-teal-800 dark:text-teal-300 mb-3 flex items-center gap-2">Hızlı Danışan Kaydı</h4>
                                    <div className="space-y-3">
                                        <input type="text" placeholder="Ad Soyad" className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white" value={quickAddForm.fullName} onChange={e => setQuickAddForm({ ...quickAddForm, fullName: e.target.value })} />
                                        <input type="text" placeholder="Telefon" className="w-full px-3 py-2 text-sm border border-slate-200 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white" value={quickAddForm.phone} onChange={e => setQuickAddForm({ ...quickAddForm, phone: e.target.value })} />
                                        <button onClick={async () => {
                                            if (!quickAddForm.fullName) { alert("İsim zorunlu"); return; }
                                            const newP = await DataService.addPatient({ ...quickAddForm, category: "Yeni Danışan" });
                                            onUpdateCompany();
                                            await handleInvitePatient(newP.id);
                                            setQuickAddForm({ fullName: "", phone: "", description: "" }); setIsQuickAddOpen(false);
                                            alert("Danışan eklendi.");
                                        }} className="w-full py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-sm transition-colors">Kaydet ve Ekle</button>
                                    </div>
                                </div>
                            )}

                            {/* Search Results */}
                            {inviteSearchTerm ? (
                                <div className="flex-1 overflow-y-auto p-2 space-y-1">
                                    {filteredPatientsToInvite.map(p => (
                                        <button key={p.id} onClick={() => handleInvitePatient(p.id)} className="w-full text-left p-3 rounded-lg hover:bg-white dark:hover:bg-slate-800 hover:shadow-sm border border-transparent hover:border-slate-100 dark:hover:border-slate-700 transition-all font-medium text-slate-900 dark:text-slate-200">
                                            {p.fullName}
                                        </button>
                                    ))}
                                </div>
                            ) : (
                                <div className="flex-1 flex flex-col overflow-hidden">
                                    {/* Slot Settings */}
                                    <div className="p-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
                                        <div className="flex justify-between mb-2">
                                            <h4 className="text-sm font-bold flex gap-1 text-slate-700 dark:text-slate-300"><Clock size={14} /> Randevu Ayarları</h4>
                                            <div className="flex gap-2">
                                                <button onClick={handlePrintAppointments} className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300 dark:hover:bg-slate-600 px-2 py-1 rounded transition-colors flex items-center gap-1" title="Listeyi Yazdır">
                                                    <Printer size={12} />
                                                </button>
                                                <button onClick={saveSlotSettings} className="text-xs bg-teal-600 hover:bg-teal-700 text-white px-2 py-1 rounded transition-colors">Kaydet</button>
                                            </div>
                                        </div>
                                        <div className="grid grid-cols-3 gap-2 text-xs">
                                            <input type="time" value={slotSettings.startHour} onChange={e => setSlotSettings({ ...slotSettings, startHour: e.target.value })} className="border border-slate-200 dark:border-slate-700 rounded p-1 bg-white dark:bg-slate-800 text-slate-900 dark:text-white" />
                                            <input type="time" value={slotSettings.endHour} onChange={e => setSlotSettings({ ...slotSettings, endHour: e.target.value })} className="border border-slate-200 dark:border-slate-700 rounded p-1 bg-white dark:bg-slate-800 text-slate-900 dark:text-white" />
                                            <input
                                                type="number"
                                                min="5"
                                                value={slotSettings.slotDuration}
                                                onChange={e => {
                                                    const raw = e.target.value;
                                                    if (raw === "") {
                                                        setSlotSettings({ ...slotSettings, slotDuration: "" });
                                                        return;
                                                    }
                                                    const parsed = Number.parseInt(raw, 10);
                                                    if (Number.isNaN(parsed)) return;
                                                    setSlotSettings({ ...slotSettings, slotDuration: parsed });
                                                }}
                                                className="border border-slate-200 dark:border-slate-700 rounded p-1 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                                            />
                                        </div>
                                    </div>
                                    <div className="flex-1 overflow-y-auto p-4 space-y-2">
                                        <div className="text-xs font-semibold text-slate-400 dark:text-slate-500 mb-2">ÖNİZLEME</div>
                                        {generateTimeSlots().map(time => {
                                            const appt = selectedDay.invitations?.find(i => {
                                                if (!i.isConfirmed) return false;
                                                const times = i.appointmentTimes || (i.appointmentTime ? [i.appointmentTime] : []);
                                                return times.includes(time);
                                            });
                                            const p = appt ? patients?.find(px => px.id === appt.patientId) : null;
                                            return (
                                                <div key={time}
                                                    onClick={() => {
                                                        if (p) {
                                                            const el = document.getElementById(`invitation-card-${p.id}`);
                                                            if (el) {
                                                                el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                                                el.classList.add('ring-2', 'ring-teal-500', 'ring-offset-2');
                                                                setTimeout(() => el.classList.remove('ring-2', 'ring-teal-500', 'ring-offset-2'), 2000);
                                                            }
                                                        }
                                                    }}
                                                    className={cn(
                                                        "flex justify-between p-2 rounded border text-sm transition-colors",
                                                        !p ? "bg-white dark:bg-slate-800 border-slate-100 dark:border-slate-700 text-slate-400 dark:text-slate-500" :
                                                            (appt?.isAttended ? "bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-900 text-green-700 dark:text-green-400 hover:bg-green-100 dark:hover:bg-green-900/30" :
                                                                appt?.isNoShow ? "bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-900 text-red-700 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-900/30" :
                                                                    "bg-teal-50 dark:bg-teal-900/20 border-teal-100 dark:border-teal-900 hover:bg-teal-100 dark:hover:bg-teal-900/30 text-teal-700 dark:text-teal-300"),
                                                        p && "cursor-pointer hover:shadow-sm"
                                                    )}
                                                >
                                                    <span className="font-mono font-bold">{time}</span>
                                                    <span className="truncate max-w-[100px]">{p ? p.fullName : "-"}</span>
                                                </div>
                                            )
                                        })}
                                    </div>
                                </div>
                            )}
                        </div>

                        {/* RIGHT: Invited List */}
                        <div className="flex-1 overflow-y-auto p-6 bg-white dark:bg-slate-900 flex flex-col transition-colors">
                            <div className="flex gap-2 mb-4">
                                <input type="text" className="flex-1 pl-3 pr-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white placeholder:text-slate-400" placeholder="Davetli listesinde ara..." value={invitedSearchTerm} onChange={e => setInvitedSearchTerm(e.target.value)} />
                                <select value={sortOption} onChange={(e) => setSortOption(e.target.value)} className="pl-3 pr-8 py-2 rounded-lg border-2 border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-700 dark:text-white font-bold text-sm">
                                    <option value="date_new">Eklenme: Yeni ➝ Eski</option>
                                    <option value="date_old">Eklenme: Eski ➝ Yeni</option>
                                    <option value="alphabetical_asc">İsim: A ➝ Z</option>
                                    <option value="alphabetical_desc">İsim: Z ➝ A</option>
                                </select>
                            </div>

                            <div className="max-h-[calc(100vh-250px)] overflow-y-auto space-y-4 pr-2">
                                {detailsOfInvited.map((p, index) => {
                                    // Determined active outcome
                                    let currentOutcome = 'none';
                                    if (p.isConfirmed) currentOutcome = 'confirmed';
                                    else if (p.isPostponed) currentOutcome = 'postponed';
                                    else if (p.isRejected) currentOutcome = 'rejected';
                                    else if (p.isWillLetKnow) currentOutcome = 'willLetKnow';
                                    else if (p.isCalled && !p.isReached) currentOutcome = 'unreachable';

                                    return (
                                        <div key={`${p.id}-${index}`} id={`invitation-card-${p.id}`} className={cn(
                                            "p-4 rounded-xl border shadow-sm flex flex-col gap-3 transition-all duration-300 scroll-mt-24",
                                            (currentOutcome !== 'none' || p.isCalled) ? "bg-slate-50/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700" : "bg-white dark:bg-slate-800 border-slate-100 dark:border-slate-700"
                                        )}>
                                            <div className="flex justify-between items-start">
                                                <div>
                                                    <div
                                                        onClick={() => navigate(`/patients/${p.id}`, { state: { from: `/companies/${company.id}`, returnDayId: selectedDay?.id } })}
                                                        className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 rounded-lg w-fit font-bold text-sm cursor-pointer transition-colors"
                                                    >
                                                        <User size={16} className="text-slate-500 dark:text-slate-400" />
                                                        {p.fullName}
                                                    </div>
                                                    {/* Transfer Status Badge */}
                                                    {p.transferFromStatus && (
                                                        <div className={cn(
                                                            "px-2 py-0.5 rounded text-[10px] font-bold border inline-flex items-center gap-1 mt-1",
                                                            p.transferFromStatus === 'attended' ? "text-green-700 dark:text-green-400 bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-900" :
                                                                p.transferFromStatus === 'noShow' ? "text-red-700 dark:text-red-400 bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-900" :
                                                                    p.transferFromStatus === 'postponed' ? "text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-900" :
                                                                        p.transferFromStatus === 'unreachable' ? "text-slate-600 dark:text-slate-400 bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700" :
                                                                            "text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700"
                                                        )}>
                                                            <History size={10} />
                                                            Transfer: {
                                                                p.transferFromStatus === 'attended' ? "GELDİ" :
                                                                    p.transferFromStatus === 'noShow' ? "GELMEDİ" :
                                                                        p.transferFromStatus === 'postponed' ? "ERTELENDİ" :
                                                                            p.transferFromStatus === 'unreachable' ? "ULAŞILAMADI" :
                                                                                p.transferFromStatus === 'uncalled' ? "ARANMADI" : "BİLİNMİYOR"
                                                            }
                                                        </div>
                                                    )}
                                                    <div className="text-sm text-slate-500 dark:text-slate-400 flex items-center gap-3 mt-1">
                                                        <span className="flex items-center gap-1.5"><Phone size={14} /> {formatPhoneNumber(p.phone)}</span>
                                                        <span className="w-1 h-1 bg-slate-300 dark:bg-slate-600 rounded-full"></span>
                                                        <span className="flex items-center gap-1.5 opacity-70">
                                                            <Clock size={14} /> Davet: {safeFormatDate(p.invitedAt, "d MMM", { locale: tr })}
                                                        </span>
                                                    </div>
                                                </div>
                                                <div className="flex items-center gap-1">
                                                    <button
                                                        onClick={() => handleTogglePriority(p.id)}
                                                        className="p-2 text-slate-300 dark:text-slate-600 hover:text-amber-400 dark:hover:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-900/20 rounded-lg transition-colors"
                                                        title={p.isPriority ? "Önceliği Kaldır" : "Öncelikli İşaretle"}
                                                    >
                                                        <Star size={20} className={cn("transition-colors", p.isPriority ? "fill-amber-400 text-amber-400" : "")} />
                                                    </button>
                                                    <button onClick={() => handleRemoveInvitation(p.id)} className="p-2 text-slate-300 dark:text-slate-600 hover:text-red-500 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors">
                                                        <Trash2 size={20} />
                                                    </button>
                                                </div>
                                            </div>

                                            <div className="pt-2 border-t border-slate-50/50 dark:border-slate-700/50">
                                                {/* STATE 1: Not called yet */}
                                                {!p.isCalled ? (
                                                    <div className="space-y-2 animate-in fade-in duration-300">
                                                        <textarea
                                                            defaultValue={p.note || ""}
                                                            onBlur={(e) => updateInvitationState(p.id, { note: e.target.value })}
                                                            placeholder="Arama öncesi not..."
                                                            className="w-full text-xs p-2 rounded-lg border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:ring-1 focus:ring-teal-500 min-h-[40px] resize-y bg-slate-50 dark:bg-slate-900 placeholder:text-slate-400 dark:placeholder:text-slate-600 dark:text-slate-200 mb-2"
                                                        />
                                                        <div className="grid grid-cols-2 gap-2">
                                                            <button
                                                                disabled={p.pharmacistWillCall}
                                                                onClick={() => updateInvitationState(p.id, { isCalled: true, isReached: true, isConfirmed: false, isPostponed: false, isRejected: false, calledBy: null })}
                                                                className={cn(
                                                                    "py-3 rounded-xl border font-bold flex flex-col items-center justify-center gap-1 transition-all shadow-sm",
                                                                    p.pharmacistWillCall
                                                                        ? "bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-400 cursor-not-allowed opacity-60"
                                                                        : "bg-blue-600 text-white hover:bg-blue-700 border-transparent hover:shadow-md"
                                                                )}
                                                            >
                                                                <Phone size={20} className="fill-current" /> ARANDI
                                                            </button>
                                                            <button
                                                                onClick={() => updateInvitationState(p.id, { pharmacistWillCall: !p.pharmacistWillCall })}
                                                                className={cn(
                                                                    "py-3 rounded-xl border font-bold flex flex-col items-center justify-center gap-1 transition-all shadow-sm",
                                                                    p.pharmacistWillCall
                                                                        ? "bg-purple-100 dark:bg-purple-900/40 border-purple-300 dark:border-purple-600 text-purple-700 dark:text-purple-300 ring-2 ring-purple-500"
                                                                        : "bg-purple-600 text-white hover:bg-purple-700 border-transparent hover:shadow-md"
                                                                )}
                                                            >
                                                                <User size={20} className="fill-current" />
                                                                {p.pharmacistWillCall ? "ECZACI ARAYACAK" : "ECZACI ARAYACAK"}
                                                            </button>
                                                        </div>

                                                        {p.pharmacistWillCall && (
                                                            <button
                                                                onClick={() => updateInvitationState(p.id, { isCalled: true, isReached: true, isConfirmed: false, isPostponed: false, isRejected: false, calledBy: 'pharmacist' })}
                                                                className="w-full py-3 rounded-xl border border-purple-600 bg-purple-600 text-white font-bold flex items-center justify-center gap-2 hover:bg-purple-700 hover:shadow-md transition-all shadow-sm animate-in zoom-in slide-in-from-top-2 duration-300"
                                                            >
                                                                <Phone size={20} className="fill-current" /> ECZACI ARADI (Sonuç Gir)
                                                            </button>
                                                        )}
                                                    </div>
                                                ) : (
                                                    // STATE 2: Called, decided outcome
                                                    <div className="animate-in fade-in slide-in-from-top-2 duration-300">
                                                        {/* Check if we are in 'Selecting Outcome' state (Called but no Final status) */}
                                                        {(p.isCalled && p.isReached && !p.isConfirmed && !p.isPostponed && !p.isRejected && !p.isWillLetKnow) ? (
                                                            <div>
                                                                {p.calledBy === 'pharmacist' && (
                                                                    <div className="mb-2 px-1 text-xs font-bold text-purple-600 bg-purple-50 p-1 rounded inline-block border border-purple-100">
                                                                        Eczacı arıyor...
                                                                    </div>
                                                                )}
                                                                <div className="flex items-center justify-between mb-2 px-1">
                                                                    <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Sonuç Seçin</span>
                                                                    <button
                                                                        onClick={() => updateInvitationState(p.id, { isCalled: false, isReached: false, calledBy: null })}
                                                                        className="text-[10px] text-red-400 hover:text-red-600 font-medium hover:underline flex items-center gap-1 bg-red-50 px-2 py-1 rounded"
                                                                    >
                                                                        İptal Et
                                                                    </button>
                                                                </div>
                                                                <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
                                                                    <button
                                                                        onClick={() => handleSetOutcome(p.id, 'confirmed')}
                                                                        className="flex items-center gap-2 p-3 rounded-xl border border-teal-100 bg-teal-50/50 text-teal-800 hover:bg-teal-100 hover:border-teal-200 hover:shadow-sm transition-all text-left"
                                                                    >
                                                                        <div className="p-1.5 bg-white rounded-full shadow-sm text-teal-600">
                                                                            <CheckCircle size={16} className="fill-current bg-white rounded-full" />
                                                                        </div>
                                                                        <span className="text-sm font-bold">Gelecek</span>
                                                                    </button>

                                                                    <button
                                                                        onClick={() => handleSetOutcome(p.id, 'postponed')}
                                                                        className="flex items-center gap-2 p-3 rounded-xl border border-amber-100 bg-amber-50/50 text-amber-800 hover:bg-amber-100 hover:border-amber-200 hover:shadow-sm transition-all text-left"
                                                                    >
                                                                        <div className="p-1.5 bg-white rounded-full shadow-sm text-amber-600">
                                                                            <CalendarClock size={16} />
                                                                        </div>
                                                                        <div className="flex flex-col leading-none">
                                                                            <span className="text-sm font-bold">Sonraki</span>
                                                                            <span className="text-[10px] opacity-70">Tekrar Ara</span>
                                                                        </div>
                                                                    </button>

                                                                    <button
                                                                        onClick={() => handleSetOutcome(p.id, 'rejected')}
                                                                        className="flex items-center gap-2 p-3 rounded-xl border border-red-100 bg-red-50/50 text-red-800 hover:bg-red-100 hover:border-red-200 hover:shadow-sm transition-all text-left"
                                                                    >
                                                                        <div className="p-1.5 bg-white rounded-full shadow-sm text-red-600">
                                                                            <Ban size={16} />
                                                                        </div>
                                                                        <span className="text-sm font-bold">İstemiyor</span>
                                                                    </button>

                                                                    <button
                                                                        onClick={() => handleSetOutcome(p.id, 'unreachable')}
                                                                        className="flex items-center gap-2 p-3 rounded-xl border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 hover:border-slate-300 hover:shadow-sm transition-all text-left"
                                                                    >
                                                                        <div className="p-1.5 bg-slate-100 rounded-full shadow-sm text-slate-500">
                                                                            <Phone size={16} className="rotate-12" />
                                                                        </div>
                                                                        <span className="text-sm font-bold">Ulaşılamadı</span>
                                                                    </button>

                                                                    <button
                                                                        onClick={() => handleSetOutcome(p.id, 'willLetKnow')}
                                                                        className="flex items-center gap-2 p-3 rounded-xl border border-indigo-100 bg-indigo-50/50 text-indigo-800 hover:bg-indigo-100 hover:border-indigo-200 hover:shadow-sm transition-all text-left"
                                                                    >
                                                                        <div className="p-1.5 bg-white rounded-full shadow-sm text-indigo-600">
                                                                            <MessageCircle size={16} />
                                                                        </div>
                                                                        <span className="text-sm font-bold">Haber Verecek</span>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        ) : (
                                                            // STATE 3: Final Outcome Badge
                                                            <div>
                                                                <div className={cn(
                                                                    "flex items-center justify-between p-4 rounded-xl border-2 shadow-sm animate-in zoom-in-95 duration-200",
                                                                    p.isConfirmed ? "bg-teal-50 dark:bg-teal-900/20 border-teal-200 dark:border-teal-800" :
                                                                        p.isPostponed ? "bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800" :
                                                                            p.isRejected ? "bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800" :
                                                                                p.isWillLetKnow ? "bg-indigo-50 dark:bg-indigo-900/20 border-indigo-200 dark:border-indigo-800" :
                                                                                    "bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700"
                                                                )}>
                                                                    <div className="flex items-center gap-4">
                                                                        {p.isConfirmed && (
                                                                            <div className="flex items-center gap-4 text-teal-700 dark:text-teal-400">
                                                                                <div className="p-3 bg-teal-100 dark:bg-teal-900/50 rounded-xl shadow-inner shadow-teal-500/10">
                                                                                    <CheckCircle size={32} className="fill-current" />
                                                                                </div>
                                                                                <div>
                                                                                    <div className="font-black text-xl tracking-tight">GELECEK</div>
                                                                                    <div className="text-sm opacity-90 font-medium">Arandı ve teyit alındı</div>
                                                                                    {p.appointmentTime && (
                                                                                        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-teal-200/50 dark:bg-teal-900/50 text-teal-800 dark:text-teal-200 font-bold text-sm mt-1.5">
                                                                                            <Clock size={14} />
                                                                                            {p.appointmentTime}
                                                                                        </div>
                                                                                    )}
                                                                                </div>
                                                                            </div>
                                                                        )}
                                                                        {p.isPostponed && (
                                                                            <div className="flex items-center gap-4 text-amber-700 dark:text-amber-400">
                                                                                <div className="p-3 bg-amber-100 dark:bg-amber-900/50 rounded-xl shadow-inner shadow-amber-500/10">
                                                                                    <CalendarClock size={32} className="fill-current" />
                                                                                </div>
                                                                                <div>
                                                                                    <div className="font-black text-xl tracking-tight">SONRAKİ</div>
                                                                                    <div className="text-sm opacity-90 font-medium">Şimdilik katılmayacak</div>
                                                                                    <div className="text-xs font-bold mt-1 bg-amber-200/50 dark:bg-amber-900/50 px-2 py-0.5 rounded inline-block">Bir sonraki etkinliğe davet edilecek</div>
                                                                                </div>
                                                                            </div>
                                                                        )}
                                                                        {p.isRejected && (
                                                                            <div className="flex items-center gap-4 text-red-700 dark:text-red-400">
                                                                                <div className="p-3 bg-red-100 dark:bg-red-900/50 rounded-xl shadow-inner shadow-red-500/10">
                                                                                    <Ban size={32} className="fill-current" />
                                                                                </div>
                                                                                <div>
                                                                                    <div className="font-black text-xl tracking-tight">İSTEMİYOR</div>
                                                                                    <div className="text-sm opacity-90 font-medium">Tekrar aranmayacak</div>
                                                                                </div>
                                                                            </div>
                                                                        )}
                                                                        {(!p.isReached && p.isCalled) && (
                                                                            <div className="flex items-center gap-4 text-slate-600 dark:text-slate-300">
                                                                                <div className="p-3 bg-slate-200 dark:bg-slate-700 rounded-xl shadow-inner">
                                                                                    <Phone size={32} className="rotate-12 fill-current" />
                                                                                </div>
                                                                                <div>
                                                                                    <div className="font-black text-xl tracking-tight">ULAŞILAMADI</div>
                                                                                    <div className="text-sm opacity-90 font-medium">Daha sonra tekrar dene</div>
                                                                                </div>
                                                                            </div>
                                                                        )}
                                                                        {p.isWillLetKnow && (
                                                                            <div className="flex items-center gap-4 text-indigo-700 dark:text-indigo-400">
                                                                                <div className="p-3 bg-indigo-100 dark:bg-indigo-900/50 rounded-xl shadow-inner shadow-indigo-500/10">
                                                                                    <MessageCircle size={32} className="fill-current" />
                                                                                </div>
                                                                                <div>
                                                                                    <div className="font-black text-xl tracking-tight">HABER VERECEK</div>
                                                                                    <div className="text-sm opacity-90 font-medium">Dönüş bekleniyor</div>
                                                                                </div>
                                                                            </div>
                                                                        )}
                                                                    </div>

                                                                    <div className="flex items-center gap-3">
                                                                        {/* Attendance Toggle only visible if confirmed or attended */}
                                                                        {(p.isConfirmed || p.isAttended || p.isNoShow) && (
                                                                            <div className="flex items-center gap-2">
                                                                                {/* 1. Status Information Label */}
                                                                                {(p.isAttended || p.isNoShow) && (
                                                                                    <div className={cn(
                                                                                        "px-3 py-1.5 rounded-lg text-sm font-bold border flex items-center gap-2",
                                                                                        p.isAttended
                                                                                            ? "bg-green-50 text-green-700 border-green-200"
                                                                                            : "bg-red-50 text-red-700 border-red-200"
                                                                                    )}>
                                                                                        {p.isAttended ? (
                                                                                            <><CheckCircle size={16} /> GELDİ</>
                                                                                        ) : (
                                                                                            <><XCircle size={16} /> GELMEDİ</>
                                                                                        )}
                                                                                    </div>
                                                                                )}

                                                                                {/* 2. Buttons */}
                                                                                {!p.isAttended && !p.isNoShow && (
                                                                                    <>
                                                                                        <button
                                                                                            onClick={() => handleToggleStatus(p.id, 'isAttended')}
                                                                                            className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-xl text-sm font-bold transition-all shadow-md active:scale-95 flex items-center gap-2"
                                                                                        >
                                                                                            <Check size={18} strokeWidth={3} />
                                                                                            GELDİ
                                                                                        </button>
                                                                                        <button
                                                                                            onClick={() => handleToggleStatus(p.id, 'isNoShow')}
                                                                                            className="bg-slate-200 dark:bg-slate-700 hover:bg-red-500 hover:text-white text-slate-600 dark:text-slate-300 px-4 py-2 rounded-xl text-sm font-bold transition-all shadow-sm active:scale-95 flex items-center gap-2 group"
                                                                                        >
                                                                                            <XCircle size={18} className="text-slate-400 group-hover:text-white" />
                                                                                            GELMEDİ
                                                                                        </button>
                                                                                    </>
                                                                                )}

                                                                                {/* 3. Undo/Cancel Attendance (If attended) */}
                                                                                {(p.isAttended || p.isNoShow) && (
                                                                                    <div className="flex items-center gap-2 border-l border-slate-300 dark:border-slate-600 pl-3 ml-2">
                                                                                        <button
                                                                                            onClick={() => handleToggleStatus(p.id, p.isAttended ? 'isAttended' : 'isNoShow')}
                                                                                            className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 px-2 py-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors font-medium"
                                                                                            title="Durumu Değiştir"
                                                                                        >
                                                                                            <Edit2 size={14} /> Değiştir
                                                                                        </button>

                                                                                        {p.isNoShow && (
                                                                                            <>
                                                                                                <button
                                                                                                    onClick={() => handleNoShowTransition(p.id, 'postponed')}
                                                                                                    className="flex items-center gap-1.5 px-2 py-1 bg-amber-500 hover:bg-amber-600 text-white rounded-md text-[10px] font-bold transition-all shadow-sm"
                                                                                                    title="GELMEDİ -> Sonraki Sefere"
                                                                                                >
                                                                                                    <CalendarClock size={12} /> Sonraki
                                                                                                </button>
                                                                                                <button
                                                                                                    onClick={() => handleNoShowTransition(p.id, 'rejected')}
                                                                                                    className="flex items-center gap-1.5 px-2 py-1 bg-red-600 hover:bg-red-700 text-white rounded-md text-[10px] font-bold transition-all shadow-sm"
                                                                                                    title="GELMEDİ -> İstemiyor"
                                                                                                >
                                                                                                    <Ban size={12} /> İstemiyor
                                                                                                </button>
                                                                                            </>
                                                                                        )}
                                                                                    </div>
                                                                                )}
                                                                            </div>
                                                                        )}

                                                                        {/* Actions for Will Let Know */}
                                                                        {p.isWillLetKnow && (
                                                                            <div className="flex items-center gap-2">
                                                                                <button
                                                                                    onClick={() => handleSetOutcome(p.id, 'confirmed')}
                                                                                    className="flex items-center gap-1.5 px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-bold transition-all shadow-sm"
                                                                                    title="Geliyorum dedi"
                                                                                >
                                                                                    <CheckCircle size={14} /> Gelecek
                                                                                </button>
                                                                                <button
                                                                                    onClick={() => handleSetOutcome(p.id, 'postponed')}
                                                                                    className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-xs font-bold transition-all shadow-sm"
                                                                                    title="Sonraki sefere dedi"
                                                                                >
                                                                                    <CalendarClock size={14} /> Sonraki
                                                                                </button>
                                                                            </div>
                                                                        )}

                                                                        <div className="h-8 w-px bg-slate-200 mx-1"></div>

                                                                        {/* Edit/Undo Button */}
                                                                        <button
                                                                            onClick={() => updateInvitationState(p.id, { isConfirmed: false, isPostponed: false, isRejected: false, isWillLetKnow: false, isAttended: false, isCalled: true, isReached: true, note: "" })}
                                                                            className="flex flex-col items-center justify-center p-3 text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition-all group scale-90 hover:scale-100"
                                                                            title="Seçimi İptal Et"
                                                                        >
                                                                            <XCircle size={24} className="mb-0.5" />
                                                                            <span className="text-[10px] font-bold">İptal</span>
                                                                        </button>
                                                                    </div>
                                                                </div>


                                                                {/* Note Input Area */}
                                                                <div className="mt-3 pt-3 border-t border-slate-100">
                                                                    <textarea
                                                                        defaultValue={p.note || ""}
                                                                        onBlur={(e) => updateInvitationState(p.id, { note: e.target.value })}
                                                                        placeholder="Sonuç ile ilgili not ekle..."
                                                                        className="w-full text-sm p-2 rounded-lg border border-slate-200 dark:border-slate-700 focus:border-teal-500 focus:ring-1 focus:ring-teal-500 min-h-[60px] resize-y bg-slate-50 dark:bg-slate-900 placeholder:text-slate-400 dark:placeholder:text-slate-600 dark:text-slate-200"
                                                                    />
                                                                </div>
                                                            </div>
                                                        )}
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    )
                                })}
                            </div>
                        </div>
                    </div>

                    {isAppointmentModalOpen && (
                        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 backdrop-blur-sm">
                            <div className="bg-white dark:bg-slate-800 p-6 rounded-xl w-full max-w-lg shadow-xl border border-slate-100 dark:border-slate-700 animate-in zoom-in-95">
                                <h3 className="font-bold mb-4 text-slate-800 dark:text-white">Saat Seç</h3>
                                <div className="grid grid-cols-4 gap-2 max-h-60 overflow-y-auto pr-2">
                                    {generateTimeSlots().map(t => {
                                        // simple availability check
                                        const taken = selectedDay.invitations.some(i => i.isConfirmed && (i.appointmentTimes || [i.appointmentTime]).includes(t));
                                        const selected = selectedSlots.includes(t);
                                        return <button key={t} disabled={taken} onClick={() => isMultiSelect ? (selected ? setSelectedSlots(s => s.filter(x => x !== t)) : setSelectedSlots(s => [...s, t])) : handleConfirmAppointment(t)} className={cn("p-2 border rounded transition-colors text-sm font-medium", taken ? "bg-slate-100 dark:bg-slate-700 border-slate-200 dark:border-slate-600 text-slate-300 dark:text-slate-500 cursor-not-allowed" : selected ? "bg-teal-100 dark:bg-teal-900/30 border-teal-500 text-teal-700 dark:text-teal-400" : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-600 hover:border-teal-500 dark:hover:border-teal-400 text-slate-700 dark:text-slate-300")}>{t}</button>
                                    })}
                                </div>
                                {isMultiSelect && <button onClick={() => handleConfirmAppointment(selectedSlots)} className="mt-4 w-full bg-teal-600 hover:bg-teal-700 text-white py-3 rounded-lg font-bold transition-colors">Onayla</button>}
                                <div className="mt-4 flex gap-2 items-center">
                                    <label className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400 cursor-pointer select-none"><input type="checkbox" checked={isMultiSelect} onChange={e => setIsMultiSelect(e.target.checked)} className="rounded text-teal-600 focus:ring-teal-500" /> Çoklu Seçim</label>
                                    <button onClick={() => setIsAppointmentModalOpen(false)} className="ml-auto text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 text-sm font-medium">İptal</button>
                                </div>
                            </div>
                        </div>
                    )}
                </ModalErrorBoundary>
            </div>
        </div>
    );
}
