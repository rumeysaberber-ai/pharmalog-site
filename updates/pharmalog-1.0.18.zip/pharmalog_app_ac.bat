@echo off
setlocal

set "APP_URL=%~1"
if "%APP_URL%"=="" set "APP_URL=http://localhost:3001"

set "CACHE_BUSTER=%RANDOM%%RANDOM%"
echo "%APP_URL%" | findstr /C:"?" >nul
if %errorlevel% equ 0 (
    set "APP_URL=%APP_URL%&v=%CACHE_BUSTER%"
) else (
    set "APP_URL=%APP_URL%?v=%CACHE_BUSTER%"
)

set "BROWSER_PROFILE=%LOCALAPPDATA%\PharmaLog\BrowserProfile"
if not exist "%BROWSER_PROFILE%" mkdir "%BROWSER_PROFILE%" >nul 2>nul

set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"

if exist "%EDGE%" (
    start "" "%EDGE%" --app="%APP_URL%" --class=PharmaLog --user-data-dir="%BROWSER_PROFILE%" --disable-application-cache --disk-cache-size=1
    exit /b
)

if exist "%CHROME%" (
    start "" "%CHROME%" --app="%APP_URL%" --user-data-dir="%BROWSER_PROFILE%" --disable-application-cache --disk-cache-size=1
    exit /b
)

start "" "%APP_URL%"
