@echo off
title PharmaLog Otomatik Baslatma Kur
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0otomatik_baslatma_kur.ps1"
pause
