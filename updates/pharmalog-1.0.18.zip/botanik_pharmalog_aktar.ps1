param(
    [switch]$ManualRange
)

$ErrorActionPreference = "Stop"

Set-Location -LiteralPath $PSScriptRoot

$configPath = Join-Path $PSScriptRoot "botanik_pharmalog_aktarim_config.json"
$logPath = Join-Path $PSScriptRoot "botanik_pharmalog_aktarim.log"

function Write-Log {
    param([string]$Message, [string]$Color = "Gray")
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $Message"
    Add-Content -LiteralPath $logPath -Value $line -Encoding UTF8
    Write-Host $Message -ForegroundColor $Color
}

function Normalize-PharmaLogUrl {
    param([string]$Url)
    $clean = ""
    if ($null -ne $Url) { $clean = $Url.Trim().TrimEnd("/") }
    if (-not $clean) { return "" }
    if ($clean -notmatch "^https?://") { $clean = "http://$clean" }
    return $clean
}

function Read-DateInput {
    param([string]$Prompt, [datetime]$DefaultValue)

    $value = Read-Host "$Prompt (GG.AA.YYYY, bos birakirsan $($DefaultValue.ToString('dd.MM.yyyy')))"
    if (-not $value.Trim()) { return $DefaultValue.Date }

    $culture = [System.Globalization.CultureInfo]::GetCultureInfo("tr-TR")
    return [datetime]::ParseExact($value.Trim(), "dd.MM.yyyy", $culture)
}

function Read-Or-CreateConfig {
    if (Test-Path -LiteralPath $configPath) {
        return Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
    }

    Write-Host ""
    Write-Host "Ilk kurulum: Botanik -> PharmaLog aktarim ayarlari" -ForegroundColor Cyan
    Write-Host ""
    $url = Read-Host "PharmaLog ana bilgisayar adresi (ornek http://192.168.1.178:3001)"
    $token = Read-Host "PharmaLog aktarim anahtari"

    $config = [ordered]@{
        pharmalogUrl = Normalize-PharmaLogUrl $url
        importToken = $token.Trim()
        sqlServer = ".\BOTANIKSQL"
        database = "eczane"
        lookbackDays = 7
        batchSize = 1000
        lastImportedSaleId = 0
    }

    $config | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $configPath -Encoding UTF8
    return Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
}

function Invoke-SqlRows {
    param([string]$ConnectionString, [string]$Query)

    $connection = New-Object System.Data.SqlClient.SqlConnection $ConnectionString
    $command = $connection.CreateCommand()
    $command.CommandText = $Query
    $command.CommandTimeout = 120
    $table = New-Object System.Data.DataTable
    $adapter = New-Object System.Data.SqlClient.SqlDataAdapter $command

    try {
        [void]$adapter.Fill($table)
        return $table
    } finally {
        $connection.Close()
        $connection.Dispose()
    }
}

try {
    $config = Read-Or-CreateConfig
    $pharmalogUrl = Normalize-PharmaLogUrl $config.pharmalogUrl

    $importToken = ""
    if ($null -ne $config.importToken) { $importToken = $config.importToken.Trim() }

    $sqlServer = ".\BOTANIKSQL"
    if ($null -ne $config.sqlServer -and $config.sqlServer.Trim()) { $sqlServer = $config.sqlServer.Trim() }

    $database = "eczane"
    if ($null -ne $config.database -and $config.database.Trim()) { $database = $config.database.Trim() }

    $lookbackDaysValue = 7
    if ($null -ne $config.lookbackDays) { $lookbackDaysValue = [int]$config.lookbackDays }
    $lookbackDays = [Math]::Max(1, $lookbackDaysValue)

    $batchSizeValue = 1000
    if ($null -ne $config.batchSize) { $batchSizeValue = [int]$config.batchSize }
    $batchSize = [Math]::Min(5000, [Math]::Max(1, $batchSizeValue))

    $lastImportedSaleIdValue = 0
    if ($null -ne $config.lastImportedSaleId) { $lastImportedSaleIdValue = [int]$config.lastImportedSaleId }

    if (-not $pharmalogUrl -or -not $importToken) {
        throw "PharmaLog adresi veya aktarim anahtari eksik. $configPath dosyasini silip tekrar calistirin."
    }

    if ($ManualRange) {
        Write-Host ""
        Write-Host "Manuel tarih araligi ile Botanik satis aktarimi" -ForegroundColor Cyan
        $defaultStart = (Get-Date).AddDays(-30)
        $defaultEnd = Get-Date
        $rangeStart = Read-DateInput "Baslangic tarihi" $defaultStart
        $rangeEnd = (Read-DateInput "Bitis tarihi" $defaultEnd).Date.AddDays(1).AddSeconds(-1)
    } else {
        $rangeStart = (Get-Date).Date.AddDays(-$lookbackDays)
        $rangeEnd = Get-Date
    }

    if ($rangeEnd -lt $rangeStart) {
        throw "Bitis tarihi baslangic tarihinden once olamaz."
    }

    $rangeStartSql = $rangeStart.ToString("yyyy-MM-dd HH:mm:ss")
    $rangeEndSql = $rangeEnd.ToString("yyyy-MM-dd HH:mm:ss")

    Write-Log "Botanik -> PharmaLog aktarim basladi." "Cyan"
    Write-Log "PharmaLog: $pharmalogUrl"
    Write-Log "SQL: $sqlServer / $database"
    Write-Log "Tarih araligi: $($rangeStart.ToString('dd.MM.yyyy HH:mm')) - $($rangeEnd.ToString('dd.MM.yyyy HH:mm'))"

    $connectionString = "Server=$sqlServer;Database=$database;Integrated Security=True;TrustServerCertificate=True;"

    $query = @"
WITH CategoryTree AS (
    SELECT KatId, KatUstId, KatAdi, KatId AS RootKatId, KatAdi AS RootKatAdi
    FROM dbo.UrunKategorisi
    WHERE KatId IN (2, 9) AND ISNULL(KatSilme, 0) = 0
    UNION ALL
    SELECT child.KatId, child.KatUstId, child.KatAdi, parent.RootKatId, parent.RootKatAdi
    FROM dbo.UrunKategorisi child
    JOIN CategoryTree parent ON child.KatUstId = parent.KatId
    WHERE ISNULL(child.KatSilme, 0) = 0
),
TargetSales AS (
    SELECT TOP ($batchSize) ea.RxId
    FROM dbo.EldenAna ea
    JOIN dbo.EldenIlaclari ei ON ei.RIRxId = ea.RxId
    JOIN dbo.UrunKategori uk ON uk.UrunId = ei.RIUrunId
    JOIN CategoryTree ct ON ct.KatId = uk.KatId
    JOIN dbo.Musteri m ON m.MusteriId = ea.RxMusteriId
    WHERE ISNULL(ea.RxSilme, 0) = 0
      AND ISNULL(ei.RISilme, 0) = 0
      AND ISNULL(ei.RIIade, 0) = 0
      AND ea.RxIslemTarihi >= CONVERT(datetime, '$rangeStartSql', 120)
      AND ea.RxIslemTarihi <= CONVERT(datetime, '$rangeEndSql', 120)
      AND ea.RxMusteriId IS NOT NULL
      AND ea.RxMusteriId <> 0
      AND NULLIF(LTRIM(RTRIM(ISNULL(m.MusteriAdiSoyadi, ''))), '') IS NOT NULL
    GROUP BY ea.RxId
    ORDER BY ea.RxId ASC
)
SELECT
    ea.RxId AS SaleId,
    ea.RxIslemTarihi AS SaleDate,
    ea.RxMusteriId AS CustomerId,
    COALESCE(NULLIF(LTRIM(RTRIM(m.MusteriAdiSoyadi)), ''), LTRIM(RTRIM(CONCAT(ISNULL(m.MusteriAdi, ''), ' ', ISNULL(m.MusteriSoyadi, ''))))) AS CustomerName,
    ISNULL(m.MusteriTelCep, '') AS Phone,
    ISNULL(CONVERT(varchar(10), m.MusteriDogumTarihi, 23), '') AS BirthDate,
    ct.RootKatAdi AS MainCategory,
    ct.KatAdi AS Category,
    ei.RIId AS SaleLineId,
    ei.RIUrunId AS ProductId,
    ISNULL(u.UrunAdi, '') AS ProductName,
    ISNULL(bar.BarkodAdi, '') AS Barcode,
    ISNULL(ei.RIAdet, 1) AS Quantity,
    ISNULL(ei.RIEtiketFiyati, 0) AS Price,
    ISNULL(ei.RIToplam, 0) AS Total
FROM TargetSales ts
JOIN dbo.EldenAna ea ON ea.RxId = ts.RxId
JOIN dbo.EldenIlaclari ei ON ei.RIRxId = ea.RxId
JOIN dbo.Urun u ON u.UrunId = ei.RIUrunId
JOIN dbo.UrunKategori uk ON uk.UrunId = ei.RIUrunId
JOIN CategoryTree ct ON ct.KatId = uk.KatId
JOIN dbo.Musteri m ON m.MusteriId = ea.RxMusteriId
OUTER APPLY (
    SELECT TOP 1 b.BarkodAdi
    FROM dbo.Barkod b
    WHERE b.BarkodUrunId = ei.RIUrunId AND ISNULL(b.BarkodSilme, 0) = 0
    ORDER BY b.BarkodId
) bar
WHERE ISNULL(ei.RISilme, 0) = 0
  AND ISNULL(ei.RIIade, 0) = 0
ORDER BY ea.RxId ASC, ei.RIId ASC
OPTION (MAXRECURSION 20)
"@

    $rows = Invoke-SqlRows -ConnectionString $connectionString -Query $query
    $salesById = [ordered]@{}

    foreach ($row in $rows.Rows) {
        $saleId = [string]$row.SaleId
        if (-not $salesById.Contains($saleId)) {
            $salesById[$saleId] = [ordered]@{
                externalSaleId = "Botanik-Elden-$saleId"
                externalCustomerId = [string]$row.CustomerId
                customerName = [string]$row.CustomerName
                phone = [string]$row.Phone
                birthDate = [string]$row.BirthDate
                saleDate = ([datetime]$row.SaleDate).ToString("o")
                category = "Botanik elden satis"
                note = "Botanik elden satis aktarimi"
                products = @()
            }
        }

        $salesById[$saleId].products += [ordered]@{
            id = "Botanik-Elden-Line-$($row.SaleLineId)"
            productId = [string]$row.ProductId
            barcode = [string]$row.Barcode
            productName = [string]$row.ProductName
            quantity = [int]$row.Quantity
            price = [decimal]$row.Price
            total = [decimal]$row.Total
            notes = "$($row.MainCategory) / $($row.Category)"
        }
    }

    $sales = @($salesById.Values)
    $body = @{
        sourceName = "Botanik"
        syncMode = "replaceRange"
        syncRangeStart = $rangeStart.ToString("o")
        syncRangeEnd = $rangeEnd.ToString("o")
        sales = $sales
    } | ConvertTo-Json -Depth 8

    $response = Invoke-RestMethod -Uri "$pharmalogUrl/api/integrations/pharmacy-sales/import" -Method Post -ContentType "application/json; charset=utf-8" -Headers @{
        "X-Pharmalog-Import-Token" = $importToken
    } -Body $body -TimeoutSec 120

    if ($salesById.Keys.Count -gt 0) {
        $maxSaleId = ($salesById.Keys | ForEach-Object { [int]$_ } | Measure-Object -Maximum).Maximum
        if ($maxSaleId -gt $lastImportedSaleIdValue) {
            $config.lastImportedSaleId = $maxSaleId
        }
    }

    $config.pharmalogUrl = $pharmalogUrl
    $config | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $configPath -Encoding UTF8

    Write-Log "Aktarim tamamlandi. Yeni danisan: $($response.created), yeni ziyaret: $($response.updated), yenilenen: $($response.refreshed), kaldirilan: $($response.removed), atlanan: $($response.skipped)" "Green"
    if ($salesById.Keys.Count -eq $batchSize) {
        Write-Log "Uyari: Bu aralikta $batchSize satis sinirina ulasildi. Daha kucuk tarih araligi ile tekrar aktarim yapin." "Yellow"
    }
} catch {
    Write-Log "[HATA] $($_.Exception.Message)" "Red"
    exit 1
}
