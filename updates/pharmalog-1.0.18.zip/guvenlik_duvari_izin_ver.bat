@echo off
title PharmaLog Guvenlik Duvari Izni
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell.exe -Verb RunAs -ArgumentList '-NoProfile -ExecutionPolicy Bypass -File ""%~dp0guvenlik_duvari_izin_ver.ps1""'"
