@echo off
title PharmaLog Aktarim Anahtari
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0pharmalog_import_anahtari_goster.ps1"
pause
