$ErrorActionPreference = "Stop"

Set-Location -LiteralPath $PSScriptRoot

$taskName = "PharmaLog Botanik Otomatik Aktarim"
$scriptPath = Join-Path $PSScriptRoot "botanik_pharmalog_aktar.ps1"

if (-not (Test-Path -LiteralPath $scriptPath)) {
    throw "botanik_pharmalog_aktar.ps1 bulunamadi."
}

$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$scriptPath`""
$triggerAtLogon = New-ScheduledTaskTrigger -AtLogOn
$triggerRepeating = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(2) -RepetitionInterval (New-TimeSpan -Minutes 5) -RepetitionDuration (New-TimeSpan -Days 3650)
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -MultipleInstances IgnoreNew

Register-ScheduledTask -TaskName $taskName -Action $action -Trigger @($triggerAtLogon, $triggerRepeating) -Settings $settings -Force | Out-Null

Write-Host "Botanik -> PharmaLog otomatik aktarim gorevi kuruldu." -ForegroundColor Green
Write-Host "Gorev adi: $taskName" -ForegroundColor Cyan
Write-Host "Program bilgisayar acilinca ve her 5 dakikada bir arka planda aktarim yapar." -ForegroundColor Cyan
