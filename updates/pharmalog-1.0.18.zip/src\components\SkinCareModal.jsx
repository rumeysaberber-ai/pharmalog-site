
import React, { useState, useEffect, useRef } from 'react';
import { X, Plus, Calendar, Clock, Check, Trash2, Shield, Heart, Award, History, AlertTriangle, Pencil } from 'lucide-react';
import { format } from 'date-fns';
import { tr } from 'date-fns/locale';
import { cn, generateUUID } from '../lib/utils';

export default function SkinCareModal({ isOpen, onClose, onSave, initialData }) {
    const [activeTab, setActiveTab] = useState('overview'); // overview, history, appointments
    const [data, setData] = useState({
        freeRights: 0,
        transactions: [], // { id, date, type: 'add_right'|'use_right'|'paid_service', description, amount? }
        appointments: []  // { id, date, note, status: 'scheduled'|'completed'|'cancelled' }
    });

    // Form States
    const [rightForm, setRightForm] = useState({ amount: 1, reason: "" });
    const [serviceForm, setServiceForm] = useState({
        type: 'usage',
        description: "",
        amount: "",
        createAppointment: false,
        apptDate: "",
        apptTime: "09:00",
        apptNote: ""
    }); // type: usage (free) | paid
    const [appointmentForm, setAppointmentForm] = useState({ date: "", time: "09:00", note: "" });
    const [editingApptId, setEditingApptId] = useState(null);
    const [customAmount, setCustomAmount] = useState(7500);

    const dateInputRef = useRef(null);

    // Helper to calculate balance from transactions
    const calculateBalance = (transactions) => {
        return transactions.reduce((acc, t) => {
            if (t.type === 'add_right') return acc + (parseInt(t.value) || 0);
            if (t.type === 'use_right') return acc - 1;
            return acc;
        }, 0);
    };

    useEffect(() => {
        if (isOpen && initialData) {
            // Force recalculation from history to ensure consistency
            const transactions = initialData.transactions || [];
            const calculatedRights = calculateBalance(transactions);

            setData({
                freeRights: calculatedRights,
                transactions: transactions,
                appointments: initialData.appointments || []
            });
        }
    }, [isOpen, initialData]);

    const handleSave = () => {
        onSave(data);
        onClose();
    };

    // --- Actions ---

    const handleAddRight = (e) => {
        e.preventDefault();
        const amount = parseInt(rightForm.amount);
        if (amount <= 0) return;

        const newTransaction = {
            id: generateUUID(),
            date: new Date().toISOString(),
            type: 'add_right',
            description: rightForm.reason || "Hak Tanımlama",
            value: amount
        };

        const newData = {
            ...data,
            freeRights: calculateBalance([newTransaction, ...data.transactions]),
            transactions: [newTransaction, ...data.transactions]
        };
        setData(newData);
        onSave(newData); // Auto-save
        setRightForm({ amount: 1, reason: "" });
    };

    const handleAddService = (e) => {
        e.preventDefault();

        const isFreeUsage = serviceForm.type === 'usage';

        // 1. FREE USAGE -> Redirect to Appointment
        if (isFreeUsage) {
            if (data.freeRights <= 0) {
                alert("Yetersiz ücretsiz bakım hakkı!");
                return;
            }
            // Redirect to appointments tab
            setActiveTab('appointments');
            // Pre-fill appointment form
            setAppointmentForm({
                date: "",
                time: "09:00",
                note: "Cilt Bakımı (Hak Kullanımı)"
            });
            return;
        }

        // 2. PAID SERVICE -> Process Transaction & Redirect to Appointment
        if (serviceForm.type === 'paid') {
            const newTransaction = {
                id: generateUUID(),
                date: new Date().toISOString(),
                type: 'paid_service',
                description: serviceForm.description || "Ücretli Cilt Bakımı",
                amount: parseFloat(serviceForm.amount || 0)
            };

            const newData = {
                ...data,
                freeRights: calculateBalance([newTransaction, ...data.transactions]),
                transactions: [newTransaction, ...data.transactions]
            };

            setData(newData);
            onSave(newData); // Auto-save

            // Redirect to appointments tab
            setActiveTab('appointments');
            // Pre-fill appointment form
            setAppointmentForm({
                date: "",
                time: "09:00",
                note: `Ücretli İşlem: ${serviceForm.description || "Cilt Bakımı"}`
            });

            // Reset Form (though we moved away)
            setServiceForm({
                type: 'usage',
                description: "",
                amount: "",
                createAppointment: false,
                apptDate: "",
                apptTime: "09:00",
                apptNote: ""
            });
        }
    };

    const handleAddAppointment = (e) => {
        e.preventDefault();
        if (!appointmentForm.date) return;

        const dateStr = `${appointmentForm.date}T${appointmentForm.time}:00`;
        const newDateIso = new Date(dateStr).toISOString();

        // Check for Right Usage context to log it
        let newTransactions = [...data.transactions];
        const isRightUsage = appointmentForm.note && appointmentForm.note.includes("Hak Kullanımı");

        if (editingApptId) {
            // Update existing
            const newData = {
                ...data,
                appointments: data.appointments.map(app =>
                    app.id === editingApptId
                        ? { ...app, date: newDateIso, note: appointmentForm.note }
                        : app
                ).sort((a, b) => new Date(a.date) - new Date(b.date))
            };
            setData(newData);
            onSave(newData); // Auto-save
            setEditingApptId(null);
        } else {
            // Create New
            const newAppt = {
                id: generateUUID(),
                date: newDateIso,
                note: appointmentForm.note,
                status: 'scheduled'
            };

            // Log creation if it's a Right Usage (for Patient Card visibility)
            if (isRightUsage) {
                newTransactions.unshift({
                    id: generateUUID(),
                    date: new Date().toISOString(), // Logged NOW, not at appointment time
                    type: 'appointment_created',
                    description: "Hak Kullanımı İçin Randevu Oluşturuldu: " + format(new Date(newDateIso), 'dd.MM.yyyy HH:mm'),
                    value: 0
                });
            }

            const newData = {
                ...data,
                transactions: newTransactions,
                appointments: [...data.appointments, newAppt].sort((a, b) => new Date(a.date) - new Date(b.date))
            };
            setData(newData);
            onSave(newData); // Auto-save
        }
        setAppointmentForm({ date: "", time: "09:00", note: "" });
    };

    const handleEditAppointment = (app) => {
        const dateObj = new Date(app.date);
        setAppointmentForm({
            date: format(dateObj, 'yyyy-MM-dd'),
            time: format(dateObj, 'HH:mm'),
            note: app.note || ""
        });
        setEditingApptId(app.id);
    };

    const handleCancelEdit = () => {
        setAppointmentForm({ date: "", time: "09:00", note: "" });
        setEditingApptId(null);
    };

    const handleCancelAppointment = (id) => {
        if (!window.confirm("Randevuyu iptal etmek istediğinize emin misiniz?")) return;

        const newData = {
            ...data,
            appointments: data.appointments.map(app =>
                app.id === id ? { ...app, status: 'cancelled' } : app
            )
        };

        setData(newData);
        onSave(newData); // Auto-save
    };

    const handleCompleteAppointment = (id) => {
        const app = data.appointments.find(a => a.id === id);
        if (!app) return;

        // Deduct right ONLY if it's a "Usage" appointment (detected by keyword or tag)
        // Keyword: "Hak Kullanımı" (Right Usage)
        let newTransactions = [...data.transactions];
        const isRightUsage = app.note && app.note.includes("Hak Kullanımı");

        if (isRightUsage) {
            // Check if already deducted? (Logic might be complex, but for now assuming simple flow)
            // Create transaction
            newTransactions.unshift({
                id: generateUUID(),
                date: new Date().toISOString(),
                type: 'use_right',
                description: "Tamamlanan Randevu: " + app.note,
                value: 0
            });
        }

        const newData = {
            ...data,
            appointments: data.appointments.map(a =>
                a.id === id ? { ...a, status: 'completed' } : a
            ),
            transactions: newTransactions,
            freeRights: calculateBalance(newTransactions)
        };

        setData(newData);
        onSave(newData);
    };

    const handleDeleteTransaction = (id) => {
        const transaction = data.transactions.find(t => t.id === id);
        if (!transaction) return;

        if (!window.confirm("Bu işlem kaydını silmek istediğinize emin misiniz?")) return;

        const newTransactions = data.transactions.filter(t => t.id !== id);

        const newData = {
            ...data,
            freeRights: calculateBalance(newTransactions),
            transactions: newTransactions
        };

        setData(newData);
        onSave(newData); // Auto-save
    }


    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-300 overflow-y-auto">
            <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-2xl shadow-2xl w-full max-w-5xl my-8 flex flex-col h-[85vh] border border-white/20 dark:border-slate-700 animate-in zoom-in-95 duration-200">

                {/* Header */}
                <div className="px-6 py-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 flex items-center justify-between flex-shrink-0">
                    <div>
                        <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                            <div className="p-2 bg-teal-100 dark:bg-teal-900/30 text-teal-600 dark:text-teal-400 rounded-lg">
                                <Shield size={20} />
                            </div>
                            Cilt Bakım Takibi
                        </h3>
                        <p className="text-sm font-medium text-slate-500 dark:text-slate-400 mt-0.5 ml-1">Bakım hakları, işlemler ve randevular.</p>
                    </div>
                    <button
                        onClick={onClose}
                        className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
                    >
                        <X size={24} />
                    </button>
                </div>

                {/* Tabs */}
                <div className="flex border-b border-slate-100 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 px-6 gap-6">
                    <button
                        onClick={() => setActiveTab('overview')}
                        className={cn("px-4 py-4 text-sm font-bold border-b-2 transition-all flex items-center gap-2", activeTab === 'overview' ? "border-teal-500 text-teal-600 dark:text-teal-400" : "border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:border-slate-200")}
                    >
                        <Award size={18} /> Genel Bakış & İşlemler
                    </button>
                    <button
                        onClick={() => setActiveTab('history')}
                        className={cn("px-4 py-4 text-sm font-bold border-b-2 transition-all flex items-center gap-2", activeTab === 'history' ? "border-teal-500 text-teal-600 dark:text-teal-400" : "border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:border-slate-200")}
                    >
                        <History size={18} /> İşlem Geçmişi
                    </button>
                    <button
                        onClick={() => setActiveTab('appointments')}
                        className={cn("px-4 py-4 text-sm font-bold border-b-2 transition-all flex items-center gap-2", activeTab === 'appointments' ? "border-teal-500 text-teal-600 dark:text-teal-400" : "border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:border-slate-200")}
                    >
                        <Calendar size={18} /> Randevular
                    </button>
                </div>

                {/* Content */}
                <div className="p-6 overflow-y-auto custom-scrollbar flex-1 bg-slate-50 dark:bg-slate-900/50">

                    {/* --- Overview Tab --- */}
                    {activeTab === 'overview' && (
                        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                            {/* Stats Card */}
                            <div className="bg-gradient-to-br from-teal-500 via-teal-600 to-emerald-600 dark:from-teal-600 dark:via-teal-700 dark:to-emerald-800 rounded-2xl p-8 text-white text-center shadow-xl shadow-teal-500/20 transform transition-all hover:scale-[1.01] relative overflow-hidden group">
                                <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity duration-300 pointer-events-none">
                                    <Shield size={120} />
                                </div>
                                <h4 className="text-lg font-medium opacity-90 mb-3 uppercase tracking-wider">Kalan Ücretsiz Bakım Hakkı</h4>
                                <div className="text-6xl font-black tracking-tighter drop-shadow-sm">{data.freeRights}</div>
                                <div className="mt-3 inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full text-sm font-medium border border-white/10">
                                    <Check size={14} className="text-white" />
                                    <span>Aktif ve Kullanılabilir</span>
                                </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {/* Add Right Form */}
                                <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm relative overflow-hidden group hover:shadow-md transition-all">
                                    <div className="absolute top-0 right-0 w-24 h-24 bg-teal-50 dark:bg-teal-900/20 rounded-bl-[100px] -mr-4 -mt-4 transition-all group-hover:scale-110"></div>
                                    <h4 className="font-bold text-slate-800 dark:text-white mb-5 flex items-center gap-3 relative z-10">
                                        <div className="bg-teal-100 dark:bg-teal-900/30 text-teal-600 dark:text-teal-400 p-2 rounded-lg">
                                            <Plus size={20} />
                                        </div>
                                        Hak Tanımla
                                    </h4>
                                    <form onSubmit={handleAddRight} className="space-y-4 relative z-10">
                                        <div>
                                            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 uppercase tracking-wide">Adet</label>
                                            <input
                                                type="number"
                                                min="1"
                                                className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white border px-4 py-3 text-sm focus:ring-teal-500 focus:border-teal-500 shadow-sm transition-all"
                                                value={rightForm.amount}
                                                onChange={e => setRightForm({ ...rightForm, amount: e.target.value })}
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2 uppercase tracking-wide">Açıklama / Sebep</label>

                                            {/* Quick Actions Toolbar */}
                                            <div className="flex flex-wrap items-center gap-2 mb-3">
                                                <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-700/50 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-600 hover:border-teal-300 dark:hover:border-teal-500 transition-colors w-full sm:w-auto">
                                                    <input
                                                        type="number"
                                                        className="w-20 text-sm px-2 py-1 border border-slate-300 dark:border-slate-500 rounded-lg focus:outline-none focus:border-teal-500 bg-white dark:bg-slate-600 text-slate-900 dark:text-white"
                                                        value={customAmount}
                                                        onChange={(e) => setCustomAmount(e.target.value)}
                                                        placeholder="Tutar"
                                                    />
                                                    <span className="text-xs font-bold text-slate-600 dark:text-slate-300">TL Alım</span>
                                                    <button
                                                        type="button"
                                                        onClick={() => {
                                                            if (!customAmount) return;
                                                            const text = `${customAmount} TL Alım`;
                                                            setRightForm(prev => ({
                                                                ...prev,
                                                                reason: prev.reason ? `${prev.reason} ${text}` : text
                                                            }));
                                                        }}
                                                        className="ml-auto p-1.5 bg-teal-100 dark:bg-teal-900/40 text-teal-700 dark:text-teal-300 rounded-lg hover:bg-teal-200 dark:hover:bg-teal-900/60 transition-colors"
                                                        title="Ekle"
                                                    >
                                                        <Plus size={14} strokeWidth={3} />
                                                    </button>
                                                </div>

                                                <button
                                                    type="button"
                                                    onClick={() => {
                                                        try {
                                                            dateInputRef.current?.showPicker();
                                                        } catch (err) {
                                                            dateInputRef.current?.focus();
                                                        }
                                                    }}
                                                    className="flex items-center gap-2 cursor-pointer bg-slate-50 dark:bg-slate-700/50 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-600 hover:border-teal-300 dark:hover:border-teal-500 hover:bg-teal-50/50 dark:hover:bg-teal-900/20 transition-all group w-full sm:w-auto justify-center sm:justify-start"
                                                >
                                                    <Calendar size={16} className="text-slate-500 dark:text-slate-400 group-hover:text-teal-600 dark:group-hover:text-teal-400" />
                                                    <span className="text-xs font-bold text-slate-600 dark:text-slate-300 group-hover:text-teal-700 dark:group-hover:text-teal-400">Tarih Ekle</span>
                                                    <input
                                                        ref={dateInputRef}
                                                        type="date"
                                                        className="sr-only"
                                                        onChange={(e) => {
                                                            if (e.target.value) {
                                                                const date = new Date(e.target.value);
                                                                const formattedDate = format(date, 'dd.MM.yyyy');
                                                                setRightForm(prev => ({
                                                                    ...prev,
                                                                    reason: prev.reason ? `${prev.reason} - ${formattedDate}` : formattedDate
                                                                }));
                                                                e.target.value = '';
                                                            }
                                                        }}
                                                    />
                                                </button>
                                            </div>

                                            <input
                                                type="text"
                                                placeholder="Örn: 5000TL Alışveriş Hediyesi"
                                                required
                                                className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white border px-4 py-3 text-sm focus:ring-teal-500 focus:border-teal-500 shadow-sm transition-all"
                                                value={rightForm.reason}
                                                onChange={e => setRightForm({ ...rightForm, reason: e.target.value })}
                                            />
                                        </div>
                                        <button type="submit" className="w-full bg-slate-800 dark:bg-slate-700 text-white py-3.5 rounded-xl text-sm font-bold hover:bg-slate-900 dark:hover:bg-slate-600 transition-all shadow-lg shadow-slate-200 dark:shadow-none hover:shadow-xl active:scale-[0.98]">
                                            Hakkı Ekle
                                        </button>
                                    </form>
                                </div>

                                {/* Add Service Form */}
                                <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm relative overflow-hidden group hover:shadow-md transition-all">
                                    <div className="absolute top-0 right-0 w-24 h-24 bg-pink-50 dark:bg-pink-900/20 rounded-bl-[100px] -mr-4 -mt-4 transition-all group-hover:scale-110"></div>
                                    <h4 className="font-bold text-slate-800 dark:text-white mb-5 flex items-center gap-3 relative z-10">
                                        <div className="bg-pink-100 dark:bg-pink-900/30 text-pink-600 dark:text-pink-400 p-2 rounded-lg">
                                            <Heart size={20} />
                                        </div>
                                        Bakım Yap / İşle
                                    </h4>
                                    <form onSubmit={handleAddService} className="space-y-4 relative z-10">
                                        <div className="flex bg-slate-100 dark:bg-slate-700 p-1.5 rounded-xl">
                                            <button
                                                type="button"
                                                onClick={() => setServiceForm({ ...serviceForm, type: 'usage' })}
                                                className={cn("flex-1 text-xs font-bold py-2.5 rounded-lg transition-all", serviceForm.type === 'usage' ? "bg-white dark:bg-slate-600 shadow-md text-slate-800 dark:text-white" : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200")}
                                            >
                                                Ücretsiz Hak
                                            </button>
                                            <button
                                                type="button"
                                                onClick={() => setServiceForm({ ...serviceForm, type: 'paid' })}
                                                className={cn("flex-1 text-xs font-bold py-2.5 rounded-lg transition-all", serviceForm.type === 'paid' ? "bg-white dark:bg-slate-600 shadow-md text-slate-800 dark:text-white" : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200")}
                                            >
                                                Ücretli İşlem
                                            </button>
                                        </div>

                                        <div>
                                            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 uppercase tracking-wide">Yapılan İşlem</label>
                                            <input
                                                type="text"
                                                placeholder="Örn: Klasik Cilt Bakımı"
                                                className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white border px-4 py-3 text-sm focus:ring-teal-500 focus:border-teal-500 shadow-sm transition-all"
                                                value={serviceForm.description}
                                                onChange={e => setServiceForm({ ...serviceForm, description: e.target.value })}
                                            />
                                        </div>

                                        {serviceForm.type === 'paid' && (
                                            <div className="animate-in slide-in-from-top-2 duration-200">
                                                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 uppercase tracking-wide">Ücret (TL)</label>
                                                <input
                                                    type="number"
                                                    min="0"
                                                    placeholder="0"
                                                    className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white border px-4 py-3 text-sm focus:ring-teal-500 focus:border-teal-500 shadow-sm transition-all"
                                                    value={serviceForm.amount}
                                                    onChange={e => setServiceForm({ ...serviceForm, amount: e.target.value })}
                                                />
                                            </div>
                                        )}

                                        <button
                                            type="submit"
                                            className={cn("w-full py-3.5 rounded-xl text-sm font-bold transition-all shadow-lg hover:shadow-xl active:scale-[0.98] text-white flex items-center justify-center gap-2", serviceForm.type === 'usage' ? "bg-teal-600 hover:bg-teal-700 shadow-teal-500/20" : "bg-pink-600 hover:bg-pink-700 shadow-pink-500/20")}
                                        >
                                            {serviceForm.type === 'usage' ? <><Calendar size={18} /> Hakkı Kullan ve Randevu Ver</> : <><Calendar size={18} /> Ücretli İşlem Randevu Ver</>}
                                        </button>
                                    </form>
                                </div>
                            </div>

                            {/* Visual Recent Transactions */}
                            {data.transactions.length > 0 && (
                                <div className="mt-8 border-t border-slate-100 dark:border-slate-800 pt-6">
                                    <h4 className="font-bold text-slate-800 dark:text-slate-200 mb-4 flex items-center justify-between">
                                        <span className="flex items-center gap-2"><Clock size={18} className="text-slate-400" /> Son İşlemler</span>
                                        <button
                                            onClick={() => setActiveTab('history')}
                                            className="text-xs font-bold text-teal-600 dark:text-teal-400 hover:text-teal-700 dark:hover:text-teal-300 bg-teal-50 dark:bg-teal-900/20 px-3 py-1.5 rounded-lg transition-colors"
                                        >
                                            Tüm Geçmişi Gör
                                        </button>
                                    </h4>
                                    <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700 overflow-hidden shadow-sm">
                                        <table className="w-full text-sm text-left">
                                            <tbody className="divide-y divide-slate-100 dark:divide-slate-700">
                                                {data.transactions.slice(0, 3).map(t => (
                                                    <tr key={t.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
                                                        <td className="px-5 py-4 text-slate-500 dark:text-slate-400 text-xs w-36 font-medium bg-slate-50/50 dark:bg-slate-800/50">
                                                            {format(new Date(t.date), 'dd.MM HH:mm', { locale: tr })}
                                                        </td>
                                                        <td className="px-5 py-4 text-slate-700 dark:text-slate-300 font-medium">
                                                            <div className="flex items-center gap-2">
                                                                <div className={cn("w-2 h-2 rounded-full",
                                                                    t.type === 'add_right' ? "bg-teal-500" :
                                                                        t.type === 'use_right' ? "bg-amber-500" :
                                                                            t.type === 'paid_service' ? "bg-pink-500" : "bg-blue-500"
                                                                )}></div>
                                                                {t.description}
                                                            </div>
                                                        </td>
                                                        <td className="px-5 py-4 text-slate-600 dark:text-slate-400 text-right w-32 font-bold">
                                                            {t.type === 'add_right' ? <span className="text-teal-600">+{t.value} Adet</span> :
                                                                t.type === 'use_right' ? <span className="text-amber-600">-1 Adet</span> :
                                                                    t.type === 'paid_service' ? <span className="text-pink-600">{t.amount}₺</span> :
                                                                        <span className="text-blue-600">Hak Kullanımı</span>}
                                                        </td>
                                                        <td className="px-4 py-4 w-12 text-right">
                                                            <button
                                                                onClick={() => handleDeleteTransaction(t.id)}
                                                                className="text-slate-300 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 p-2 rounded-lg transition-all"
                                                                title="Sil ve Geri Al"
                                                            >
                                                                <Trash2 size={16} />
                                                            </button>
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            )}

                        </div>
                    )}

                    {/* --- History Tab --- */}
                    {activeTab === 'history' && (
                        <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 overflow-hidden shadow-sm animate-in fade-in slide-in-from-bottom-4 duration-500">
                            {data.transactions.length > 0 ? (
                                <table className="w-full text-sm text-left">
                                    <thead className="bg-slate-50/80 dark:bg-slate-700/80 text-slate-500 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-600 backdrop-blur-sm">
                                        <tr>
                                            <th className="px-5 py-4">Tarih</th>
                                            <th className="px-5 py-4">İşlem Tipi</th>
                                            <th className="px-5 py-4">Açıklama</th>
                                            <th className="px-5 py-4 text-right">Değer</th>
                                            <th className="px-5 py-4 w-12 text-right"></th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-100 dark:divide-slate-700">
                                        {data.transactions.map(t => (
                                            <tr key={t.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors group">
                                                <td className="px-5 py-4 text-slate-500 dark:text-slate-400 font-medium whitespace-nowrap bg-slate-50/30 dark:bg-slate-800/30">
                                                    {format(new Date(t.date), 'dd.MM.yyyy HH:mm', { locale: tr })}
                                                </td>
                                                <td className="px-5 py-4">
                                                    <span className={cn("px-2.5 py-1 rounded-lg text-xs font-bold inline-flex items-center gap-1.5 shadow-sm border",
                                                        t.type === 'add_right' ? "bg-teal-50 dark:bg-teal-900/20 text-teal-700 dark:text-teal-300 border-teal-100 dark:border-teal-800" :
                                                            t.type === 'use_right' ? "bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-300 border-amber-100 dark:border-amber-800" :
                                                                t.type === 'paid_service' ? "bg-pink-50 dark:bg-pink-900/20 text-pink-700 dark:text-pink-300 border-pink-100 dark:border-pink-800" :
                                                                    "bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 border-blue-100 dark:border-blue-800"
                                                    )}>
                                                        <div className={cn("w-1.5 h-1.5 rounded-full",
                                                            t.type === 'add_right' ? "bg-teal-500" :
                                                                t.type === 'use_right' ? "bg-amber-500" :
                                                                    t.type === 'paid_service' ? "bg-pink-500" : "bg-blue-500"
                                                        )}></div>
                                                        {t.type === 'add_right' ? 'Hak Tanımlama' :
                                                            t.type === 'use_right' ? 'Hak Kullanımı' :
                                                                t.type === 'paid_service' ? 'Ücretli İşlem' : 'Hak Kullanımı (Randevu)'}
                                                    </span>
                                                </td>
                                                <td className="px-5 py-4 text-slate-700 dark:text-slate-200 font-medium">{t.description}</td>
                                                <td className="px-5 py-4 text-right font-bold">
                                                    {t.type === 'add_right' ? <span className="text-teal-600 dark:text-teal-400">+{t.value} Adet</span> :
                                                        t.type === 'use_right' ? <span className="text-amber-600 dark:text-amber-400">-1 Adet</span> :
                                                            t.type === 'paid_service' ? <span className="text-pink-600 dark:text-pink-400">{t.amount}₺</span> :
                                                                <span className="text-blue-600 dark:text-blue-400">Hak Kullanımı</span>}
                                                </td>
                                                <td className="px-4 py-4 text-right">
                                                    <button
                                                        onClick={() => handleDeleteTransaction(t.id)}
                                                        className="text-slate-300 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 p-2 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                                                        title="İşlemi Sil ve Etkisini Geri Al"
                                                    >
                                                        <Trash2 size={16} />
                                                    </button>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            ) : (
                                <div className="p-12 flex flex-col items-center justify-center text-center">
                                    <div className="bg-slate-50 dark:bg-slate-700/50 p-4 rounded-full mb-4">
                                        <History size={32} className="text-slate-400 dark:text-slate-500" />
                                    </div>
                                    <h5 className="text-sm font-bold text-slate-800 dark:text-white mb-1">İşlem Kaydı Bulunamadı</h5>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">Bu danışan için henüz herhangi bir işlem geçmişi yok.</p>
                                </div>
                            )}
                        </div>
                    )}

                    {/* --- Appointments Tab --- */}
                    {activeTab === 'appointments' && (
                        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                            {/* Add Appointment */}
                            <div className={cn("p-5 rounded-2xl border flex flex-wrap items-end gap-4 shadow-sm transition-all",
                                editingApptId ? "bg-amber-50 dark:bg-amber-900/10 border-amber-200 dark:border-amber-800" : "bg-white dark:bg-slate-800 border-slate-100 dark:border-slate-700"
                            )}>
                                <div className="flex-1 min-w-[150px]">
                                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 uppercase tracking-wide">Tarih</label>
                                    <input
                                        type="date"
                                        className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white border px-4 py-3 text-sm focus:ring-teal-500 focus:border-teal-500 shadow-sm transition-all"
                                        value={appointmentForm.date}
                                        onChange={e => setAppointmentForm({ ...appointmentForm, date: e.target.value })}
                                    />
                                </div>
                                <div className="w-32">
                                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 uppercase tracking-wide">Saat</label>
                                    <input
                                        type="time"
                                        className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white border px-4 py-3 text-sm focus:ring-teal-500 focus:border-teal-500 shadow-sm transition-all"
                                        value={appointmentForm.time}
                                        onChange={e => setAppointmentForm({ ...appointmentForm, time: e.target.value })}
                                    />
                                </div>
                                <div className="flex-[2] min-w-[200px]">
                                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 uppercase tracking-wide">Not / İşlem</label>
                                    <input
                                        type="text"
                                        placeholder="Örn: Cilt Bakımı Randevusu"
                                        className="w-full rounded-xl border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-900 dark:text-white border px-4 py-3 text-sm focus:ring-teal-500 focus:border-teal-500 shadow-sm transition-all"
                                        value={appointmentForm.note}
                                        onChange={e => setAppointmentForm({ ...appointmentForm, note: e.target.value })}
                                    />
                                </div>
                                <div className="flex items-center gap-2 w-full sm:w-auto">
                                    {editingApptId && (
                                        <button
                                            onClick={handleCancelEdit}
                                            className="bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 px-4 py-3.5 rounded-xl text-sm font-bold hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors"
                                        >
                                            İptal
                                        </button>
                                    )}
                                    <button
                                        onClick={handleAddAppointment}
                                        className={cn("px-6 py-3.5 rounded-xl text-sm font-bold transition-all flex items-center justify-center gap-2 text-white shadow-lg flex-1 sm:flex-auto hover:shadow-xl active:scale-95",
                                            editingApptId ? "bg-amber-500 hover:bg-amber-600 shadow-amber-500/20" : "bg-teal-600 hover:bg-teal-700 shadow-teal-500/20"
                                        )}
                                    >
                                        {editingApptId ? <Check size={18} strokeWidth={2.5} /> : <Plus size={18} strokeWidth={2.5} />}
                                        {editingApptId ? "Güncelle" : "Randevu Ekle"}
                                    </button>
                                </div>
                            </div>

                            {/* List */}
                            <div className="space-y-3">
                                {data.appointments.length > 0 ? (
                                    data.appointments.map(app => (
                                        <div key={app.id} className={cn("bg-white dark:bg-slate-800 p-4 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between shadow-sm hover:shadow-md transition-all gap-4 group",
                                            app.status === 'cancelled' ? "border-slate-100 dark:border-slate-800 opacity-60 bg-slate-50 dark:bg-slate-800/50" :
                                                app.status === 'completed' ? "border-green-100 dark:border-green-900 bg-green-50/20 dark:bg-green-900/10" : "border-slate-100 dark:border-slate-700"
                                        )}>
                                            <div className="flex items-center gap-4 w-full sm:w-auto">
                                                <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 shadow-sm",
                                                    app.status === 'scheduled' ? "bg-teal-100 dark:bg-teal-900/30 text-teal-600 dark:text-teal-400" :
                                                        app.status === 'completed' ? "bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400" : "bg-slate-100 dark:bg-slate-700 text-slate-400"
                                                )}>
                                                    <Calendar size={22} />
                                                </div>
                                                <div className="flex-1">
                                                    <div className="flex flex-wrap items-center gap-2 mb-1">
                                                        <span className="font-bold text-slate-800 dark:text-slate-200 text-lg">
                                                            {format(new Date(app.date), 'dd MMMM yyyy', { locale: tr })}
                                                        </span>
                                                        <span className="font-semibold text-slate-500 dark:text-slate-400">
                                                            {format(new Date(app.date), 'HH:mm', { locale: tr })}
                                                        </span>
                                                        {app.status === 'cancelled' && <span className="text-[10px] font-bold uppercase tracking-wider bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded-full border border-slate-200 dark:border-slate-600">İptal</span>}
                                                        {app.status === 'completed' && <span className="text-[10px] font-bold uppercase tracking-wider bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 px-2 py-0.5 rounded-full border border-green-200 dark:border-green-800">Tamamlandı</span>}
                                                    </div>
                                                    <p className="text-sm text-slate-600 dark:text-slate-300 font-medium line-clamp-1">{app.note}</p>
                                                </div>
                                            </div>

                                            <div className="flex items-center gap-2 w-full sm:w-auto justify-end border-t sm:border-t-0 pt-3 sm:pt-0 border-slate-100 dark:border-slate-700">
                                                {app.status === 'scheduled' ? (
                                                    <>
                                                        <button
                                                            onClick={() => handleEditAppointment(app)}
                                                            className="p-2.5 text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-900/20 rounded-xl transition-all hover:scale-105 active:scale-95 bg-amber-50/50 dark:bg-amber-900/10 border border-transparent hover:border-amber-200"
                                                            title="Düzenle"
                                                        >
                                                            <Pencil size={18} />
                                                        </button>
                                                        <button
                                                            onClick={() => handleCompleteAppointment(app.id)}
                                                            className="p-2.5 text-green-600 hover:bg-green-50 dark:hover:bg-green-900/20 rounded-xl transition-all hover:scale-105 active:scale-95 bg-green-50/50 dark:bg-green-900/10 border border-transparent hover:border-green-200"
                                                            title="Tamamlandı İşaretle"
                                                        >
                                                            <Check size={18} strokeWidth={2.5} />
                                                        </button>
                                                        <button
                                                            onClick={() => handleCancelAppointment(app.id)}
                                                            className="p-2.5 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition-all hover:scale-105 active:scale-95 bg-red-50/50 dark:bg-red-900/10 border border-transparent hover:border-red-200"
                                                            title="İptal Et"
                                                        >
                                                            <X size={18} strokeWidth={2.5} />
                                                        </button>
                                                    </>
                                                ) : (
                                                    <button
                                                        onClick={() => {
                                                            if (window.confirm("Bu randevu kaydını tamamen silmek istediğinize emin misiniz?")) {
                                                                const newData = {
                                                                    ...data,
                                                                    appointments: data.appointments.filter(a => a.id !== app.id)
                                                                };
                                                                setData(newData);
                                                                onSave(newData); // Auto-save
                                                            }
                                                        }}
                                                        className="p-2.5 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition-all opacity-0 group-hover:opacity-100"
                                                        title="Listeden Tamamen Sil"
                                                    >
                                                        <Trash2 size={18} />
                                                    </button>
                                                )}
                                            </div>
                                        </div>
                                    ))
                                ) : (
                                    <div className="p-12 flex flex-col items-center justify-center text-center">
                                        <div className="bg-slate-50 dark:bg-slate-700/50 p-4 rounded-full mb-4">
                                            <Calendar size={32} className="text-slate-400 dark:text-slate-500" />
                                        </div>
                                        <h5 className="text-sm font-bold text-slate-800 dark:text-white mb-1">Planlanmış Randevu Yok</h5>
                                        <p className="text-xs text-slate-500 dark:text-slate-400">Yeni bir randevu eklemek için üstteki formu kullanabilirsiniz.</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    )}
                </div>

                {/* Footer */}
                <div className="px-6 py-5 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 flex justify-end gap-3 flex-shrink-0 rounded-b-2xl">
                    <button
                        onClick={onClose}
                        className="px-6 py-3 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold hover:bg-slate-200 dark:hover:bg-slate-600 rounded-xl transition-colors"
                    >
                        Kapat
                    </button>
                </div>
            </div>
        </div>
    );
}
