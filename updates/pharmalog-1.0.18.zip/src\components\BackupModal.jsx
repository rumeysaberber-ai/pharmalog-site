import { useState, useRef } from "react";
import { Download, Upload, AlertTriangle, CheckCircle, X, ShieldCheck } from "lucide-react";
import { DataService } from "../lib/data";

export default function BackupModal({ isOpen, onClose }) {
    const [isRestoring, setIsRestoring] = useState(false);
    const fileInputRef = useRef(null);

    const handleDownloadBackup = async () => {
        try {
            const token = localStorage.getItem('token');
            const response = await fetch('/api/backup', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Yedek indirilemedi");
            }

            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'dermasoft_yedek.json';
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        } catch (error) {
            console.error("Backup download error:", error);
            alert("Yedek indirme başarısız: " + error.message);
        }
    };

    const handleRestoreBackup = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        if (!window.confirm("DİKKAT! Yedekten geri yükleme yaptığınızda mevcut verilerin üzerine yazılacaktır. Bu işlem geri alınamaz.\n\nDevam etmek istiyor musunuz?")) {
            e.target.value = null;
            return;
        }

        setIsRestoring(true);
        const formData = new FormData();
        formData.append('backupFile', file);

        try {
            const response = await fetch('/api/restore', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (response.ok) {
                alert("Yedek başarıyla geri yüklendi! Sayfa yenilenecek.");
                window.location.reload();
            } else {
                alert("Hata: " + (result.error || "Bilinmeyen bir hata oluştu."));
            }
        } catch (error) {
            console.error("Restore error:", error);
            alert("Sunucuya bağlanılamadı.");
        } finally {
            setIsRestoring(false);
            e.target.value = null;
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden">
                <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
                    <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                        <ShieldCheck className="text-teal-600" size={24} />
                        Sistem Yedekleme
                    </h3>
                    <button onClick={onClose} className="text-slate-400 hover:text-slate-600 hover:bg-slate-100 p-1 rounded-full transition-colors">
                        <X size={20} />
                    </button>
                </div>

                <div className="p-6 space-y-8">
                    {/* Backup Section */}
                    <div className="bg-teal-50 border border-teal-100 rounded-xl p-5">
                        <div className="flex items-start gap-4">
                            <div className="bg-white p-2 rounded-lg text-teal-600 shadow-sm">
                                <Download size={24} />
                            </div>
                            <div className="flex-1">
                                <h4 className="font-semibold text-teal-900">Veri Yedeği Al</h4>
                                <p className="text-sm text-teal-700 mt-1">
                                    Tüm danışan kayıtlarını ve ürün veritabanını bilgisayarınıza `.json` dosyası olarak indirin.
                                </p>
                                <button
                                    onClick={handleDownloadBackup}
                                    className="mt-4 bg-teal-600 hover:bg-teal-700 text-white px-4 py-2 rounded-lg font-medium text-sm transition-colors shadow-sm inline-flex items-center gap-2"
                                >
                                    <Download size={16} />
                                    Yedeği İndir
                                </button>
                            </div>
                        </div>
                    </div>

                    {/* Restore Section */}
                    <div className="bg-amber-50 border border-amber-100 rounded-xl p-5">
                        <div className="flex items-start gap-4">
                            <div className="bg-white p-2 rounded-lg text-amber-600 shadow-sm">
                                <Upload size={24} />
                            </div>
                            <div className="flex-1">
                                <h4 className="font-semibold text-amber-900">Yedeği Geri Yükle</h4>
                                <p className="text-sm text-amber-700 mt-1">
                                    Daha önce aldığınız bir yedek dosyasını yükleyerek verileri geri getirin.
                                    <span className="block mt-1 font-bold flex items-center gap-1">
                                        <AlertTriangle size={12} />
                                        Mevcut veriler silinecektir!
                                    </span>
                                </p>

                                <input
                                    type="file"
                                    ref={fileInputRef}
                                    accept=".json"
                                    onChange={handleRestoreBackup}
                                    className="hidden"
                                />

                                <button
                                    onClick={() => fileInputRef.current.click()}
                                    disabled={isRestoring}
                                    className="mt-4 bg-white border border-amber-200 text-amber-800 hover:bg-amber-100 px-4 py-2 rounded-lg font-medium text-sm transition-colors shadow-sm inline-flex items-center gap-2"
                                >
                                    {isRestoring ? (
                                        <>Yükleniyor...</>
                                    ) : (
                                        <>
                                            <Upload size={16} />
                                            Yedek Dosyası Seç
                                        </>
                                    )}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 text-center text-xs text-slate-400">
                    Olası bir bilgisayar arızasına karşı düzenli yedek almanız önerilir.
                </div>
            </div>
        </div>
    );
}
