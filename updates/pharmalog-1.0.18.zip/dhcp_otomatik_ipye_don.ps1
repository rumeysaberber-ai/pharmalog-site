$ErrorActionPreference = "Stop"

function Test-Admin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-Admin)) {
    Write-Host "Bu islem yonetici yetkisi gerektirir. Yonetici olarak tekrar aciliyor..."
    Start-Process -FilePath "powershell.exe" -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

$config = Get-NetIPConfiguration |
    Where-Object {
        $_.IPv4Address -and
        $_.NetAdapter.Status -eq "Up" -and
        $_.IPv4Address.IPAddress -notlike "169.254.*"
    } |
    Select-Object -First 1

if (-not $config) {
    throw "Aktif ag baglantisi bulunamadi."
}

$adapterName = $config.InterfaceAlias
Write-Host "Ag baglantisi otomatik IP moduna aliniyor: $adapterName"

netsh interface ipv4 set address name="$adapterName" dhcp | Out-Host
netsh interface ipv4 set dnsservers name="$adapterName" dhcp | Out-Host

Write-Host ""
Write-Host "TAMAMLANDI. Windows IP adresini modemden otomatik alacak."
