import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Calendar, Clock, User, Phone, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { format, parseISO, addMinutes } from 'date-fns';
import { tr } from 'date-fns/locale';

export default function PublicBooking() {
    const { companyId, eventId } = useParams();
    const [event, setEvent] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [success, setSuccess] = useState(false);

    const [selectedSlot, setSelectedSlot] = useState(null);
    const [form, setForm] = useState({ fullName: '', phone: '' });
    const [submitting, setSubmitting] = useState(false);

    useEffect(() => {
        fetchEvent();
    }, [companyId, eventId]);

    const fetchEvent = async () => {
        try {
            // Use relative path to leverage Vite proxy in dev and same-origin in prod
            const res = await fetch(`/api/public/events/${companyId}/${eventId}`);
            if (!res.ok) throw new Error("Etkinlik bulunamadı.");
            const data = await res.json();
            setEvent(data);
        } catch (err) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    const generateSlots = () => {
        if (!event) return [];
        const slots = [];
        const start = parseISO(`2000-01-01T${event.startHour}`);
        const end = parseISO(`2000-01-01T${event.endHour}`);
        const duration = parseInt(event.slotDuration) || 30;

        let current = start;
        while (current < end) {
            const timeStr = format(current, "HH:mm");
            const isTaken = event.busySlots?.includes(timeStr);
            slots.push({ time: timeStr, taken: isTaken });
            current = addMinutes(current, duration);
        }
        return slots;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!selectedSlot || !form.fullName || !form.phone) return;

        setSubmitting(true);
        try {
            const res = await fetch('/api/public/book', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    companyId,
                    eventId,
                    time: selectedSlot,
                    fullName: form.fullName,
                    phone: form.phone
                })
            });

            const data = await res.json();
            if (res.ok) {
                setSuccess(true);
            } else {
                console.error("Booking Error Detail:", data);
                alert(`${data.error}\n\nTeknik Detay: ${data.details || 'Yok'}`);
                // Refresh slots
                fetchEvent();
            }
        } catch (err) {
            console.error("Booking Network Error:", err);
            alert(`İşlem başarısız. Bağlantı hatası: ${err.message}`);
        } finally {
            setSubmitting(false);
        }
    };

    if (loading) return (
        <div className="min-h-screen bg-slate-50 flex items-center justify-center">
            <Loader2 className="h-10 w-10 text-teal-600 animate-spin" />
        </div>
    );

    if (error) return (
        <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
            <div className="bg-white p-8 rounded-2xl shadow-xl text-center max-w-md w-full">
                <AlertCircle className="h-16 w-16 text-red-500 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-slate-800 mb-2">Hata</h2>
                <p className="text-slate-600">{error}</p>
            </div>
        </div>
    );

    if (success) return (
        <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
            <div className="bg-white p-8 rounded-2xl shadow-xl text-center max-w-md w-full animate-in zoom-in duration-300">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <CheckCircle className="h-10 w-10 text-green-600" />
                </div>
                <h2 className="text-2xl font-bold text-slate-800 mb-2">Randevunuz Onaylandı!</h2>
                <p className="text-slate-600 mb-6">
                    Sayın <strong>{form.fullName}</strong>,<br />
                    <strong>{event.companyName}</strong> etkinliği için<br />
                    <strong>{format(parseISO(event.date), "d MMMM yyyy", { locale: tr })}</strong> saat <strong>{selectedSlot}</strong> randevunuz oluşturulmuştur.
                </p>
                <button
                    onClick={() => window.location.reload()}
                    className="text-teal-600 hover:text-teal-700 font-medium underline"
                >
                    Yeni Randevu Al
                </button>
            </div>
        </div>
    );

    const availableSlots = generateSlots();

    return (
        <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6 lg:px-8 font-jakarta">
            <div className="max-w-xl mx-auto">
                {/* Header */}
                <div className="text-center mb-10">
                    <h1 className="text-3xl font-bold text-slate-900 mb-2 uppercase">
                        {event.pharmacyName ? (
                            <>
                                {event.pharmacyName} <span className="text-teal-600">{event.companyName}</span> <span className="text-slate-500 text-2xl block mt-1">UZMAN GÜNÜ ETKİNLİĞİ</span>
                            </>
                        ) : (
                            event.companyName
                        )}
                    </h1>
                    <div className="inline-flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm text-slate-600 border border-slate-200">
                        <Calendar className="h-4 w-4 text-teal-500" />
                        <span className="font-medium">{format(parseISO(event.date), "d MMMM yyyy, EEEE", { locale: tr })}</span>
                    </div>
                </div>

                <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-100">
                    <div className="p-8">
                        <div className="flex items-center gap-3 mb-6">
                            <Clock className="h-6 w-6 text-teal-600" />
                            <h2 className="text-xl font-bold text-slate-800">
                                {selectedSlot ? "Bilgilerinizi Giriniz" : "Randevu Saati Seçiniz"}
                            </h2>
                        </div>

                        {!selectedSlot ? (
                            <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                                {availableSlots.map((slot) => (
                                    <button
                                        key={slot.time}
                                        disabled={slot.taken}
                                        onClick={() => setSelectedSlot(slot.time)}
                                        className={`
                                            py-3 px-2 rounded-xl text-sm font-bold transition-all duration-200 border
                                            ${slot.taken
                                                ? 'bg-slate-100 text-slate-400 border-transparent cursor-not-allowed decoration-slate-400 opacity-60'
                                                : 'bg-white text-slate-700 border-slate-200 hover:border-teal-500 hover:bg-teal-50 hover:text-teal-700 hover:shadow-md active:scale-95'
                                            }
                                        `}
                                    >
                                        {slot.time}
                                    </button>
                                ))}
                            </div>
                        ) : (
                            <form onSubmit={handleSubmit} className="space-y-6 animate-in slide-in-from-right duration-300">
                                <div className="bg-teal-50 p-4 rounded-2xl flex items-center justify-between border border-teal-100 mb-6">
                                    <div className="flex items-center gap-3">
                                        <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-teal-600 font-bold shadow-sm">
                                            {selectedSlot}
                                        </div>
                                        <div>
                                            <p className="text-xs text-teal-600 font-semibold uppercase tracking-wider">Seçilen Saat</p>
                                            <button
                                                type="button"
                                                onClick={() => setSelectedSlot(null)}
                                                className="text-xs text-teal-700 underline font-medium"
                                            >
                                                Değiştir
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div className="space-y-4">
                                    <div className="space-y-1">
                                        <label className="text-xs font-semibold text-slate-500 ml-1 uppercase">Ad Soyad</label>
                                        <div className="relative">
                                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                <User className="h-5 w-5 text-slate-400" />
                                            </div>
                                            <input
                                                type="text"
                                                required
                                                value={form.fullName}
                                                onChange={e => setForm({ ...form, fullName: e.target.value })}
                                                className="text-gray-900 block w-full pl-10 pr-3 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 outline-none transition-all placeholder-slate-400"
                                                placeholder="Adınız Soyadınız"
                                            />
                                        </div>
                                    </div>

                                    <div className="space-y-1">
                                        <label className="text-xs font-semibold text-slate-500 ml-1 uppercase">Telefon Numarası</label>
                                        <div className="relative">
                                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                <Phone className="h-5 w-5 text-slate-400" />
                                            </div>
                                            <input
                                                type="tel"
                                                required
                                                value={form.phone}
                                                onChange={e => setForm({ ...form, phone: e.target.value })}
                                                className="text-gray-900 block w-full pl-10 pr-3 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 outline-none transition-all placeholder-slate-400"
                                                placeholder="05XX XXX XX XX"
                                            />
                                        </div>
                                        <p className="text-xs text-slate-400 ml-1">Randevu hatırlatması için gereklidir.</p>
                                    </div>
                                </div>

                                <button
                                    type="submit"
                                    disabled={submitting}
                                    className="w-full flex items-center justify-center py-4 px-4 bg-teal-600 hover:bg-teal-700 text-white rounded-xl font-bold text-lg shadow-lg shadow-teal-600/20 transform hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-70 disabled:cursor-not-allowed"
                                >
                                    {submitting ? (
                                        <>
                                            <Loader2 className="animate-spin -ml-1 mr-2 h-5 w-5" />
                                            İşleniyor...
                                        </>
                                    ) : (
                                        'Randevuyu Onayla'
                                    )}
                                </button>
                            </form>
                        )}
                    </div>

                    {/* Footer */}
                    <div className="bg-slate-50 px-8 py-4 border-t border-slate-100 text-center">
                        <p className="text-xs text-slate-400">
                            © 2024 PharmaLog Randevu Sistemi
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
}
