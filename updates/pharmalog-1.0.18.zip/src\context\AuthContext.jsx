import React, { createContext, useContext, useState, useEffect } from 'react';
import { DataService } from '../lib/data';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [token, setToken] = useState(localStorage.getItem('token'));
    const [loading, setLoading] = useState(true);

    // Initial Check
    useEffect(() => {
        const initAuth = async () => {
            const storedToken = localStorage.getItem('token');
            if (storedToken) {
                try {
                    DataService.clearCache();
                    const res = await fetch('/api/check-auth', {
                        headers: {
                            'Authorization': `Bearer ${storedToken}`
                        }
                    });
                    const data = await res.json();
                    if (data.success) {
                        setUser(data.user);
                    } else {
                        logout();
                    }
                } catch (error) {
                    console.error("Auth check failed", error);
                    logout();
                }
            }
            setLoading(false);
        };
        initAuth();
    }, []);

    const login = async (username, password, rememberMe = true) => {
        try {
            const res = await fetch('/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password, rememberMe })
            });
            const data = await res.json();

            if (data.success) {
                DataService.clearCache();
                setToken(data.token);
                setUser(data.user);
                localStorage.setItem('token', data.token);
                localStorage.setItem('user_details', JSON.stringify(data.user)); // Persist for data.js
                return { success: true };
            } else {
                return { success: false, error: data.error };
            }
        } catch (error) {
            return { success: false, error: "Sunucu hatası." };
        }
    };

    const logout = () => {
        DataService.clearCache();
        setUser(null);
        setToken(null);
        localStorage.removeItem('token');
        localStorage.removeItem('user_details');

        // Notify server (optional)
        fetch('/api/logout', {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${token}` }
        }).catch(() => { });

        // We do NOT force a redirect here. 
        // 1. If the user is on a protected route, <RequireAuth> will detect user=null and redirect.
        // 2. If the user is on a public route, they should stay there (just logged out).
    };

    return (
        <AuthContext.Provider value={{ user, token, loading, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);
