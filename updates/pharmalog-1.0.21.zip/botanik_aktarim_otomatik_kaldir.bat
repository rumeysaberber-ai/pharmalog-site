@echo off
title Botanik Otomatik Aktarim Kaldir
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0botanik_aktarim_otomatik_kaldir.ps1"
pause
