$ErrorActionPreference = "Stop"

Write-Host "Botanik otomatik aktarim artik devre disi." -ForegroundColor Yellow
Write-Host "Aktarim sadece PharmaLog > Ayarlar > Botanik Satis Aktarimi ekranindan manuel yapilir." -ForegroundColor Cyan
Write-Host "Daha once kurulmus otomatik gorevi kaldirmak icin botanik_aktarim_otomatik_kaldir.bat calistirin." -ForegroundColor Cyan
