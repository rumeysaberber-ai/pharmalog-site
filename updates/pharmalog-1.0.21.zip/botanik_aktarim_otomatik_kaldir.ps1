$ErrorActionPreference = "Stop"

$taskName = "PharmaLog Botanik Otomatik Aktarim"

try {
    $task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    if ($task) {
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
        Write-Host "Botanik otomatik aktarim gorevi kaldirildi." -ForegroundColor Green
    } else {
        Write-Host "Botanik otomatik aktarim gorevi zaten yok." -ForegroundColor Yellow
    }
} catch {
    Write-Host "Botanik otomatik aktarim gorevi kaldirilamadi: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
