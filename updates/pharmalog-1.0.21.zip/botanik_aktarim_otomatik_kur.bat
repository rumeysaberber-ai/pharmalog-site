@echo off
title Botanik Otomatik Aktarim Devre Disi
echo.
echo Botanik otomatik aktarim artik kullanilmiyor.
echo Aktarim sadece PharmaLog ^> Ayarlar ^> Botanik Satis Aktarimi ekranindan manuel yapilir.
echo.
echo Daha once kurulmus otomatik gorevi kaldirmak icin botanik_aktarim_otomatik_kaldir.bat calistirin.
echo.
pause
