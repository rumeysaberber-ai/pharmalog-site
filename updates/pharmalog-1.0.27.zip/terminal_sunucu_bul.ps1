param(
    [string]$ConfigFile = (Join-Path $PSScriptRoot "terminal_adres.txt"),
    [int]$Port = 3001
)

$ErrorActionPreference = "Stop"

function Test-PharmaLogServer {
    param([string]$BaseUrl)

    try {
        $response = Invoke-RestMethod -Uri "$($BaseUrl.TrimEnd('/'))/api/health" -TimeoutSec 2 -UseBasicParsing
        return $response.ok -eq $true -and $response.service -eq "pharmalog"
    } catch {
        return $false
    }
}

function Save-AndReturnAddress {
    param([string]$Address)

    Set-Content -LiteralPath $ConfigFile -Value $Address -Encoding ASCII
    Write-Output $Address
    exit 0
}

# The saved address remains the fastest path while it is valid.
if (Test-Path -LiteralPath $ConfigFile) {
    $savedAddress = (Get-Content -LiteralPath $ConfigFile -Raw).Trim()
    if ($savedAddress -and (Test-PharmaLogServer -BaseUrl $savedAddress)) {
        Write-Output $savedAddress
        exit 0
    }
}

# Probe in small parallel batches. This stays fast but avoids creating hundreds
# of simultaneous sockets on older terminal computers.
$prefixes = Get-NetIPConfiguration |
    Where-Object {
        $_.NetAdapter.Status -eq "Up" -and
        $_.IPv4Address -and
        $_.IPv4DefaultGateway -and
        $_.IPv4Address.IPAddress -notlike "169.254.*"
    } |
    ForEach-Object {
        $parts = $_.IPv4Address.IPAddress.Split('.')
        if ($parts.Count -eq 4) { "$($parts[0]).$($parts[1]).$($parts[2])" }
    } |
    Sort-Object -Unique

foreach ($prefix in $prefixes) {
    for ($batchStart = 1; $batchStart -le 254; $batchStart += 64) {
        $batchEnd = [Math]::Min($batchStart + 63, 254)
        $probes = New-Object System.Collections.Generic.List[object]

        foreach ($lastOctet in $batchStart..$batchEnd) {
            $ip = "$prefix.$lastOctet"
            $client = New-Object System.Net.Sockets.TcpClient
            try {
                $async = $client.BeginConnect($ip, $Port, $null, $null)
                $probes.Add([pscustomobject]@{ Ip = $ip; Client = $client; Async = $async })
            } catch {
                $client.Dispose()
            }
        }

        if ($probes.Count -gt 0) {
            Start-Sleep -Milliseconds 500
        }

        foreach ($probe in $probes) {
            try {
                if ($probe.Async.IsCompleted -and $probe.Client.Connected) {
                    $probe.Client.EndConnect($probe.Async)
                    $candidate = "http://$($probe.Ip):$Port"
                    if (Test-PharmaLogServer -BaseUrl $candidate) {
                        foreach ($item in $probes) { $item.Client.Dispose() }
                        Save-AndReturnAddress -Address $candidate
                    }
                }
            } catch {
                # Another device may use the same port; it is simply not PharmaLog.
            } finally {
                $probe.Client.Dispose()
            }
        }
    }
}

exit 1
