@echo off
setlocal EnableDelayedExpansion
title PharmaLog Terminal
color 0B
cls

set "CONFIG_FILE=%~dp0terminal_adres.txt"
set "APP_URL="

echo.
echo Ana bilgisayar otomatik araniyor...
for /f "usebackq delims=" %%A in (`powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0terminal_sunucu_bul.ps1" -ConfigFile "%CONFIG_FILE%"`) do set "APP_URL=%%A"

if "%APP_URL%"=="" (
    echo.
    echo Ana bilgisayar otomatik bulunamadi.
    echo Adresi bir kez yazin; sonraki IP degisimlerinde otomatik aranir.
    echo Ornek: http://192.168.1.190:3001
    echo.
    set /p APP_URL=Adres: 
    if "!APP_URL!"=="" (
        echo Adres bos olamaz.
        pause
        exit /b 1
    )
    >"%CONFIG_FILE%" echo(!APP_URL!
)

if "%APP_URL%"=="" (
    echo Adres bos olamaz.
    pause
    exit /b 1
)

if exist "%~dp0botanik_yardimci_baslat.bat" (
    call "%~dp0botanik_yardimci_baslat.bat"
    powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "try { $r = Invoke-WebRequest -Uri 'http://127.0.0.1:3017/health' -UseBasicParsing -TimeoutSec 2; if ($r.StatusCode -eq 200) { exit 0 } else { exit 1 } } catch { exit 1 }"
    if !errorlevel! neq 0 (
        echo.
        echo [UYARI] Botanik yardimci servisi baslatilamadi.
        echo Botanik satis aktarimi calismazsa botanik_yardimci.err.log dosyasini kontrol edin.
        echo.
    )
)

echo.
echo Baglanti kontrol ediliyor: %APP_URL%
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "try { $r = Invoke-RestMethod -Uri '%APP_URL%/api/health' -UseBasicParsing -TimeoutSec 5; if ($r.ok -eq $true -and $r.service -eq 'pharmalog') { exit 0 } else { exit 1 } } catch { exit 1 }"
if %errorlevel% neq 0 (
    echo.
    echo [HATA] Ana bilgisayara baglanilamadi.
    echo.
    echo Kontrol edin:
    echo 1. Ana bilgisayarda "PharmaLog Ana Bilgisayar" acik mi?
    echo 2. Bu bilgisayar ayni Wi-Fi/agda mi?
    echo 3. Ana bilgisayar ve terminal ayni yerel agda mi?
    echo 4. Ana bilgisayarda Windows Guvenlik Duvari izin verdi mi?
    echo.
    echo Program sonraki acilista ana bilgisayari yeniden otomatik arayacaktir.
    pause
    exit /b 1
)

call "%~dp0pharmalog_app_ac.bat" "%APP_URL%"
